/**************************************************************************\
 * ResourceDefs.h                                                         *
 **************************************************************************
 * This file is assembled for use with mwbres source code files.          *
 **************************************************************************
 * Copyright © 1998 by Prodigal Software.  All rights reserved.           *
\**************************************************************************/

#ifdef PS_BRES_DEFINES_H
#else
#define PS_BRES_DEFINES_H

// values for BRES_APP_FLAGS flags:

#define BRES_APP_SINGLE_LAUNCH          0 // radio
#define BRES_APP_MULTIPLE_LAUNCH        1 //  ...
#define BRES_APP_EXCLUSIVE_LAUNCH       2 //  ...
#define BRES_APP_BACKGROUND             4 // optional
#define BRES_APP_ARGV_ONLY              8 // optional

// general types

enum ResourceTypes {
    BTYPE_MIME_STRING =                 'MIMS',
    BTYPE_MINI_ICON =                   'MICN',
    BTYPE_LARGE_ICON =                  'ICON'
};

// specific resources

#define BRES_APP_FLAGS_TYPE             'APPF'
#define BRES_APP_FLAGS_ID               1
#define BRES_APP_FLAGS_NAME             "BEOS:APP_FLAGS"

#define BRES_APP_SIG_TYPE               'MIMS' // BTYPE_MIME_STRING
#define BRES_APP_SIG_ID                 1
#define BRES_APP_SIG_NAME               "BEOS:APP_SIG"

#define BRES_APP_TYPE_TYPE              'MIMS' // BTYPE_MIME_STRING
#define BRES_APP_TYPE_ID                2
#define BRES_APP_TYPE_NAME              "BEOS:TYPE"

#define BRES_LARGE_ICON_TYPE            'ICON' // BTYPE_LARGE_ICON
#define BRES_LARGE_ICON_ID              101
#define BRES_LARGE_ICON_NAME            "BEOS:L:STD_ICON"
#define BRES_LARGE_ICON_SIZE            32

#define BRES_MINI_ICON_TYPE             'MICN' // BTYPE_MINI_ICON
#define BRES_MINI_ICON_ID               101
#define BRES_MINI_ICON_NAME             "BEOS:M:STD_ICON"
#define BRES_MINI_ICON_SIZE             16

#define BRES_FILE_TYPES_TYPE            'MSGG'
#define BRES_FILE_TYPES_ID              1
#define BRES_FILE_TYPES_NAME            "BEOS:FILE_TYPES"
// an archived message?  C string array of name "types" with mime strings?

#define BRES_APP_VERSION_TYPE           'APPV'
#define BRES_APP_VERSION_ID             1
#define BRES_APP_VERSION_NAME           "BEOS:APP_VERSION"
// my guess is:
//   version, subversion, subsubversion,
//   state, revision (compile num?),
//   short description [ 64 ]
//   long description [ 256? ]
//   .... lots of unknown data

#endif // PS_BRES_DEFINES_H

/* END OF FILE ************************************************************/
