#include "ResourceDefs.h"

resource( BRES_APP_SIG_TYPE, BRES_APP_SIG_ID, BRES_APP_SIG_NAME )
{
    "application/x-vnd.PS-img2mwbres"
}

resource( BRES_APP_FLAGS_TYPE, BRES_APP_FLAGS_ID, BRES_APP_FLAGS_NAME )
{
    BRES_APP_MULTIPLE_LAUNCH
}

#include "icon16x16.r"
#include "icon32x32.r"

/*
resource( BRES_MINI_ICON_TYPE, BRES_MINI_ICON_ID, BRES_MINI_ICON_NAME )
{
    read( "icon16x16.raw" )
}

resource( BRES_LARGE_ICON_TYPE, BRES_LARGE_ICON_ID, BRES_LARGE_ICON_NAME )
{
    read( "icon32x32.raw" )
}
*/
