/**************************************************************************\
 * img2mwbres.cc - Converts image files to mwbres source code.            *
 **************************************************************************
 * Copyright © 1998 by Lars Jørgen Aas <larsa@tihlde.hist.no>.            *
 * All commercial rights reserved.                                        *
\**************************************************************************/

// *************************************************************************
// TODO:
//  · vacuum the code
//  · wait for mwbres to be fixed and remove options and extra code
//  · change the rgb color syntax to avoid problems with bash <-> '#'
//  · indent and format textual data better for huge bitmaps (add comments?)

// *************************************************************************
// BUGS:
//  · see no evil, hear no evil...
//  · garbage in -> garbage out.  this utility is not foolproof

// *************************************************************************
// CHANGELOG:
//    v0.9: (1998-01-04)
//  · first release

// *************************************************************************

#include <support/SupportDefs.h>
#include <app/Application.h>
#include <app/Handler.h>
#include <interface/GraphicsDefs.h>
#include <interface/Screen.h>
#include <interface/Bitmap.h>
#include <interface/Alert.h>
#include <storage/Entry.h>
#include <storage/Path.h>
#include <storage/Node.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <Datatypes.h>
#include <GetBitmap.h>

#include "ResourceDefs.h"

// *************************************************************************

#define STRCPY( dest, source )                    \
   if ( dest != B_EMPTY_STRING ) {                \
       delete [] dest;                            \
       dest = NULL;                               \
   }                                              \
   if ( source == B_EMPTY_STRING )                \
       dest = (char *) B_EMPTY_STRING;            \
   else if ( source ) {                           \
       dest = new char [ strlen( source ) + 1 ];  \
       strcpy( dest, source );                    \
   }

#define APP_SIG      "application/x-vnd.PS-img2mwbres"
#define APP_VERSION  "0.9"
#define APP_RELDATE  "1998-01-04"

// rgb color offsets:
#define BLUE_OFF 0
#define GREEN_OFF 1
#define RED_OFF 2
#define ALPHA_VAL 255

enum { // mwbres bug handling
    FIX_NOTHING,
    FIX_APPROXIMATE,
    FIX_CLEAR_PIXEL,
    FIX_CLEAR_SIGN_BIT
};

// global settings:
bool debug = false;
bool raw = false;
bool noheaders = false;
bool resourcedefs = false;
int mwbres_bug_handling = FIX_APPROXIMATE; // default
bool transparency = false;
bool transparency_rgb = false;
rgb_color transparent_rgb = {0,0,0,0};
int transparent_idx = 0;

// *************************************************************************

class psFileList { // linked list of files to crunch
public:
    psFileList( void );
    ~psFileList( void );
    void SetFileName( const char * const filename ) { STRCPY( icon_filename, filename ); };
    char * GetFileName( void ) const { return icon_filename; };
    void SetResFileName( const char * const filename ) { STRCPY( res_filename, filename ); };
    char * GetResFileName( void );
    void SetType( const char * const type ) { STRCPY( res_type, type ); };
    void SetId( const char * const id ) { STRCPY( res_id, id ); };
    void SetName( const char * const name ) { STRCPY( res_name, name ); };
    void SetNext( class psFileList * const Next );
    class psFileList * GetNext( void ) const { return next; };
    class psFileList * GetPrev( void ) const { return prev; };
    class psFileList * GetFirst( void ) const;
    class psFileList * GetLast( void ) const;
private:
    char * icon_filename, * res_filename, * res_type, * res_id, * res_name;
    class psFileList * prev, * next;
    friend class psApp;
}; // class psFileList;

// *************************************************************************

class psApp : public BApplication {
public:
    psApp( void );
    ~psApp( void );
    void ArgvReceived( int32 argc, char ** argv ); // shell arguments
    void RefsReceived( BMessage * msg ); // image "droppings"
    void ReadyToRun( void ); // do the crunching

    void DumpBitmap( BBitmap * Bitmap, FILE * output, psFileList * File );
    void DumpHeader( class psFileList * File, FILE * output, int width, int height ) const;
    void DisplayError( const char * const message ) const;
    void DisplayWarning( const char * const message ) const;

private:
    static int square( int a ) { return a*a; };
    static int hexbyte( const char * const hex );
    static char * uint32_to_char( uint32 key );

    app_info * Info;
    BScreen * Screen;
    psFileList * FileList;
    bool GUI, shell;
}; // class psApp

// *************************************************************************

void
main(
    int argc,
    char ** argv )
{
    psApp * App = new psApp;
    App->Run();
    delete App;
    exit( 0 );
} // main()

// *************************************************************************

psApp::psApp(
    void )
  : BApplication( APP_SIG )
{
    Info = new app_info;
    GetAppInfo( Info );
    FileList = NULL;
    Screen = NULL;
    GUI = false;
    shell = false;
} // psApp()

psApp::~psApp(
    void )
{
    if ( FileList ) delete FileList->GetFirst(); // cascading
    delete Info;
    delete Screen;
} // ~psApp()

void
psApp::ArgvReceived(
    int32 argc,
    char ** argv )
{
    shell = true;
    // I better finish the psArgs class - this kind of code is tedious.
    for ( int i = 1; i < argc; i++ ) {
        if ( ( strcmp( argv[i], "--output" ) == 0 ) ||
             ( strcmp( argv[i], "-o" ) == 0 ) ) {
             i++;
             if ( ! argv[i] || FileList == NULL ) {
                 break;
             }
             FileList->SetResFileName( argv[i] );
        } else if ( ( strcmp( argv[i], "--type" ) == 0 ) ||
                    ( strcmp( argv[i], "-t" ) == 0 ) ) {
              // set type string
             i++;
             if ( ! argv[i] || FileList == NULL ) {
                 break;
             }
             FileList->SetType( argv[i] );
        } else if ( ( strcmp( argv[i], "--Type" ) == 0 ) ||
                    ( strcmp( argv[i], "-T" ) == 0 ) ) {
              // set type string
             i++;
             if ( ! argv[i] || FileList == NULL ) {
                 break;
             }
             FileList->SetType( uint32_to_char( atoi( argv[i] ) ) );
        } else if ( ( strcmp( argv[i], "--id" ) == 0 ) ||
                    ( strcmp( argv[i], "-i" ) == 0 ) ) {
              // set id number
             i++;
             if ( ! argv[i] || FileList == NULL ) {
                 break;
             }
             FileList->SetId( argv[i] );
        } else if ( ( strcmp( argv[i], "--name" ) == 0 ) ||
                    ( strcmp( argv[i], "-n" ) == 0 ) ) {
              // set name string
             i++;
             if ( ! argv[i] || FileList == NULL ) {
                 break;
             }
             FileList->SetName( argv[i] );
#ifndef NO_MWBRES_BUG_HANDLING
        } else if ( ( strcmp( argv[i], "--bugfix" ) == 0 ) ||
                    ( strcmp( argv[i], "-b" ) == 0 ) ) {
             i++;
             if ( ! argv[i] ) {
                 break;
             }
             if ( strcmp( argv[i], "do-nothing" ) == 0 ) {
                 mwbres_bug_handling = FIX_NOTHING;
             } else if ( strcmp( argv[i], "approximate" ) == 0 ) {
                 mwbres_bug_handling = FIX_APPROXIMATE;
             } else if ( strcmp( argv[i], "clear-pixel" ) == 0 ) {
                 mwbres_bug_handling = FIX_CLEAR_PIXEL;
             } else if ( strcmp( argv[i], "clear-sign-bit" ) == 0 ) {
                 mwbres_bug_handling = FIX_CLEAR_SIGN_BIT; // not very useful
             } else {
                 char message[ 256 ]; // size will cause crash with long args?
                 sprintf( message, "No bugfix handling method '%s'\n", argv[i] );
                 DisplayWarning( message );
             }
#endif
        } else if ( ( strcmp( argv[i], "--help" ) == 0 ) ||
                    ( strcmp( argv[i], "-h" ) == 0 ) ) {
             fprintf( stdout, "%s\n",
                      "img2mwbres v" APP_VERSION " (" APP_RELDATE ") - an image to mwbres source code converter.\n"
                      "Usage: img2mwbres [global options] <file> [options] [<file> [options]]...\n"
                      "\n"
                      "Global options:\n"
                      "    -h, --help                print usage information\n"
                      "    -d, --debug               print debug information (if any)\n"
                      "    -V, --version             print version information\n"
#ifndef NO_MWBRES_BUG_HANDLING
                      "    -b, --bugfix <method>     specify mwbres signed bit bug handling\n"
                      "                              which must be one of:\n"
                      "                                do-nothing   - act like mwbres is fixed\n"
                      "                                approximate  - find 'closest' pixel [default]\n"
                      "                                clear-pixel  - clear the pixel to black\n"
                      "                              this option does not work with '--raw'\n"
#endif
                      "    -N, --noheaders           don't print \"resource()\" headers\n"
                      "    -I, --include             include ResourceDefs.h and use the defines\n"
                      "    -r, --raw                 write raw data, not textual mwbres source code\n"
                      "    -c, --transparent <color> specify the color to make transparent\n"
                      "                              8 bit: index value, 32 bit: \"#rrggbb\"\n"
                      "\n"
                      "File options:\n"
                      "    -o, --output <filename>   specify filename for resource file\n"
                      "    -t, --type <key>          specify the resource type key 'string' (no uint32)\n"
                      "    -T, --Type <key-num>      specify the resource type numerically\n"
                      "    -i, --id <id>             specify the resource id number\n"
                      "    -n, --name <name>         specify the resource name\n" );
        } else if ( ( strcmp( argv[i], "--debug" ) == 0 ) ||
                    ( strcmp( argv[i], "-d" ) == 0 ) ) {
             debug = true;
        } else if ( ( strcmp( argv[i], "--version" ) == 0 ) ||
                    ( strcmp( argv[i], "-V" ) == 0 ) ) {
             fprintf( stdout, "img2mwbres v%s (%s)\n", APP_VERSION, APP_RELDATE );
        } else if ( ( strcmp( argv[i], "--noheaders" ) == 0 ) ||
                    ( strcmp( argv[i], "-N" ) == 0 ) ) {
             noheaders = true;
        } else if ( ( strcmp( argv[i], "--include" ) == 0 ) ||
                    ( strcmp( argv[i], "-I" ) == 0 ) ) {
             resourcedefs = true;
        } else if ( ( strcmp( argv[i], "--raw" ) == 0 ) ||
                    ( strcmp( argv[i], "-r" ) == 0 ) ) {
             raw = true;
        } else if ( ( strcmp( argv[i], "--transparent" ) == 0 ) ||
                    ( strcmp( argv[i], "-c" ) == 0 ) ) {
            i++;
            if ( ! argv[i] ) {
                DisplayError( "option requires an argument." );
                break;
            }
            if ( ( argv[i][0] == '#' ) && ( strlen( argv[i] ) == 7 ) ) {
                // #rrggbb syntax
                int red, green, blue;
                red = hexbyte( argv[i] + 1 );
                green = hexbyte( argv[i] + 3 );
                blue = hexbyte( argv[i] + 5 );
                if ( red == -1 || green == -1 || blue == -1 ) {
                    DisplayError( "couldn't decode color value" );
                    break;
                }
                transparent_rgb.red = red;
                transparent_rgb.green = green;
                transparent_rgb.blue = blue;
                transparency_rgb = true;
            } else {
                // color index
                transparent_idx = atoi( argv[i] );
                if ( transparent_idx > 255 || transparent_idx < 0 ) {
                    DisplayError( "couldn't decode color value" );
                    break;
                }
                transparency_rgb = false;
            }
            transparency = true;
        } else { // assume new filename
            psFileList * New = new psFileList;
            New->SetFileName( argv[i] );
            if ( FileList ) {
                FileList = FileList->GetLast();
                FileList->SetNext( New );
            } else {
                FileList = New;
            }
        }
    }
} // ArgvReceived()

void
psApp::RefsReceived(
    BMessage * msg )
{
    GUI = true;
    uint32 type;
    int32 count;
    char string[256];
    msg->GetInfo("refs", &type, &count );
    if ( type != B_REF_TYPE )
        return;

    entry_ref item;
    BPath path;
    BEntry entry;
    status_t err;
    for ( int i = 0; i < count; i++ ) { 
        if ( ( err = msg->FindRef( "refs", i, &item ) ) == B_OK ) {
            entry.SetTo( &item );
            entry.GetPath( &path );
            psFileList * New = new psFileList;
            New->SetFileName( path.Path() );
            if ( ! FileList ) {
                FileList = New;
            } else {
                FileList = FileList->GetLast();
                FileList->SetNext( New );
            }
        }
    }
} // RefsReceived()

void
psApp::ReadyToRun(
    void )
{
    if ( FileList ) {
        DATAInit( APP_SIG );

        psFileList * File = FileList->GetFirst();
        do {
            char * filename = File->GetFileName();
            char * resource = File->GetResFileName();
            BBitmap * Bitmap = GetBitmap( filename );
            if ( ! Bitmap ) {
                char * ptr = strrchr( filename, '/' );
                if ( ptr ) ptr++;
                else ptr = filename;
                char error[256];
                sprintf( error, "Error opening image file \"%s\".", ptr );
                DisplayError( error );
            } else {
                FILE * output = fopen( resource, "w" );
                if ( ! output ) {
                    char * ptr = strrchr( resource, '/' );
                    if ( ptr ) ptr++;
                    else ptr = resource;
                    char error[256];
                    sprintf( error, "Error opening \"%s\" for output.", ptr );
                    DisplayError( error );
                } else {
                    DumpBitmap( Bitmap, output, File );
                    fclose( output );
                    if ( raw == false ) {
                        BNode file( resource );
                        file.WriteAttr( "BEOS:TYPE", 'MIMS', 0,
                                        "text/plain",
                                strlen( "text/plain" ) + 1 );
                        file.WriteAttr( "BEOS:PREF_APP", 'MIMS', 0,
                                        "application/x-mw-BeIDE",
                                strlen( "application/x-mw-BeIDE" ) + 1 );
                    } // else raw files - no attributes
                }
                delete Bitmap;
            }
            File = File->GetNext();
        } while ( File );

        DATAShutdown();
    } // else cause feedback.... (to come)
    be_app->PostMessage( B_QUIT_REQUESTED );
} // ReadyToRun()

void
psApp::DumpBitmap(
    BBitmap * Bitmap,
    FILE * output,
    psFileList * File )
{
    BRect bounds = Bitmap->Bounds();
    int width = bounds.right - bounds.left + 1;
    int height = bounds.bottom - bounds.top + 1;

    color_space colors = Bitmap->ColorSpace();

    if ( ! Screen )
        Screen = new BScreen;

    if ( ( raw == false ) && ( noheaders == false ) ) {
        if ( resourcedefs == true ) {
            fprintf( output, "#include <ResourceDefs.h>\n\n" );
        }
        DumpHeader( File, output, width, height );
        fprintf( output, "{\n" );
    }

    uint8 * data = (uint8 *) Bitmap->Bits();
    uint8 * pix = new uint8 [ width ];

    for ( int line = 0; line < height; line++ ) {
        if ( raw == false ) {
            fprintf( output, "    " );
        }
        if ( colors == B_COLOR_8_BIT ) {
            for ( int pixel = 0; pixel < width; pixel++ ) {
                pix[pixel] = data[(line*width)+pixel];
                if ( ( transparency == true ) && ( transparency_rgb == false ) ) {
                    if ( pix[pixel] == transparent_idx ) {
                        pix[pixel] = B_TRANSPARENT_8_BIT;
                    }
                }
            }
        } else if ( colors == B_RGB_32_BIT ) {
            for ( int pixel = 0; pixel < width; pixel++ ) {
                uint8 red   = data[(line*width*4)+(pixel*4)+RED_OFF];
                uint8 green = data[(line*width*4)+(pixel*4)+GREEN_OFF];
                uint8 blue  = data[(line*width*4)+(pixel*4)+BLUE_OFF];
                pix[pixel] = Screen->IndexForColor( red, green, blue, ALPHA_VAL );
                if ( ( transparency == true ) && ( transparency_rgb == true ) ) {
                    if ( ( red == transparent_rgb.red ) &&
                         ( green == transparent_rgb.green ) &&
                         ( blue == transparent_rgb.blue ) ) {
                        pix[pixel] = B_TRANSPARENT_8_BIT;
                    }
                }
            }
        } else {
            DisplayError( "Sorry, there is no support for that kind of bitmap." );
            fprintf( output, "...ABORTING!\n" );
            delete [] pix;
            return;
        }

        for ( int pixel = 0; pixel < width; pixel += 4 ) {
            uint32 value = (pix[pixel]<<24) + (pix[pixel+1]<<16) + (pix[pixel+2]<<8) + pix[pixel+3];
#ifndef NO_MWBRES_BUG_HANDLING
            if ( value & 0x80000000 ) {
                if ( mwbres_bug_handling == FIX_NOTHING ) {
                    // nothing
                } else if ( mwbres_bug_handling == FIX_APPROXIMATE ) {
                    // find the "most similar" color with value < 128
                    int color, best_color = 0;
                    int distance, best_distance = 200000; // > 3*256^2
                    rgb_color ideal, approx;
                    ideal = Screen->ColorForIndex( value >> 24 );
                    for ( color = 0; color < 128; color++ ) {
                        approx = Screen->ColorForIndex( color );
                        distance = square( approx.red - ideal.red ) +
                                   square( approx.green - ideal.green ) +
                                   square( approx.blue - ideal.blue );
                        if ( distance < best_distance ) {
                            best_color = color;
                            best_distance = distance;
                        }
                    }
                    value &= 0x00ffffff + ( best_color << 24 );
                } else if ( mwbres_bug_handling == FIX_CLEAR_PIXEL ) {
                    // set problematic pixel to 0
                    value &= 0x00ffffff;
                } else if ( mwbres_bug_handling == FIX_CLEAR_SIGN_BIT ) {
                    // remove sign bit
                    value &= 0x7fffffff;
                } else {
                    DisplayWarning( "unknown bug handling method.\n" );
                }
            }
#endif
            if ( raw == false ) {
                if ( pixel < (width-4) ) {
                    fprintf( output, "%u,", value );
                } else {
                    fprintf( output, "%u", value );
                }
            } else { // fetching from pix[] circumvents bug handling code...
                fprintf( output, "%c%c%c%c", pix[pixel], pix[pixel+1], pix[pixel+2], pix[pixel+3] );
            }
        }
        if ( raw == false ) {
            if ( line != (height - 1) ) {
                fprintf( output, "," );
            }
            fprintf( output, "\n" );
        }
    }
    if ( ( raw == false ) && ( noheaders == false ) ) {
        fprintf( output, "}\n" );
    }
    delete [] pix;
} // DumpBitmap()

void
psApp::DumpHeader(
    psFileList * File,
    FILE * output,
    int width,
    int height ) const
{
    if ( File->res_type && File->res_id ) { // user has specified values himself
        fprintf( output, "resource( '%s', %s, \"%s\" )\n",
                 File->res_type, File->res_id, File->res_name );
    } else if ( ( width == 32 ) && ( height == 32 ) ) { // assuming large icon
        if ( resourcedefs == true ) {
            fprintf( output, "resource( BRES_LARGE_ICON_TYPE, BRES_LARGE_ICON_ID, " );
        } else {
            fprintf( output, "resource( '%s', %d, ",
                     uint32_to_char(BRES_LARGE_ICON_TYPE), BRES_LARGE_ICON_ID );
        }
        if ( File->res_name != B_EMPTY_STRING ) {
            fprintf( output, "\"%s\" )\n", File->res_name );
        } else {
            if ( resourcedefs == true ) {
                fprintf( output, "BRES_LARGE_ICON_NAME )\n" );
            } else {
                fprintf( output, "\"%s\" )\n", BRES_LARGE_ICON_NAME );
            }
        }
    } else if ( ( width == 16 ) && ( height == 16 ) ) { // assuming mini icon
        if ( resourcedefs == true ) {
            fprintf( output, "resource( BRES_MINI_ICON_TYPE, BRES_MINI_ICON_ID, " );
        } else {
            fprintf( output, "resource( '%s', %d, ",
                     uint32_to_char(BRES_MINI_ICON_TYPE), BRES_MINI_ICON_ID );
        }
        if ( File->res_name != B_EMPTY_STRING ) {
            fprintf( output, "\"%s\" )\n", File->res_name );
        } else {
            if ( resourcedefs == true ) {
                fprintf( output, "BRES_MINI_ICON_NAME )\n" );
            } else {
                fprintf( output, "\"%s\" )\n", BRES_MINI_ICON_NAME );
            }
        }
    } else { // whatever... to be filled in later by the user
        if ( File->res_name != B_EMPTY_STRING ) {
            fprintf( output, "resource( 'PICT', 1, \"%s\" )\n", File->res_name );
        } else {
            fprintf( output, "resource( 'PICT', 1, \"\" )\n" );
        }
    }
} // DumpHeader()

void
psApp::DisplayError(
    const char * const message ) const
{
    if ( GUI ) {
        BAlert * Alert = new BAlert( "Error", message, "Close" );
        Alert->Go();
    } else {
        fprintf( stderr, "Error: %s\n", message );
    }
} // DisplayError()

void
psApp::DisplayWarning(
    const char * const message ) const
{
    if ( GUI ) {
        if ( debug ) { // only if debug is on - alerts are annoying
            BAlert * Alert = new BAlert( "Warning", message, "Close" );
            Alert->Go();
        }
    } else { // probably shell
        fprintf( stderr, "Warning: %s\n", message );
    }
} // DisplayWarning()

int
psApp::hexbyte(
    const char * const hex )
{
    int val;
    if ( hex[0] >= '0' && hex[0] <= '9' ) {
        val = 16 * (hex[0] - '0');
    } else if ( hex[0] >= 'a' && hex[0] <= 'f' ) {
        val = 16 * ( 10 + (hex[0] - 'a') );
    } else if ( hex[0] >= 'A' && hex[0] <= 'F' ) {
        val = 16 * ( 10 + (hex[0] - 'A') );
    } else {
        return -1;
    }
    if ( hex[1] >= '0' && hex[1] <= '9' ) {
        val += hex[1] - '0';
    } else if ( hex[1] >= 'a' && hex[1] <= 'f' ) {
        val += 10 + hex[1] - 'a';
    } else if ( hex[1] >= 'A' && hex[1] <= 'F' ) {
        val += 10 + hex[1] - 'A';
    } else {
        return -1;
    }
    return val;
} // hexbyte()

char *
psApp::uint32_to_char(
    uint32 key )
{
    static char buf[5];
    buf[0] = (key >> 24);
    buf[1] = (key >> 16) & 0xff;
    buf[2] = (key >> 8) & 0xff;
    buf[3] = key & 0xff;
    buf[4] = 0;
    return buf;
} // uint32_to_char()

// *******************************************************************************

psFileList::psFileList(
     void )
{
     icon_filename = res_filename = NULL;
     res_type = res_id = NULL;
     res_name = (char *) B_EMPTY_STRING;
     next = NULL;
     prev = NULL;
} // psFileList()

psFileList::~psFileList(
    void )
{
    delete [] icon_filename;
    delete [] res_filename;
    delete [] res_type;
    delete [] res_id;
    if ( res_name != B_EMPTY_STRING ) delete [] res_name;
    delete next; // cascading - remove recursion?
} // ~psFileList() 

char *
psFileList::GetResFileName(
    void )
{
    if ( ( res_filename == NULL ) &&
         ( icon_filename != NULL ) ) {
        char * ptr = strrchr( icon_filename, '.' );
        if ( ( ptr != NULL ) &&
             ( strlen( ptr ) <= 5 ) && // accept four letter (max) extensions (.tiff/.jpeg)
             ( strchr( ptr, '/' ) == NULL ) ) { // avoid dir with . and short filename
            *ptr = '\0';
        }
        if ( raw ) 
            res_filename = new char [ strlen( icon_filename ) + 5 ];
        else
            res_filename = new char [ strlen( icon_filename ) + 3 ];
        strcpy( res_filename, icon_filename );
        if ( raw ) {
            strcat( res_filename, ".raw" );
        } else {
            strcat( res_filename, ".r" );
        }
        if ( ptr ) {
            *ptr = '.';
        }
    }
    return res_filename;
} // GetResName()

void
psFileList::SetNext(
    class psFileList * const Next )
{
    if ( next ) { // beware! cascading deletion...
        delete next;
        next = NULL;
    }
    if ( Next ) {
        Next->prev = this;
        next = Next;
    }
} // SetNext()

class psFileList *
psFileList::GetFirst(
    void ) const
{
    psFileList * ptr = (psFileList *) this;
    while ( ptr->prev ) {
        ptr = ptr->prev;
    }
    return ptr;
} // GetFirst()

class psFileList *
psFileList::GetLast(
    void ) const
{
    psFileList * ptr = (psFileList *) this;
    while ( ptr->next ) {
        ptr = ptr->next;
    }
    return ptr;
} // GetLast()

/* END OF FILE ******************************************************************/
