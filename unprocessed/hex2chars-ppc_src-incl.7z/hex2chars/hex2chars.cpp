/*
hex2chars - a quick hack to go from a generic hex file like this:

	FA8E B2B2 B2B2 B2B2 B2B2 B2B2 B2B2 
	
to a file like this:

	unsigned char theImage[] = {0xFA, 0x8E, 0xB2, and so on . . .}; 

used for creating image bitmaps.

i eat all spaces in the hex file, so output from Masao Kawamura's
hexjuggler is fine.  

to use: 
first make your image, save it as raw data.
open the image in hexjuggler (or some other hex editing program).
copy the hex and save it as a text file called "hex" (using StyledEdit).

put "hex" in the same directory as hex2chars.  
from the command line type "hex2chars".  
a new file called "chars" will be created.  an alert will pop up
when it's done.

"chars" has this format:

	unsigned char theImage[] = {0xFA, 0x8E, 0xB2, and so on . . .}; 

you can open "chars" in StyledEdit to check that everything is okay.

#include "chars" in your project somewhere.
	
	myBitMap = new BBitmap(bitRect, B_COLOR_8_BIT);
	myBitMap->SetBits(theImage,54400,0,B_COLOR_8_BIT);

will make a bitmap using your image.  whew!

i know it's dumb and slow.  but it's a very quick hack, and is easily 
modified to your taste!


douglas 12.oct.97
glmrboy@shoko.calarts.edu
*/

#include "hex2chars.h"
#include <fcntl.h>
#include <unistd.h>
#include <Path.h>
#include <Directory.h>
#include <File.h>


main(void)
{	
	THelloApplication *myApplication;
	myApplication = new THelloApplication();
	myApplication->Run();
	delete myApplication;
	return 0;
} 

const char *app_signature = "application/x-vnd.dIr-hex2chars";

THelloApplication::THelloApplication()
		  :BApplication(app_signature)
{
	int				ref;
	char			theChar[2];
	char			replaceChar[1];
	char			outChar[5];
	char*			header = "unsigned char theImage[] = {";
	int				charIndex1 = 0;
	BFile			newFile;
	BDirectory		myDirectory;
	status_t		myStatus;
	ssize_t			sizeWritten;
	off_t 			totalSize;
	int				counter = 0;
	
	ref = open("./hex", O_RDONLY);
	myDirectory = BDirectory("./");
	myStatus =  myDirectory.InitCheck();
	newFile = BFile();
	myStatus = newFile.SetTo("./", B_READ_WRITE);
	myStatus = myDirectory.CreateFile("chars", &newFile, false); 
	myStatus = newFile.Write(header, strlen(header));
	
	if (ref >= 0) {
		while ((read(ref, (char *)&theChar, 2*sizeof(char)) >= 2)) {
			if (theChar[0] == ' ') {
				theChar[0] = theChar[1];
				read(ref, (char *)&replaceChar, sizeof(char));
				theChar[1] = replaceChar[0];
			}
				
			outChar[charIndex1++] = '0';
			outChar[charIndex1++] = 'x';
			outChar[charIndex1++] = theChar[0];
			outChar[charIndex1++] = theChar[1];
			outChar[charIndex1++] = ',';
			charIndex1 = 0;
			myStatus = newFile.Write(outChar, sizeof(outChar));
			
			if (counter++ > 10) {
				outChar[0] = '\n';
				myStatus = newFile.Write(outChar, sizeof(char));
				counter = 0;
			}
		}
		outChar[0] = '}';
		outChar[1] = ';';
		myStatus = newFile.GetSize(&totalSize);
		myStatus = newFile.WriteAt(totalSize -1,outChar, 2*sizeof(char));
	}
	close(ref);	
	newFile.Unset();
	BAlert* alert = new BAlert("", 
           "done hex2chars conversion!\n", 
           "whew!"); 
    alert->Go(); 
	be_app->PostMessage(B_QUIT_REQUESTED);

}

void THelloApplication::MessageReceived(BMessage *msg)
{
}
