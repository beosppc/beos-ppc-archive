//=============================================================
//	Iconography						Copyright 1996 Eric Kidd
//=============================================================
//	Based on sample plugin code by Hiroshi Lockheimer.

#pragma once
#pragma export on

extern "C" {

extern void	module_initialize(void *inSettings, long inSettingsSize);
extern void	module_cleanup(void **outSettings, long *outSettingsSize);
extern void	module_start_saving(BView *inView);
extern void	module_stop_saving();
extern void module_start_config(BView *inView);
extern void module_stop_config();

}

#pragma export reset
