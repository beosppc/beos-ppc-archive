#!/bin/sh
#
# This script installs the MacFile application and associated files to your BeOS system.
#
# If you tried to install by opening this script from the tracker and it opened in a text editor
# instead of running, try running this script from a terminal window (just drag this script's icon
# from the tracker onto a open terminal window).
#

cd $(dirname "$0")

LINK_PREF_DIRECTORY=/boot/home/config/be/Preferences
LINK_APPL_DIRECTORY=/boot/home/config/be/Applications
BIN_DIRECTORY=/boot/home/config/bin

ARCHIVEDIR=`dirname "$0"`
ARCHIVE="install.zip"

#name for the uam volume folder and files
UAM_FOLDER="BeUAM_Volume"
UAM_DIRECTORY=/boot/home/BeUAM_Volume
UAM_ARCHIVE="BeUAMPackage.pkg.zip"


start() 
{ 
        if [ -f $1 ]; then 
                $1 $2 & 
        else 
                echo There is no $1 
        fi 
} 

function installFiles {
	#install file system and utilities
	unzip -o "$ARCHIVEDIR/$ARCHIVE" -d $BIN_DIRECTORY

	#make sure the files got installed properly
	if [ ! -e "$BIN_DIRECTORY/MacFile" ]; then
		msg="Installation failed, configuration app failed to install!!"
		alert --stop "$msg" "Quit"
		exit 0
	fi

	if [ ! -e "$BIN_DIRECTORY/afp_server" ]; then
		msg="Installation failed, afp_server failed to install!!"
		alert --stop "$msg" "Quit"
		exit 0
	fi

	#creat links in the right places for easy access
	ln -s  -f $BIN_DIRECTORY/MacFile $LINK_PREF_DIRECTORY/MacFile
	ln -s  -f $BIN_DIRECTORY/afp_server $LINK_APPL_DIRECTORY/afp_server

	#create the BeUAM Volume folder
	mkdir $UAM_DIRECTORY
	unzip -o "$ARCHIVEDIR/$UAM_ARCHIVE" -d $UAM_DIRECTORY
}

function removeFiles {
	#remove deprecated configuration tool
	rm -f -v $BIN_DIRECTORY/AFPConfig
	rm -f -v $LINK_PREF_DIRECTORY/AFPConfig
	rm -f -v $BIN_DIRECTORY/MacFile
	rm -f -v $LINK_PREF_DIRECTORY/MacFile

	#remove old afp_server application
	rm -f -v $BIN_DIRECTORY/afp_server
	rm -f -v $LINK_APPL_DIRECTORY/afp_server

	#remove deprecated tracker add-ons
	rm -f "/boot/home/config/add-ons/Tracker/AFP-Create Share"
	rm -f "/boot/home/config/add-ons/Tracker/AFP-Remove Share"
	rm -f "/boot/home/config/add-ons/Tracker/AFP-Set Login Message"

	#remove the uam package if its there
	rm -r -v "$UAM_DIRECTORY/BeUAMPackage.pkg"
}


#Make sure the zip file with the app bits is present
if [ ! -e "$ARCHIVEDIR/$ARCHIVE" ]; then
	msg="The file \"$ARCHIVE\" that contains the application binaries is missing. Installation aborted."
	alert --stop "$msg" "Quit"
	exit 0
fi

#We must shut down afp_server before installing the new one.
msg="To install MacFile the current server will be shut down and connected users will be disconnected. Do you wish to continue?"
result=$(alert --stop "$msg" "NO" "YES")
if [ "$result" = "NO" ]; then
	exit 0
fi

#Shutdown the current MacFile (afp_server) process
quit application/x-vnd.afp_server

removeFiles
installFiles

#start the server
start $BIN_DIRECTORY/afp_server
waitfor afp_server

#share the uam volume
"$ARCHIVEDIR/share_uam"

result=$(alert --info $'MacFile has been installed and is now running. Would you like to open the configuration tool?' "No" "Yes")
if [ "$result" = "Yes" ]; then
	start $BIN_DIRECTORY/MacFile
fi

result=$(alert --info $'MacFile has been successfully installed.\nPlease read the release notes for further information.' "Open Release Notes" "Done")

	if [ "$result" = "Open Release Notes" ] ; then	
		StyledEdit "$ARCHIVEDIR/ReleaseNotes.txt"
	fi
