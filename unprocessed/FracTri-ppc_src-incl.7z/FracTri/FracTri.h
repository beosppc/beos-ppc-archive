
#include "BlanketModule.h"
#include "ScrollConfig.h"



class TriFracSaver : public BlanketModule::Saver
{
public:
	TriFracSaver ( BlanketModule* owner_, BView* view_, int pulse_rate_ ) ;
	virtual void Tick () ;

private :
	BPoint corners [ 3 ] ;
	BPoint current_point ;
	bool initialised ;
} ;



class TriFracModule : public BlanketModule
{
public:
	TriFracModule ( BMessage* message_ ) ;
	BlanketModule::Saver* InstantiateSaver ( BView* view_, bool preview_ ) ;
	BlanketModule::Config* InstantiateConfig ( BView* view_ ) ;
} ;
