#include "FracTri.h"

BArchivable* BlanketModule::Instantiate ( BMessage* message_ )
{
	return new TriFracModule ( message_ ) ;
}



TriFracSaver::TriFracSaver ( BlanketModule* owner_, BView* view_, int pulse_rate_ ) :
BlanketModule::Saver ( owner_, view_, pulse_rate_ ),
initialised ( false )
{
}

void TriFracSaver::Tick ()
{
	if ( !this->initialised )
	{
		// Store the bounds temporarily
		BRect bounds = this->View ()->Bounds () ;
	
		// Calculate the positions of the 3 corners
		this->corners [ 0 ] = BPoint ( bounds.left, bounds.bottom ) ;
		this->corners [ 1 ] = BPoint ( bounds.right, bounds.bottom ) ;
		this->corners [ 2 ] = BPoint ( ( bounds.left + bounds.right ) * 0.5, bounds.top ) ;

		// Find the centre of the screen
		this->current_point = BPoint ( ( bounds.left + bounds.right ) * 0.5, this->current_point.y = ( bounds.top + bounds.bottom ) * 0.5 ) ;

		this->initialised = true ;
	}

	{
		int loops = 10 ;
		while ( --loops )
		{
			// Create a random colour
			rgb_color colour = { rand () % 256, rand () % 256, rand () % 256, 255 } ;

			// Use the random colour
			this->View ()->SetHighColor ( colour ) ;

			{
				// Choose a random corner
				int corner = rand () % 3 ;

				// Find the point midway between the current point and a random corner
				this->current_point.x = ( this->current_point.x + this->corners [ corner ].x ) * 0.5 ;
				this->current_point.y = ( this->current_point.y + this->corners [ corner ].y ) * 0.5 ;
			}

			// Fill the pixel at the current point
			this->View ()->StrokeLine ( this->current_point, this->current_point ) ;
		}
	}
}



TriFracModule::TriFracModule ( BMessage* message_ ) :
BlanketModule ( message_ )
{
}

BlanketModule::Saver* TriFracModule::InstantiateSaver ( BView* view_, bool preview_ )
{
	return new TriFracSaver ( this, view_, ( preview_ ? 100000 : 10000 ) ) ;
}

BlanketModule::Config* TriFracModule::InstantiateConfig ( BView* view_ )
{
	const char* config_text =
		"Hacked together by Daniel Pink (bestuff@danpink.demon.co.uk).  "
		"Creates a fractal triangle by repeatedly moving half way towards "
		"a random corner.  If you don't understand this description, just "
		"look at the code :)" ;

	return new ScrollConfig ( this, view_, config_text ) ;
}	
