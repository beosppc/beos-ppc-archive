/***************************************************************
/
/	File:	MailKit.h
/
/	Description:	Master include for the Mail Kit.
/
/	Copyright 1992-98, Be Incorporated.
/
***************************************************************/


#include <E-mail.h>
