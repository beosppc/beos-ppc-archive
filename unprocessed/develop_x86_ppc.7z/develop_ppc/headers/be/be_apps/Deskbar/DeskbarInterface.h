#include <BeBuild.h>
#include <View.h>

enum deskbar_location {
	B_DESKBAR_TOP,
	B_DESKBAR_BOTTOM,
	B_DESKBAR_LEFT_TOP,
	B_DESKBAR_LEFT_TOP_EXPANDED,
	B_DESKBAR_RIGHT_TOP,
	B_DESKBAR_RIGHT_TOP_EXPANDED,
	B_DESKBAR_LEFT_BOTTOM,
	B_DESKBAR_RIGHT_BOTTOM
};

class BDeskbarInterface {
public:
							BDeskbarInterface();
							~BDeskbarInterface();
					
		BRect				Frame() const;
			
		deskbar_location	Location() const;
		status_t			SetLocation(deskbar_location) const;
			
		const char*			AddOnExists(int32 id) const;
		int32				AddOnExists(const char* name) const;
			
		uint32				CountAddOns() const;
			
		status_t			AddAddOn(BView* archivableView, bool maintain, int32* id) const;
			
		status_t			RemoveAddOn(int32 id) const;
		status_t			RemoveAddOn(const char* name) const;
};

_IMPEXP_BE status_t AddSymLinkForSelf(const char* customName);
_IMPEXP_BE status_t RemoveSymLinkToSelf(const char* customName);