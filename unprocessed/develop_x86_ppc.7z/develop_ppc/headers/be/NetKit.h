/***************************************************************
/
/	File:	NetKit.h
/
/	Copyright 1992-98, Be Incorporated.
/
***************************************************************/


#include <net_settings.h>
#include <netdb.h>
#include <socket.h>
#include <netinet/in.h>
