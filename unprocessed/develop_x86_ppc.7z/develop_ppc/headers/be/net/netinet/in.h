/*******************************************************************************
/
/	File:		netinet/in.h
/
/	Description:	To aid in porting Unix code.
/
/	Copyright 1993-98, Be Incorporated, All Rights Reserved.
/
*******************************************************************************/

#include <socket.h>
