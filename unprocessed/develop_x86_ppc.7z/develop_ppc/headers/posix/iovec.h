#ifndef _IOVEC_H
#define _IOVEC_H

#include <sys/uio.h>

#endif

