#ifndef _WCHAR_H_
#define _WCHAR_H_

#include <wchar_t.h>

#endif /* _WCHAR_H_ */
