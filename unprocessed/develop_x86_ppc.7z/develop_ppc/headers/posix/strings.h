#ifndef _STRINGS_H_
#define _STRINGS_H_

#include <string.h>


#endif /* _STRINGS_H_ */
