#ifndef _MEMORY_H_
#define _MEMORY_H_

#include <string.h>      /* they really want memcpy() and friends */

#endif /* _MEMORY_H_ */
