#ifndef _SYS_FCNTL_H_
#define _SYS_FCNTL_H_

#include <fcntl.h>

#endif /* _SYS_FCNTL_H_ */
