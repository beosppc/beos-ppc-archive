/*
 * <sys/socket.h>
 * Copyright (c) 1997 Be, Inc.	All Rights Reserved
 *
 * To aid in porting Unix code
 */
#include <socket.h>
