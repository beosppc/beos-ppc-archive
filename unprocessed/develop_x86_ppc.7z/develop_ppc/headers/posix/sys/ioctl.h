#ifndef _SYS_IOCTL_H
#define _SYS_IOCTL_H

#include <termios.h>
/* XXX include socket header file? */

#endif /* _SYS_IOCTL_H */
