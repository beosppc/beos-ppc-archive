#ifndef _WCHAR_T_
#define _WCHAR_T_

typedef unsigned short wchar_t;

#endif /* _WCHAR_T_ */
