/*  Metrowerks Standard Library  Version 4.0  1998 August 10  */

/*  $Date: 1998/12/04 23:58:22 $ 
 *  $Revision: 1.2 $ 
 *  $NoKeywords: $ 
 *
 *		Copyright � 1995-1998 Metrowerks, Inc.
 *		All rights reserved.
 */

/*
 *	new.h        hh 971206 Changed file name from new
 */

#ifndef _NEW_H
#define _NEW_H

#include <new>

#ifdef MSIPL_USING_NAMESPACE
	using namespace std;
#endif

#endif

/*     Change record
hh 971206  Changed filename from new to new.h and added namespace support
*/
