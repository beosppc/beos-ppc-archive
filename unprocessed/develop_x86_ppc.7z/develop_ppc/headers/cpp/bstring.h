/*  Metrowerks Standard Library  Version 4.0  1998 August 10  */

/*  $Date: 1998/12/04 23:58:21 $ 
 *  $Revision: 1.2 $ 
 *  $NoKeywords: $ 
 *
 *		Copyright � 1995-1998 Metrowerks, Inc.
 *		All rights reserved.
 */

/*
 *	bstring.h     
 */

#ifndef _BSTRING_H              
#define _BSTRING_H

#include <string>

#ifdef MSIPL_USING_NAMESPACE 
	using namespace std;
#endif

#endif

/*     Change record
// vss 980304 Include guards given standard names
// vss 980304 Backward compatibility added with "using"
*/
