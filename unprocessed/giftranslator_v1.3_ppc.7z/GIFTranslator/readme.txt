GIFTranslator v1.3 by Daniel Switkin, software@switkin.com
http://www.switkin.com/software/giftranslator

Please note the following:

- You should install the translator in /boot/home/config/add-ons/Translators 
- Your options are saved in /boot/home/config/settings/GIFTranslator_settings 
- Dithering is recommended when saving photographs or other images with many 
colors. Line art and similar images should be saved without dithering, which will 
use the original nearest color mapping. 
- Since you have no control over the optimal palette, it only makes sense to pick a 
transparent color (should you want one) by rgb value. For the other three palettes, 
you can now choose a specific index if you know it. If you select an rgb value, make 
sure it is part of that predefined palette. 
- Loading an animated gif will display only the first frame 
- Debugging info is no longer printed by default. If you want to see it, or have a bug
to file, open a Terminal and type:

export GIF_TRANSLATOR_DEBUG=1

You can then launch ShowImage or your favorite app from that shell.

Please submit bug reports and feature requests to software@switkin.com.

Simple license:
THIS IS FREE SOFTWARE DISTRIBUTED FOR THE BENEFIT OF THE BE 
COMMUNITY. BY USING IT, YOU ASSUME ALL RESPONSIBILITY FOR ANY 
CONSEQUENCES OR LICENSING ISSUES THAT MAY ARISE.