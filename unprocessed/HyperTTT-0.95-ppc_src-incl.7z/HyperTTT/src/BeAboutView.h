/*********************************************************************
HyperTTT - Tic tac toe in higher dimensions
Copyright (c) 1998 Brian Nenninger

This program is free software; you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with 
this program; if not, write to the Free Software Foundation, Inc., 675 Mass 
Ave., Cambridge, MA 02139, USA.

You may contact me at bwn@kreative.net
************************************************************************/

#ifndef BeABOUTVIEW_H
#define BeABOUTVIEW_H

#include <View.h>

class BeTTTWindow;

class BeAboutView : public BView
{
protected:
  BeTTTWindow *m_parent;
  
  BRect m_bounds;
  char **m_lines;
  int m_maxlen;
  int m_numLines;
  int *m_strWidths;
  int m_maxWidth;
  
public:
  BeAboutView(BRect, char*);
  virtual ~BeAboutView();
  
  void SetParent(BeTTTWindow *);
  
  virtual void Draw(BRect);  
};

#endif
