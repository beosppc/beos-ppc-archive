/*
 *  IFF_ILBMHandler.cpp 1.3.0 (Mar. 1st, 1998)
 *  Amiga IFF ILBM datatype handler
 *
 *  Originally written by Tim Stack <stack@eng.utah.edu>.
 *  Adapted and enhanced by Edmund Vermeulen <edmundv@xs4all.nl>.
 */


// Includes
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <InterfaceDefs.h>
#include <CheckBox.h>
#include <DataIO.h>
#include <DataHandler.h>
#include <Datatypes.h>


// Defines
#define ILBM_FORMAT 'ILBM'
#define CHANGE_COMPRESSION 'CHCO'


// Amiga IFF stuff
#define mskNone 0
#define mskHasMask 1
#define cmpNone 0
#define cmpByteRun1 1
#define HAM_MASK 0x800

typedef uchar UBYTE;
typedef int16 WORD;
typedef uint16 UWORD;

typedef UBYTE Masking;
typedef UBYTE Compression;

struct BitmapHeader
{
	UWORD w;
	UWORD h;
	WORD x;
	WORD y;
	UBYTE nPlanes;
	Masking masking;
	Compression compression;
	UBYTE pad1;
	UWORD transparentColor;
	UBYTE xAspect;
	UBYTE yAspect;
	WORD pageWidth;
	WORD pageHeight;
};

struct RawBitmapHeader
{
	uchar w[2];
	uchar h[2];
	uchar x[2];
	uchar y[2];
	UBYTE nPlanes;
	Masking masking;
	Compression compression;
	UBYTE pad1;
	uchar transparentColor[2];
	UBYTE xAspect;
	UBYTE yAspect;
	uchar pageWidth[2];
	uchar pageHeight[2];
};

static void RawToBitmapHeader(const RawBitmapHeader &raw, BitmapHeader &bmh)
{
	bmh.w = (raw.w[0] << 8) | raw.w[1];
	bmh.h = (raw.h[0] << 8) | raw.h[1];
	bmh.x = (raw.x[0] << 8) | raw.x[1];
	bmh.y = (raw.y[0] << 8) | raw.y[1];
	bmh.nPlanes = raw.nPlanes;
	bmh.masking = raw.masking;
	bmh.compression = raw.compression;
	bmh.pad1 = raw.pad1;
	bmh.transparentColor = (raw.transparentColor[0] << 8) | raw.transparentColor[1];
	bmh.xAspect = raw.xAspect;
	bmh.yAspect = raw.yAspect;
	bmh.pageWidth = (raw.pageWidth[0] << 8) | raw.pageWidth[1];
	bmh.pageHeight = (raw.pageHeight[0] << 8) | raw.pageHeight[1];
}

static void BitmapHeaderToRaw(const BitmapHeader &bmh, RawBitmapHeader &raw)
{
	raw.w[0] = (bmh.w >> 8) & 0xff;
	raw.w[1] = bmh.w  & 0xff;
	raw.h[0] = (bmh.h >> 8) & 0xff;
	raw.h[1] = bmh.h  & 0xff;
	raw.nPlanes = bmh.nPlanes;
	raw.masking = bmh.masking;
	raw.compression = bmh.compression;
	raw.pad1 = bmh.pad1;
	raw.transparentColor[0] = (bmh.transparentColor >> 8) & 0xff;
	raw.transparentColor[1] = bmh.transparentColor  & 0xff;
	raw.xAspect = bmh.xAspect;
	raw.yAspect = bmh.yAspect;
	raw.pageWidth[0] = (bmh.pageWidth >> 8) & 0xff;
	raw.pageWidth[1] = bmh.pageWidth  & 0xff;
	raw.pageHeight[0] = (bmh.pageHeight >> 8) & 0xff;
	raw.pageHeight[1] = bmh.pageHeight  & 0xff;
}

struct ColorRegister
{
	UBYTE red;
	UBYTE green;
	UBYTE blue;
};


// Structure for passing into ProcessChunks()
struct IffInfo
{
	int depth;
	bool ham;
};


// Datatype information
char handlerName[] = "IFF_ILBMHandler";
char handlerInfo[] = "Written by Tim Stack & Edmund Vermeulen";
int32 handlerVersion = 130;

Format inputFormats[] =
{
	{ ILBM_FORMAT, DATA_BITMAP, 1.0 * 0.8, 0.9, "image/x-iff-ilbm", "Amiga IFF ILBM" },
	{ DATA_BITMAP, DATA_BITMAP, 0.9 * 1.0, 0.7, "image/x-be-bitmap", "Be bitmap" },
	{ 0, 0, 0.0, 0.0, "", "" }
};

Format outputFormats[] =
{
	{ DATA_BITMAP, DATA_BITMAP, 0.9 * 1.0, 0.7, "image/x-be-bitmap", "Be bitmap" },
	{ ILBM_FORMAT, DATA_BITMAP, 1.0 * 0.8, 0.9, "image/x-iff-ilbm", "Amiga IFF ILBM" },
	{ 0, 0, 0.0, 0.0, "", "" }
};


// Global compression setting
static Compression compression_setting = cmpByteRun1;


// Config view class
class IFFConfigView : public BCheckBox
{
public:
	IFFConfigView();
	virtual void AttachedToWindow();
	virtual void MessageReceived(BMessage *msg);
};


// Config view member functions
IFFConfigView::IFFConfigView()
	: BCheckBox(
		BRect(0.0, 0.0, 90.0, 17.0),
		"",
		"Compression",
		new BMessage(CHANGE_COMPRESSION))
{
	if (compression_setting == cmpByteRun1)
		SetValue(B_CONTROL_ON);
}

void IFFConfigView::AttachedToWindow()
{
	SetTarget(this);
	BCheckBox::AttachedToWindow();
}

void IFFConfigView::MessageReceived(BMessage *msg)
{
	switch (msg->what)
	{
		case CHANGE_COMPRESSION:
			if (Value() == B_CONTROL_ON)
				compression_setting = cmpByteRun1;
			else
				compression_setting = cmpNone;
			break;

		default:
			BCheckBox::MessageReceived(msg);
			break;
	}
}

inline int32 RawToInt32(const uchar *four_bytes)
{
	return
		(four_bytes[0] << 24) |
		(four_bytes[1] << 16) |
		(four_bytes[2] << 8) |
		four_bytes[3];
}

inline void Int32ToRaw(int32 value, uchar *four_bytes)
{
	four_bytes[0] = (value >> 24) & 0xff;
	four_bytes[1] = (value >> 16) & 0xff;
	four_bytes[2] = (value >> 8) & 0xff;
	four_bytes[3] = value & 0xff;
}

// Convert one row of interleaved bitplane data to a chunky pixels row
static bool
ConvertPlanarToChunky(
	BPositionIO &inStream,
	const BitmapHeader &bmh,
	uchar *row32_start,
	// Used for buffered input:
	uchar *buffer_start,
	uchar *buffer_end,
	uchar * &in_buffer)
{
	bool alive = true;
	int row_len = ((bmh.w + 15) / 16) * 2;

	// Set the whole row to nils, since we are going
	// to OR each pixel in
	memset(row32_start, 0, row_len * 32);

	// Planes are interleaved which is groovy so we can read in the planes,
	// convert to a chunky row, and then write them out
	for (int curr_plane = 0;
	     curr_plane < bmh.nPlanes + (bmh.masking == mskHasMask);
	     ++curr_plane)
	{
		uchar *in_row32 =
			bmh.nPlanes != 24 ? row32_start : row32_start + 2 - curr_plane / 8;

		// Current bit in the chunky pixel we're reading in
		uchar plane_bit = 1 << (curr_plane % 8);

		// Compression?
		if (bmh.compression == cmpNone)
		{
			// Check that we don't read past the buffer
			if (in_buffer + row_len > buffer_end)
			{
				memmove(buffer_start, in_buffer, buffer_end - in_buffer);
				alive = inStream.Read(
					buffer_start + (buffer_end - in_buffer),
					in_buffer - buffer_start) > 0;
				in_buffer = buffer_start;
			}

			// Ignore the masking bitplane if there is one
			if (curr_plane < bmh.nPlanes)
			{
				for (int i = 0 ; i < row_len; ++i)
				{
					uchar plane_byte = *in_buffer;
					++in_buffer;

					// Check if there's a pixel in the bitplane and OR it in the
					// chunky pixel. Repeat for each bit in the plane byte
					if (plane_byte & 0x80) *in_row32 |= plane_bit; in_row32 += 4;
					if (plane_byte & 0x40) *in_row32 |= plane_bit; in_row32 += 4;
					if (plane_byte & 0x20) *in_row32 |= plane_bit; in_row32 += 4;
					if (plane_byte & 0x10) *in_row32 |= plane_bit; in_row32 += 4;
					if (plane_byte & 0x08) *in_row32 |= plane_bit; in_row32 += 4;
					if (plane_byte & 0x04) *in_row32 |= plane_bit; in_row32 += 4;
					if (plane_byte & 0x02) *in_row32 |= plane_bit; in_row32 += 4;
					if (plane_byte & 0x01) *in_row32 |= plane_bit; in_row32 += 4;
				}
			}
			else
			{
				in_buffer += row_len;
			}
		}
		else  // RLE compressed
		{
			int count = row_len;
			while (count > 0)
			{
				// Check that we don't read past the buffer
				if (in_buffer == buffer_end)
				{
					alive = inStream.Read(buffer_start, buffer_end - buffer_start) > 0;
					in_buffer = buffer_start;
				}

				int n = signed char(*in_buffer);
				++in_buffer;
				if (n >= 0)
				{
					++n;
					if (n > count)
						n = count;
					count -= n;

					// Check that we don't read past the buffer
					if (in_buffer + n > buffer_end)
					{
						memmove(buffer_start, in_buffer, buffer_end - in_buffer);
					    alive = inStream.Read(
					    	buffer_start + (buffer_end - in_buffer),
					    	in_buffer - buffer_start) > 0;
						in_buffer = buffer_start;
					}

					// Ignore masking bitplane
					if (curr_plane < bmh.nPlanes)
					{
						for (; n > 0; --n)
						{
							uchar plane_byte = *in_buffer;
							++in_buffer;

							if (plane_byte & 0x80) *in_row32 |= plane_bit; in_row32 += 4;
							if (plane_byte & 0x40) *in_row32 |= plane_bit; in_row32 += 4;
							if (plane_byte & 0x20) *in_row32 |= plane_bit; in_row32 += 4;
							if (plane_byte & 0x10) *in_row32 |= plane_bit; in_row32 += 4;
							if (plane_byte & 0x08) *in_row32 |= plane_bit; in_row32 += 4;
							if (plane_byte & 0x04) *in_row32 |= plane_bit; in_row32 += 4;
							if (plane_byte & 0x02) *in_row32 |= plane_bit; in_row32 += 4;
							if (plane_byte & 0x01) *in_row32 |= plane_bit; in_row32 += 4;
						}
					}
					else
					{
						in_buffer += n;
					}
				}
				else
				{
					if (n != -128)
					{
						n = -n + 1;
						if (n > count)
							n = count;
						count -= n;

						// Check that we don't read past the buffer
						if (in_buffer == buffer_end)
						{
							alive = inStream.Read(buffer_start, buffer_end - buffer_start) > 0;
							in_buffer = buffer_start;
						}

						// Ignore masking bitplane
						if (curr_plane < bmh.nPlanes)
						{
							uchar plane_byte = *in_buffer;
							for (; n > 0; --n)
							{
								if (plane_byte & 0x80) *in_row32 |= plane_bit; in_row32 += 4;
								if (plane_byte & 0x40) *in_row32 |= plane_bit; in_row32 += 4;
								if (plane_byte & 0x20) *in_row32 |= plane_bit; in_row32 += 4;
								if (plane_byte & 0x10) *in_row32 |= plane_bit; in_row32 += 4;
								if (plane_byte & 0x08) *in_row32 |= plane_bit; in_row32 += 4;
								if (plane_byte & 0x04) *in_row32 |= plane_bit; in_row32 += 4;
								if (plane_byte & 0x02) *in_row32 |= plane_bit; in_row32 += 4;
								if (plane_byte & 0x01) *in_row32 |= plane_bit; in_row32 += 4;
							}
						}
						++in_buffer;
					}
				}
			}
		}
	}

	return alive;
}

// Write the IFF ILBM bitmap body to the output stream
static bool
WriteBitmapBody(
	BPositionIO &inStream,
	BPositionIO &outStream,
	const BitmapHeader &bmh,
	const ColorRegister *cmap,
	bool ham)
{
	bool alive = true;

	int row_len = ((bmh.w + 15) / 16) * 2;

	// Allocate 32-bit pixel row
	uchar *row32 = new uchar[row_len * 32 + (ham ? 4 : 0)];
	uchar *row32_start = row32;

	if (ham)
	{
		// If the first pixel in a row is a modify then it
		// modifies the border pixel which is the 0 color
		// register, so we need to set this up instead of
		// writing a special case in the ham -> 32-bit code
		row32[0] = cmap[0].blue;
		row32[1] = cmap[0].green;
		row32[2] = cmap[0].red;
		row32_start += 4;
	}

	// Read in blocks that are multiples of 2048 bytes, but at least one row
	int plane_row_len = row_len * (bmh.nPlanes + (bmh.masking == mskHasMask));
	int in_size = (plane_row_len / 2048 + 1) * 2048;
	uchar *buffer_start = new uchar[in_size];
	uchar *buffer_end = buffer_start + in_size;
	// Force a new buffer to be read the first time
	uchar *in_buffer = buffer_end;

	// Loop through every row in the picture
	for (int curr_row = 0; curr_row < bmh.h; ++curr_row)
	{
		if (!ConvertPlanarToChunky(
			inStream, bmh, row32_start, buffer_start, buffer_end, in_buffer))
		{
			alive = false;
			break;
		}

		if (ham)
		{
			// It's hold and modify mode. Only modify one color component
			// and hold the other ones, or look-up the color in the color map.
			// Both ham6 and ham8 are supported.
			uchar *in_row32 = row32_start;
			for (int i = 0; i < bmh.w; ++i)
			{
				uchar chunky_byte = *in_row32;
				switch (chunky_byte & (bmh.nPlanes == 8 ? 0xC0 : 0x30))
				{
					// Look-up color
					case 0x00:
						in_row32[0] = cmap[chunky_byte].blue;
						in_row32[1] = cmap[chunky_byte].green;
						in_row32[2] = cmap[chunky_byte].red;
						break;

					// Modify blue, hold the rest
					case 0x10:
					case 0x40:
						in_row32[0] = bmh.nPlanes == 8
							? (in_row32[-4] & 0x03) | ((chunky_byte & 0x3f) << 2)
							: (chunky_byte & 0x0f) | ((chunky_byte & 0x0f) << 4);
						in_row32[1] = in_row32[-3];
						in_row32[2] = in_row32[-2];
						break;

					// Only modify red
					case 0x20:
					case 0x80:
						in_row32[0] = in_row32[-4];
						in_row32[1] = in_row32[-3];
						in_row32[2] = bmh.nPlanes == 8
							? (in_row32[-2] & 0x03) | ((chunky_byte & 0x3f) << 2)
							: (chunky_byte & 0x0f) | ((chunky_byte & 0x0f) << 4);
						break;

					// Only modify green
					case 0x30:
					case 0xC0:
						in_row32[0] = in_row32[-4];
						in_row32[1] = bmh.nPlanes == 8
							? (in_row32[-3] & 0x03) | ((chunky_byte & 0x3f) << 2)
							: (chunky_byte & 0x0f) | ((chunky_byte & 0x0f) << 4);
						in_row32[2] = in_row32[-2];
						break;
				}
				in_row32[3] = 255;  // Set alpha to opaque
				in_row32 += 4;
			}
		}
		else
		{
			if (bmh.nPlanes != 24)
			{
				// Convert chunky 8-bit to 32-bit
				uchar *in_row32 = row32_start;
				for (int i = 0; i < bmh.w; ++i)
				{
					uchar chunky_byte = *in_row32;
					in_row32[0] = cmap[chunky_byte].blue;
					in_row32[1] = cmap[chunky_byte].green;
					in_row32[2] = cmap[chunky_byte].red;
					in_row32[3] = 255;  // Set alpha to opaque
					in_row32 += 4;
				}
			}
		}

		if (outStream.Write(row32_start, bmh.w * 4) != bmh.w * 4)
		{
			alive = false;
			break;
		}
	}

	delete[] buffer_start;
	delete[] row32;

	return alive;
}

// Process the IFF chunks, and either convert it to DATA_BITMAP,
// or fill in the IffInfo structure to identify the IFF ILBM
static bool
ProcessChunks(
	BPositionIO &inStream,
	BPositionIO &outStream,
	IffInfo *iffInfo)
{
	// Check if it really is IFF ILBM
	char data[12];
	if (inStream.Read(data, 12) != 12 ||
	   strncmp(data, "FORM", 4) != 0 ||
	   strncmp(data + 8, "ILBM", 4) != 0)
	{
		return false;
	}

	// IFF bitmap header
	BitmapHeader bmh;
	bool bmhd_found = false;
	bool ham = false;

	// Allocate space for 256 colors
	ColorRegister *cmap = new ColorRegister[256];

	// We will loop as long as there hasn't been some error,
	// the bitmap hasn't been written out yet,
	// and we can read four bytes with a chunk name
	bool alive = true;
	bool done = false;
	uchar four_bytes[4];
	while (alive && !done && inStream.Read(four_bytes, 4) == 4)
	{
		int32 chunk_name = RawToInt32(four_bytes);

		// Get the chunk size
		if (inStream.Read(four_bytes, 4) != 4)
		{
			alive = false;
			break;
		}
		int32 chunk_size = RawToInt32(four_bytes);

		switch (chunk_name)
		{
			case 'BMHD':  // Bitmap header
			{
				bmhd_found = true;  // Essential

				// Read in the bitmap header, and check if we support
				// the bitplane depth and compression method
				RawBitmapHeader raw;
				if (inStream.Read(&raw, sizeof(RawBitmapHeader)) != sizeof(RawBitmapHeader))
				{
					alive = false;
					break;
				}

				RawToBitmapHeader(raw, bmh);
				if (bmh.nPlanes < 0 || (bmh.nPlanes > 8 && bmh.nPlanes != 24) ||
				    (bmh.compression != cmpNone && bmh.compression != cmpByteRun1))
				{
					alive = false;
					break;
				}

				if (iffInfo)  // Only identify the IFF ILBM
					break;

				// Create DATA_BITMAP header
				DATABitmap hdr;
				hdr.magic = DATA_BITMAP;
				hdr.colors = B_RGB_32_BIT;  // Always convert to true color
				hdr.bounds.Set(0.0, 0.0, bmh.w - 1.0, bmh.h - 1.0);
				hdr.rowBytes = bmh.w * 4;
				hdr.dataSize = bmh.h * hdr.rowBytes;

				// Write the header out
				alive = outStream.Write(&hdr, sizeof(DATABitmap)) == sizeof(DATABitmap);
				break;
			}
			case 'CMAP':  // Color map
			{
				// Read in the color map
				if (chunk_size > 256 * 3 ||
				    inStream.Read(cmap, chunk_size) != chunk_size)
				{
					alive = false;
					break;
				}

				int n_colors = chunk_size / 3;

				// If the lower four bits of all color map entries are unused,
				// we assume that they are old style 4-bit color values
				// that need to be converted to 8-bit
				bool four_bit_color = true;
				for (int i = 0; i < n_colors; ++i)
				{
					if ((cmap[i].red   & 0x0f) ||
					    (cmap[i].green & 0x0f) ||
					    (cmap[i].blue  & 0x0f))
					{
						four_bit_color = false;
						break;
					}
				}
				if (four_bit_color)
				{
					// Convert the color map to 8-bit if it's not already.
					// We have to duplicate the value in the low order bits
					// so that white is 0xff instead of 0xf0
					for (int i = 0; i < n_colors; ++i)
					{
						cmap[i].red   = cmap[i].red   | (cmap[i].red   >> 4);
						cmap[i].green = cmap[i].green | (cmap[i].green >> 4);
						cmap[i].blue  = cmap[i].blue  | (cmap[i].blue  >> 4);
					}
				}

				// If there are 32 colors and 6 planes then we assume it is ehb
				if (n_colors == 32 && bmh.nPlanes == 6)
				{
					// Fill in the extra half brite colors
					for (int i = 32; i < 64; ++i)
					{
						cmap[i].red   = cmap[i - 32].red   / 2;
						cmap[i].green = cmap[i - 32].green / 2;
						cmap[i].blue  = cmap[i - 32].blue  / 2;
					}
				}
				break;
			}
			case 'CAMG':  // Commodore Amiga mode id
			{
				if (chunk_size == 4 && inStream.Read(four_bytes, 4) != 4)
				{
					alive = false;
					break;
				}

				uint32 mode_id = RawToInt32(four_bytes);
				ham = (mode_id & HAM_MASK) != 0 && (bmh.nPlanes == 6 || bmh.nPlanes == 8);
				break;
			}
			case 'BODY':  // The bitplane data
			{
				done = true;  // No need to process any further chunks after this one

				if (!bmhd_found)
				{
					alive = false;
					break;
				}

				if (iffInfo)  // Only identify the IFF ILBM
				{
					iffInfo->ham = ham;
					iffInfo->depth = bmh.nPlanes;
					break;
				}

				// Write the bitmap body out
				alive = WriteBitmapBody(inStream, outStream, bmh, cmap, ham);
				break;
			}
			default:  // Unknown chunk
			{
				alive = inStream.Seek(chunk_size, SEEK_CUR) >= 0;
				break;
			}

		}  // End of chunk name switch

		if (chunk_size % 2 == 1)  // Uneven chunk size
			alive = inStream.Seek(1, SEEK_CUR) >= 0;

	}  // End of chunk loop

	delete[] cmap;
	return alive && done;
}


// RLE encodes the data in runs of a maximum of 128 bytes, preceded by a
// control byte that indicates the number of bytes in the run.
// A positive control byte is followed by n+1 (literal) bytes of data,
// a negative control byte is followed by the byte to be repeated -n+1 times,
// -128 is a no-op.
static size_t
RunLengthEncode(signed char *dest, const signed char *source, size_t in_size)
{
	size_t out = 0;
	size_t in = 0;

	while (in < in_size)
	{
 		if (in < in_size - 2 &&
 		    source[in] == source[in + 1] &&
 		    source[in] == source[in + 2])
 		{
 			// Begin replicate run
 			size_t hold = in;
			size_t count = 3;
 			in += 3;
			while (in < in_size &&
			       source[in] == source[hold] &&
			       count < 128)
			{
				++count;
				++in;
			}
            dest[out++] = 1 - count;
            dest[out++] = source[hold];
        }
		else
		{
			// Do a literal run
			size_t hold = out++;
			size_t count = 0;
			while (in < in_size &&
			       !(in < in_size - 2 &&
			         (source[in] == source[in + 1] &&
			          source[in] == source[in + 2])))
			{
				dest[out++] = source[in++];
				if (++count == 128)
					break;
			}
			dest[hold] = count - 1;
		}
	}

	return out;
}


// Convert DATA_BITMAP to IFF ILBM
static bool
WriteIff(BPositionIO &inStream, BPositionIO &outStream)
{
	DATABitmap bmp;
	if (inStream.Read(&bmp, sizeof(DATABitmap)) != sizeof(DATABitmap) ||
	    bmp.magic != DATA_BITMAP ||
	    !bmp.bounds.IsValid())
	{
		return false;
	}

	// Fill in the ILBM bitmap header
	BitmapHeader bmh;
	bmh.w = bmp.bounds.right - bmp.bounds.left + 1;
	bmh.h = bmp.bounds.bottom - bmp.bounds.top + 1;
	bmh.x = 0;
	bmh.y = 0;

	int32 base_size = 20 + sizeof(BitmapHeader);

	int chunks;
	int skip;
	switch (bmp.colors)
	{
		case B_RGB_32_BIT:
			bmh.nPlanes = 24;
			chunks = 3;
			skip = 4;
			break;

		case B_COLOR_8_BIT:
			bmh.nPlanes = 8;
			base_size += 8 + 256 * sizeof(ColorRegister);  // For CMAP chunk
			chunks = 1;
			skip = 1;
			break;

		case B_MONOCHROME_1_BIT:
			bmh.nPlanes = 1;
			base_size += 8 + 2 * sizeof(ColorRegister);  // For CMAP chunk
			chunks = 0;
			skip = 0;
			break;

		default:  // Unsupported
			return false;
	}

	// Some rigorous checking
	if (bmp.rowBytes != ((bmh.w * (skip ? skip : 1) / (skip ? 1 : 8) + 3) / 4) * 4 ||
	    bmp.dataSize != bmp.rowBytes * bmh.h)
	{
		return false;
	}

	bmh.masking = mskNone;
	bmh.compression = compression_setting;
	bmh.pad1 = 0;
	bmh.transparentColor = 0;
	bmh.xAspect = 1;
	bmh.yAspect = 1;
	bmh.pageWidth = bmh.w;
	bmh.pageHeight = bmh.h;

	// We want even lines of bitplane data
	int row_len = ((bmh.w + 15) / 16) * 2;

	// Allocate the output buffer(s)
	uchar *plane_buffer = 0;
	uchar *rle_buffer = 0;
	if (bmh.compression == cmpNone)
	{
		if (chunks > 0)
			plane_buffer = new uchar[row_len * 8 * chunks];
	}
	else
	{
		// We must be prepared for a worst case scenario, when RLE actually
		// increases the data size, instead of compressing it
		int rle_row_len = row_len + ((row_len + 127) / 128);
		if (chunks > 0)
		{
			plane_buffer = new uchar[row_len];
			rle_buffer = new uchar[rle_row_len * 8 * chunks];
		}
		else  // B_MONOCHROME_1_BIT
		{
			rle_buffer = new uchar[rle_row_len];
		}
	}

	uchar four_bytes[4];

	// IFF identifier
	outStream.Write("FORM", 4);
	// IFF data size (uncompressed)
	Int32ToRaw(base_size + row_len * bmh.nPlanes * bmh.h , four_bytes);
	outStream.Write(four_bytes, 4);
	// ILBM & BMHD identifiers
	outStream.Write("ILBMBMHD", 8);
	// BMHD chunk size
	Int32ToRaw(sizeof(RawBitmapHeader), four_bytes);
	outStream.Write(four_bytes, 4);
	// BMHD chunk data
	RawBitmapHeader raw;
	BitmapHeaderToRaw(bmh, raw);
	outStream.Write(&raw, sizeof(RawBitmapHeader));

	switch (bmp.colors)
	{
		case B_COLOR_8_BIT:
		{
			// Copy Be's colour map to our own
			ColorRegister *cmap = new ColorRegister[256];
			const rgb_color *be_map = system_colors()->color_list;
			for (int i = 0; i < 256; ++i)
			{
				cmap[i].red   = be_map[i].red;
				cmap[i].green = be_map[i].green;
				cmap[i].blue  = be_map[i].blue;
			}
			// CMAP identifier
			outStream.Write("CMAP", 4);
			// CMAP chunk size
			Int32ToRaw(256 * sizeof(ColorRegister), four_bytes);
			outStream.Write(four_bytes, 4);
		 	// CMAP chunk data
			outStream.Write(cmap, 256 * sizeof(ColorRegister));
			delete[] cmap;
			break;
		}
		case B_MONOCHROME_1_BIT:
		{
			// Two colours, white and black
			const ColorRegister cmap[2] = { {255, 255, 255}, {0, 0, 0} };
			// CMAP identifier
			outStream.Write("CMAP", 4);
			// CMAP chunk size
			Int32ToRaw(2 * sizeof(ColorRegister), four_bytes);
			outStream.Write(four_bytes, 4);
			// CMAP chunk data
			outStream.Write(cmap, 2 * sizeof(ColorRegister));
			break;
		}
		default:
		{
			// 24-bit doesn't need a colour map
			break;
		}
	}

	// BODY identifier
	outStream.Write("BODY", 4);
	// BODY chunk size (uncompressed)
	off_t body_pos = outStream.Position();
	Int32ToRaw(row_len * bmh.nPlanes * bmh.h, four_bytes);
	outStream.Write(four_bytes, 4);

	// In case of compression, we will keep track of the real body
	// size written, and Seek() back later to write the correct IFF
	// and BODY chunk sizes
	int32 rle_body_size = 0;

	// Allocate the input buffer
	uchar *line_buffer = new uchar[bmp.rowBytes];

	// The bitplane data has to be interleaved for each pixel row,
	// so we will go through it one line at the time
	bool alive = true;
	for (UWORD y = 0; alive && y < bmh.h; ++y)
	{
		uchar *in_plane_buffer = plane_buffer;
		uchar *in_rle_buffer = rle_buffer;
		int32 rle_size = 0;

		// Read in one pixel row
		if (inStream.Read(line_buffer, bmp.rowBytes) != bmp.rowBytes)
		{
			alive = false;
			break;
		}

		// B_MONOCHROME_1_BIT doesn't need any conversion
		if (chunks == 0 && bmh.compression == cmpByteRun1)
		{
			// Compress each bitplane row separately
			rle_size = RunLengthEncode(
				reinterpret_cast<signed char *>(rle_buffer),
				reinterpret_cast<const signed char *>(line_buffer),
				row_len);
		}

		// Chunky to planar conversion; 8-bit just has one chunk,
		// but a 32-bit bitmap has 3 chunks (red, green, and blue)
		for (int32 c = chunks; c > 0; --c)
		{
			uchar plane_mask = 1;
			// Create 8 bitplanes
			for (int32 b = 0; b < 8; ++b)
			{
				// Do all pixels in one row
				for (UWORD x = 0; x < row_len * 8; x += 8)
				{
					uchar plane_byte = 0;
					int32 place = x * skip + c - 1;

					// Let's do 8 bits in one go!
					if ((x     < bmh.w) && (line_buffer[place           ] & plane_mask)) plane_byte |= 0x80;
					if ((x + 1 < bmh.w) && (line_buffer[place + skip    ] & plane_mask)) plane_byte |= 0x40;
					if ((x + 2 < bmh.w) && (line_buffer[place + skip * 2] & plane_mask)) plane_byte |= 0x20;
					if ((x + 3 < bmh.w) && (line_buffer[place + skip * 3] & plane_mask)) plane_byte |= 0x10;
					if ((x + 4 < bmh.w) && (line_buffer[place + skip * 4] & plane_mask)) plane_byte |= 0x08;
					if ((x + 5 < bmh.w) && (line_buffer[place + skip * 5] & plane_mask)) plane_byte |= 0x04;
					if ((x + 6 < bmh.w) && (line_buffer[place + skip * 6] & plane_mask)) plane_byte |= 0x02;
					if ((x + 7 < bmh.w) && (line_buffer[place + skip * 7] & plane_mask)) plane_byte |= 0x01;

					// Set one byte of bitplane data
					*in_plane_buffer = plane_byte;
					++in_plane_buffer;
				}

				plane_mask <<= 1;

				if (bmh.compression == cmpByteRun1)
				{
					// Compress each bitplane row separately
					ssize_t size = RunLengthEncode(
						reinterpret_cast<signed char *>(in_rle_buffer),
						reinterpret_cast<signed const char *>(plane_buffer),
						row_len);
					rle_size += size;
					in_rle_buffer += size;
					in_plane_buffer = plane_buffer;
				}
			}
		}

		// Write out a whole pixel row
		if (bmh.compression == cmpByteRun1)
		{
			alive = outStream.Write(rle_buffer, rle_size) == rle_size;
			rle_body_size += rle_size;
		}
		else  // No compression
		{
			if (chunks > 0)
			{
				ssize_t size = row_len * chunks * 8;
				alive = outStream.Write(plane_buffer, size) == size;
			}
			else  // B_MONOCHROME_1_BIT
			{
				alive = outStream.Write(line_buffer, row_len) == row_len;
			}
		}
	}

	if (bmh.compression == cmpByteRun1)
	{
		// An uneven chunk has to be padded
		if (alive && (rle_body_size & 1))
		{
			const char pad_char = '\0';
			alive = outStream.Write(&pad_char, 1) == 1;
			++rle_body_size;
		}

		// Write new IFF and BODY chunk size
		if (alive)
		{
			Int32ToRaw(base_size + rle_body_size, four_bytes);
			alive = outStream.WriteAt(4, four_bytes, 4) == 4;
		}
		if (alive)
		{
			Int32ToRaw(rle_body_size, four_bytes);
			alive = outStream.WriteAt(body_pos, four_bytes, 4) == 4;
		}
	}

	delete[] line_buffer;
	delete[] plane_buffer;
	delete[] rle_buffer;

	return alive;
}


// Datatype identify function
status_t
Identify(
	BPositionIO &		inSource,
	const Format *		inFormat,
	BMessage *			/*ioExtension*/,
	DATAInfo &			outInfo,
	uint32				outType)
{
	if (outType && outType != DATA_BITMAP && outType != ILBM_FORMAT)
		return DATA_NO_HANDLER;

	// Check if it is IFF ILBM
	IffInfo iffInfo;
	if (ProcessChunks(inSource, inSource, &iffInfo))
	{
		inFormat = &inputFormats[0];
		// Fill in some fancy format information
		sprintf(
			outInfo.formatName,
			"%s, %d %s%s",
			inputFormats[0].formatName,
			iffInfo.depth,
			iffInfo.depth == 1 ? "plane" : "planes",
			iffInfo.ham ? " HAM" : "");
	}
	else
	{
		// Check if it is DATA_BITMAP
		char data[32];
		if (inSource.ReadAt(0, data, 32) != 32)
			return DATA_NO_HANDLER;

		DATABitmap *hdr = reinterpret_cast<DATABitmap *>(data);
		if (hdr->magic == DATA_BITMAP &&
		    hdr->bounds.IsValid() &&
		    hdr->rowBytes >= 4 && (hdr->rowBytes & 3) == 0 &&
		    (hdr->colors == B_RGB_32_BIT ||
		     hdr->colors == B_COLOR_8_BIT ||
		     hdr->colors == B_MONOCHROME_1_BIT) &&
		    hdr->dataSize == (hdr->bounds.bottom - hdr->bounds.top + 1) * hdr->rowBytes)
		{
			inFormat = &inputFormats[1];
			strcpy(outInfo.formatName, inputFormats[1].formatName);
		}
		else
		{
			return DATA_NO_HANDLER;
		}
	}

	// Set the DATAInfo to the recognized type
	outInfo.formatType = inFormat->type;
	outInfo.formatGroup = inFormat->t_cls;
	outInfo.formatQuality = inFormat->quality;
	outInfo.formatCapability = inFormat->capability;
	strcpy(outInfo.MIMEName, inFormat->MIME);

	return B_OK;
}


// Datatype translate function
status_t
Translate(
	BPositionIO &       inStream,
	const DATAInfo &    inInfo,
	BMessage *          /*ioExtension*/,
	uint32              outFormat,
	BPositionIO &       outStream)
{
	if (outFormat == 0)
		outFormat = DATA_BITMAP;

	if (inInfo.formatType == ILBM_FORMAT && outFormat == DATA_BITMAP)
	{
		if (ProcessChunks(inStream, outStream, 0))
			return B_NO_ERROR;
	}

	if (inInfo.formatType == DATA_BITMAP && outFormat == ILBM_FORMAT)
	{
		if (WriteIff(inStream, outStream))
			return B_NO_ERROR;
	}

	return DATA_NO_HANDLER;
}


// Datatype config make function
status_t
MakeConfig(
	BMessage * /*ioExtension*/,
	BView * &  outView,
	BRect &    outExtent)
{
	outView = new IFFConfigView();
	outView->ResizeToPreferred();
	outExtent = outView->Bounds();

	return B_OK;
}
