#include <InterfaceKit.h>

#define FONT "Erich"
#define FONTSIZE 12
#define XGUTTER 10
#define YGUTTER 10
#define INNERGUTTER 10

#define HTGT_URL 1
#define HTGT_GetButton 2

#define WINWIDTH 200

class HTTPGetWindow : public BWindow {

	public:
		HTTPGetWindow( BRect frame, char *name );
	virtual void MessageReceived( BMessage *msg );
	virtual bool QuitRequested();
	virtual void SaveRequested( record_ref dir, const char *filename );
	
	private:
		BTextControl *url;
		BButton *get;
		BView *background;
		char urlcp[256];
};
