#include "StatusWindow.h"
#include "URLSocket.h"

class URLStatus : public WinStatusBar
{
	public:
		URLStatus( char *url, BRect rect, record_ref bfile );
		~URLStatus();
	virtual void Stop();
	long Go();
	
	private:
		static long entry_func( void *arg );
		long entryFunc();
		thread_id my_thread;
		URLSocket *sock;
		char urlcp[256];
		BFile file;
};
