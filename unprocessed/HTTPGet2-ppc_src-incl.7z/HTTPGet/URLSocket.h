#include "NetSocket.h"
#include <string.h>
#include <stdio.h>

class URLSocket : public NetSocket {
	
	public:
		URLSocket( char *url );
		char *Path()
		{
			return( path );
		}
	private:
		char path[MAXPATHLEN];
};
