#include <Application.h>
#include <InterfaceKit.h>

#include "HTTPGetWindow.h"
#include "URLStatus.h"

char *getfilename( char *url );

class HTTPGetApplication : public BApplication {
	public:
		HTTPGetApplication();
	virtual void AboutRequested();
	virtual void MessageReceived( BMessage *msg );
	void GetURL( char *url, record_ref dir, const char *filename );
		HTTPGetWindow *win;
		StatusWindow *status;
		char urlcp[256];
		char filename[256];
};
