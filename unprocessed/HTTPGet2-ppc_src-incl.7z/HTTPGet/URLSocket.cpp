#include "URLSocket.h"

URLSocket::URLSocket( char *url )
{
	char turl[MAXPATHLEN];
	char scheme[50], host[MAXPATHLEN];
	int port;
	char *slash, *colon;
	char *delim;
	char *t;
	
	strcpy(turl, url);

	delim = "://";

	if ((colon = strstr(turl, delim)) == NULL)
	{
		strcpy(scheme, "http");
		t = turl;
	}
	else
	{
		*colon = '\0';
		strcpy(scheme, turl);
		t = colon + strlen(delim);
	}

	/* Now t points to the beginning of host name */

	if ((slash = strchr(t, '/')) == NULL) {
		/* If there isn't even one slash, the path must be empty */
		strcpy(host, t);
		strcpy(path, "/");
	} else {
		strcpy(path, slash);
		*slash = '\0';	/* Terminate host name */
		strcpy(host, t);
	}

	/* Check if the hostname includes ":portnumber" at the end */

	if ((colon = strchr(host, ':')) == NULL) {
		port = 80;	/* HTTP standard */
	} else {
		*colon = '\0';
		port = atoi(colon + 1);
	}
	SetHostPort( host, port );
}
