//Thread-safe version of localtime, to be used until Be gets around to implementing localtime_r
#ifndef _SGB_SAFE_TIME_H_
#define _SGB_SAFE_TIME_H_


//******************************************************************************************************
//****SYSTEM HEADER FILES
//******************************************************************************************************
#include <time.h>


//******************************************************************************************************
//****FUNCTION DECLARATIONS
//******************************************************************************************************
bool InitSafeTime();
void Safe_localtime(time_t source_timeval,struct tm* dest_brokendowntime);


#endif