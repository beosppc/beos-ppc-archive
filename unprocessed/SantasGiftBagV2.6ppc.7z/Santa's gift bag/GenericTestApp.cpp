//Generic test app framework
#include <Application.h>
#include <Window.h>

class GenericApp : public BApplication
{
	public:
		GenericApp();
		~GenericApp();
};

class GenericWindow : public BWindow
{
	public:
		GenericWindow();
		~GenericWindow();
};

int main()
{
	new GenericApp;
	be_app->Run();
	delete be_app;
}

GenericApp::GenericApp()
: BApplication("application/x-vnd.BT-Generic")
{
	new GenericWindow;
}

GenericApp::~GenericApp()
{ }

GenericWindow::GenericWindow()
: BWindow(BRect(50,50,450,450),"Generic test window",B_TITLED_WINDOW,0)
{
	//Add your test code here

	Show();
}

GenericWindow::~GenericWindow()
{
	be_app->PostMessage(B_QUIT_REQUESTED);	
}
