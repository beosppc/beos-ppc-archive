#ifndef _SGB_GET_STRINGS_MAX_WIDTH_H_
#define _SGB_GET_STRINGS_MAX_WIDTH_H_

#include <SupportDefs.h>

float GetStringsMaxWidth(const char** Strings,int32 NumberOfStrings,const BFont* Font,
	float* StringWidths = NULL);
//Fills the StringsWidths array with the width of each individual string in the array using 
//BFont::GetStringWidths(), then finds the longest string width in the array and returns that width.

#endif