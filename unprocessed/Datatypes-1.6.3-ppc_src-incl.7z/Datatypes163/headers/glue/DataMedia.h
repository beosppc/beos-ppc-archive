/*	DataMedia.h
 *	Copyright � 1996-1997 Jon Watte
 *	datatypes@mindcontrol.org
 *
 *	This format is the "standard" interchange format for streaming media, such as video, 
 *	animation and/or sound interleaved, in the context of Datatypes.lib. It is designed to 
 *	be easy to read and write without seeking, more than for performance or capabilities 
 *	- for instance, no compression.
 *	We also do NOT use DATA_BITMAP or DATA_SOUND chunks, because those do 
 *	not conform to the magic-headersize-datasize-position header layout, and also use 
 *	floating point numbers in headers which may or may not be portable across platforms.
 *	The well-defined byte order is big endian (68K, PPC) at least for now.
 *
 *	To use the classes defined herein, you will have to include the source file DataVideo.cpp 
 *	in your application; it's not part of Datatypes.lib.
 */

#pragma once


#if !defined(_DATAMEDIA_H_)
#define _DATAMEDIA_H_

#include <SupportDefs.h>
#include <DataIO.h>


/*	The media format is built for streaming. While it is legal for datatypes 
 *	to seek in their output streams, applications may not deal well with a 
 *	datatype that does so. Thus, you are STRONGLY encouraged to thread the 
 *	output stream as non-seekable when you write DATA_MEDIA output!
 */

enum { MEDIA_START_MAGIC = 'mhi!' };
struct MediaStreamHeader {
	uint32		magic;			/*	MEDIA_START_MAGIC	*/
	uint32		headersize;		/*	size of this header (20 for now)	*/
	uint32		datasize;		/*	size of data (not including header)	*/
	uint32		ticksstart; 	/*	media clock when file was started
								 *	Typically you'd want it as 0, but other values are OK
								 *	Even though each chunk has its own timestamp, they are 
								 *	expected to never be decreasing	*/
	uint32		tickspersec;	/*	speed of stream
								 *	The convention is to use one of the values 1000, 44100 or 48000
								 *	and ALWAYS use the sound sample rate if there is sound...	*/
/*	ulong		tagsrequired[datasize/sizeof(ulong)];
 *	here, you write each tag that you think you will use in the file.
 */
};

/*	MEDIA_BITMAP_HEADER is a special bitmap header that contains information about 
 *	the coming bitmap frames. It defines the preferred color space, the total size of the frame, 
 *	and the rowbytes to use at that size.
 *	This is used because the first BITMAP_CHUNK may not encompass all of the desired 
 *	frame size.
 *	MEDIA_BITMAP_HEADER uses the MediaBitmapHeader struct for this purpose, but 
 *	contains no data after the header.
 */
enum { MEDIA_BITMAP_HEADER = 'bmbh' };
/*	MEDIA_BITMAP_CHUNK describes a sub-part of the total image to be displayed.
*	It can be a sub-part of the desired image or frame.
*/
enum { MEDIA_BITMAP_CHUNK = 'mbmc' };
enum {	/*	encodings for the "space" header value	*/
	MEDIA_8_BIT_FIXED = 8,
	MEDIA_8_BIT_GRAY  = 9,
	MEDIA_8_BIT_PALETTE = 10,
	MEDIA_32_BIT_BGRA = 32,
	MEDIA_32_BIT_ARGB = 32+256,
	MEDIA_16_BIT_BGRA = 16,
	MEDIA_16_BIT_ARGB = 16+256
};
struct MediaBitmapHeader {
	uint32		magic;		/*	MEDIA_BITMAP_CHUNK	*/
	uint32		hdrsize;	/*	(24 for now)	*/
	uint32		datasize;	/*	same as ysize*rowbytes	*/
	int32		position;	/*	media clock when to play it	*/
	uint16		space;		/*	this would NOT be color_space values
							 *	see the enum above for values
							 */
	uint16		xpos;		/*	Where within bitmap to place data	*/
	uint16		ypos;		/*	Where within bitmap to place data	*/
	uint16		xsize;		/*	number of pixels	*/
	uint16		ysize;		/*	number of rows	*/
	uint16		rowbytes;	/*	bytes per row in media (typically multiple of 4) */
/*	uchar		data[ysize][rowbytes];
 *	here, you write the data of the bitmap image
 */
};

/*	For the MEDIA_8_BIT_PALETTE MediaBitmapHeader (which is not really 
 *	recommended, but put in here due to popular pressure) you should precede 
 *	the first frame (and any other frame for which you want a change of palette) 
 *	with this header. The reader, when reading the stream and finding this chunk, 
 *	will immediately change the palette to the one specified there. Typically, it 
 *	should have the same "position" as the MediaBitmapHeader.
 */
enum { MEDIA_PALETTE_CHUNK = 'mpac' };
struct MediaPaletteHeader {
	uint32		magic;
	uint32		hdrsize;
	uint32		datasize;
	int32		position;
	int32		numcolors;
	uint16		space;		/*	tells order and format of colors - 32_BIT or 16_BIT values only	*/
/*	uchar		data[numcolors][entrysize(space)];
 *	here, you write the values for the palette. The palette will take effect for each MEDIA_BITMAP_CHUNK 
 *	frame after this.
 */
};

/*	MEDIA_SOUND_HEADER defines what the total sound track will look like.
*	It uses the same struct MediaSoundHeader as MEDIA_SOUND_CHUNK, but no 
*	data. This is an optional header to prepare the player for what'll come.
*/
enum { MEDIA_SOUND_HEADER = 'smnh' };

/*	MEDIA_SOUND_CHUNK contains actual sound data to play. Due to rounding 
 *	error in "position", any MEDIA_SOUND_CHUNK that appears to have a gap 
 *	of only one sample should be considered playable end-to-end with the previous 
 *	sound chunk.
 */
enum { MEDIA_SOUND_CHUNK = 'msnc' } ;
struct MediaSoundHeader {
	uint32		magic;		/*	MEDIA_SOUND_CHUNK	 */
	uint32		hdrsize;	/*	(24 for now)	*/
	uint32		datasize;	/*	divide by channels times padfunc(samplebits) to get number of frames	*/
	int32		position;	/*	media clock when to play it	*/
	int32		samplerate;	/*	44100 or 48000 mostly	*/
	int16		channels;	/*	2 for stereo, left first	*/
							/*	same as "number samples per samplerate frame".	*/
	int16		samplebits;	/*	bits per sample - stored in low order bits, padded 	*/
							/*	to even power of two sized samples	*/
							/*	8 -> 1 byte per sample	*/
							/*	12 -> 2 bytes per sample	*/
							/*	16 -> 2 bytes per sample	*/
							/*	24 -> 4 bytes per sample	*/
							/*	Always linear encoding	*/
/*	uchar		data[datasize/<framesize>][channels][padfunc(samplebits)]
 *	<framesize> = padfunc(samplebits)*channels
 *	here, you write sound data
 */
};

/*	For loops (and markers, really) you can emit this chunk. 
 *	A good place to do it is in immediate vincinity of the chunk that starts the loop
 *	Readers should beware that a loop chunk may precede a data chunk it relates 
 *	to; this will violate the general principle of monotonically increasing chunk 
 *	start times. However, this is the way developers have said they want it.
 */
enum { MEDIA_LOOP_CHUNK = 'mlop' };
struct MediaLoopHeader {
	uint32		magic;			/*	MEDIA_LOOP_CHUNK	*/
	uint32		hdrsize;		/*	24 for now	*/
	uint32		datasize;		/*	strlen(loopname)+1	*/
	int32		position;		/*	Where to start looping	*/
	int32		end;			/*	Where to loop back from	*/
	int32		loopcount;		/*	0 == user starts, no looping
								 *	1 == auto-start, no looping
								 *	2+ == auto-start, loop this many times
								 *	-1 == loop infinite
								 */
/*	char			loopname[datasize];
 *	zero-terminated loop name string
 */
};


enum { MEDIA_END_MAGIC = 'mbye' };
struct MediaStreamTrailer {
	uint32		magic;		/*	MEDIA_END_MAGIC	*/
	int32		headersize;	/*	(20 for now)	*/
	int32		datasize;	/*	size of text (not zero-terminated) that follows	*/
	int32		endtime;	/*	media clock when file done	*/
	int32		numframes;	/*	number of "major" frames; typically number of video 	*/
/*	char		textinfo[datasize];
 *	This is an arbitrarily-sized "comment" field where copyrights, human-readable information, 
 *	notes, ... whatever can be stored. It is not zero-terminated.
 */
};


#if defined(__cplusplus) && defined(__BEOS__)

#include <OS.h>			/*	for sem_id and thread_id	*/

class BBitmap;

/*	This simple utility class will write a standard baseline media stream for you.
 */
class MEDIAWriter {
public:
					MEDIAWriter(
						BPositionIO &		outstream,
						int32			samplerate = 44100,
						bool			usesvideo = true,
						bool			usessound = false);
					~MEDIAWriter();
	void			SetComment(
						const char *	comment);

	int32			PutBitmap(
						BBitmap *		bitmap,
						int32			afterSamples = 4410);	/*	delay BEFORE bitmap triggers	*/
	int32			PutBitmapHeader(
						BRect			area,
						color_space		space,
						int32			rowbytes);
	int32			PutBitData(
						const void *	bits,
						int32			rowBytes,
						int32			xsize,
						int32			ysize,
						int32			numCols,
						int32			numRows,
						color_space		space,
						int32			afterSamples = 4410);	/*	delay BEFORE bitmap triggers	*/
	int32			PutSound(
						const void *	data,
						int32			numsamples,				/*	delay AFTER sound triggers	*/
						int32			numchannels = 2,
						int32			samplebits = 16);
	/*	typically, do PutSound() for a second or so of audio; then PutBitmap() for the 
		bitmaps for that second, then another PutSound(), etc until you're done	*/
protected:
	BPositionIO &		fOutput;
	int32			fSampleRate;
	int32			fBitmapCount;
	int32			fSoundCount;
	int32			fLastBitmapClock;
	int32			fNextSoundClock;
	int32			fLastSoundClock;
	char *			fComment;
};


/*	MEDIANotifier is defined for use by MEDIAReaderStream.
 *	MEDIAReaderStream will call the various hooks in the MEDIANotifier passed to its 
 *	constructor as data arrives.
 */
class MEDIANotifier {
public:
					MEDIANotifier() { }
virtual				~MEDIANotifier() { }

virtual	void		BitmapCreated(
						BBitmap			*theBitmap) = 0;
virtual	void		BitmapUpdated(
						BBitmap			*theBitmap,
						int32			xPos,
						int32			yPos,
						int32			xSize,
						int32			ySize) = 0;
virtual	void		AudioSetup(
						int32			samplerate,
						int32			channels,
						int32			bits) = 0;
virtual	void		AudioReceived(
						const void		*audioData,
						int32			bufferSize,
						int32			samplerate,
						int32			channels,
						int32			bits) = 0;
virtual	void		StreamEnded() = 0;
};

/*	DefaultNotifier is a stock object that is suitable to pass into MEDIAReaderStream. 
 *	It takes a view in which it will draw as argument, and it can optionally resize this 
 *	view once the size of the frame is known.
 *	It can also start the AudioSubscriber business all by itself; no user intervention 
 *	needed.
 */
class DefaultNotifier :
	public MEDIANotifier
{
		BView		*fView;
		bool		fResize;
		bool		fHasFinished;
public:
					DefaultNotifier(
						BView			*view,
						bool			resize = false,
						bool			wantAudio = false);
					~DefaultNotifier();

		bool		HasFinished();

virtual	void		BitmapCreated(
						BBitmap			*theBitmap);
virtual	void		BitmapUpdated(
						BBitmap			*theBitmap,
						int32			xPos,
						int32			yPos,
						int32			xSize,
						int32			ySize);
virtual	void		AudioSetup(
						int32			samplerate,
						int32			channels,
						int32			bits);
virtual	void		AudioReceived(
						const void		*audioData,
						int32			bufferSize,
						int32			samplerate,
						int32			channels,
						int32			bits);
virtual	void		StreamEnded();
};

/*	This stream is useful when translating into DATA_VIDEO, if you want to immediately 
 *	"play" the data you're importing. Note that it doesn't handle translators that Seek() or 
 *	SetSize() the output stream, which makes it just a toy, really. Useful for verifying 
 *	translators you write, though.
 */
class MEDIAReaderStream :
	public BPositionIO			/*	this class not yet updated to PR	*/
{
public:
						MEDIAReaderStream(
							MEDIANotifier	*notifier) throw(int32);
						~MEDIAReaderStream();

		ssize_t			ReadAt(	//	returns bytes read
							off_t			pos,
							void *			buffer,
							size_t		size);
		ssize_t			WriteAt(	//	returns bytes written
							off_t			pos,
							const void *	data,
							size_t			size);
		off_t			Seek(	//	returns position seeked to
							off_t			position,
							uint32			whence);
		off_t			Position() const; // returns position
		off_t			Size() const; // returns total size
		status_t		SetSize(	//	returns 0 for success
							off_t			size);

		BBitmap			*DetachBitmap();

protected:

		void			*fData;
		size_t			fDataPhys;
		size_t			fDataLog;
		size_t			fPosition;
		bigtime_t		fPlayBaseTime;
		bigtime_t		fTicksPerSec;

		int32			lastsamplerate;
		int32			lastchannels;
		int32			lastbits;
		int32			bitmapx;
		int32			bitmapy;
		BBitmap			*fBitmap;
		MEDIANotifier	*fNotifier;
		uint32			fPalette[256];
		bool			fDetached;

virtual	void			HandleChunk(					/*	override to handle chunks not handled by this	*/
							uint32			magic,		/*	chunk type out of header	*/
							const void		*header,	/*	header			*/
							const void		*data,		/*	data after header		*/
							int32			dataSize);	/*	size of data block		*/
virtual	void			NapTime(						/*	snooze until header item is supposed to be played	*/
							const void		*header);	/*	you can override to, say, do free run, or alter playback speed	*/

private:

		/*	These are used by the implementation of the bitmap playback	*/
		void			ResizeBitmap(
							MediaBitmapHeader	*header);
		void			ParseBitmapData(
							MediaBitmapHeader	*header,
							const void			*data,
							int32				datasize);
		void			InitPalette();	/*	Called from constructor	*/
		void			SetPalette(
							MediaPaletteHeader	*header,
							const void			*data,
							int32				size);
};

#endif	//	__BEOS__

#endif	//	_DATAMEDIA_H_
