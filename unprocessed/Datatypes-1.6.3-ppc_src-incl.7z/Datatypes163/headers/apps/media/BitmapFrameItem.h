/*	BitmapFrameItem.h	*/

#pragma once

#include "FrameItem.h"


class BitmapFrameItem :
	public FrameItem
{
public:
		BBitmap					*fMap;

								BitmapFrameItem(
									BBitmap			*map,
									const char		*name,
									long			delay);
								~BitmapFrameItem();

		bool					Edit(
									BListView		*list,
									long			index);

};
