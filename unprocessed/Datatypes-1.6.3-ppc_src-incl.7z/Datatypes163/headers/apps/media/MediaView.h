/*	MediaView.h	*/


#pragma once

#include <ListView.h>

class FrameItem;

class MediaView :
	public	BListView
{
public:
								MediaView(
									BRect		area);
								~MediaView();

		void					AttachedToWindow();

		void					DrawItem(
									BRect		updateRect,
									long		index);
		void					MessageReceived(
									BMessage	*message);

		bool					SaveTo(
									BFile		&file);
		void					RecalcItemTotals(
									FrameItem	*item,
									long		atIndex);

private:

		void					ClearAll();
		bool					ReadFile(
									record_ref	ref,
									long		asItem);

};
