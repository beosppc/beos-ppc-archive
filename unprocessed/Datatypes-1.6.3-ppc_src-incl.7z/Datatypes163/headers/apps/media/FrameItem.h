/*	FrameItem.h	*/
/*	Abstract superclass of all items that are handled	*/

#pragma once


class FrameItem :
	public BObject
{
public:
		long					fTicksDuration;
		long					fRunningTotal;
		char					fName[B_FILE_NAME_LENGTH];
		unsigned long			fType;	/*	needed for time merge info	*/

								FrameItem()
								{
									fTicksDuration = 0;
									fRunningTotal = 0;
									fName[0] = 0;
									fType = 0;
								}
								~FrameItem()
								{
								}

		virtual bool			Edit(
									BListView			*view,
									long				yourIndex) = 0;
};
