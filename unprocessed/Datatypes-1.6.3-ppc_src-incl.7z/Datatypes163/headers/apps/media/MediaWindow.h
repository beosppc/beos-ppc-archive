/*	MediaWindow.h	*/

#pragma once


#include <Window.h>

class MediaView;
class FrameItem;

enum {
	MEDIA_SAVE = 'm000',
	MEDIA_MAKE,
	MEDIA_MAKE_PANEL,
	MEDIA_MAKE_REPLY,
	MEDIA_PLAY,
	MEDIA_EDIT,
	MEDIA_REMOVE
};

class MediaWindow : public BWindow {

		MediaView					*fView;

public:

									MediaWindow(
										const char			*title);
									~MediaWindow();

		void						SaveRequested(
										record_ref			directory,
										const char			*name);
		void						MessageReceived(
										BMessage			*message);
		void						MenusWillShow();

private:

		void						EnableItem(
										unsigned long		command,
										bool				enabled);
		void						MakeViews();

		void						Edit();
		void						Remove();
		void						MakeMovie();
		void						DoMakeMovie(
										BMessage			*message);
		void						Play();
};
