/*	AppMakeView.h
 *	The workhorse function that calls Datatypes.lib to find out what a file really is,
 *	and if it knows the base format, creates an appropriate display view.
 */

#pragma once

#include "Datatypes.h"
class BPositionIO;

/*	The main work function */
extern long AppMakeView(
				BPositionIO *		inStream,
				BView * &		outView,
				BRect &			outExtent,
				const char *	hintMIME,
				char * &		outDataInfo);	//	call delete[]



/*	Helper functions */
extern long AppMakeTextView(
				BView * &		outView,
				BRect &			outExtent,
				BPositionIO &		stream,
				DATAInfo &		info);
extern long AppMakeBitmapView(
				BView * &		outView,
				BRect &			outExtent,
				BPositionIO &		stream,
				DATAInfo &		info);
extern long AppMakePictureView(
				BView * &		outView,
				BRect &			outExtent,
				BPositionIO &		stream,
				DATAInfo &		info);
extern long AppMakeMediaView(
				BView * &		outView,
				BRect &			outExtent,
				BPositionIO &		stream,
				DATAInfo &		info);
