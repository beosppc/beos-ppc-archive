/*	MediaPlayerView.h	*/

#pragma once

#include <View.h>
#include "DataMedia.h"
#include <OS.h>
#include "Datatypes.h"
#include <DataIO.h>



class MEDIAReaderStream;
class DefaultNotifier;


class MediaPlayerView :
	public BView
{
public:
								MediaPlayerView(
									BRect			area,
									BPositionIO			*input,
									const DATAInfo	&info);
								~MediaPlayerView();
		void					Draw(
									BRect			area);
		void					MouseDown(
									BPoint			where);
private:
		DATAInfo				fInfo;
		BBitmap					*fBitmap;
		BPositionIO					*fInput;
		MEDIAReaderStream		*fOutput;
		DefaultNotifier			*fNotifier;
		bool					fIsPlaying;
		thread_id				fThread;

static	long					ThreadFunc(
									void			*data);
};
