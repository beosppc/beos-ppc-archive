/*	PictureView.h
 */

#pragma once

#include <View.h>

class BPicture;

class PictureView :
	public BView
{
public:
								PictureView(
									BRect area,
									BPicture *pic);
								~PictureView();

		void					SetOwnership(
									bool			own);
		bool					GetOwnership();
		void					SetPicture(
									BPicture *		map);
		BPicture *				GetPicture();
		void					SetAdjustBars(
									bool			adjusts);
		bool					GetAdjustBars();

		void					Draw(
									BRect			area);
		void					FrameResized(
									float			newWidth,
									float			newHeight);
protected:

		BPicture *				fPicture;
		bool					fAdjustBars;
		bool					fOwnership;

		void					AdjustBars();
};
