/*	prefix.h	*/

#pragma once

#if defined(__cplusplus)
	#include <BeHeaders>
#endif

#define DEBUG 1
#include <Debug.h>
