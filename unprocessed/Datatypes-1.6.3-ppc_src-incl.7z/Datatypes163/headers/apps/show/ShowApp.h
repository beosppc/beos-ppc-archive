//	ShowApp.h

#pragma once

#include <Application.h>


class ShowApp :
	public BApplication
{
public:
								ShowApp(
									const char *	signature);

		void					RefsReceived(
									BMessage *		message);

		void					Pulse();
};
