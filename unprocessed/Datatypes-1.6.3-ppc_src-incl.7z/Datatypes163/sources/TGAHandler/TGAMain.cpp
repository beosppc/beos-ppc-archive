/*	TGAMain.cpp	*/


#include "DataHandler.h"

#include <Application.h>
#include <Window.h>
#include <Alert.h>
#include <stdlib.h>


class TGAWindow :
	public BWindow
{
public:
								TGAWindow(
									BRect			area,
									const char *	title,
									window_type		kind,
									uint32			flags);
		bool					QuitRequested();
};

TGAWindow::TGAWindow(
	BRect			area,
	const char *	title,
	window_type		kind,
	uint32			flags) :
	BWindow(area, title, kind, flags)
{
}


bool
TGAWindow::QuitRequested()
{
	be_app->PostMessage(B_QUIT_REQUESTED);
	return true;	/*	we will die!		*/
}


void
main()
{
	BApplication app("application/x-tga-handler");
	TGAWindow *window = new TGAWindow(BRect(100,100,400,300), 
		"TGA Settings", B_TITLED_WINDOW, B_NOT_RESIZABLE | B_NOT_ZOOMABLE);
	BView *config = NULL;
	BRect extent(0,0,300,200);
	status_t err = MakeConfig(NULL, config, extent);
	if ((err < B_OK) || (config == NULL))
	{
		BAlert *alrt = new BAlert("No Config", "TGAHandler does not currently support user configuration.", "Quit");
		alrt->Go();
		exit(1);
	}
	window->ResizeTo(extent.Width(), extent.Height());
	window->AddChild(config);
	window->Show();
	app.Run();
}
