/*	TGAHandler.cpp	*/
/*	Datatypes translator for the Targa format	*/
/*	Targa does 16bpp and 32bpp with alpha, too. We don't, at least not yet.	*/

#include <InterfaceDefs.h>
#include <Debug.h>
#include <Rect.h>
#include <View.h>
#include <StringView.h>
#include <string.h>
#include <stdio.h>
#include <Mime.h>
#include <unistd.h>
#include <stdlib.h>

#include "DataHandler.h"
#include "Datatypes.h"
#include <DataIO.h>


#define	VERSION	"v1.1.0"
#define	EMAIL	"<datatypes@mindcontrol.org>"


char			handlerName[] = "TGAHandler";		//	required, C string, ex "Jon's Sound"
char			handlerInfo[] = "Targa file format handler " VERSION " " EMAIL;		//	required, descriptive C string, ex "Jon's Sound Handler (shareware $5: hplus@ix.netcom.com) v1.00"
int32			handlerVersion = 110;		//	required, integer, ex 100

static	int	debug = 0;


/*
	uint32		type;						//	BeOS data type
	uint32		t_cls;						//	class of this format
	float		quality;					//	format quality 0.0-1.0
	float		capability;					//	handler capability 0.0-1.0
	char		MIME[B_MIME_TYPE_LENGTH+11];	//	MIME string
	char		formatName[B_MIME_TYPE_LENGTH+11];	//	only descriptive
*/
Format			inputFormats[] = {
	{ 'TGA ', DATA_BITMAP, 0.6, 0.5, "image/targa", "Targa bitmap format" },
	{ DATA_BITMAP, DATA_BITMAP, 0.4, 0.6, "image/x-be-bitmap", "Be Bitmap Format" },
	{ 0, 0, 0, 0, 0, 0 },
};		//	optional (else Identify is always called)

Format			outputFormats[] = {
	{ 'TGA ', DATA_BITMAP, 0.6, 0.5, "image/targa", "Targa bitmap format" },
	{ DATA_BITMAP, DATA_BITMAP, 0.4, 0.6, "image/x-be-bitmap", "Be Bitmap Format" },
	{ 0, 0, 0, 0, 0, 0 },
};	//	optional (else Translate is called anyway)



//	This is the header of the Targa file format
//	We only recognize version 1 and 2, and not 16 bit data or less than 8 bit data at that
	struct TargaHeader {
		uchar		cmtlen;
		uchar		maptype;
		uchar		version;
		uchar		cmap_origin;
		uchar		cmap_origin_hi;
		uchar		cmap_size;
		uchar		cmap_size_hi;
		uchar		cmap_bits;
		ushort		left;
		ushort		top;
		ushort		width;
		ushort		height;
		uchar		pixsize;
		uchar		descriptor;
	};


	//	Return DATA_NO_HANDLER if not handling this data.
	//	Even if inputFormats exists, may be called for data without hints
	//	Ff outType is not 0, must be able to export in wanted format

status_t
Identify(	//	required
	BPositionIO &		inSource,
	const Format *		inFormat,
	BMessage *			ioExtension,
	DATAInfo &			outInfo,
	uint32				outType)
{
	//	Check that our assumptions hold water
	ASSERT(sizeof(short) == 2);
	if (sizeof(short) != 2) {
		fprintf(stderr, "TGAHandler sees sizeof(short) as %d, should be 2\n", sizeof(short));
		return B_ERROR;
	}
	union {
		char c[2];
		short s;
	} t;
	t.s=1;
	ASSERT((t.c[0] == 0) && (t.c[1] == 1));
	if (t.c[1] != 1) {
		fprintf(stderr, "TGAHandler compiled with wrong endian-ness!\n");
		return B_ERROR;
	}
	if (getenv("TGA_HANDLER_DEBUG") != NULL) debug = 1;

	//	check that we can handle the output format requested
	if ((outType != 0) && (outType != DATA_BITMAP) && (outType != 'TGA '))
		return DATA_NO_HANDLER;

	union {
		TargaHeader	data;	//	enough for a DATA_BITMAP and Targa header
		DATABitmap	bitmap;
	}	buffer;

	//	read header and see what happens
	uint32 iThink = 0;	//	set to guess of format
	status_t err;
	ssize_t size = sizeof(buffer);
	err = inSource.Read(&buffer, size);
	if ((err < B_OK) || (size != sizeof(buffer))) 
		return err;

	//	make a guess based on magic numbers
	if (buffer.bitmap.magic == DATA_BITMAP) {
		iThink = DATA_BITMAP;
	} else if (((buffer.data.version == 1) && (buffer.data.pixsize == 8)) || 
			((buffer.data.version == 2) && ((buffer.data.pixsize == 24) || (buffer.data.pixsize == 32)))) {
		iThink = 'TGA ';
		if (debug) printf("TGA, version %d, pixsize %d\n", buffer.data.version, buffer.data.pixsize);
	} else
		return DATA_NO_HANDLER;

	//	verify our guess
	if (iThink == DATA_BITMAP)
	{
		int multi = 0;
		switch (buffer.bitmap.colors)
		{
		case B_RGB_32_BIT:
		case B_BIG_RGB_32_BIT:
			multi = 4;
			break;
		case B_COLOR_8_BIT:
			multi = 1;
			break;
		default:
			return DATA_NO_HANDLER;
		}
		if ((buffer.bitmap.bounds.right <= buffer.bitmap.bounds.left) ||
				(buffer.bitmap.bounds.bottom <= buffer.bitmap.bounds.top))
			return DATA_NO_HANDLER;
		if (buffer.bitmap.rowBytes < buffer.bitmap.bounds.IntegerWidth()*multi)
			return DATA_NO_HANDLER;
		if (buffer.bitmap.dataSize < buffer.bitmap.rowBytes*buffer.bitmap.bounds.IntegerHeight())
			return DATA_NO_HANDLER;

		//	set up outInfo
		outInfo.formatType = inputFormats[1].type;
		outInfo.formatHandler = 0;
		outInfo.formatGroup = inputFormats[1].t_cls;
		outInfo.formatQuality = inputFormats[1].quality;
		outInfo.formatCapability = inputFormats[1].capability;
		sprintf(outInfo.formatName, "%s, type %d", inputFormats[1].formatName, buffer.bitmap.colors);
		strcpy(outInfo.MIMEName, inputFormats[1].MIME);

	} else {	//	Targa

		//	maptype can be 0 (no map) or 1 (palette map)
		if ((buffer.data.maptype != 0) && (buffer.data.maptype != 1))
			return DATA_NO_HANDLER;
		//	palette origin must be < 256 and size >=2 <= 256
		int porigin = buffer.data.cmap_origin + buffer.data.cmap_origin_hi*256;
		int psize = buffer.data.cmap_size + buffer.data.cmap_size_hi*256;
		if (buffer.data.pixsize < 16)
			if ((porigin > 254) || (porigin+psize > 256) || (psize < 2) || (psize > 256))
				return DATA_NO_HANDLER;
		//	descriptor must be for 0 or 8 alpha bits, plus maybe top-to-bottom
		int descriptor = buffer.data.descriptor;
		if (buffer.data.pixsize == 8) {
			//	for 8 bit, PhotoShop seems to think the palette index is an attribute
			if ((descriptor != 0) && (descriptor != 32) && (descriptor != 8) && (descriptor != 40))
				return DATA_NO_HANDLER;
			if ((buffer.data.cmap_bits != 24) && (buffer.data.cmap_bits != 32))
				return DATA_NO_HANDLER;
		} else if (buffer.data.pixsize == 24) {
			//	24 bit data should not have any alpha data
			if ((descriptor != 0) && (descriptor != 32))
				return DATA_NO_HANDLER;
		} else if (buffer.data.pixsize == 32) {
			//	32 bit data should have alpha data
			if ((descriptor != 8) && (descriptor != 40))
				return DATA_NO_HANDLER;
		} else
			return DATA_NO_HANDLER;

		outInfo.formatType = inputFormats[0].type;
		outInfo.formatHandler = 0;
		outInfo.formatGroup = inputFormats[0].t_cls;
		outInfo.formatQuality = inputFormats[0].quality;
		outInfo.formatCapability = inputFormats[0].capability;
		sprintf(outInfo.formatName, "%s, type %d (%d bits)", inputFormats[0].formatName, buffer.data.version, buffer.data.pixsize);
		strcpy(outInfo.MIMEName, inputFormats[0].MIME);
	}
	return B_OK;
}


	//	Return DATA_NO_HANDLER if not handling the output format
	//	If outputFormats exists, will only be called for those formats

static status_t
CopyLoop(
	BPositionIO &		input,
	BPositionIO &		output)
{
	size_t block = 65536L;
	void * buffer = malloc(block);
	char temp[1024];
	if (!buffer) {
		buffer = temp;
		block = 1024;
	}
	bool done = false;
	status_t err = B_OK;
	while (!done) {
		ssize_t to_read = block;
		err = input.Read(buffer, to_read);
		if (err < B_OK) break;
		done = (to_read < block);
		if (debug) printf("Write %d\n", to_read);
		err = output.Write(buffer, to_read);
		if (err < B_OK) break;
	}
	if (buffer != temp)
		free(buffer);
	return err > 0 ? B_OK : err;
}


const char tga8trailer[] = "\0\0\0\0\0\0\0\0TRUEVISION-XFILE\x2E\0";
int trailerlen = 26;

static status_t
WriteTGAPalette(
	BPositionIO &		output)
{
	//	set up system palette so TGA can read it
	const color_map *ptr = system_colors();
	unsigned char data[256*4];
	for (int ix=0; ix<256; ix++)
	{
		data[ix*4] = ptr->color_list[ix].blue;
		data[ix*4+1] = ptr->color_list[ix].green;
		data[ix*4+2] = ptr->color_list[ix].red;
		data[ix*4+3] = ptr->color_list[ix].alpha;
	}
	data[B_TRANSPARENT_8_BIT*4+3] = 255;	//	transparent index should be transparent

	//	output to stream
	if (debug) printf("Write %d\n", 1024);
	status_t err = output.Write(data, 256*4);
	if (debug) printf("Writing TGA palette returns %x\n", err);
	return err;
}


//	We work from the assumption that the DATA_BITMAP data will be "local" and that 
//	seeking will be efficient. It's either that, or assuming that the destination is always local, 
//	which might be an equally valid assumption. Oh, well.
//	We currently write TGA in 24 bit format, bottom-to-top. Writing top-to-bottom could 
//	eliminate the seeking wholly.
static status_t
CopyTGA24(
	BPositionIO &		input,
	BPositionIO &		output,
	color_space			space,
	int					xsize,
	int					ysize,
	int					rowbytes)
{
	off_t pos = input.Position();
	status_t err;
	char * buffer = (char *)malloc(xsize*4);
	if (!buffer) return B_NO_MEMORY;
	for (int ix=ysize-1; ix>=0; ix--)
	{
		err = input.Seek(pos+(off_t)ix*rowbytes, SEEK_SET);
		if (err < B_OK) break;
		ssize_t rd = xsize*4;
		err = input.Read(buffer, rd);
		if (debug) printf("Read returns %x\n", err);
		if (err < B_OK) break;
		if (rd != xsize*4)
		{
			err = B_ERROR;
			break;
		}
		char * src = buffer;
		char * dst = buffer;
		char * end = buffer+xsize*4;
		if (space == B_RGB_32_BIT)
		{
			while (src <= end) {
				uchar blue = src[0];
				uchar green = src[1];
				uchar red = src[2];
				dst[0] = blue;
				dst[1] = green;
				dst[2] = red;
				dst += 3;
				src += 4;
			}
		} else {
			while (src <= end) {
				uchar blue = src[3];
				uchar green = src[2];
				uchar red = src[1];
				dst[0] = blue;
				dst[1] = green;
				dst[2] = red;
				dst += 3;
				src += 4;
			}
		}
		if (debug) printf("Write %d\n", xsize*3);
		err = output.Write(buffer, xsize*3);
		if (debug) printf("Write returns %x\n", err);
		if (err < B_OK) break;
	}
	free(buffer);
	return (err < B_OK) ? err : B_OK;
}


//	Again, we assume the DATA_BITMAP data is the more efficient for seeking. 
//	Again, if we changed write order to top-to-bottom, we could eliminate seeking.
static status_t
CopyTGA8(
	BPositionIO &		input,
	BPositionIO &		output,
	int					xsize,
	int					ysize,
	int					rowbytes)
{
	off_t pos = input.Position();
	status_t err;
	char * buffer = (char *)malloc(xsize);
	if (!buffer) return B_NO_MEMORY;
	for (int ix=ysize-1; ix>=0; ix--)
	{
		err = input.Seek(pos+(off_t)ix*rowbytes, SEEK_SET);
		if (err < B_OK) break;
		ssize_t rd = xsize;
		err = input.Read(buffer, rd);
		if (debug) printf("Read returns %x\n", err);
		if (err < B_OK) break;
		if (rd != xsize)
		{
			err = B_ERROR;
			break;
		}
		if (debug) printf("Write %d\n", xsize);
		err = output.Write(buffer, xsize);
		if (debug) printf("Write returns %x\n", err);
		if (err < B_OK) break;
	}
	free(buffer);
	return (err < B_OK) ? err : B_OK;
}


static status_t
WriteTarga(
	BPositionIO &		input,
	BPositionIO &		output,
	BMessage *			ioExtension)
{
	TargaHeader tgaheader;

	//	find the comment, if any
	char * comment = "";
	if (ioExtension != NULL)
		if (ioExtension->FindString(kCommentExtension, &comment))
			comment = "";

	//	read bitmap header
	DATABitmap bmheader;
	status_t err;
	ssize_t size = sizeof(bmheader);
	err = input.Read(&bmheader, size);
	if (err < B_OK) return err;
	if (size != sizeof(bmheader)) return B_ERROR;

	//	Create tga header and reserve output space.
	//	A network socket stream can be smart enough to always return OK for SetSize() and only do 
	//	buffering when it's really needed.
	switch (bmheader.colors) {
	case B_COLOR_8_BIT:
		tgaheader.maptype = 1;
		tgaheader.version = 1;
		err = output.SetSize((off_t)sizeof(tgaheader)+((off_t)bmheader.bounds.IntegerHeight()+1)*
				((off_t)bmheader.bounds.IntegerWidth()+1)+trailerlen);	//	8 bit files end in a magic string
		tgaheader.cmap_origin = 0;
		tgaheader.cmap_origin_hi = 0;
		tgaheader.cmap_size = 0;
		tgaheader.cmap_size_hi = 1;
		tgaheader.cmap_bits = 32;	//	we write alpha in palette
		tgaheader.pixsize = 8;
		tgaheader.descriptor = 0;
		break;
	case B_RGB_32_BIT:
	case B_BIG_RGB_32_BIT:
		tgaheader.maptype = 0;
		tgaheader.version = 2;
		err = output.SetSize((off_t)sizeof(tgaheader)+((off_t)bmheader.bounds.IntegerHeight()+1)*
				((off_t)bmheader.bounds.IntegerWidth()+1)*3+strlen(comment)+trailerlen);
		tgaheader.cmap_origin = 0;
		tgaheader.cmap_origin_hi = 0;
		tgaheader.cmap_size = 0;
		tgaheader.cmap_size_hi = 0;
		tgaheader.cmap_bits = 0;
		tgaheader.pixsize = 24;
		tgaheader.descriptor = 0;
		break;
	}
	if (err < B_OK) return err;

	int cmtlen = strlen(comment);
	if (cmtlen > 255) cmtlen = 255;
	tgaheader.cmtlen = cmtlen;

	tgaheader.left = tgaheader.top = 0;
	write_16_swap((int16*)&tgaheader.width, bmheader.bounds.IntegerWidth()+1);
	write_16_swap((int16*)&tgaheader.height, bmheader.bounds.IntegerHeight()+1);

	//	output header
	if (debug) printf("Write %d\n", sizeof(tgaheader));
	err = output.Write(&tgaheader, sizeof(tgaheader));
	if (debug) printf("Write header returns %x\n", err);
	if (err < B_OK) return err;
	if (cmtlen > 0)
		err = output.Write(comment, cmtlen);
	if (debug) printf("Write comment returns %x\n", err);
	if (err < B_OK) return err;

	//	now, output data. TGA is bottom-to-top, left-to-right as we write it
	if (tgaheader.version == 2)
		//	write the 24-bit data
		err = CopyTGA24(input, output, bmheader.colors, read_16_swap((int16*)&tgaheader.width),
			read_16_swap((int16*)&tgaheader.height), bmheader.rowBytes);
	else
	{
		//	write the (fixed) system palette
		err = WriteTGAPalette(output);
		if (err < B_OK) return err;
		//	write the 8-bit data
		err = CopyTGA8(input, output, read_16_swap((int16*)&tgaheader.width),
			read_16_swap((int16*)&tgaheader.height), bmheader.rowBytes);
	}
	if (err < B_OK) return err;
	//	write the magic TRUEVISION trailer
	err = output.Seek(0, SEEK_END);
	if (debug) printf("Seek trailer returns %x\n", err);
	if (err < B_OK) return err;
	err = output.Write(tga8trailer, trailerlen);
	if (debug) printf("Write trailer returns %x\n", err);
	return err < B_OK ? err : B_OK;
}


//	assume that the bitmap is local (such as writing into a BitmapStream)
//	thus, we seek in the bitmap (output) and not in the Targa (input)
static status_t
WriteBitmap(
	BPositionIO &		input,
	BPositionIO &		output,
	BMessage *			ioExtension)
{
	TargaHeader		tgaheader;
	DATABitmap		bmheader;
	status_t		err;
	ssize_t			rd;
	uint32			palette[256];

	//	read targa header
	rd = sizeof(tgaheader);
	err = input.Read(&tgaheader, rd);
	if (err < B_OK) return err;
	if (rd != sizeof(tgaheader)) return B_ERROR;

	//	set up header
	bmheader.magic = DATA_BITMAP;
	bmheader.bounds.left = 0;
	bmheader.bounds.top = 0;
	bmheader.bounds.right = read_16_swap((int16*)&tgaheader.width)-1;
	bmheader.bounds.bottom = read_16_swap((int16*)&tgaheader.height)-1;
	bmheader.rowBytes = (bmheader.bounds.IntegerWidth()+1)*4;
	bmheader.dataSize = bmheader.rowBytes*(bmheader.bounds.bottom+1);

	//	we always output in 24 bit format, since palettes cannot be represented well in 8 bit mode
	bmheader.colors = B_RGB_32_BIT;
	if (debug) printf("Write %d\n", sizeof(bmheader));
	err = output.Write(&bmheader, sizeof(bmheader));
	if (debug) printf("Write bmheader returns %x\n", err);
	if (err < B_OK) return err;
	err = output.SetSize(bmheader.dataSize+sizeof(bmheader));
	if (debug) printf("SetSize bmheader returns %s\n", err);
	if (err < B_OK) return err;

	//	deal with comment, if any
	if (tgaheader.cmtlen) {
		char comment[256];
		ssize_t rd = tgaheader.cmtlen;
		err = input.Read(comment, rd);
		if (err < B_OK) return err;
		if (rd != tgaheader.cmtlen) return B_ERROR;
		comment[tgaheader.cmtlen] = 0;
		if (ioExtension != NULL)
			ioExtension->AddString(kCommentExtension, comment);
		if (debug) printf("comment len %d: %s\n", tgaheader.cmtlen, comment);
	}

	if (debug) printf("maptype %d\n", tgaheader.maptype);
	//	deal with color map, if any
	if (tgaheader.maptype == 1) {
		for (int ix=0; ix<256; ix++)
			palette[ix] = ix*0x01010100;	//	bgra, black to white
		ssize_t rd = tgaheader.cmap_size+256*tgaheader.cmap_size_hi;
		int nitems = rd;
		if (rd+tgaheader.cmap_origin > 256)
			return DATA_NO_HANDLER;
		rd = rd*tgaheader.cmap_bits/8;	//	read bytes
		err = input.Read(&palette[tgaheader.cmap_origin], rd);
		if (debug) printf("Read palette returns %d\n", err);
		if (err < B_OK) return err;
		if (rd != nitems*tgaheader.cmap_bits/8) return B_ERROR;
		//	adjust palette if necessary
		if (tgaheader.cmap_bits != 32) {
			uchar * ptr = (uchar *)&palette[tgaheader.cmap_origin];
			for (int ix=nitems-1; ix>=0; ix--) {
				ulong blue = ptr[ix*3];
				ulong green = ptr[ix*3+1];
				ulong red = ptr[ix*3+2];
				ptr[ix*4] = blue;
				ptr[ix*4+1] = green;
				ptr[ix*4+2] = red;
				ptr[ix*4+3] = 0;	//	no transparency
			}
		}
	}

	//	set up buffer
	uint32 * scanline = (uint32 *)malloc(bmheader.rowBytes);
	if (scanline == NULL) return B_NO_MEMORY;

	off_t pos = output.Position();

	//	use different copy loops for direct vs indexed data
	if ((tgaheader.version == 2) && ((tgaheader.pixsize == 32) || (tgaheader.pixsize == 24))) {
		int start, end, add;
		int width = read_16_swap((int16*)&tgaheader.width);
		if (debug) printf("type 2 pixsize %d\n", tgaheader.pixsize);

		if (tgaheader.descriptor & 0x20) {
			start = 0;
			end = read_16_swap((int16*)&tgaheader.height);
			add = 1;
		} else {
			start = read_16_swap((int16*)&tgaheader.height)-1;
			end = -1;
			add = -1;
		}
		while (start != end) {
			err = output.Seek(pos+bmheader.rowBytes*start, SEEK_SET);
			if (err < B_OK) { free(scanline); return err; }
			ssize_t wdata = width*tgaheader.pixsize/8;
			err = input.Read(scanline, wdata);
			if (err < B_OK) { free(scanline); return err; }
			if (wdata != width*tgaheader.pixsize/8) { free(scanline); return B_ERROR; }
			if (tgaheader.pixsize != 32) {
				ulong * dst = &scanline[width-1];
				uchar * src = ((uchar *)scanline)+3*(width-1);
				while (src >= ((uchar *)scanline)) {
					ulong val = src[0];
					val = (val << 8) | src[1];
					val = (val << 8) | src[2];
					dst[0] = (val << 8);		//	no transparency
					src -= 3;
					dst -= 1;
				}
			}
			if (debug) printf("Write %d\n", bmheader.rowBytes);
			err = output.Write(scanline, bmheader.rowBytes);
			if (err < B_OK) { free(scanline); return err; }
			start += add;
		}
	}
	else if ((tgaheader.version == 1) && (tgaheader.pixsize == 8)) {
		int start, end, add;
		int width = read_16_swap((int16*)&tgaheader.width);
		if (tgaheader.descriptor & 0x20) {
			start = 0;
			end = read_16_swap((int16*)&tgaheader.height);
			add = 1;
		} else {
			start = read_16_swap((int16*)&tgaheader.height)-1;
			end = -1;
			add = -1;
		}
		while (start != end) {
			err = output.Seek(pos+bmheader.rowBytes*start, SEEK_SET);
			if (err < B_OK) { free(scanline); return err; }
			ssize_t wdata = width;
			err = input.Read(scanline, wdata);
			if (err < B_OK) { free(scanline); return err; }
			if (wdata != width) { free(scanline); return B_ERROR; }
			//	expand pixels
			ulong * dst = &scanline[width-1];
			uchar * src = ((uchar *)scanline)+(width-1);
			while (src >= ((uchar *)scanline)) {
				ulong val = palette[src[0]];
				dst[0] = val;		//	no transparency
				src -= 1;
				dst -= 1;
			}
			//	output the 24 bit data
			if (debug) printf("Write %d\n", bmheader.rowBytes);
			err = output.Write(scanline, bmheader.rowBytes);
			if (err < B_OK) { free(scanline); return err; }
			start += add;
		}
	}
	else {
		free(scanline);
		return DATA_NO_HANDLER;
	}

	free(scanline);
	return B_OK;
}


status_t
Translate(	//	required
	BPositionIO &		inSource,
	const DATAInfo &	inInfo,
	BMessage *			ioExtension,
	uint32				outFormat,
	BPositionIO &		outDestination)
{
	if (getenv("TGA_HANDLER_DEBUG") != NULL) debug = 1;

	if (outFormat == inInfo.formatType)
		return CopyLoop(inSource, outDestination);
	else if ((outFormat == 'TGA ') && (inInfo.formatType == DATA_BITMAP))
		return WriteTarga(inSource, outDestination, ioExtension);
	else if ((outFormat == DATA_BITMAP) && (inInfo.formatType == 'TGA '))
		return WriteBitmap(inSource, outDestination, ioExtension);

	//	if it was none of the permutations we know, this ain't for us!
	return DATA_NO_HANDLER;
}


	//	right now, there is nothing to configure for this handler

	//	The view will get resized to what the parent thinks is 
	//	reasonable. However, it will still receive MouseDowns etc.
	//	Your view should change settings in the translator immediately, 
	//	taking care not to change parameters for a translation that is 
	//	currently running. Typically, you'll have a global struct for 
	//	settings that is atomically copied into the translator function 
	//	as a local when translation starts.
	//	Store your settings wherever you feel like it.

#include <StringView.h>

status_t
MakeConfig(	//	optional
	BMessage *			ioExtension,
	BView * &			outView,
	BRect &				outExtent)
{
	//	ignore config

	outView = new BView(BRect(0,0,200,150), "TGAHandler Settings", B_FOLLOW_NONE, B_WILL_DRAW);
	rgb_color gray = { 222, 222, 222, 0 };
	outView->SetViewColor(gray);

	BStringView *str = new BStringView(BRect(10,10,190,34), "title", handlerName);
	str->SetFont(be_bold_font);
	outView->AddChild(str);

	str = new BStringView(BRect(10,44,190,68), "info", VERSION " " __DATE__);
	str->SetFont(be_plain_font);
	outView->AddChild(str);

	str = new BStringView(BRect(10,69,190,93), "author", EMAIL);
	str->SetFont(be_plain_font);
	outView->AddChild(str);

	outExtent.Set(0,0,200,150);

	return B_OK;
}


	//	Copy your current settings to a BMessage that may be passed 
	//	to DATATranslate at some later time when the user wants to 
	//	use whatever settings you're using right now.

status_t
GetConfigMessage(	//	optional
	BMessage *			ioExtension)
{
	//	ignore config
	return B_OK;
}

