/*	Record.cpp	*/

#include <Datatypes.h>
#include <DataFormats.h>

#include <Application.h>
#include <Window.h>
#include <Button.h>
#include <FilePanel.h>
#include <Alert.h>



class MyWindow :
	public BWindow
{
public:
								MyWindow();
								~MyWindow();
		bool					QuitRequested();
static	status_t				RecordThread(
									void *			data);
		void					MessageReceived(
									BMessage *		message);

		DATAID					fHandler;
		thread_id				fRecordThread;
		BView *					fCapture;
};


void
main()
{
	BApplication app("application/x-record");
	DATAInit("application/x-record");
	MyWindow * mw = new MyWindow;
	mw->Show();
	app.Run();
	DATAShutdown();
}


#define START_CAPTURE 'Stcp'


MyWindow::MyWindow() :
	BWindow(BRect(200,200,400,400), "Capture", B_TITLED_WINDOW, B_NOT_RESIZABLE | B_NOT_ZOOMABLE)
{
	fRecordThread = -1;
	fCapture = NULL;
	DATAID * list = NULL;
	int32 count = 0;
	if (DATAListCaptures(DATA_SOUND, list, count) || (count < 1))
	{
		BAlert *alrt = new BAlert("Not!", "There are no audio capture datatypes installed.", "Quit");
		alrt->Go();
		PostMessage(B_QUIT_REQUESTED);
		return;
	}
	BRect x;
	int ix;
	for (ix=0; (ix < count) && DATAMakeCapturePanel(list[ix], NULL, fCapture, x); ix++)
		fCapture = NULL;
	if (!fCapture)
	{
		BAlert *alrt = new BAlert("Not!", "None of the installed audio capture datatypes liked me.", "Quit");
		alrt->Go();
		PostMessage(B_QUIT_REQUESTED);
		delete[] list;
		return;
	}
	else
		fHandler = list[ix];
	delete[] list;
	ResizeTo(x.Width(), x.Height()+30);
	x.top = x.bottom+3;
	x.bottom = x.top+20;
	x.left += 10;
	x.right -= 10;
	AddChild(fCapture);
	BButton *btn = new BButton(x, "start", "Start", new BMessage(START_CAPTURE));
	AddChild(btn);
}


MyWindow::~MyWindow()
{
	be_app->PostMessage(B_QUIT_REQUESTED);
}


bool
MyWindow::QuitRequested()
{
	thread_id w = fRecordThread;
	status_t status;
	if (w > 0)
		wait_for_thread(w, &status);
	be_app->PostMessage(B_QUIT_REQUESTED);
	return true;
}


void
MyWindow::MessageReceived(
	BMessage *				message)
{
	if (message->what == START_CAPTURE)
	{
		if (fRecordThread < 1)
		{
			fRecordThread = spawn_thread(RecordThread, "RecordThread", B_NORMAL_PRIORITY, this);
			resume_thread(fRecordThread);
		}
	}
	else
		inherited::MessageReceived(message);
}


status_t
MyWindow::RecordThread(
	void *				data)
{
	MyWindow *mw = (MyWindow *)data;
	BFile output("/boot/captured_sound", O_RDWR | O_CREAT | O_TRUNC);
	if (output.InitCheck())
	{
		BAlert *alrt = new BAlert("Oops!", "Could not create the file /boot/captured_sound.", "Quit");
		alrt->Go();
	}	/*	DATACapture is synchronous	*/
	else if (DATACapture(mw->fHandler, mw->fCapture, NULL, output, DATA_SOUND))
	{
		BAlert *alrt = new BAlert("Oops!", "There was an error when trying to capture sound.", "Quit");
		alrt->Go();
	}
	mw->fRecordThread = -1;
	mw->PostMessage(B_QUIT_REQUESTED);
}
