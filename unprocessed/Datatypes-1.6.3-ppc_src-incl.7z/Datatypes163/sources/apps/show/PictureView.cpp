/*	PictureView.cpp
 */

#include "PictureView.h"
#include <Picture.h>
#include <ScrollBar.h>


PictureView::PictureView(
	BRect			area,
	BPicture *		map) :
	BView(area, "picture", B_FOLLOW_ALL, B_WILL_DRAW | B_FRAME_EVENTS)
{
	fPicture = map;
	fOwnership = true;
	fAdjustBars = true;
}


PictureView::~PictureView()
{
	if (fOwnership && fPicture)
		delete fPicture;
}


void
PictureView::SetOwnership(
	bool			ownership)
{
	fOwnership = ownership;
}


bool
PictureView::GetOwnership()
{
	return fOwnership;
}


void
PictureView::SetPicture(
	BPicture *		map)
{
	if (fOwnership && fPicture)
		delete fPicture;
	fPicture = map;
	Invalidate();
	if (fAdjustBars)
		AdjustBars();
}


BPicture *
PictureView::GetPicture()
{
	return fPicture;
}


void
PictureView::SetAdjustBars(
	bool			adjust)
{
	fAdjustBars = adjust;
	if (fAdjustBars)
		AdjustBars();
}


bool
PictureView::GetAdjustBars()
{
	return fAdjustBars;
}


void
PictureView::Draw(
	BRect			area)
{
	if (!fPicture)
		return;
	DrawPicture(fPicture);
}


void
PictureView::FrameResized(
	float			newWidth,
	float			newHeight)
{
	BView::FrameResized(newWidth, newHeight);
	if (fAdjustBars)
		AdjustBars();
}


	static void
	AdjustBar(
		BScrollBar *		bar,
		float				page,
		float				total)
	{
		if (total <= page) {
			bar->SetRange(0, 0);
		}
		bar->SetRange(0, total-page);
		float pgStep = page-4.0;
		if (pgStep<16.0)
			pgStep = 16.0;
		bar->SetSteps(4.0, pgStep);
	}

void
PictureView::AdjustBars()
{
	/*	This can't do anything until we know how large a BPicture is */
#if 0
	BRect area(0,0,0,0);
	BRect bounds(Bounds());
	if (fPicture)
		area = fPicture->Bounds();

	BScrollBar *bar = ScrollBar(B_HORIZONTAL);
	if (bar)
		AdjustBar(bar, bounds.Width(), area.Width());
	bar = ScrollBar(B_VERTICAL);
	if (bar)
		AdjustBar(bar, bounds.Height(), area.Height());
#endif
}






