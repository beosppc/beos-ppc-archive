//	ShowApp.cpp

#include "ShowApp.h"
#include "Datatypes.h"
#include <DataIO.h>
#include "AppMakeView.h"

#include <Window.h>
#include <ScrollBar.h>
#include <File.h>
#include <Alert.h>
#include <stdio.h>
#include <Box.h>
#include <StringView.h>
#include <Screen.h>


#ifndef max
#define max(a,b) ((a)>(b)?(a):(b))
#endif

ShowApp::ShowApp(
	const char *		signature) :
	BApplication(signature)
{
	SetPulseRate(500000);
	if (DATAVersion == NULL) {
		BAlert *alrt = new BAlert("", "libdatatypes.so is not installed!", "Quit");
		alrt->Go();
		PostMessage(B_QUIT_REQUESTED);
		return;
	}
	long curv, minv;
	DATAVersion(curv, minv);
	if (curv < DATA_MIN_VERSION) {
		BAlert *alrt = new BAlert("", "libdatatypes.so is too old!", "Quit");
		alrt->Go();
		PostMessage(B_QUIT_REQUESTED);
		return;
	}
	if (minv > DATA_CURRENT_VERSION) {
		BAlert *alrt = new BAlert("", "libdatatypes.so is too new!?", "Quit");
		alrt->Go();
		PostMessage(B_QUIT_REQUESTED);
		return;
	}
	long err = DATAInit("application/x-show-app");
	if (err) {
		char message[100];
		sprintf(message, "libdatatypes.so got error 0x%08x when initializing!", err);
		BAlert *alrt = new BAlert("", message, "Quit");
		alrt->Go();
		PostMessage(B_QUIT_REQUESTED);
		return;
	}
}


void
ShowApp::RefsReceived(
	BMessage *message)
{
	BScreen screen;
	BRect winR = screen.Frame();
	winR.left += 48;
	winR.right -= 4;
	winR.top += 26;
	winR.bottom -= 26;

	for (int ix=0; message->HasRef("refs", ix); ix++)
	{
		/*	get the file out of the message */

		entry_ref ref;
		if (message->FindRef("refs", ix, &ref))
			continue;
		BFile *file = new BFile(&ref, O_RDWR);
		struct stat stbuf;
		char str[B_FILE_NAME_LENGTH+30];
		if (file->GetStat(&stbuf))
		{
			sprintf(str, "Error finding file %s!", ref.name);
			BAlert *error = new BAlert("", str, "OK");
			error->Go();
			continue;
		}

		/*	try to create a view */

		BView *outView = NULL;
		char *dataInfo;
		BRect extent;
		const char *mimeStr = NULL;
		if (B_OK <= file->ReadAttr("BEOS:TYPE", B_STRING_TYPE, 0, str, B_FILE_NAME_LENGTH))
		{
			mimeStr = str;
		}
		long err = AppMakeView(file, outView, extent, mimeStr, dataInfo);

		if (err || !outView)
		{
			char msg[1024];
			sprintf(msg, "No Datatype handler found for '%s'!", ref.name);
			BAlert *error = new BAlert("Missing Handler", msg, "OK");
			error->Go();
			continue;
		}

		/* Put this view in a window with scroll bars */

		BRect winSize = winR;
		if (winSize.Width() > extent.Width()+B_V_SCROLL_BAR_WIDTH)
			winSize.right = winSize.left+extent.Width()+B_V_SCROLL_BAR_WIDTH;
		if (winSize.Height() > extent.Height()+B_H_SCROLL_BAR_HEIGHT)
			winSize.bottom = winSize.top+extent.Height()+B_H_SCROLL_BAR_HEIGHT;
		BWindow *window = new BWindow(winSize, ref.name, B_DOCUMENT_WINDOW, 0);
		BRect viewR = window->Bounds();
		viewR.right -= B_V_SCROLL_BAR_WIDTH;
		viewR.bottom -= B_H_SCROLL_BAR_HEIGHT;

		outView->MoveTo(0,0);
		outView->ResizeTo(viewR.right, viewR.bottom);
		window->AddChild(outView);

		BRect tR = viewR;
		tR.top = tR.bottom+1;
		tR.bottom = tR.top+B_H_SCROLL_BAR_HEIGHT;
		tR.right++;
		tR.left += 160;
		BScrollBar *hBar = new BScrollBar(tR, "horiz", outView,
			0, max(extent.Width()-viewR.Height(), 0), B_HORIZONTAL);
		hBar->SetSteps(8, 240);
		window->AddChild(hBar);

		tR.right = tR.left;
		tR.left = -1;
		BBox *box = new BBox(tR, NULL, B_FOLLOW_LEFT|B_FOLLOW_BOTTOM);
		window->AddChild(box);
		rgb_color dkGray = { 150, 150, 150, 0 };
		box->SetHighColor(dkGray);
		tR.InsetBy(1, 1);
		tR.OffsetTo(BPoint(1,1));
		BStringView *strv = new BStringView(tR, "info", dataInfo, B_FOLLOW_ALL);
		box->AddChild(strv);
		rgb_color gray = { 222, 222, 222, 0 };
		strv->SetViewColor(gray);
		strv->SetDrawingMode(B_OP_COPY);
		strv->SetFont(be_plain_font);
		strv->SetFontSize(9);
		delete[] dataInfo;

		tR = viewR;
		tR.left = tR.right+1;
		tR.right = tR.left+B_V_SCROLL_BAR_WIDTH;
		tR.bottom++;
		tR.top--;
		BScrollBar *vBar = new BScrollBar(tR, "vert", outView,
			0, max(extent.Height()-viewR.Height(), 0), B_VERTICAL);
		vBar->SetSteps(8, 160);
		window->AddChild(vBar);

		window->Show();
		winR.OffsetBy(5, 15);

		/*	Since the user may resize the window, we should put 
			the view inside another view that adjusts the scroll 
			bars, but I'm too lazy for that right now. */
	}
}


/*
   I would do the check in AppActivated, but there is a 
   race condition in where the window list still contains 
   a window when the application gets deactivated
 */
void
ShowApp::Pulse()
{
	BApplication::Pulse();
	if (!CountWindows())
		PostMessage(B_QUIT_REQUESTED);
}


