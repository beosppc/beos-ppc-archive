//	main.cpp

#include "ShowApp.h"
#include "Datatypes.h"
#include <stdio.h>

int
main(
	int		argc,
	char *	argv[])
{
	ShowApp app("application/x-show-app");
	for (int ix=1; ix<argc; ix++) {
		entry_ref ref;
		if (get_ref_for_path(argv[ix], &ref)) {
			fprintf(stderr, "can't find: %s\n", argv[ix]);
			continue;
		}
		BMessage *msg = new BMessage(B_REFS_RECEIVED);
		msg->AddRef("refs", &ref);
		app.PostMessage(msg);
	}
	app.Run();
	DATAShutdown();
	return 0;
}


