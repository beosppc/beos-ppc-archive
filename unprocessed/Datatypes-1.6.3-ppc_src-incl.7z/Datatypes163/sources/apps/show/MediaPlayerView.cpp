/*	MediaPlayerView.cpp	*/

#include "MediaPlayerView.h"
#include "DataMedia.h"
#include <DataIO.h>
#include <Bitmap.h>


MediaPlayerView::MediaPlayerView(
	BRect			area,
	BPositionIO			*input,
	const DATAInfo	&info) :
	BView(area, "MediaPlayer", B_FOLLOW_ALL, B_WILL_DRAW)
{
	fBitmap = NULL;
	fInput = input;
	fNotifier = new DefaultNotifier(this);
	fOutput = new MEDIAReaderStream(fNotifier);
	fIsPlaying = false;
	fThread = -1;
	fInfo = info;
}


MediaPlayerView::~MediaPlayerView()
{
	if (fThread > 0)
		kill_thread(fThread);
	if (fInput)
		delete fInput;
	if (fOutput)
		delete fOutput;
	if (fNotifier)
		delete fNotifier;
	if (fBitmap)
		delete fBitmap;
}


void
MediaPlayerView::Draw(
	BRect			/* area */)
{
	if (!fBitmap)
		fBitmap = fOutput->DetachBitmap();
	if (fBitmap)
		DrawBitmap(fBitmap, BPoint(0,0));
	else
		DrawString("Click to play", BPoint(20,30));
}


void
MediaPlayerView::MouseDown(
	BPoint			/* where */)
{
	if (fIsPlaying)
		return;

	if (fBitmap)
		delete fBitmap;
	fBitmap = NULL;
	fIsPlaying = true;
	fThread = spawn_thread(ThreadFunc, "MediaPlayer", B_URGENT_DISPLAY_PRIORITY, this);
	if (fThread >= 0)
		resume_thread(fThread);
}


long
MediaPlayerView::ThreadFunc(
	void			*data)
{
	MediaPlayerView *view = (MediaPlayerView *)data;
	/*	Note that the "spinning loop" is within DATATranslate	*/
	DATATranslate(*view->fInput, &view->fInfo, NULL, *view->fOutput, DATA_MEDIA);
	view->Window()->Lock();
	view->fBitmap = view->fOutput->DetachBitmap();
	view->fIsPlaying = false;
	view->Window()->Unlock();
	return B_OK;
}






