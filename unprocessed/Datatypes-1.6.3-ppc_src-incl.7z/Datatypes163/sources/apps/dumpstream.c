/*	dumpstream.c
 */

/*	Jon Watte, <datatypes@mindcontrol.org>
 */

/*	This simple tool will diagnose a MediaStream file,
 *	making sure that it is consistent and print the 
 *	identifying information of each chunk header.
 */

#include <stdio.h>
#include <stdlib.h>


typedef struct Header {
	unsigned long	tag;
	unsigned long	hdrsize;
	unsigned long	datasize;
	unsigned long	position;
} Header;

/*	Stolen from DataVideo.h	*/

typedef struct MediaStreamHeader {
	unsigned long	tag;			/*	MEDIA_START_MAGIC	*/
	long		hdrsize;		/*	size of this header (20 for now)	*/
	long		datasize;		/*	size of data (not including header)	*/
	long		ticksstart; 	/*	media clock when file was started
								 *	Typically you'd want it as 0, but other values are OK
								 *	Even though each chunk has its own timestamp, they are 
								 *	expected to never be decreasing	*/
	long		tickspersec;	/*	speed of stream
								 *	The convention is to use one of the values 1000, 44100 or 48000
								 *	and ALWAYS use the sound sample rate if there is sound...	*/
/*	ulong		tagsrequired[datasize/sizeof(ulong)];
 *	here, you write each tag that you think you will use in the file.
 */
} MediaStreamHeader;


static int
readit(
	FILE *f,
	long size,
	void *data,
	long *adj)
{
	while (size > 0) {
		int toread = 32768;
		int res;
		if (toread > size)
			toread = size;
		res = fread(data, 1, toread, f);
		if (res < 0)
			return 1;
		*adj += res;
		if (res != toread)
			return 1;
		size -= toread;
	}
	return 0;
}


static void
dump(
	FILE *f)
{
	Header h;
	MediaStreamHeader msh;
	void *skip = malloc(32768);
	int end = 0;
	long pos = 0;
	if (!skip) {
		puts("  -- out of memory!");
		return;
	}
	if (!fread(&msh, sizeof(msh), 1, f)) {
		puts("  -- file is truncated!");
		free(skip);
		return;
	}
	pos += sizeof(msh);
	printf("         Stream('%.4s',%d,%d,%d,%d)\n", &msh.tag, msh.hdrsize, 
		msh.datasize, msh.ticksstart, msh.tickspersec);
	if (readit(f, msh.hdrsize-sizeof(msh)+msh.datasize, skip, &pos)) {
		puts("  -- file read error");
		free(skip);
		return;
	}
	while (!ferror(f) && !feof(f) && fread(&h, sizeof(h), 1, f)) {
		pos += sizeof(h);
		printf("%8ld:Chunk('%.4s',%d,%d,%d)\n", pos, &h.tag, h.hdrsize, 
			h.datasize, h.position);
		if (h.tag == 'mbye')
			end = 1;
		if (readit(f, h.hdrsize-sizeof(h)+h.datasize, skip, &pos)) {
			puts("  -- file read error");
			free(skip);
			return;
		}
	}
	free(skip);
	if (!end) {
		puts("  -- file did not have end chunk!");
	}
}


int
main(
	int argc,
	char *argv[])
{
	int ix;
	if (argc == 1) {
		puts("(stdin)");
		dump(stdin);
	} else for (ix=1; ix<argc; ix++) {
		if (!strcmp(argv[ix], "-")) {
			puts("(stdin)");
			dump(stdin);
		} else {
			FILE *file = fopen(argv[ix], "r");
			puts(argv[ix]);
			if (file) {
				dump(file);
				fclose(file);
			} else {
				puts("  -- cannot open");
			}
		}
	}
	return 0;
}
