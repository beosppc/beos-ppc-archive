//	TextHandler.cpp

#include "DataHandler.h"
#include "Datatypes.h"
#include "DataStreams.h"
#include "DataVideo.h"
#include <InterfaceDefs.h>
#include <Debug.h>


char handlerName[] = "Streamed Media Format";
long handlerVersion = 141;
char handlerInfo[] = "Demo version 1.4.1";

Format inputFormats[] = {
	{	DATA_MEDIA,	DATA_MEDIA,
		0.5,	0.4,
		"application/x-media-format",
		"Generic streamed media format"
	},
	{	0,	0,
		0,	0,
		"",
		""
	}
};

Format outputFormats[] = {
	{	DATA_MEDIA,	DATA_MEDIA,
		0.5,	0.4,
		"application/x-media-format",
		"Generic streamed media format"
	},
	{	0,	0,
		0,	0,
		"",
		""
	}
};


long
Identify(
	DStream &			inSpec,
	const Format *		format,
	BMessage *			/* ioExtension */,
	DATAInfo &			outInfo,
	ulong				outType)
{
	puts("Identify called");

	/*	Can we translate to wanted format?	*/
	if (outType && (outType != DATA_MEDIA)) {
		printf("Out type wrong %.4s\n", &outType);
		return DATA_NO_HANDLER;
	}

	/*	Does the file start with the expected magic number?	*/
	ulong magic = 0;
	long rd = sizeof(magic);
	if (inSpec.Read(&magic, rd) < 0) {
		puts("First Read failed");
		return DATA_NO_HANDLER;
	}
	if (magic != 'mhi!') {
		puts("Magic wrong");
		return DATA_NO_HANDLER;
	}
	/*	Sanity check the header size	*/
	if (inSpec.Read(&magic, rd) < 0) {
		puts("Second Read failed");
		return DATA_NO_HANDLER;
	}
	if ((magic & 3) || (magic < 20) || (magic > 128)) {
		puts("Second field wrong");
		return DATA_NO_HANDLER;
	}

	puts("Identify OK");

	/*	So decide it's a file we know.	*/
	outInfo.formatType = DATA_MEDIA;
	outInfo.formatGroup = DATA_MEDIA;
	outInfo.formatQuality = outputFormats[0].quality;
	outInfo.formatCapability = outputFormats[0].capability;
	strcpy(outInfo.formatName, outputFormats[0].formatName);
	strcpy(outInfo.MIMEName, outputFormats[0].MIME);

	return B_OK;
}


static long
CopyLoop(
	DStream &			inStream,
	DStream &			outStream,
	int					readChunk = 32768)
{
	void *data = malloc(readChunk);
	long e = B_OK;
	long rd = readChunk;
	do {
		e = inStream.Read(data, rd);
		if (!e) {
			/*	If we get a non-scanline sized chunk, we just copy it literally
			 *	this is required for the large-block non-dropping case
			 */
			e = outStream.Write(data, rd);
		}
	} while (!e && (rd == readChunk));		//	rd will be set to less when at end
	if (!rd)
		e = B_OK;
	free(data);
	return e;
}


long
Translate(
	DStream &			inStream,
	const DATAInfo &	inInfo,
	BMessage *			/* ioExtension */,
	ulong				outFormat,
	DStream &			outStream)
{
	if (outFormat && (outFormat != DATA_MEDIA))
		return DATA_NO_HANDLER;
	if (inInfo.formatType != DATA_MEDIA)
		return DATA_NO_HANDLER;
	puts("Translate OK");
	return CopyLoop(inStream, outStream);
}


