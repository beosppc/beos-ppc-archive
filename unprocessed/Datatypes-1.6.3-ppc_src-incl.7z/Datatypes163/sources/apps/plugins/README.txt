These plug-ins are the ones that came with DR8 versions of Datatypes. 
They have not been updated for DR9/Preview Release, although doing so 
would be fairly simple. It is left as an excercise for the reader.
