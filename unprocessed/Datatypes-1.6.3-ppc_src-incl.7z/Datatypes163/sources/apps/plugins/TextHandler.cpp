//	TextHandler.cpp

#include "DataHandler.h"
#include "Datatypes.h"
#include "DataStreams.h"
#include <AppDefs.h>


char handlerName[] = "Simple TEXT";
long handlerVersion = 120;
char handlerInfo[] = "Demo version 1.2";


Format inputFormats[] = {
	{	B_ASCII_TYPE,	DATA_TEXT,
		0.3,	1.0,
		"",
		"Plain TEXT"
	},
	{	0,	0,
		0,	0,
		"",
		""
	}
};

Format outputFormats[] = {
	{	B_ASCII_TYPE,	DATA_TEXT,
		0.3,	1.0,
		"",
		"Plain TEXT"
	},
	{	0,	0,
		0,	0,
		"",
		""
	}
};



static long
ConvertData(
	DStream &			inStream,
	DStream &			outStream)
{
	long len = inStream.Size();
	char *buffer = (char *)malloc(32768);
	for (long size=32768;
			size && len > 0;
			len -= size, size = 32768) {

		//	get data
		long err = inStream.Read(buffer, size);
		if (err) {
			free(buffer);
			return err;
		}

		//	convert returns
		for (char *ptr = buffer; ptr<&buffer[size]; ptr++) {
			if (*ptr == 13) {
				if (ptr<&buffer[size-1] && ptr[1] == 10) {
					*(ptr++) = ' ';	//	cheezy way of converting...
					*ptr = 10;
				}
				else {
					*ptr = 10;
				}
			}
		}
		//	put data
		err = outStream.Write(buffer, size);
		if (err) {
			free(buffer);
			return err;
		}
	}
	free(buffer);
	return 0;
}


static bool
IsTEXT(
	char *ptr,
	long size)
{
	while (size-- > 0) {
		int ch = *(unsigned char *)(ptr++);
		if ((ch <9) || (ch == 11) || ((ch > 13) && (ch < 32)))
			return FALSE;
	}
	return TRUE;
}


long
Identify(
	DStream &			inSpec,
	const Format *		format,
	BMessage *			/* ioExtension */,
	DATAInfo &			outInfo,
	ulong				/* outType */)
{
	/*	We use the conversion function to read the data */

	DMallocStream out;
	long err = ConvertData(inSpec, out);

	/*	Then look at it to determine if it's TEXT */

	long offset, size;
	const void *peek = out.Peek(offset, size);
	if (!err && peek && IsTEXT(((char *)peek)+offset, size)) {

		if (!format)
			format = &inputFormats[0];
		outInfo.formatType = format->type;
		outInfo.formatGroup = format->t_cls;
		outInfo.formatQuality = format->quality;
		outInfo.formatCapability = format->capability;
		strcpy(outInfo.formatName, format->formatName);
		strcpy(outInfo.MIMEName, format->MIME);

	} else
		err = DATA_NO_HANDLER;

	return err;
}


long
Translate(
	DStream &			inStream,
	const DATAInfo &	inInfo,
	BMessage *			/* ioExtension */,
	ulong				outFormat,
	DStream &			outStream)
{
	/*	Check that we handle input and output types */

	if (inInfo.formatType != B_ASCII_TYPE)
		return DATA_NO_HANDLER;

	if ((outFormat != 0) && (outFormat != B_ASCII_TYPE))
		return DATA_NO_HANDLER;

	/*	Actually convert data */

	return ConvertData(inStream, outStream);
}




