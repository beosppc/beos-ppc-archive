//	TextHandler.cpp

#include "DataHandler.h"
#include "Datatypes.h"
#include "DataStreams.h"
#include <InterfaceDefs.h>
#include <Debug.h>


char handlerName[] = "Screen Dump";
long handlerVersion = 140;
char handlerInfo[] = "Demo version 1.4";

#define DUMP_FORMAT		'BITM'


Format inputFormats[] = {
	{	DUMP_FORMAT,	DATA_BITMAP,
		0.3,	0.5,
		"",
		"BeOS screen dump format"
	},
	{	DATA_BITMAP,	DATA_BITMAP,
		0.3,	0.5,
		"",
		"Standard bitmap format"
	},
	{	0,	0,
		0,	0,
		"",
		""
	}
};

Format outputFormats[] = {
	{	DATA_BITMAP,	DATA_BITMAP,
		0.3,	0.5,
		"",
		"Standard bitmap format"
	},
	{	DUMP_FORMAT,	DATA_BITMAP,
		0.3,	0.5,
		"",
		"BeOS screen dump format"
	},
	{	0,	0,
		0,	0,
		"",
		""
	}
};


struct DumpHeader {
	long	left;
	long	top;
	long	right;
	long	bottom;
	long	colors;
	long	size;
};



static int
GetBITMRowBytes(
	long			left,
	long			right,
	color_space		colors)
{
	int rowBytes = right-left+1;	//	calculate a rowBytes to work with
	switch (colors) {
	case B_COLOR_8_BIT:
		/* rowBytes are OK */ break;
	case B_RGB_32_BIT:
		rowBytes = rowBytes*4; break;
	case B_RGB_16_BIT:
		rowBytes = rowBytes*2; break;
	case B_MONOCHROME_1_BIT:
		rowBytes = rowBytes/8; break;
	case B_GRAYSCALE_8_BIT:
		/* rowBytes are OK */ break;
	default:
		/* illegal format - no rowBytes */
		rowBytes = 0; break;
	}
	return rowBytes;
}



long
Identify(
	DStream &			inSpec,
	const Format *		format,
	BMessage *			/* ioExtension */,
	DATAInfo &			outInfo,
	ulong				outType)
{
	if (outType && (outType != DATA_BITMAP) && (outType != DUMP_FORMAT))
		return DATA_NO_HANDLER;

	char	data[32];

	long size = 32;
	long e = inSpec.Read(data, size);
	if (!e && (size < 32))
		e = DATA_NO_HANDLER;
	if (e < 0)
		return e;

	/*	Check for DATABitmap magic	*/
	unsigned long magic = DATA_BITMAP;
	bool isDataBitmap = false;
	if (!strncmp(data, (char *)&magic, 4)) {
		isDataBitmap = true;
		//	validate parameters
		DATABitmap hdr;
		memcpy(&hdr, data, sizeof(hdr));
		if (hdr.bounds.left > hdr.bounds.right)
			isDataBitmap = false;
		if (hdr.bounds.top > hdr.bounds.bottom)
			isDataBitmap = false;
	/*	I'm being quite fascist about rowBytes */
		if ((hdr.rowBytes < 4) || (hdr.rowBytes & 3))
			isDataBitmap = false;
		if ((hdr.colors != B_COLOR_8_BIT) && (hdr.colors != B_RGB_32_BIT) &&
				(hdr.colors != B_MONOCHROME_1_BIT) && (hdr.colors != B_GRAYSCALE_8_BIT) &&
				(hdr.colors != B_RGB_16_BIT))
			isDataBitmap = false;
		if (hdr.dataSize < (((long)hdr.bounds.Height()+1)*hdr.rowBytes))
			isDataBitmap = false;
	}

	/*	If not, check for DUMP_FORMAT format - this has no magic, so we have to use consistency checks only */
	bool isDump = false;
	if (!isDataBitmap) {

		isDump = true;	//	assume success

		//	validate header
		DumpHeader hdr;
		memcpy(&hdr, data, sizeof(hdr));
		if (hdr.left > hdr.right)
			isDump = false;
		if (hdr.top > hdr.bottom)
			isDump = false;

		int rowBytes = 0;
		if (isDump)
			rowBytes = GetBITMRowBytes(hdr.left, hdr.right, (color_space)hdr.colors);
		if (!rowBytes)
			isDump = false;
		if (hdr.size < ((hdr.bottom-hdr.top)*rowBytes))
			isDump = false;
	}

	if (!isDump && !isDataBitmap)
		return DATA_NO_HANDLER;

	const Format * inFormat = format;
	if (isDump)
		format = &inputFormats[0];
	else	//	isDataBitnap
		format = &inputFormats[1];
	if (inFormat) {
		if (inFormat->type != format->type)
			/*	It's not what we expected	*/
			return DATA_NO_HANDLER;
	}
	outInfo.formatType = format->type;
	outInfo.formatGroup = format->t_cls;
	outInfo.formatQuality = format->quality;
	outInfo.formatCapability = format->capability;
	strcpy(outInfo.formatName, format->formatName);
	strcpy(outInfo.MIMEName, format->MIME);

	return B_OK;
}


static long
CopyLoop(
	DStream &			inStream,
	DStream &			outStream,
	int					readChunk = 32768,
	int					writeChunk = 32768)
{
	ASSERT(readChunk >= writeChunk);
	int maxChunk = readChunk > writeChunk ? readChunk : writeChunk;
	void *data = malloc(maxChunk);
	if (writeChunk > readChunk) {
		/*	Pad the extra area with 0s	*/
		for (int ix=readChunk; ix<writeChunk; ix++)
			((char*)data)[ix] = 0;
	}
	long e = B_OK;
	long rd = readChunk;
	do {
		e = inStream.Read(data, rd);
		if (!e) {
			/*	If we get a non-scanline sized chunk, we just copy it literally
			 *	this is required for the large-block non-dropping case
			 */
			if (rd == readChunk)
				rd = writeChunk;
			e = outStream.Write(data, rd);
		}
	} while (!e && (rd == writeChunk));		//	rd will be set to less when at end
	free(data);
	return e;
}


long
Translate(
	DStream &			inStream,
	const DATAInfo &	inInfo,
	BMessage *			/* ioExtension */,
	ulong				outFormat,
	DStream &			outStream)
{
	/*	Check that we handle input and output types */

	switch (inInfo.formatType) {
	case DATA_BITMAP:
	case DUMP_FORMAT:
		/*	these are OK	*/ break;
	default:
		return DATA_NO_HANDLER;
	}

	if (outFormat == 0)
		outFormat = DATA_BITMAP;
	switch (outFormat) {
	case DATA_BITMAP:
	case DUMP_FORMAT:
		/*	these are OK	*/ break;
	default:
		return DATA_NO_HANDLER;
	}

	/*	Actually convert data */

	if (inInfo.formatType == outFormat) {	//	no conversion necessary
		return CopyLoop(inStream, outStream);
	}

	if (inInfo.formatType == DATA_BITMAP) {	//	so we know we're going to DUMP_FORMAT
		ASSERT(outFormat == DUMP_FORMAT);
		DumpHeader hdr;
		DATABitmap bmp;
		long e = B_OK;
		long size = sizeof(bmp);
		e = inStream.Read(&bmp, size);
		if (size < sizeof(bmp))
			e = DATA_NO_HANDLER;
		if (e)
			return e;
		hdr.left = bmp.bounds.left;
		hdr.top = bmp.bounds.top;
		hdr.right = bmp.bounds.right;
		hdr.bottom = bmp.bounds.bottom;
		hdr.colors = bmp.colors;
		int rowBytes = GetBITMRowBytes(hdr.left, hdr.right, (color_space)hdr.colors);
		ASSERT(rowBytes<=bmp.rowBytes);
		hdr.size = rowBytes*(hdr.bottom-hdr.top+1);
		e = outStream.Write(&hdr, sizeof(hdr));
		if (e)
			return e;
		if (hdr.size == bmp.dataSize) {
			return CopyLoop(inStream, outStream);
		} else {	//	linewise copy
			return CopyLoop(inStream, outStream, bmp.rowBytes, rowBytes);
		}
	}
	
	if (inInfo.formatType == DUMP_FORMAT) {		//	this should always be taken if we get this far
		ASSERT(outFormat == DATA_BITMP);
		DumpHeader hdr;
		DATABitmap bmp;
		long e = B_OK;
		long size = sizeof(hdr);
		e = inStream.Read(&hdr, size);
		if (size < sizeof(hdr))
			e = DATA_NO_HANDLER;
		if (e)
			return e;
		bmp.magic = DATA_BITMAP;
		bmp.bounds.left = hdr.left;
		bmp.bounds.top = hdr.top;
		bmp.bounds.right = hdr.right;
		bmp.bounds.bottom = hdr.bottom;
		bmp.colors = (color_space)hdr.colors;
		int rowBytes = GetBITMRowBytes(hdr.left, hdr.right, (color_space)hdr.colors);
		bmp.rowBytes = (rowBytes+3)&~3;
		bmp.dataSize = bmp.rowBytes*(hdr.bottom-hdr.top+1);
		e = outStream.Write(&bmp, sizeof(bmp));
		if (e)
			return e;
		if (hdr.size == bmp.dataSize) {
			return CopyLoop(inStream, outStream);
		} else {	//	linewise copy
			return CopyLoop(inStream, outStream, rowBytes, bmp.rowBytes);
		}
	}

	return DATA_NO_HANDLER;
}


