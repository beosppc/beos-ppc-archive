
/* MediaMain.cpp */

#include "MediaWindow.h"
#include "Datatypes.h"


void
main()
{
	puts("Creating application");
	BApplication app('medi');

	puts("Checking Datatypes");
	long min, cur;
	DATAVersion(min, cur);
	if (cur < DATA_MIN_VERSION)
	{
		BAlert *alrt = new BAlert("Too old!", "The Datatypes.lib library is too old for this program!", "Quit");
		alrt->Go();
		app.PostMessage(B_QUIT_REQUESTED);
	}
	else if (min > DATA_CURRENT_VERSION)
	{
		BAlert *alrt = new BAlert("Too new!", "The Datatypes.lib library is too new for this program!", "Quit");
		alrt->Go();
		app.PostMessage(B_QUIT_REQUESTED);
	}
	else
	{
		puts("Initializing Datatypes");
		DATAInit('medi');
		puts("Creating window");
		MediaWindow *window = new MediaWindow("NewMovie");
		window->Show();
	}
	puts("Application started");
	app.Run();
	puts("Shutting down Datatypes");
	DATAShutdown();
	puts("Done");
}

