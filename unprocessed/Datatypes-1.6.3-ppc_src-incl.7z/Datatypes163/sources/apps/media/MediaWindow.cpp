/*	MediaWindow.cpp	*/

#include "MediaWindow.h"
#include "MediaView.h"
#include "FrameItem.h"
#include "BitmapFrameItem.h"


	static BRect
	GetArea()
	{
		static long scrncnt_storage = 0;
		long scrncnt = atomic_add(&scrncnt_storage, 1) % 6;
		screen_info info;
		get_screen_info(&info);
		float width = 60.0;
		get_dock_width(&width);
		width += 7.0;
		info.frame.OffsetBy(width+scrncnt*50.0, 25.0+scrncnt*5.0);
		info.frame.bottom -= 60.0;
		info.frame.right = info.frame.left+320.0;
		return info.frame;
	}

MediaWindow::MediaWindow(
	const char			*name) :
	BWindow(GetArea(), name, B_TITLED_WINDOW, B_NOT_CLOSABLE)
{
	Lock();
	MakeViews();
	Unlock();
}


MediaWindow::~MediaWindow()
{
	/*	do nothing	*/
}


void
MediaWindow::SaveRequested(
	record_ref			directory,
	const char			*name)
{
	/*	do later	*/
	SetTitle(name);
}


void
MediaWindow::MessageReceived(
	BMessage			*message)
{
	switch (message->what) {
	case MEDIA_SAVE:
		RunSavePanel(Title());
		break;
	case MEDIA_MAKE:
		MakeMovie();
		break;
	case MEDIA_MAKE_PANEL:
		RunSavePanel("Movie", NULL, NULL, NULL, new BMessage(MEDIA_MAKE_REPLY));
		break;
	case MEDIA_MAKE_REPLY:
		DoMakeMovie(message);
		break;
	case MEDIA_PLAY:
		Play();
		break;
	case MEDIA_EDIT:
		Edit();
		break;
	case MEDIA_REMOVE:
		Remove();
		break;
	default:
		inherited::MessageReceived(message);
		break;
	}
}


void
MediaWindow::EnableItem(
	unsigned long		command,
	bool				enabled)
{
	BMenuBar *bar = KeyMenuBar();
	if (!bar)
		return;
	BMenuItem *item = bar->FindItem(command);
	if (!item)
		return;
	item->SetEnabled(enabled);
}


void
MediaWindow::MenusWillShow()
{
	long sel = fView->CurrentSelection();
	bool en = (sel >= 0);
	EnableItem(MEDIA_SAVE, fView->CountItems() > 0);
	EnableItem(MEDIA_MAKE, fView->CountItems() > 0);
	EnableItem(MEDIA_PLAY, fView->CountItems() > 0);
	EnableItem(MEDIA_EDIT, en);
	EnableItem(MEDIA_REMOVE, en);
}


void
MediaWindow::MakeViews()
{
	BRect bounds = Bounds();

	BRect temp = bounds;
	temp.bottom = temp.top+19.0;
	BMenuBar *bar = new BMenuBar(temp, "MediaWindow");
	BMenu *movie = new BMenu("Movie");
	bar->AddItem(movie);
	BMenu *edit = new BMenu("Edit");
	bar->AddItem(edit);
	BMenuItem *save = new BMenuItem("Save", new BMessage(MEDIA_SAVE), 'S');
	movie->AddItem(save);
	BMenuItem *make = new BMenuItem("Make", new BMessage(MEDIA_MAKE), 'M');
	movie->AddItem(make);
	BMenuItem *play = new BMenuItem("Play", new BMessage(MEDIA_PLAY), 'P');
	movie->AddItem(play);
	BMenuItem *info = new BMenuItem("Edit", new BMessage(MEDIA_EDIT), 'I');
	edit->AddItem(info);
	BMenuItem *remove = new BMenuItem("Remove", new BMessage(MEDIA_REMOVE), 'B');
	edit->AddItem(remove);
	AddChild(bar);

	temp = bounds;
	temp.top = bar->Frame().bottom+1;
	temp.right -= B_V_SCROLL_BAR_WIDTH;
	fView = new MediaView(temp);
	AddChild(fView);

	temp.left = temp.right+1.0;
	temp.right = bounds.right+1.0;
	temp.top -= 1.0;
	temp.bottom += 1.0;
	BScrollBar *vert = new BScrollBar(temp, "vert", fView, 0, 0, B_VERTICAL);
	AddChild(vert);
}


void
MediaWindow::Edit()
{
	long sel = fView->CurrentSelection();
	if (sel < 0)
		return;
	FrameItem *item = (FrameItem *)fView->ItemAt(sel);
	if (item)
		if (item->Edit(fView, sel))
			fView->RecalcItemTotals(NULL, 0);
}


void
MediaWindow::Remove()
{
	long sel = fView->CurrentSelection();
	if (sel < 0)
		return;
	FrameItem *item = (FrameItem *)fView->RemoveItem(sel);
	if (item)
		delete item;
	fView->RecalcItemTotals(NULL, sel);
}


void
MediaWindow::MakeMovie()
{
	/*	do later */
	if (IsSavePanelRunning()) {
		BAlert *alrt = new BAlert("Save?", 
			"You are currently trying to save this movie. Do you want to stop doing that, and make the movie instead?",
			"Cancel", "Stop & Make");
		if (alrt->Go() != 1) {
			return;
		}
		CloseSavePanel();
	}
	PostMessage(MEDIA_MAKE_PANEL);
}


void
MediaWindow::DoMakeMovie(
	BMessage			*message)
{
	record_ref ref = message->FindRef("directory");
	const char *name = message->FindString("name");
	BDirectory dir(ref);
	BFile file;
	if (dir.Error())
		goto error;
	if (dir.GetFile(name, &file))
		if (dir.Create(name, &file))
			goto error;
	if (file.Open(B_READ_WRITE))
		goto error;
	if (!fView->SaveTo(file))
		goto error;
	file.Close();
	return;

error:
	if (file.IsOpen())
		file.Close();
	BAlert *alrt = new BAlert("Error", "There was an error in making the movie.", "Stop");
	alrt->Go();
	if (!dir.Error() && !file.Error())
		dir.Remove(&file);
	return;
}


void
MediaWindow::Play()
{
	BRect area;
	{
		FrameItem *fitem = (FrameItem *)fView->ItemAt(0);
		BitmapFrameItem *bitsf = dynamic_cast<BitmapFrameItem *>(fitem);
		if (bitsf)
		{
			area = bitsf->fMap->Bounds();
		}
		else
		{
			beep();
			return;
		}
	}
		
	area.OffsetBy(64,32);
	BWindow *window = new BWindow(area, "Play Movie", B_BORDERED_WINDOW, 
		B_NOT_MOVABLE | B_NOT_CLOSABLE | B_NOT_ZOOMABLE | B_NOT_RESIZABLE |
		B_NOT_MINIMIZABLE);
	area.OffsetTo(B_ORIGIN);
	BView *drawView = new BView(area, "view", B_FOLLOW_ALL, 0);
	window->Lock();
	window->AddChild(drawView);
	drawView->SetViewColor(B_TRANSPARENT_32_BIT);
	drawView->SetDrawingMode(B_OP_COPY);
	window->Unlock();
	window->Show();
	window->Flush();

	long max = fView->CountItems();
	double now = system_time();
	for (int ix=0; ix<max; ix++)
	{
		FrameItem *item = (FrameItem *)fView->ItemAt(ix);
		BitmapFrameItem *bits = dynamic_cast<BitmapFrameItem *>(item);
		if (bits)
		{
			window->Lock();
			BRect r = bits->fMap->Bounds();
			drawView->DrawBitmapAsync(bits->fMap, r, r);
			window->Flush();
			window->Unlock();
			double then = now+bits->fRunningTotal*1000000.0/44100.0;
			double realnow = system_time();
			double d = then-realnow;
			if (d >= 1000.0)
			{
				snooze(d);
			}
		}
	}
	window->PostMessage(B_QUIT_REQUESTED);
}
