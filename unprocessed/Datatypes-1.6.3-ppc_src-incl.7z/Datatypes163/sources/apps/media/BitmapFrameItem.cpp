/*	BitmapFrameItem.cpp	*/

#include "BitmapFrameItem.h"
#include "Datatypes.h"
#include <Beep.h>
#include <string.h>


BitmapFrameItem::BitmapFrameItem(
	BBitmap			*bitmap,
	const char		*name,
	long			delay)
{
	fMap = bitmap;
	strncpy(fName, name, sizeof(fName));
	fName[sizeof(fName)-1] = 0;
	fTicksDuration = delay;
	fType = DATA_BITMAP;
}


BitmapFrameItem::~BitmapFrameItem()
{
	delete fMap;
}


bool
BitmapFrameItem::Edit(
	BListView			*list,
	long				item)
{
	/*	do nothing	*/
	beep();
	return true;
}
