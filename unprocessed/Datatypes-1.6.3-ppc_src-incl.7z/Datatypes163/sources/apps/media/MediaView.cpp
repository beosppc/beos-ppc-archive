//	MediaView.cpp


#include "MediaView.h"
#include "FrameItem.h"
#include "BitmapFrameItem.h"
#include "MediaWindow.h"
#include "GetBitmap.h"
#include "DataVideo.h"
#include "DataStreams.h"
#include <Beep.h>


MediaView::MediaView(
	BRect			area) :
	BListView(area, "MediaList", B_FOLLOW_ALL, 
		B_WILL_DRAW | B_NAVIGABLE | B_FULL_UPDATE_ON_RESIZE)
{
}


void
MediaView::AttachedToWindow()
{
	inherited::AttachedToWindow();
	SetFontName("Erich");
	SetFontSize(9);
	SetDrawingMode(B_OP_COPY);
	SetInvocationMessage(new BMessage(MEDIA_EDIT));
}


MediaView::~MediaView()
{
	ClearAll();
}


void
MediaView::DrawItem(
	BRect			updateRect,
	long			index)
{
	FrameItem *item = (FrameItem *)ItemAt(index);
	if (!item)
		return;
	BRect frame = ItemFrame(index);
	if (!frame.Intersects(updateRect))
		return;

	float baseLine = frame.bottom-BaselineOffset();
	MovePenTo(3.0, baseLine);
	DrawString(item->fName);
	frame.left = frame.right-160.0;	/*	time width */

	FillRect(frame, B_SOLID_LOW);
	char buf[20];

	sprintf(buf, "%ld", item->fTicksDuration);
	MovePenTo(frame.right-82.0-StringWidth(buf), baseLine);
	DrawString(buf);

	sprintf(buf, "%ld", item->fRunningTotal);
	MovePenTo(frame.right-StringWidth(buf)-2.0, baseLine);
	DrawString(buf);
}


void
MediaView::MessageReceived(
	BMessage		*message)
{
	switch (message->what) {
	case B_SIMPLE_DATA:
		{
			bool succe = false;
			BPoint where(0.0,CountItems()*ItemHeight());
			if (message->WasDropped())
				where = message->DropPoint();
			if (message->HasRef("refs"))
			{
				succe = true;
				long item = (where.y/ItemHeight()+0.5);
				if (item > CountItems())
					item = CountItems();
				if (item < 0)
					item = 0;
				for (int ix=0; message->HasRef("refs", ix); ix++) {
					bool ok = ReadFile(message->FindRef("refs", ix), item);
					if (ok)
						item++;
					succe = succe && ok;
				}
				RecalcItemTotals(NULL, 0);
			}
			if (!succe)
			{
				beep();
			}
		}
		break;
	default:
		inherited::MessageReceived(message);
		break;
	}
}


bool
MediaView::SaveTo(
	BFile			&file)
{
	long err = B_OK;
	{
		DFileStream input(&file);
		input.SetDispose(false);
		MEDIAWriter writer(input);
		BRect area(0,0,0,0);
		bool set = false;
		bool fmt8 = true;
		long rowbytes = 0;
		for (int ix=0; ix<CountItems() && !err; ix++)
		{
			FrameItem *item = (FrameItem *)ItemAt(ix);
			BitmapFrameItem *bits = dynamic_cast<BitmapFrameItem *>(item);
			if (bits)
			{
				if (bits->fMap->ColorSpace() != B_COLOR_8_BIT)
					fmt8 = false;
				if (bits->fMap->BytesPerRow() > rowbytes)
					rowbytes = bits->fMap->BytesPerRow();
				if (!set)
				{
					area = bits->fMap->Bounds();
					set = true;
				}
				else
				{
					area = area | bits->fMap->Bounds();
				}
			}
		}
		err = writer.PutBitmapHeader(area, fmt8 ? B_COLOR_8_BIT : B_RGB_32_BIT, rowbytes);
		for (int ix=0; ix<CountItems() && !err; ix++)
		{
			FrameItem *item = (FrameItem *)ItemAt(ix);
			BitmapFrameItem *bits = dynamic_cast<BitmapFrameItem *>(item);
			if (bits)
			{
				err = writer.PutBitmap(bits->fMap, ix?4410:0);
			}
		}
	}
	return !err;
}


void
MediaView::ClearAll()
{
	for (int ix = CountItems()-1; ix>=0; ix--)
	{
		FrameItem *frm = (FrameItem *)ItemAt(ix);
		delete frm;
	}
	MakeEmpty();
}


bool
MediaView::ReadFile(
	record_ref			ref,
	long				asItem)
{
	BBitmap *map = GetBitmap(ref);
	if (map)
	{
		char path[B_FILE_NAME_LENGTH];
		strcpy(path, "<unknown>");
		BFile file(ref);
		file.GetName(path);
		BitmapFrameItem *item = new BitmapFrameItem(map, path, 4410);
		AddItem(item, asItem);
		return true;
	}
	return false;
}


void
MediaView::RecalcItemTotals(
	FrameItem			*item,	/*	NULL when item deleted	*/
	long				index)	/*	index of first affected item	*/
{
	FrameItem *first = (FrameItem *)ItemAt(0);
	first->fRunningTotal = first->fTicksDuration;
	float runningTotal = first->fRunningTotal;
	/*	Right now, we do it from the beginning...	*/
	for (int ix=1; ix<CountItems(); ix++)
	{
		FrameItem *curItem = (FrameItem *)ItemAt(ix);
		ASSERT(curItem != NULL);
		for (int iy=ix-1; iy>=0; iy--)
		{
			FrameItem *prevItem = (FrameItem *)ItemAt(iy);
			ASSERT(prevItem != NULL);
			if (prevItem->fType == curItem->fType) {
				if (prevItem->fRunningTotal+curItem->fTicksDuration > runningTotal)
					runningTotal = prevItem->fRunningTotal+curItem->fTicksDuration;
				curItem->fRunningTotal = runningTotal;
				break;	/*	out of inner loop; go to next item in outer loop	*/
			}
		}
	}
	Invalidate();	/*	Redraw the items	*/
}
