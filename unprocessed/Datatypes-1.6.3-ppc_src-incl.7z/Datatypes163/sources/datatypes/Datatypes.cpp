//	Datatypes.cpp
/*	$Id: Datatypes.cpp,v 1.1 1997/07/22 21:26:58 hplus Exp $	*/

#include <DataIO.h>
#include <Datatypes.h>
#include <DataHandler.h>
#include <DList.h>
#if PROTECTION
	#include "Acquire.h"
#endif

#include <OS.h>
#include <image.h>
#include <File.h>
#include <Directory.h>
#include <Volume.h>
#include <string.h>
#include <OS.h>
#include <stdlib.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <alloca.h>


int debug = 0;


const char dataDefaultTranslatorPath[]	= "/boot/home/config/add-ons/Datatypes:/system/add-ons/Datatypes:/system/add-ons/rraster";


struct XLInfo {
					XLInfo() { memset(this, 0, sizeof(*this)); }

	XLInfo *		next;

	char			name[NAME_MAX];
	image_id		image;
	const char *	handlerName;
	const char *	handlerInfo;
	int32			handlerVersion;
	const Format *	inputFormats;
	const Format *	outputFormats;

	status_t		(*Identify)(
						BPositionIO &		inSource,
						const Format *		inFormat,
						BMessage *			ioExtension,
						DATAInfo &			outInfo,
						uint32				outType);
	status_t		(*Translate)(
						BPositionIO &		inSource,
						const DATAInfo &	inInfo,
						BMessage *			ioExtension,
						uint32				outFormat,
						BPositionIO &		outDestination);
	status_t		(*MakeConfig)(
						BMessage *			ioExtension,
						BView * &			outView,
						BRect &				outExtent);
	status_t		(*GetConfigMessage)(
						BMessage *			ioExtension);

	status_t		(*MakeCapturePanel)(
						BMessage *			ioExtension,
						BView * &			outView,
						BRect &				outExtent);
	status_t		(*Capture)(
						BView *				configView,
						BMessage *			ioExtension,
						BPositionIO &		outStream,
						uint32				captureFormat);

};


class StAcquire {
	sem_id		fSem;
public:
				StAcquire(
					sem_id sem)
				{
					acquire_sem(sem);
					fSem = sem;
				}
				~StAcquire()
				{
					release_sem(fSem);
				}
};


static XLInfo *sInfo;
static sem_id sSem;


const char *
DATAVersion(	//	returns version string
	int32 &		outCurVersion,	//	current version spoken
	int32 &		outMinVersion)	//	minimum version understood
{
	static char vString[50];
	static char vDate[] = __DATE__;
	if (!vString[0]) {
		sprintf(vString, "Datatypes Library v%d.%d.%d %s\n",
			DATA_CURRENT_VERSION/100,
			(DATA_CURRENT_VERSION/10)%10,
			DATA_CURRENT_VERSION%10,
			vDate);
	}
	outCurVersion = DATA_CURRENT_VERSION;
	outMinVersion = DATA_MIN_VERSION;
	return vString;
}


static status_t
LoadTranslator(
	const char *		path)
{
	//	check that this ref is not already loaded
	bool found = FALSE;
	const char *name = strrchr(path, '/');
	if (name)
		name++;
	else
		name = path;
	for (XLInfo *i = sInfo; i && !found; i=i->next)
		if (!strcmp(name, i->name))
			found = TRUE;
	if (debug) printf("LoadTranslator(%s) found = %s\n", path, found ? "true" : "false");
	//	we use name for determining whether it's loaded
	//	that is not entirely foolproof, but making SURE will be 
	//	a very slow process that I don't much care for.
	if (found)
		return B_NO_ERROR;

	//	go ahead and load it
	image_id image = load_add_on(path);
	if (debug) printf("load_add_on(%s) = %d\n", path, image);
	if (image < 0)
		return image;

	XLInfo *info = new XLInfo;
	strcpy(info->name, name);
	info->image = image;

	//	find all the symbols
	status_t err = get_image_symbol(image, "handlerName", B_SYMBOL_TYPE_DATA,
			(void **)&info->handlerName);
	if (!err && get_image_symbol(image, "handlerInfo",
			B_SYMBOL_TYPE_DATA, (void **)&info->handlerInfo))
		info->handlerInfo = NULL;
	long * vptr = NULL;
	if (!err)
		err = get_image_symbol(image, "handlerVersion",
				B_SYMBOL_TYPE_DATA, (void **)&vptr);
	if (!err && (vptr != NULL))
		info->handlerVersion = *vptr;
	if (!err && get_image_symbol(image, "inputFormats",
			B_SYMBOL_TYPE_DATA, (void **)&info->inputFormats))
		info->inputFormats = NULL;
	if (!err && get_image_symbol(image, "outputFormats",
			B_SYMBOL_TYPE_DATA, (void **)&info->outputFormats))
		info->outputFormats = NULL;
	if (!err)
		err = get_image_symbol(image, "Identify", B_SYMBOL_TYPE_TEXT,
				(void **)&info->Identify);
	if (!err)
		err = get_image_symbol(image, "Translate",
				B_SYMBOL_TYPE_TEXT, (void **)&info->Translate);
	if (!err && get_image_symbol(image, "MakeConfig",
			B_SYMBOL_TYPE_TEXT, (void **)&info->MakeConfig))
		info->MakeConfig = NULL;
	if (!err && get_image_symbol(image, "GetConfigMessage",
			B_SYMBOL_TYPE_TEXT, (void **)&info->GetConfigMessage))
		info->GetConfigMessage = NULL;
	if (!err && get_image_symbol(image, "MakeCapturePanel",
			B_SYMBOL_TYPE_TEXT, (void **)&info->MakeCapturePanel))
		info->MakeCapturePanel = NULL;
	else if (!err && get_image_symbol(image, "Capture",
			B_SYMBOL_TYPE_TEXT, (void **)&info->Capture))
		info->Capture = NULL, info->MakeCapturePanel = NULL;	//	can't allow one without the other

	if (err) {	//	this is not a correct add-on
		delete info;
		return err;
	}

	//	add to global list
	info->next = sInfo;
	sInfo = info;

	return B_NO_ERROR;
}


static void
LoadDir(
	const char *	path,
	int32 &			loadErr,
	int32 &			nLoaded)
{
	loadErr = B_OK;
	DIR *	dir = opendir(path);
	if (debug) printf("LoadDir(%s) opendir() = %08x\n", path, dir);
	if (!dir)
	{
		loadErr = B_FILE_NOT_FOUND;
		return;
	}
	struct dirent *dent;
	struct stat stbuf;
	char cwd[PATH_MAX] = "";
	while (NULL != (dent = readdir(dir)))
	{
		strcpy(cwd, path);
		strcat(cwd, "/");
		strcat(cwd, dent->d_name);
		status_t err = stat(cwd, &stbuf);
		if (debug) printf("stat(%s) = %08x\n", cwd, err);
		if (!err && S_ISREG(stbuf.st_mode) &&
			strcmp(dent->d_name, ".") && strcmp(dent->d_name, ".."))
		{
			err = LoadTranslator(cwd);
			if (B_OK == err)
			{
				nLoaded++;
			}
			else
			{
				loadErr = err;
			}
			if (debug) printf("LoadTranslator(%s) = %d  (%d/%08x)\n", cwd, err, nLoaded, loadErr);
		}
	}
	closedir(dir);
}


status_t
DATAInit(		//	establish connection
	const char *	/* app_type */,
	const char *	path)
{
	if (getenv("DATATYPES_DEBUG") != NULL)
		debug = 1;
	if (sSem <= 0)
		sSem = create_sem(1, "Datatypes Lock");
	if (sSem <= 0)
		return sSem;

	StAcquire lock(sSem);

	status_t loadErr = 0;
	int32 nLoaded = 0;

	if (path == NULL)
	{
		path = getenv("DATATYPES");
	}
	if (path == NULL)
	{
		path = dataDefaultTranslatorPath;
	}
	//	else parse path syntax; load folders and files
	char pathbuf[PATH_MAX];
	const char *ptr = path;
	const char *end = ptr;
	struct stat stbuf;
	while (*ptr != 0)
	{
		//	find segments specified by colons
		end = strchr(ptr, ':');
		if (end == NULL)
		{
			end = ptr+strlen(ptr);
		}
		if (end-ptr > PATH_MAX-1)
		{
			loadErr = B_BAD_VALUE;
			if (debug) printf("too long path!\n");
		}
		else
		{
			//	copy this segment of the path into a path, and load it
			memcpy(pathbuf, ptr, end-ptr);
			pathbuf[end-ptr] = 0;
			if (debug) printf("load path: %s\n", pathbuf);
			if (!stat(pathbuf, &stbuf))
			{
				//	files are loaded as translators
				if (S_ISREG(stbuf.st_mode))
				{
					status_t err = LoadTranslator(pathbuf);
					if (err != B_OK)
						loadErr = err;
					else
						nLoaded++;
				}
				else
				{
					//	directories are scanned
					LoadDir(pathbuf, loadErr, nLoaded);
				}
			} else if (debug) printf("cannot stat()!\n");
		}
		ptr = end+1;
		if (*end == 0)
			break;
	}

	//	if anything loaded, it's not too bad
	if (nLoaded)
		loadErr = B_OK;

	return loadErr;
}


status_t
DATAShutdown()	//	don't want to talk anymore
{
	if (sSem > 0) {

		acquire_sem(sSem);

		XLInfo *info = sInfo;
		sInfo = NULL;
		while (info != NULL) {
			XLInfo *del = info;
			info = info->next;
			unload_add_on(del->image);
			delete del;
		}

		delete_sem(sSem);
		sSem = 0;

	} else {

		return DATA_NOT_INITIALIZED;	
	}
	return B_NO_ERROR;
}


//	these functions call through to the translators


//	CheckFormats is a utility function that returns TRUE if the 
//	data provided and translator info can be used to make a 
//	determination (even if that termination is negative) and 
//	FALSE if content identification has to be done.
static bool
CheckFormats(
	XLInfo *			info,
	uint32				hintType,
	const char *		hintMIME,
	const Format * &	outFormat)
{
	outFormat = NULL;

	//	return FALSE if we can't use hints for this module
	//
	if (!hintType && !hintMIME)
		return FALSE;
	if (!info->inputFormats)
		return FALSE;

	//	scan for suitable format
	//
	const Format *fmt = info->inputFormats;
	int mlen = 0;
	//	check for the length of the MIME string, since it may be just a prefix
	//	so we use strncmp().
	if (hintMIME)
		mlen = strlen(hintMIME);
	while (fmt->type) {
		if ((fmt->type == hintType) ||
				(hintMIME && mlen && !strncmp(fmt->MIME, hintMIME, mlen)))
		{
			outFormat = fmt;
			return TRUE;
		}
		fmt++;
	}
	//	the module did export formats, but none mathced.
	//	we return true (uses formats) but set outFormat to NULL
	return TRUE;
}


status_t
DATAIdentify(	//	find out what something is
	BPositionIO &		inSource,
	BMessage *			ioExtension,
	DATAInfo &			outInfo,
	uint32				inHintType,
	const char *		inHintMIME,
	uint32				inWantType)
{
	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	XLInfo *info = sInfo;
	XLInfo *bestMatch = NULL;
	float bestWeight = 0.0;
	while (info) {

		Format *format = NULL;
		DATAInfo tmpInfo;
		float weight = 0.0;

		status_t err = inSource.Seek(0, SEEK_SET);
		if (err < B_OK) {
			return err;
		}

		if (CheckFormats(info, inHintType, inHintMIME, format)) {

			//	after checking the formats for hints, we still need to make sure the translator recognizes 
			//	the data and can output the desired format, so we call its' Identify() function.
			if (debug) printf("CheckFormats(%s) OK\n", info->name);
			if (format && !info->Identify(inSource, format, ioExtension,
					tmpInfo, inWantType)) {

				goto add_match;
			}
		} else if (!info->Identify(inSource, NULL, ioExtension, 
				tmpInfo, inWantType)) {

			if (debug) printf("Identify(%s) OK\n", info->name);
	add_match:
			 // XOR to discourage taking advantage of undocumented features.
			tmpInfo.formatHandler = info->image^DATA_CURRENT_VERSION;
			weight = tmpInfo.formatQuality * tmpInfo.formatCapability;

			if (weight > bestWeight) {

				bestMatch = info;
				bestWeight = weight;
				outInfo = tmpInfo;
			}
		} else if (debug) printf("%s refuses\n", info->name);
		info = info->next;
	}
	return bestMatch ? B_NO_ERROR : DATA_NO_HANDLER;
}


	static int
	compare_data(
		const void *a,
		const void *b)
	{
		register DATAInfo *ai = (DATAInfo *)a;
		register DATAInfo *bi = (DATAInfo *)b;
		return - ai->formatQuality*ai->formatCapability +
				bi->formatQuality*bi->formatCapability;
	}

status_t
DATAGetHandlers(	//	find all handlers for a type
	BPositionIO &		inSource,
	BMessage *			ioExtension,
	DATAInfo * &		outInfo,	//	call delete[] on outInfo when done
	int32 &				outNumInfo,
	uint32				inHintType,
	const char *		inHintMIME,
	uint32				inWantType)
{
	outInfo = NULL;
	outNumInfo = 0;

	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	int32 physCnt = 10;
	outInfo = new DATAInfo[physCnt];
	outNumInfo = 0;

	XLInfo *info = sInfo;

	while (info) {

		Format *format = NULL;
		DATAInfo tmpInfo;

		status_t err = inSource.Seek(0, SEEK_SET);
		if (err < B_OK) {
			delete outInfo;
			outInfo = NULL;
			return err;
		}

		if (CheckFormats(info, inHintType, inHintMIME, format)) {
			if (format && !info->Identify(inSource, format, ioExtension, tmpInfo, 
					inWantType)) {

				goto add_match;
			}
		} else if (!info->Identify(inSource, NULL, ioExtension, tmpInfo, inWantType)) {

	add_match:
			//	dynamically resize output list
			//
			if (physCnt <= outNumInfo) {

				physCnt += 10;
				DATAInfo *nOut = new DATAInfo[physCnt];
				for (int ix=0; ix<outNumInfo; ix++) {

					nOut[ix] = outInfo[ix];
				}
				delete[] outInfo;
				outInfo = nOut;
			}

			 // XOR to discourage taking advantage of undocumented features
			tmpInfo.formatHandler = info->image^DATA_CURRENT_VERSION;

			outInfo[outNumInfo++] = tmpInfo;
		}
		info = info->next;
	}
	if (outNumInfo > 1) {
		qsort(outInfo, outNumInfo, sizeof(*outInfo), compare_data);
	}
	return outNumInfo ? B_NO_ERROR : DATA_NO_HANDLER;
}


extern status_t
DATAGetAllHandlers(
	DATAID * & outList,
	int32 & outCount)
{
	outList = NULL;
	outCount = 0;

	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	//	count handlers
	XLInfo *info = NULL;
	for (info = sInfo; info != NULL; info = info->next)
		outCount++;
	outList = new DATAID[outCount];
	outCount = 0;
	for (info = sInfo; info != NULL; info = info->next)
		outList[outCount++] = info->image^DATA_CURRENT_VERSION;

	return B_NO_ERROR;
}


extern status_t
DATAGetHandlerInfo(
	DATAID				forHandler,
	const char * &		outName,
	const char * &		outInfo,
	int32 &				outVersion)
{
	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	//	find the handler we've requested
	XLInfo *info = NULL;
	for (info = sInfo; info != NULL; info = info->next) {

		if ((info->image^DATA_CURRENT_VERSION) == forHandler)
			break;
	}
	if (!info)
		return DATA_NO_HANDLER;

	outName = info->handlerName;
	outInfo = info->handlerInfo;
	outVersion = info->handlerVersion;

	return B_NO_ERROR;
}


extern status_t
DATAGetInputFormats(
	DATAID				forHandler,
	const Format * &	outFormats,		//	don't write contents!
	int32 &				outNumFormats)
{
	outFormats = NULL;
	outNumFormats = 0;

	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	//	find the handler we've requested
	XLInfo *info = NULL;
	for (info = sInfo; info != NULL; info = info->next) {

		if ((info->image^DATA_CURRENT_VERSION) == forHandler)
			break;
	}
	if (!info)
		return DATA_NO_HANDLER;

	outFormats = info->inputFormats;
	if (outFormats)
		while (outFormats[outNumFormats].type)
			outNumFormats++;

	return B_NO_ERROR;
}


extern status_t
DATAGetOutputFormats(
	DATAID forHandler,
	const Format * & outFormats,
	int32 & outNumFormats)
{
	outFormats = NULL;
	outNumFormats = 0;

	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	//	find the handler we've requested
	XLInfo *info = NULL;
	for (info = sInfo; info != NULL; info = info->next) {

		if ((info->image^DATA_CURRENT_VERSION) == forHandler)
			break;
	}
	if (!info)
		return DATA_NO_HANDLER;

	outFormats = info->outputFormats;
	if (outFormats)
		while (outFormats[outNumFormats].type)
			outNumFormats++;

	return B_NO_ERROR;
}


status_t
DATATranslate(	//	morph data into form we want
	BPositionIO &		inSpec,
	const DATAInfo *	inInfo,			//	may be NULL
	BMessage *			ioExtension,
	BPositionIO &		outSpec,
	uint32 				inWantOutType,
	uint32				inHintType,
	const char *		inHintMIME)
{
	DATAInfo stat_info;

	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	if (!inInfo) {	//	go look for a suitable translator?

		inInfo = &stat_info;

		status_t err = DATAIdentify(inSpec, ioExtension, stat_info, 
				inHintType, inHintMIME, inWantOutType);
		if (err)
			return err;
	}

	XLInfo *info = NULL;
	for (info = sInfo; info != NULL; info = info->next) {

		if ((info->image^DATA_CURRENT_VERSION) == inInfo->formatHandler)
			break;
	}
	if (!info)
		return DATA_NO_HANDLER;

	status_t err = inSpec.Seek(0, SEEK_SET);
	if (err < B_OK) {
		return err;
	}

	return info->Translate(inSpec, *inInfo, ioExtension, inWantOutType, outSpec);
}


//	A translator may support settings for things such as preferred bit depth, etc.
//	Create a BView that contains controls and logic to "run" and change these settings.

status_t
DATAMakeConfig(
	DATAID				forHandler,
	BMessage *			ioExtension,
	BView * &			outView,
	BRect &				outExtent)
{
	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	XLInfo *info = NULL;
	for (info = sInfo; info != NULL; info = info->next) {

		if ((info->image^DATA_CURRENT_VERSION) == forHandler)
			break;
	}
	if (!info || !info->MakeConfig)
		return DATA_NO_HANDLER;

	return info->MakeConfig(ioExtension, outView, outExtent);
}


//	For batch translation using different kinds of settings, a Datatype could 
//	support returning an ioExtension message with its parameters in it. It will 
//	then be passed to DATATranslate in the ioExtension parameter.
//	Copy into the message, which will already be allocated.

status_t
DATAGetConfigMessage(
	DATAID				forHandler,
	BMessage *			ioExtension)
{
	if (!ioExtension)
		return B_BAD_VALUE;

	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	XLInfo *info = NULL;
	for (info = sInfo; info != NULL; info = info->next) {

		if ((info->image^DATA_CURRENT_VERSION) == forHandler)
			break;
	}
	if (!info || !info->GetConfigMessage)
		return DATA_NO_HANDLER;

	return info->GetConfigMessage(ioExtension);
}


			//	Some Datatypes get data from thin air (QuickCam, recorder, ...)
			//	These Datatypes utilize the Capture API, a simple API that lets 
			//	applications run the Datatype and tell it to start generating 
			//	data.

status_t
DATAListCaptures(		//	experimental - may change
	uint32				captureType,
	DATAID * &			outHandlers,	//	delete[] when done
	int32 &				outNumHandlers)
{
	outHandlers = NULL;
	outNumHandlers = 0;

	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	int phys = 16;
	int logi = 0;
	outHandlers = new DATAID[phys];
	for (XLInfo *info = sInfo; info != NULL; info = info->next)
	{
		if (info->Capture != NULL)
		{
			for (int ix=0; info->outputFormats[ix].type != 0; ix++)
			{
				if (info->outputFormats[ix].type == captureType)
				{
					if (logi >= phys)
					{
						DATAID * rep = new DATAID[logi*2];
						if (!rep)
							return B_NO_MEMORY;
						memcpy(rep, outHandlers, sizeof(DATAID)*logi);
						phys = logi*2;
						delete[] outHandlers;
						outHandlers = rep;
					}
					outHandlers[logi++] = (info->image ^ DATA_CURRENT_VERSION);
					if (debug) printf("Capture: %s -> %s\n", info->name, info->handlerName);
				}
			}
		}
	}
	outNumHandlers = logi;
	return B_OK;
}


status_t
DATAMakeCapturePanel(	//	experimental - may change
	DATAID				handler,
	BMessage *			ioExtension,
	BView * &			outView,
	BRect &				outExtent)
{
	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	for (XLInfo *info = sInfo; info != NULL; info = info->next)
	{
		if ((info->MakeCapturePanel != NULL) && (info->image == (handler ^ DATA_CURRENT_VERSION)))
		{
			return (*info->MakeCapturePanel)(ioExtension, outView, outExtent);
		}
	}
	return DATA_NO_HANDLER;
}


status_t
DATACapture(			//	experimental - may change
	DATAID				handler,
	BView *				view,
	BMessage *			ioExtension,
	BPositionIO &		stream,
	uint32				captureType)
{
	if (sSem <= 0)
		return DATA_NOT_INITIALIZED;

#if PROTECTION
	Acquire lock(sSem);
#endif

	for (XLInfo *info = sInfo; info != NULL; info = info->next)
	{
		if ((info->Capture != NULL) && (info->image == (handler ^ DATA_CURRENT_VERSION)))
		{
			return (*info->Capture)(view, ioExtension, stream, captureType);
		}
	}
	return DATA_NO_HANDLER;
}






