//	DataMedia.cpp

#include <Datatypes.h>
#include <DataIO.h>
#include "DataMedia.h"
#include <Bitmap.h>
#include <InterfaceDefs.h>
#include <string.h>

#include <Debug.h>


/**********************************************************************
 *
 *	MEDIAWriter
 *
 **********************************************************************/



//	This simple utility class will write a standard baseline media stream for you.
MEDIAWriter::MEDIAWriter(
	BPositionIO &		outstream,
	int32			samplerate,
	bool			usesvideo,
	bool			usessound) :
	fOutput(outstream)
{
	fSampleRate = samplerate;
	fBitmapCount = 0;
	fSoundCount = 0;
	fLastBitmapClock = 0;
	fNextSoundClock = 0;
	fLastSoundClock = 0;
	fComment = NULL;

	MediaStreamHeader hdr;
	hdr.magic = MEDIA_START_MAGIC;
	hdr.headersize = sizeof(hdr);

	int items = 0;
	if (usesvideo) items++;
	if (usessound) items++;
	hdr.datasize = items*sizeof(uint32);
	hdr.ticksstart = 0;
	hdr.tickspersec = samplerate;

	fOutput.Write(&hdr, sizeof(hdr));

	uint32 tag = MEDIA_BITMAP_CHUNK;
	if (usesvideo)
		fOutput.Write(&tag, sizeof(tag));

	tag = MEDIA_SOUND_CHUNK;
	if (usessound)
		fOutput.Write(&tag, sizeof(tag));
}


MEDIAWriter::~MEDIAWriter()
{
	const char *comment = fComment;
	if (!comment) {
		comment = "Created by MEDIAWriter.\n";
	}

	MediaStreamTrailer butt;
	butt.magic = MEDIA_END_MAGIC;
	butt.headersize = sizeof(butt);
	butt.datasize = strlen(comment);
	butt.endtime = fLastBitmapClock > fNextSoundClock ? fLastBitmapClock : fNextSoundClock;
	butt.numframes = fBitmapCount > fSoundCount ? fBitmapCount : fSoundCount;

	fOutput.Write(&butt, sizeof(butt));
	fOutput.Write(comment, butt.datasize);
	delete[] fComment;
}


void
MEDIAWriter::SetComment(
	const char *	text)
{
	delete[] fComment;
	if (!text) {
		fComment = NULL;
	} else {
		fComment = new char[strlen(text)+1];
		strcpy(fComment, text);
	}
}


	static uint16
	space_convert(
		color_space		space)
	{
		/*	This will change when the PowerMac version has different byte order */
		switch (space) {
		case B_COLOR_8_BIT:
			return MEDIA_8_BIT_FIXED;
		case B_GRAYSCALE_8_BIT:
			return MEDIA_8_BIT_GRAY;
		case B_RGB_16_BIT:
			return MEDIA_16_BIT_BGRA;
		case B_RGB_32_BIT:
			return MEDIA_32_BIT_BGRA;
		default:
			//	don't know what this is!
			return 0;
		}
	}

int32
MEDIAWriter::PutBitmap(
	BBitmap *		bitmap,
	int32			afterSamples)
{
	ASSERT(bitmap != NULL);
	return PutBitData(
		bitmap->Bits(),
		bitmap->BytesPerRow(),
		bitmap->Bounds().left,
		bitmap->Bounds().top,
		bitmap->Bounds().Width()+1, 
		bitmap->Bounds().Height()+1,
		bitmap->ColorSpace(),
		afterSamples);
}


int32
MEDIAWriter::PutBitmapHeader(
	BRect				area,
	color_space			space,
	int32				rowbytes)
{
	/*	Set up bitmap chunk header */
	MediaBitmapHeader hdr;
	hdr.magic = MEDIA_BITMAP_HEADER;
	hdr.hdrsize = sizeof(hdr);
	hdr.datasize = 0;
	hdr.position = fLastBitmapClock;
	hdr.space = space_convert(space);
	if (!hdr.space) return DATA_ILLEGAL_DATA;	//	make sure we know the representation
	hdr.xpos = area.left;
	hdr.ypos = area.top;
	hdr.xsize = area.IntegerWidth()-1;
	hdr.ysize = area.IntegerHeight()-1;
	int32 altrb = hdr.xsize;
	switch (hdr.space) {	/*	calculate actual rowBytes of image	*/
	default:	/* 8 bit formats */
		break;
	case MEDIA_32_BIT_BGRA:
	case MEDIA_32_BIT_ARGB:
		altrb *= 4;
		break;
	case MEDIA_16_BIT_BGRA:
	case MEDIA_16_BIT_ARGB:
		altrb *= 2;
		break;
	}
	altrb = (altrb+7)&~7;
	if (altrb > rowbytes)
		rowbytes = altrb;
	hdr.rowbytes = rowbytes;

	/*	Write header */
	int32 err = fOutput.Write(&hdr, sizeof(hdr));
	return err;
}


int32
MEDIAWriter::PutBitData(
	const void *	bits,
	int32				rowBytes,
	int32				xpos,
	int32				ypos,
	int32				numCols,
	int32				numRows,
	color_space		space,
	int32			afterSamples)
{
	fBitmapCount++;

	/*	Update internal clock */
	/*	The relation is such that no "next" frame can play before any "previous" frame */
	fLastBitmapClock += afterSamples;
	if (fLastBitmapClock < fLastSoundClock)
		fLastBitmapClock = fLastSoundClock;	//	sound was already played

	/*	Set up bitmap chunk header */
	MediaBitmapHeader hdr;
	hdr.magic = MEDIA_BITMAP_CHUNK;
	hdr.hdrsize = sizeof(hdr);
	hdr.datasize = rowBytes*numRows;
	hdr.position = fLastBitmapClock;
	hdr.space = space_convert(space);
	if (!hdr.space) return DATA_ILLEGAL_DATA;	//	make sure we know the representation
	hdr.xpos = xpos;
	hdr.ypos = ypos;
	hdr.xsize = numCols;
	hdr.ysize = numRows;
	hdr.rowbytes = rowBytes;

	/*	Write header */
	int32 err = fOutput.Write(&hdr, sizeof(hdr));
	if (err) return err;

	/*	Write data */
	err = fOutput.Write(bits, hdr.datasize);
	return err;
}


int32
MEDIAWriter::PutSound(
	const void *	data,
	int32			numsamples,
	int32				numchannels,
	int32				samplebits)
{
	fSoundCount++;

	/*	Calculate sample storage size */
	int nbytes = 1;
	while (nbytes*8 < samplebits)
		nbytes *= 2;

	/*	Update internal clock */
	/*	The relation is such that no "next" frame can play before any "previous" frame */
	if (fLastBitmapClock > fNextSoundClock)
		fNextSoundClock = fLastBitmapClock;	//	bitmap was already played
	fLastSoundClock = fNextSoundClock;
	fNextSoundClock += numsamples;

	/*	Set up sound chunk header */
	MediaSoundHeader hdr;
	hdr.magic = MEDIA_SOUND_CHUNK;
	hdr.hdrsize = sizeof(hdr);
	hdr.datasize = numsamples*numchannels*nbytes;
	hdr.position = fLastSoundClock;
	hdr.samplerate = fSampleRate;
	hdr.channels = numchannels;
	hdr.samplebits = samplebits;

	/*	Write header */
	int32 err = fOutput.Write(&hdr, sizeof(hdr));
	if (err) return err;

	/*	Write data */
	err = fOutput.Write(data, hdr.datasize);
	return err;
}






/**********************************************************************
 *
 *	MEDIAReaderStream
 *
 **********************************************************************/



MEDIAReaderStream::MEDIAReaderStream(
	MEDIANotifier		*notifier) throw(int32)
{
	ASSERT(notifier != NULL);
	fData = malloc(16384);
	if (!fData) {
		throw B_NO_MEMORY;
	}
	fDataPhys = 0;
	fDataLog = 0;
	fBitmap = NULL;
	fNotifier = notifier;
	fPosition = 0;
	fPlayBaseTime = 0.0;
	fTicksPerSec = 44100.0;
	fDetached = false;

	lastsamplerate = 0;
	lastchannels = 0;
	lastbits = 0;
	bitmapx = 0;
	bitmapy = 0;
	InitPalette();
}


/*	Note that MEDIAReaderStream does NOT delete the notifier	*/
MEDIAReaderStream::~MEDIAReaderStream()
{
	if (!fDetached)
		delete fBitmap;
}


BBitmap *
MEDIAReaderStream::DetachBitmap()
{
	if (fBitmap)
		fDetached = true;
	return fBitmap;
}


ssize_t
MEDIAReaderStream::ReadAt(
	off_t				/* pos */,
	void				* /* buffer */,
	size_t				/* size */)
{
	DEBUGGER("MEDIAReaderStream doesn't support Read()");
	return B_ERROR;
}


	struct GenericHeader {
		uint32		magic;
		int32		hdrsize;
		int32		datasize;
		int32		playtime;
	};

ssize_t
MEDIAReaderStream::WriteAt(
	off_t				pos,
	const void			*buffer,
	size_t				size)
{
	if (!fData)
		return B_NO_MEMORY;

	/*	First, make sure we have space in the buffer	*/
	if (fDataPhys < size+fDataLog) {
		fDataPhys = ((size*2+fDataLog+4095+32)&~4095)-32;	/*	Be smart about how much to grow	*/
		void *newPtr = realloc(fData, fDataPhys);
		if (!newPtr) {	/*	purge current data	*/
			fDataLog = 0;
			fDataPhys = 0;
			free(fData);
			fData = NULL;
			fNotifier->StreamEnded();	/*	all the fun is over	*/
			return B_NO_MEMORY;
		}
		fData = newPtr;
	}
	/*	Get the actual data	*/
	memcpy(((char *)fData)+fDataLog, buffer, size);
	fDataLog += size;
	/*	Check for whether we have a chunk	*/
	GenericHeader *gh = (GenericHeader *)fData;
	while ((fDataLog >= 16) && (fDataLog >= gh->hdrsize + gh->datasize)) {
		/*	Deal with chunk	*/
		HandleChunk(gh->magic, fData, ((char *)fData)+gh->hdrsize, gh->datasize);
		/*	Slide chunk in memory	*/
		fDataLog -= (gh->hdrsize+gh->datasize);
		fPosition += (gh->hdrsize+gh->datasize);
		if (fDataLog > 0)
			memmove(fData, ((char *)fData)+(gh->hdrsize+gh->datasize), fDataLog);
	}
	return B_OK;
}


off_t
MEDIAReaderStream::Seek(
	off_t				/* pos */,
	uint32				/* whence */)
{
	DEBUGGER("MEDIAReaderStream does not support Seek()");
	return B_ERROR;	/*	cannot seek in MEDIAReaderStream	*/
}


off_t
MEDIAReaderStream::Position() const
{
	return fPosition;
}


off_t
MEDIAReaderStream::Size() const
{
	DEBUGGER("MEDIAReaderStream does not support Size()");
	return B_ERROR;
}


status_t
MEDIAReaderStream::SetSize(
	off_t				/* size */)
{
	DEBUGGER("MEDIAReaderStream does not support SetSize()");
	return B_ERROR;
}


void
MEDIAReaderStream::HandleChunk(
	uint32				magic,
	const void			*header,
	const void			*data,
	int32				dataSize)
{
	/*	See what we can do about the data	*/
	switch (magic) {
	case MEDIA_START_MAGIC:		/*	Prepare for playback	*/
		fPlayBaseTime = system_time() - 1000000.0 *
			(double)((MediaStreamHeader *)header)->ticksstart/
			(double)((MediaStreamHeader *)header)->tickspersec;
		fTicksPerSec = (double)((MediaStreamHeader *)header)->tickspersec;
		break;
	case MEDIA_BITMAP_HEADER:	/*	Setup bitmap	*/
		ResizeBitmap((MediaBitmapHeader *)header);
		break;
	case MEDIA_BITMAP_CHUNK:	/*	Put bits in bitmap	*/
		ResizeBitmap((MediaBitmapHeader *)header);
		ParseBitmapData((MediaBitmapHeader *)header, data, dataSize);
		break;
	case MEDIA_PALETTE_CHUNK:
		SetPalette((MediaPaletteHeader *)header, data, dataSize);
		break;
	case MEDIA_SOUND_HEADER:	/*	Setup audio	*/
		fNotifier->AudioSetup(
			((MediaSoundHeader *)header)->samplerate,
			((MediaSoundHeader *)header)->channels,
			((MediaSoundHeader *)header)->samplebits);
		break;
	case MEDIA_SOUND_CHUNK:		/*	Play sound	*/
		NapTime(header);
		fNotifier->AudioReceived(
			data,
			dataSize,
			((MediaSoundHeader *)header)->samplerate,
			((MediaSoundHeader *)header)->channels,
			((MediaSoundHeader *)header)->samplebits);
		break;
	case MEDIA_END_MAGIC:		/*	Close up and go home	*/
		fNotifier->StreamEnded();
		free(fData);
		fData = NULL;
		fDataPhys = 0;
		fDataLog = 0;
		break;
	default:
	//	unhandled!
		;
	}
}


void
MEDIAReaderStream::NapTime(
	const void			*header)
{
	/*	Pause until time has appeared	*/
	double naptime = 1000000.0*(double)((GenericHeader *)header)->playtime/fTicksPerSec-
		system_time()+fPlayBaseTime;
//	If these lines are in here, system will adjust time base in event of skips
//	With them taken out,it will try to chase the timeline as determined at start
//	if (naptime < 0)
//		fPlayTimeBase -= naptime;
	if (naptime > 999.0)
		snooze(naptime);
}


	static void
	preserve_bits(
		BBitmap *		from,
		BBitmap *		to)
	{
		for (int iy=from->Bounds().bottom; iy>=0; iy--)
			memcpy(((char *)to->Bits())+to->BytesPerRow()*iy, 
				((char *)from->Bits())+from->BytesPerRow()*iy,
				from->BytesPerRow());
	}


void
MEDIAReaderStream::ResizeBitmap(
	MediaBitmapHeader	*header)
{
	if ((!fBitmap) || (bitmapx < header->xsize+header->xpos) || (bitmapy < header->ysize+header->ypos)) {
		BBitmap *oldMap = fBitmap;
		bitmapx = (header->xsize+header->xpos+7)&~7;
		bitmapy = (header->ysize+header->ypos+7)&~7;
		printf("bitmapx %d bitmapy %d\n", bitmapx, bitmapy);
		BRect area(0,0, bitmapx-1, bitmapy-1);
		fBitmap = new BBitmap(area, B_RGB_32_BIT);
		printf("%08x %08x\n", fBitmap->Bits(), fBitmap->BytesPerRow()*bitmapy);
		memset(fBitmap->Bits(), 0, fBitmap->BytesPerRow()*bitmapy);
		if (oldMap)
			preserve_bits(oldMap, fBitmap);
		delete oldMap;
		fNotifier->BitmapCreated(fBitmap);
	}
}


void
MEDIAReaderStream::ParseBitmapData(
	MediaBitmapHeader	*header,
	const void			*data,
	int32				/* datasize */)
{
	uint32 *ptr = (uint32 *)fBitmap->Bits();
	int ptrrow = fBitmap->BytesPerRow()/sizeof(uint32);
	ptr += header->xpos + ptrrow*header->ypos;
	ASSERT(header->xpos+header->xsize <= bitmapx);
	ASSERT(header->ypos+header->ysize <= bitmapy);
	switch (header->space) {
	case MEDIA_8_BIT_PALETTE:	/*	We're assuming that PALETTE and FIXED are not mixed		*/
	case MEDIA_8_BIT_FIXED:		/*	Thus we can use palette translation in both cases, since the	*/
								/*	palette is initialized on construction					*/
		for (int iy8a=header->ysize; iy8a>0; iy8a--) {
			for (int ix8a=header->xsize-1; ix8a>=0; ix8a--)
				ptr[ix8a] = fPalette[((uchar *)data)[ix8a]];
			data = &((char *)data)[header->rowbytes];
			ptr += ptrrow;
		}
		break;
	case MEDIA_8_BIT_GRAY:
		for (int iy8a=header->ysize; iy8a>0; iy8a--) {
			for (int ix8a=header->xsize-1; ix8a>=0; ix8a--)
				ptr[ix8a] = ((uchar *)data)[ix8a]*(uint32)0x01010101;
			data = &((char *)data)[header->rowbytes];
			ptr += ptrrow;
		}
		break;
	case MEDIA_32_BIT_BGRA:
	case MEDIA_32_BIT_ARGB:
		/*	Both of these are moved into bitmap right now	*/
		/*	We could code one to use lwbrx to swap byte order	*/
		for (int iy8a=header->ysize; iy8a>0; iy8a--) {
			memcpy(ptr, data, header->rowbytes);
			data = &((char *)data)[header->rowbytes];
			ptr += ptrrow;
		}
		break;
	case MEDIA_16_BIT_BGRA:
	case MEDIA_16_BIT_ARGB:
	default:
		/*	unknown bits format - ignore?	*/
		;
	}
	NapTime(header);
	fNotifier->BitmapUpdated(fBitmap, header->xpos, header->ypos, header->xsize, header->ysize);
}


void
MEDIAReaderStream::InitPalette()
{
	for (int ix=0; ix<256; ix++)
	{
		rgb_color c = system_colors()->color_list[ix];
		fPalette[ix] = ((uint32)c.blue<<24)|((uint32)c.green<<16)|((uint32)c.red<<8)|((uint32)c.alpha);
	}
}


void
MEDIAReaderStream::SetPalette(
	MediaPaletteHeader		* /* header */,
	const void				*data,
	int32					dataSize)
{
	if (dataSize > sizeof(uint32)*256)
		dataSize = sizeof(uint32)*256;
	memcpy(fPalette, data, dataSize);	/*	will NOT work for 16-bit palettes...	*/
										/*	similarly, does NOT swap RGB order if needed	*/
}




/**********************************************************************
 *
 *	DefaultNotifier
 *
 **********************************************************************/


DefaultNotifier::DefaultNotifier(
	BView			*view,
	bool			wantResize,
	bool			/* wantAudio */)
{
	fHasFinished = false;
	fResize = wantResize;
	fView = view;
}


DefaultNotifier::~DefaultNotifier()
{
}


bool
DefaultNotifier::HasFinished()
{
	return fHasFinished;
}


void
DefaultNotifier::BitmapCreated(
	BBitmap			*theBitmap)
{
	if (fResize)
	{
		fView->Window()->Lock();
		BRect b = fView->Bounds();
		if (b != theBitmap->Bounds())
			fView->ResizeTo(b.Width(), b.Height());
		fView->Window()->Unlock();
	}
}


void
DefaultNotifier::BitmapUpdated(
	BBitmap			*theBitmap,
	int32			xPos,
	int32			yPos,
	int32			xSize,
	int32			ySize)
{
	fView->Window()->Lock();
	BRect area(xPos,yPos, xPos+xSize-1,yPos+ySize-1);
	fView->DrawBitmap(theBitmap, area, area);
	fView->Window()->Unlock();
}


void
DefaultNotifier::AudioSetup(
	int32			/* samplerate */,
	int32			/* channels */,
	int32			/* bits */)
{
	/*	do nothing	*/
}


void
DefaultNotifier::AudioReceived(
	const void		* /* audioData */,
	int32			/* bufferSize */,
	int32			/* samplerate */,
	int32			/* channels */,
	int32			/* bits */)
{
	/*	do nothing, again	*/
}


void
DefaultNotifier::StreamEnded()
{
	/*	do nothing	*/
}

