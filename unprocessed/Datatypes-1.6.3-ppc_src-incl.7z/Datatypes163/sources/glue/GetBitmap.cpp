/*	GetBitmap.cpp		*/

#include "GetBitmap.h"
#include <Datatypes.h>
#include <DataIO.h>
#include "BitmapStream.h"

#include <sys/stat.h>
#include <File.h>
#include <Application.h>
#include <Resources.h>


BBitmap *
GetBitmap(
	const char			*name)
{
	BBitmap *ret = NULL;
	struct stat st;
	if (!stat(name, &st) && S_ISREG(st.st_mode))
	{
		ret = GetBitmapFile(name);
	}
	else
	{
		ret = GetBitmap(DATA_BITMAP, name);
	}
	return ret;
}


BBitmap *
GetBitmapFile(
	const char *		path)
{
	BFile file(path, B_READ_ONLY);
	if (file.InitCheck())
		return NULL;
	BitmapStream output;
	if (DATATranslate(file, NULL, NULL, output, DATA_BITMAP))
		return NULL;
	BBitmap *ret = NULL;
	if (output.DetachBitmap(ret))
		return NULL;
	return ret;
}


BBitmap *
GetBitmap(
	ulong				type,
	long				id)
{
	if (!be_app)
		return NULL;
	app_info info;
	be_app->GetAppInfo(&info);
	BFile resFile(&info.ref, B_READ_ONLY);
	if (resFile.InitCheck())
		return NULL;
	BResources file(&resFile);
	size_t size = 0;
	void *data = file.FindResource(type, id, &size);
	if (!data)
		return NULL;
	BMemoryIO input(data, size);
	BitmapStream output;
	if (DATATranslate(input, NULL, NULL, output, DATA_BITMAP))
		return NULL;
	BBitmap *ret = NULL;
	if (output.DetachBitmap(ret))
		return NULL;
	return ret;
}


BBitmap *
GetBitmap(
	ulong				type,
	const char			*name)
{
	if (!be_app)
		return NULL;
	app_info info;
	be_app->GetAppInfo(&info);
	BFile resFile(&info.ref, B_READ_ONLY);
	if (resFile.InitCheck())
		return NULL;
	BResources file(&resFile);
	size_t size = 0;
	void *data = file.FindResource(type, name, &size);
	if (!data)
		return NULL;
	BMemoryIO input(data, size);
	BitmapStream output;
	if (DATATranslate(input, NULL, NULL, output, DATA_BITMAP))
		return NULL;
	BBitmap *ret = NULL;
	if (output.DetachBitmap(ret))
		return NULL;
	return ret;
}
