/*	Convert					*/
/*	A program to convert data files using the Datatypes library	*/
/*	$Id: Convert.cpp,v 1.1 1997/07/22 21:23:53 hplus Exp $	*/

#include <Datatypes.h>
#include <DataIO.h>
#include <File.h>
#include <stdio.h>
#include <string.h>


int
main(
	int			argc,
	char *		argv[])
{
	/*	argument checking	*/
	if (argc != 4) {
		fprintf(stderr, "usage: convert <srcfile> <fmt> <dstfile>\n");
		return -1;
	}
	if (strlen(argv[2]) != 4) {
		fprintf(stderr, "usage: <fmt> must be 4 characters\n");
		return -1;
	}

	/*	initialize datatypes	*/
	status_t err = DATAInit("application/x-test-converter");
	if (err != B_OK) {
		fprintf(stderr, "error: cannot initialize datatypes: %08x\n", err);
		return -1;
	}

	/*	set up plumbing for translation	*/
	BFile input(argv[1], O_RDONLY);
	if (input.InitCheck()) {
		fprintf(stderr, "error: cannot open %s\n", argv[1]);
		return -1;
	}
	BFile output(argv[3], O_RDWR | O_CREAT);
	if (output.InitCheck()) {
		if (output.SetTo(argv[3], O_RDWR)) {
			fprintf(stderr, "error: cannot create %s\n", argv[3]);
			return -1;
		}
	}

	/*	do the actual translation	*/
	err = DATATranslate(input, NULL, NULL, output, *(int32*)argv[2]);
	if (err != B_OK) {
		if (err == DATA_NO_HANDLER) {
			fprintf(stderr, "error: unknown file type of %s\n", argv[1]);
		} else {
			fprintf(stderr, "error: cannot translate file: %08x\n", err);
		}
		return -1;
	}
	return 0;
}
