/*	checkin.c	*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <alloca.h>


const char * from = ".";
const char * to = "../RCS";
const char * user;
int errors = 0;


int
usage()
{
	fprintf(stderr, "usage: checkin [options] [files]\n");
	fprintf(stderr, "Defaults:\n");
	fprintf(stderr, "-from %s\n", from);
	fprintf(stderr, "-to   %s\n", to);
	fprintf(stderr, "-user %s\n", user);
}


void
do_file(
	const char *		path)
{
	const char * argv[] = {
		"ci", "-l", "-w", NULL, NULL, NULL
	};
	int child, status;
	char * outp = (char *)alloca(strlen(path)+strlen(to)+5);
	char * wuser = (char *)alloca(strlen(user)+3);
	strcpy(outp, to);
	strcat(outp, "/");
	strcat(outp, path);
	strcat(outp, ",v");
	strcpy(wuser, "-w");
	strcat(wuser, user);
	argv[2] = wuser;
	argv[3] = path;
	argv[4] = outp;
	child = fork();
	if (child == 0)
		exit(execvp("ci", (char **)argv));
	else if (child > 0)
		wait_for_thread(child, &status);
	if (status < 0)
	{
		printf("got an error checking in %s\n", path);
		errors++;
	}
}

void checkin(const char * path);

void
do_dir(
	const char *		path)
{
	DIR *d;
	struct dirent * dent;
static struct stat st;
	char * sbuf = (char *)alloca(strlen(path)+257);

	d = opendir(path);
	if (d == NULL)
	{
		fprintf(stderr, "could not list directory %s\n", path);
		errors++;
		return;
	}
	while (NULL != (dent = readdir(d)))
	{
		if (dent->d_name[0] == '.')	/*	ignore anything with a period	*/
			continue;
		strcpy(sbuf, to);
		strcat(sbuf, "/");
		strcat(sbuf, path);
		mkdir(sbuf, 0x1ff);
		if (stat(sbuf, &st) || !S_ISDIR(st.st_mode))
		{
			fprintf(stderr, "cannot create directory %s\n", path);
			errors++;
			return;
		}
		strcpy(sbuf, path);
		strcat(sbuf, "/");
		strcat(sbuf, dent->d_name);
		checkin(sbuf);
	}
	closedir(d);
}


void
checkin(
	const char *		path)
{
static struct stat stbuf;
	if (stat(path, &stbuf))
	{
		fprintf(stderr, "cannot stat: %s\n", path);
		errors++;
		return;
	}
	if (S_ISREG(stbuf.st_mode))
		do_file(path);
	else if (S_ISDIR(stbuf.st_mode))
		do_dir(path);
	else
	{
		fprintf(stderr, "cannot check in %s\n", path);
		errors++;
	}
}


int
main(
	int argc,
	char * argv[])
{
	int ix;

	user = getenv("USER");
	if (!user) user = "rcs-user";

	if (argc == 1)
	{
		usage();
		exit(1);
	}

	for (ix=1; ix<argc; ix++)
	{
		if (!strcmp(argv[ix], "-help"))
		{
			usage();
			exit(1);
		}
		else if (!strcmp(argv[ix], "-from"))
		{
			ix++;
			from = argv[ix];
		}
		else if (!strcmp(argv[ix], "-to"))
		{
			ix++;
			to = argv[ix];
		}
		else if (!strcmp(argv[ix], "-user"))
		{
			ix++;
			user = argv[ix];
		}
		else
			checkin(argv[ix]);
	}
	return errors;
}
