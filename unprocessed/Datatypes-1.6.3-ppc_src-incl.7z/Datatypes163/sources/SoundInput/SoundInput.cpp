/*	SoundInput	*/
/*	A Datatypes handler that uses the Capture API	*/

#include <InterfaceDefs.h>
#include <Debug.h>
#include <Rect.h>
#include <View.h>
#include <StringView.h>
#include <string.h>
#include <stdio.h>
#include <Mime.h>
#include <unistd.h>
#include <stdlib.h>
#include <Button.h>
#include <Message.h>
#include <Window.h>
#include <AudioStream.h>
#include <Subscriber.h>
#include <alloca.h>
#include <Bitmap.h>


#include "DataHandler.h"
#include "Datatypes.h"
#include <DataIO.h>


#define	VERSION	"v1.0.1"
#define	EMAIL	"<datatypes@mindcontrol.org>"


char			handlerName[] = "SoundInput";		//	required, C string, ex "Jon's Sound"
char			handlerInfo[] = "Sound Input Capture " VERSION " " EMAIL;		//	required, descriptive C string, ex "Jon's Sound Handler (shareware $5: hplus@ix.netcom.com) v1.00"
int32			handlerVersion = 100;		//	required, integer, ex 100

static	int	debug = 0;


/*
	uint32		type;						//	BeOS data type
	uint32		t_cls;						//	class of this format
	float		quality;					//	format quality 0.0-1.0
	float		capability;					//	handler capability 0.0-1.0
	char		MIME[B_MIME_TYPE_LENGTH+11];	//	MIME string
	char		formatName[B_MIME_TYPE_LENGTH+11];	//	only descriptive
*/
Format			inputFormats[] = {
	{ 0, 0, 0, 0, 0, 0 },
};		//	capture reads nothing!

Format			outputFormats[] = {
	{ DATA_SOUND, DATA_SOUND, 0.6, 0.5, "audio/x-data-sound", "Datatypes Sound Format" },
	{ 0, 0, 0, 0, 0, 0 },
};		//	capture only outputs the "standard" baseline format



//	This magic file format tells the translator to read from its input 
//	rather than from the file - thus allowing non-capture-aware programs 
//	to capture, too!
//	User will choose "import", select the "Capture N seconds of sound" 
//	file (provided by this datatype) and will receive that much sound.

#define MAGIC_FILE_MAGIC		'Smgk'
//#define FLAG_VOX				1L
//#define FLAG_TIMEOUT			2L

//	level of variation allowed in the input signal to still detect an offset zero center
#define NOISE 12

struct MagicCaptureFile {
	uint32				magic;
	uint32				version;
	uint32				flags;
	uint32				numFrames;
	char				captureName[32];
};


	static int
	strnlen(
		const char *		str,
		int					mx)
	{
		const char * start = str;
		while (mx-- > 0)
			if (!*str)
				break;
			else
				str++;
		return str-start;
	}


	//	Return DATA_NO_HANDLER if not handling this data.
	//	Even if inputFormats exists, may be called for data without hints
	//	If outType is not 0, must be able to export in wanted format

status_t
Identify(	//	required
	BPositionIO &		inSource,
	const Format *		inFormat,
	BMessage *			ioExtension,
	DATAInfo &			outInfo,
	uint32				outType)
{
	if (outType && (outType != DATA_SOUND))
		return DATA_NO_HANDLER;

	//	To preserve compatibility with non-capture-aware translators,
	//	we use a special data file format that tells us what to capture
	MagicCaptureFile hdr;
	if (inSource.Read(&hdr, sizeof(hdr)) < sizeof(hdr))
		return DATA_NO_HANDLER;
	if (hdr.magic != MAGIC_FILE_MAGIC)
		return DATA_NO_HANDLER;
	if ((hdr.version < 100) || (hdr.version > 199))
		return DATA_NO_HANDLER;
	if (hdr.numFrames > 44100*300L)	/*	can only do five minutes of capture	*/
		return DATA_NO_HANDLER;
	if (hdr.numFrames < 1024)			/*	minimum capture size	*/
		return DATA_NO_HANDLER;
	if (strnlen(hdr.captureName, 32) >= 32)
		return DATA_NO_HANDLER;

	outInfo.formatType = DATA_SOUND;
	outInfo.formatGroup = DATA_SOUND;
	outInfo.formatQuality = 0.5;
	outInfo.formatCapability = 0.5;
	strcpy(outInfo.formatName, "Datatypes Sound Format");
	strcpy(outInfo.MIMEName, "audio/x-data-sound");

	return B_OK;
}


void DoCapture(BView * view, BMessage * ioExtension, uint32 frames, uint32 flags, BPositionIO & output);

status_t
Translate(	//	required
	BPositionIO &		inSource,
	const DATAInfo &	inInfo,
	BMessage *			ioExtension,
	uint32				outFormat,
	BPositionIO &		outDestination)
{
	if (outFormat && (outFormat != DATA_SOUND))
		return DATA_NO_HANDLER;

	//	To preserve compatibility with non-capture-aware translators,
	//	we use a special data file format that tells us what to capture
	MagicCaptureFile hdr;
	if (inSource.Read(&hdr, sizeof(hdr)) < sizeof(hdr))
		return DATA_NO_HANDLER;
	if (hdr.magic != MAGIC_FILE_MAGIC)
		return DATA_NO_HANDLER;
	if ((hdr.version < 100) || (hdr.version > 199))
		return DATA_NO_HANDLER;
	if (strnlen(hdr.captureName, 32) >= 32)
		return DATA_NO_HANDLER;

	return DATA_NO_HANDLER;		/*	do viewless capture later	*/
//	return DoCapture(NULL, ioExtension, hdr.numFrames, hdr.flags, outDestination);
}


	//	right now, there is nothing to configure for this handler

	//	The view will get resized to what the parent thinks is 
	//	reasonable. However, it will still receive MouseDowns etc.
	//	Your view should change settings in the translator immediately, 
	//	taking care not to change parameters for a translation that is 
	//	currently running. Typically, you'll have a global struct for 
	//	settings that is atomically copied into the translator function 
	//	as a local when translation starts.
	//	Store your settings wherever you feel like it.

#include <StringView.h>

status_t
MakeConfig(	//	optional
	BMessage *			ioExtension,
	BView * &			outView,
	BRect &				outExtent)
{
	//	ignore config

	outView = new BView(BRect(0,0,200,150), "SoundInput Settings", B_FOLLOW_NONE, B_WILL_DRAW);
	rgb_color gray = { 222, 222, 222, 0 };
	outView->SetViewColor(gray);

	BStringView *str = new BStringView(BRect(10,10,190,34), "title", handlerName);
	str->SetFont(be_bold_font);
	outView->AddChild(str);

	str = new BStringView(BRect(10,44,190,68), "info", VERSION " " __DATE__);
	str->SetFont(be_plain_font);
	outView->AddChild(str);

	str = new BStringView(BRect(10,69,190,93), "author", EMAIL);
	str->SetFont(be_plain_font);
	outView->AddChild(str);

	outExtent.Set(0,0,200,150);

	return B_OK;
}


	//	Copy your current settings to a BMessage that may be passed 
	//	to DATATranslate at some later time when the user wants to 
	//	use whatever settings you're using right now.

status_t
GetConfigMessage(	//	optional
	BMessage *			ioExtension)
{
	//	ignore config
	return B_OK;
}


#define STOP_CAPTURE	'Scap'

class CaptureView :
	public BView
{
public:
								CaptureView(
									BRect			area,
									BButton *		stop);
								~CaptureView();
		void					Draw(
									BRect			area);
		void					Pulse();
		void					AttachedToWindow();
		void					DetachedFromWindow();
		void					MessageReceived(
									BMessage *		message);

public:

		BButton *				fStop;
		int						curValueL;
		int						curValueR;
		int					curCenterL;
		int					curCenterR;

		BDACStream *			fStream;
		BSubscriber *			fSubscriber;

		BPositionIO *			fOutput;
		bool					fRecording;
		bool					fTriggered;
		uint32					fNumFrames;
		uint32					fCapturedFrames;

		BBitmap *				fBitmap;
		BView *					fBitmapView;

static	bool					StreamFunc(
									void *			userData,
									char *			buffer,
									size_t			count,
									void *			header);
};


CaptureView::CaptureView(
	BRect			area,
	BButton *		stop) :
	BView(area, "SoundInput", B_FOLLOW_NONE, B_WILL_DRAW|B_PULSE_NEEDED)
{
	fStop = stop;
	fStream = new BDACStream;
	fSubscriber = new BSubscriber("SoundInput");
	status_t err = fSubscriber->Subscribe(fStream);
	if (err < B_OK)
		printf("Error %08x subscribing to audio in\n", err);
	fOutput = NULL;
	fRecording = false;
	fTriggered = false;
	fNumFrames = 0;
	fCapturedFrames = 0;
	curValueL = curValueR = 0;
	AddChild(stop);
	BRect a(area);
	a.OffsetTo(B_ORIGIN);
	fBitmap = new BBitmap(area, B_COLOR_8_BIT, true);
	if (fBitmap != NULL)
	{
		fBitmap->Lock();
		fBitmapView = new BView(area, "bm", B_FOLLOW_NONE, 0);
		fBitmap->AddChild(fBitmapView);
		fBitmap->Unlock();
	}
	curCenterL = curCenterR = 0;
}


CaptureView::~CaptureView()
{
	delete fBitmap;
}


rgb_color highColor[] = {
	{ 50, 210, 100, 0 },
	{ 50, 210, 100, 0 },
	{ 50, 210, 100, 0 },
	{ 50, 210, 100, 0 },
	{ 50, 210, 100, 0 },
	{ 50, 210, 100, 0 },
	{ 50, 210, 100, 0 },
	{ 50, 210, 100, 0 },
	{ 50, 210, 100, 0 },
	{ 50, 210, 100, 0 },
	{ 50, 210, 100, 0 },	/* 10 */
	{ 50, 250, 100, 0 },
	{ 50, 250, 100, 0 },
	{ 180, 250, 100, 0 },
	{ 255, 200, 100, 0 },
	{ 255, 50, 100, 0 },	/* 15 */
};

rgb_color lowColor[] = {
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 50, 80, 50, 0 },
	{ 80, 80, 0, 0 },
	{ 80, 80, 0, 0 },
	{ 80, 40, 0, 0 },
};

void
CaptureView::Draw(
	BRect			area)
{
	BView *dr = (fBitmap ? fBitmapView : this);
	if (fBitmap)
		fBitmap->Lock();
	rgb_color gray = { 100, 100, 100, 0 };
	dr->SetHighColor(gray);
	dr->FillRect(area);

	dr->SetDrawingMode(B_OP_COPY);

	int dbl = 1;
	BRect rL(16,132, 44,137);
	BRect rR(rL);
	rR.OffsetBy(30, 0);
	for (int ix=0; ix<16; ix++)
	{
		dr->SetHighColor(highColor[ix]);
		dr->SetLowColor(lowColor[ix]);
		if (dbl <= curValueL)
			dr->FillRect(rL, B_SOLID_HIGH);
		else
			dr->FillRect(rL, B_SOLID_LOW);
		if (dbl <= curValueR)
			dr->FillRect(rR, B_SOLID_HIGH);
		else
			dr->FillRect(rR, B_SOLID_LOW);
		dbl = (dbl + 370) * 1.2;
		rL.top -= 8;
		rL.bottom -= 8;
		rR.top -= 8;
		rR.bottom -= 8;
	}
	rgb_color white = { 255, 255, 255, 0 };
	dr->SetHighColor(white);
	dr->SetLowColor(gray);
	char str[30];
	sprintf(str, "%d", fCapturedFrames);
	dr->DrawString(str, BPoint(15, 154));
	if (fBitmap)
	{
		fBitmapView->Sync();
		fBitmap->Unlock();
		DrawBitmap(fBitmap, BPoint(0,0));
	}
}


void
CaptureView::Pulse()
{
	inherited::Pulse();
	Draw(Bounds());
	Flush();
}


void
CaptureView::AttachedToWindow()
{
	inherited::AttachedToWindow();
	status_t err = 0;
	err = fSubscriber->EnterStream(0, false, this, StreamFunc, NULL, true);
	if (err == B_OK)
		err = fStream->StartStreaming();
	if (err < B_OK)
		printf("Error %08x trying to enter stream\n", err);
	fStop->SetTarget(this, Window());
	Window()->SetPulseRate(100000);
}


void
CaptureView::DetachedFromWindow()
{
	fRecording = false;
	if (fSubscriber)
		fSubscriber->ExitStream(true);
	inherited::DetachedFromWindow();
}


void
CaptureView::MessageReceived(
	BMessage *				message)
{
	if (message->what == STOP_CAPTURE)
		fRecording = false;
	else
		inherited::MessageReceived(message);
}


#define TRIGGER 127


bool
CaptureView::StreamFunc(
	void *			userData,
	char *			buffer,
	size_t			count,
	void *			header)
{
	int nFrames = count/4;
	int maxL = 0;
	int maxR = 0;
	short *ptr = (short *)buffer;

	/*	since there is hardware offset from 0, we need to detect the zero point dynamically	*/
	int cl = ((CaptureView *)userData)->curCenterL;
	int cr = ((CaptureView *)userData)->curCenterR;
	int detectL = cl;
	int detectR = cr;
	int detectLCount = 0;
	int detectRCount = 0;

	for (int ix=0; ix<nFrames; ix++)
	{
		int l = ptr[ix*2];
		int r = ptr[ix*2+1];
		/*	check for current max relative to old zero point	*/
		if (l-cl > maxL)
			maxL = l-cl;
		else if (cl-l > maxL)
			maxL = cl-l;
		if (r-cr > maxR)
			maxR = r-cr;
		else if (cr-r > maxR)
			maxR = cr-r;
		/*	detect changing zero point	*/
		if (abs(l-detectL) < NOISE)
			detectLCount++;
		else
		{
			detectL = l;
			detectLCount = 1;
		}
		if (abs(r-detectR) < NOISE)
			detectRCount++;
		else
		{
			detectR = r;
			detectRCount = 1;
		}
	}
	/*	update notion of zero point	*/
	if (detectLCount > nFrames/4)
		((CaptureView *)userData)->curCenterL = detectL;
	else
		((CaptureView *)userData)->curCenterL = 0;
	if (detectRCount > nFrames/4)
		((CaptureView *)userData)->curCenterR = detectR;
	else
		((CaptureView *)userData)->curCenterR = 0;
//	printf("detect %d %d\n", ((CaptureView *)userData)->curCenterL, ((CaptureView *)userData)->curCenterR);

	if (((CaptureView *)userData)->Window()->Lock())
	{
		if (((CaptureView *)userData)->curValueL < maxL)
			((CaptureView *)userData)->curValueL = maxL;
		else
			((CaptureView *)userData)->curValueL = (((CaptureView *)userData)->curValueL+maxL)/2;
		if (((CaptureView *)userData)->curValueR < maxR)
			((CaptureView *)userData)->curValueR = maxR;
		else
			((CaptureView *)userData)->curValueR = (((CaptureView *)userData)->curValueR+maxR)/2;
	
		if (((CaptureView *)userData)->fRecording && ((CaptureView *)userData)->fOutput)
		{
			if (!((CaptureView *)userData)->fTriggered)
				if ((maxL > TRIGGER) || (maxR > TRIGGER))
					((CaptureView *)userData)->fTriggered = true;
			if (((CaptureView *)userData)->fTriggered)
			{
				void * buf2 = alloca(count);
				memcpy(buf2, buffer, count);
				ssize_t e = ((CaptureView *)userData)->fOutput->Write(buf2, count);
				if (e < 0)
					printf("error %08x writing\n", e);
				((CaptureView *)userData)->fCapturedFrames += nFrames;
				if ((((CaptureView *)userData)->fCapturedFrames >= ((CaptureView *)userData)->fNumFrames)
					&& (((CaptureView *)userData)->fNumFrames > 0))
				{
					((CaptureView *)userData)->fRecording = false;
					((CaptureView *)userData)->fOutput = NULL;
				}
			}
		}
	
		((CaptureView *)userData)->Window()->Unlock();
	}

	return true;
}


status_t
MakeCapturePanel(	//	optional, experimental
	BMessage *			ioExtension,
	BView * &			outView,
	BRect &				outExtent)
{
	outExtent.Set(0,0,89,199);
	BButton *b = new BButton(BRect(10,167,79,187), "stop", "Stop", new BMessage(STOP_CAPTURE));
	CaptureView *v = new CaptureView(outExtent, b);
	outView = v;
	return B_OK;
}


	//	Start capture. The capture will run until "done", as far as 
	//	the Datatype decides.

status_t
Capture(			//	Optional, experimental
	BView *				configView,
	BMessage *			ioExtension,
	BPositionIO &		outStream,
	uint32				captureFormat)
{
	if (captureFormat != DATA_SOUND)
		return DATA_NO_HANDLER;
	DATASound header;
	header.magic = DATA_SOUND;
	header.channels = 2;
	header.sampleFreq = 44100.0;
	header.numFrames = 0;
	outStream.Write(&header, sizeof(header));

	bool created = false;
	if (!configView)
	{
		created = true;
		configView = new BView(BRect(0,0,80,100), "capture", B_FOLLOW_NONE, 0);
	}
	((CaptureView *)configView)->fOutput = &outStream;
	((CaptureView *)configView)->fCapturedFrames = 0;
	/*	if there is no view that can stop us, run for default time (5 seconds)	*/
	((CaptureView *)configView)->fNumFrames = (created ? 44100*5 : 0);
	((CaptureView *)configView)->fTriggered = false;
	((CaptureView *)configView)->fRecording = true;
	bigtime_t timeout = system_time()+5000000L;
	status_t err = B_OK;
	while (((CaptureView *)configView)->fRecording)
	{
		snooze(500000);
		configView->Window()->Lock();
		if (!((CaptureView *)configView)->fTriggered && (system_time() > timeout))
		{
			err = B_TIMED_OUT;
			break;
		}
		configView->Window()->Unlock();
	}
	((CaptureView *)configView)->fRecording = false;
	if (err == B_OK)
	{
		header.numFrames = ((CaptureView *)configView)->fCapturedFrames;
		outStream.Seek(0, SEEK_SET);
		outStream.Write(&header, sizeof(header));
	}
	if (created)
		delete configView;
	return err;
}

