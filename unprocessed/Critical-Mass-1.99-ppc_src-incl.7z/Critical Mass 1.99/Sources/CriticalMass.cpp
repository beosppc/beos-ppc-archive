//	Critical Mass Be
//	13/7/1997
//	Hamish Carr
//
//	Critical Mass.cpp - the mainline

#pragma once
#include "CMassApplication.h"

main()
	{	
	new CMassApplication();
	be_app->Run();
	
	return(0);
	}
