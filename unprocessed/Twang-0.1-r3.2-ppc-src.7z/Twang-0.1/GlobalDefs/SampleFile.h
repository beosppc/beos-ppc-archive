#ifndef _SAMPLEFILE
#define _SAMPLEFILE

#include "Gloub.h"

enum {
	HEADER_OK = 0,
	FILE_ERROR = -1,
	NOT_ERROR = 1,
	OBSCURE_ERROR = 2,
	MALFORM_ERROR = 3
};

enum {
	NO_TYPE = 0,
	RAW_TYPE = 1,
	WAVE_TYPE = 2,
	AIFF_TYPE = 3,
	SND_TYPE = 4
};

// form chunk header


#define FormID		'FORM'
#define AIFFckID	'AIFF'

struct FormChunkHeader
{
	uint32				ckID;
	uint32				ckSize;
};

struct FormAIFFHeader
{
	uint32				chunkType;
	uint32				chunkLen;
	uint32				formType;
};

#define CommonID    'COMM'  /* ckID for Common Chunk */ 

struct  CommonChunk { 
    uint16          numChannels; 
    uint16			numSampleFrames1; 
    uint16			numSampleFrames2; 
    uint16          sampleSize; 
    uint32		    sampleRate;	// HACK:don't unerstand 80bit floats! 
    uint32			hackPad;
    uint16			pad;
};  

#define SoundDataID 'SSND'  /* ckID for Sound Data Chunk */ 

struct  SoundDataChunk { 
    uint32			offset; 
    uint32			blockSize; 
//    uint32			soundData[]; 

};   

#define MarkerCkID    'MARK'  /* ckID for Marker Chunk */ 

typedef short   MarkerId; 

struct  Marker{ 
    MarkerId            id; 
    unsigned long       position; 
//	char             	markerName[];	// pascal ?? string 
}; 

struct  MarkerChunk{ 
    unsigned short      numMarkers; 
//    Marker              Markers[]; 
}; 


#define InstrumentID    'INST'  /* ckID for Instrument Chunk */ 

#define NoLooping               0 
#define ForwardLooping          1 
#define ForwardBackwardLooping  2 

struct  Loop{ 
    short           playMode; 
    MarkerId        beginLoop; 
    MarkerId        endLoop; 
}; 

struct  InstrumentChunk{ 
    char            baseNote; 
    char            detune; 
    char            lowNote; 
    char            highNote; 
    char            lowVelocity; 
    char            highVelocity; 
    short           gain; 
    Loop            sustainLoop; 
    Loop            releaseLoop; 
}; 


#define MIDIDataID  'MIDI'  /* ckID for MIDI Data Chunk */ 

struct  MIDIDataChunk { 
//    unsigned char       MIDIdata[]; 
}; 

#define AudioRecordingID  'AESD'        /* ckID for Audio Recording */ 
                                        /*   Chunk.                 */ 

struct  AudioRecordingChunk{ 
    unsigned char       AESChannelStatusData[24]; 
}; 

#define ApplicationSpecificID  'APPL'   /* ckID for Application */ 
                                        /*  Specific Chunk.     */ 

struct  ApplicationSpecificChunk { 
    uint32		applicationSignature; 
//    char        data[]; 
}; 


#define CommentID       'COMT'  /* ckID for Comments Chunk.  */ 

struct  Comment{ 
    unsigned long       timeStamp; 
    short				markID; 
    unsigned short      count; 
//    char                text[]; 
}; 

struct  CommentsChunk{ 
    unsigned short      numComments; 
//   Comment             comments[]; 
}; 

#define NameID          'NAME'  /* ckID for Name Chunk.  */ 
#define AuthorID        'AUTH'  /* ckID for Author Chunk.  */ 
#define CopyrightID     '(c) '  /* ckID for Copyright Chunk.  */ 
#define AnnotationID    'ANNO'  /* ckID for Annotation Chunk.  */ 

struct TextChunk { 
//   char                text[]; 
}; 

// riff wave header

struct RiffChunkHeader
{
	uint32				chunkType;
	uint32				chunkLen;
};

struct RiffWaveCommonHeader
{
	uint16				format;
	uint16				channels;
	uint32				sampleRate;
	uint32				byteRate;
	uint16				blockAlign;
};

struct RiffWavePCMHeader
{
	uint16				bitsPerSample;
};



// base sample file class

class _GLOUBEXP SampleFile: public BFile
{
public:
						SampleFile(short typ=NO_TYPE);
						~SampleFile();
						
	status_t			SeekToFrame(off_t fr);
	void				SetFormat(short nchan, short dsize, long sr);
	status_t			SetTo(entry_ref *p, uint32 mode=B_READ_ONLY);
	status_t			SetTo(char *p, uint32 mode=B_READ_ONLY);
	status_t			ReadHeaderInfo();
	status_t			WriteHeaderInfo();
	status_t			ProcessHeaderInfo();
	status_t			TryAiffFile();
	status_t			TrySndFile();
	status_t			TryWaveFile();
	status_t			TryRawFile();
	status_t			WriteWaveHeader();
	status_t			WriteAiffHeader();
	status_t			WriteSndHeader();
	void				NormalizeInput(char * buf, long nf);
	void				NormalizeOutput(short * buf, long nf);
	void				NormalizeOutputCpy(char *buf, float *b2, long nf);
	size_t				NormalizeInputCpy(float *buf, char *b2, long nf);
	size_t				NormalizeInputCpy(short *buf, char *b2, long nf);
	long				Frame();
	long				FrameToOffset(long fr);
	long				OffsetToFrame(long fr);
	long				FrameToByte(long fr);
	long				ByteToFrame(long nb);
	void				SetType(short typ);
	inline short		Type() { return fileType; }
	status_t			Plonk(short *buffer);
	status_t			Finalize();
	inline off_t		ByteSize() { return nFrames*nChannels*sampleSize; }
	void				operator=(SampleFile&f);
	void				operator=(BFile&f);
	
	uint32				openMode;
	short				nChannels;
	short				sampleSize;
	off_t				nFrames;
	short				fileType;
	short				sampleType;
	off_t				sampleDataStart;
	long				sampleRate;
};

inline long SampleFile::Frame()
{
	return (Position() - sampleDataStart) / (sampleSize * nChannels);
}

inline long SampleFile::FrameToOffset(long fr)
{
	return fr*(sampleSize * nChannels) + sampleDataStart;
}

inline long SampleFile::FrameToByte(long fr)
{
	return fr*(sampleSize * nChannels);
}

inline long SampleFile::ByteToFrame(long bt)
{
	return bt/(sampleSize * nChannels);
}

#endif