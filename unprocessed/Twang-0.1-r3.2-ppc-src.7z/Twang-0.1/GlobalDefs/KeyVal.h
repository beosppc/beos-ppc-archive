#ifndef _KEYVAL
#define _KEYVAL

#include "Gloub.h"

class _GLOUBEXP KeyVal {
public:
	char		*Key;
	long		Value;
};

class _GLOUBEXP KeyIndex {
public:
				KeyIndex(KeyVal* kv, ushort n);
				KeyIndex();
	void		SetKeyVal(KeyVal *k, ushort n);
	long		ValueOf(char *k);
	char		*KeyOf(long v);
	void		ClearIndex();
	bool		ChangeKey(char *, char *);
	bool		ChangeKey(long, char *);
	bool		AddToIndex(char *, long);
	bool		RemoveFromIndex( long);
	bool		RemoveFromIndex(char *);
	void		operator=(KeyIndex *k);
	
	KeyVal		*kv;
	ushort		nkv;
};

#define KEYVAL_SHITE	-100000000

#endif