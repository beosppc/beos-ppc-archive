#ifndef _VPCONTROL_H
#define _VPCONTROL_H

class NumCtrl;
class TSliderView;
class VSlider;
class TextSlider;

#include "Gloub.h"

class _GLOUBEXP VParamControl : public BView
{
public:
	NumCtrl			*mDataField;
	BStringView		*mLabel;
	VSlider			*mSlider;
	BHandler		*mHandler;
	float			mMax, mMin;

public:
					VParamControl(	BRect rect, int paramtype,
									char *name, char *labelstr,
									char *initstr,
									float min, float max, float inc);
					~VParamControl();
	virtual void	MessageReceived( BMessage* inMsg );
	void			SetFloatValue(float val);
	virtual void	SetTarget(BHandler *handler);
	virtual void	SetViewColor(rgb_color color);
};

#endif

