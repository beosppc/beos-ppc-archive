#ifndef _MYBUTTON
#define _MYBUTTON

#include "Gloub.h"

class _GLOUBEXP MyButton:	public BButton
{
	public:
	BMessage		*MBMess1, *MBMess2, *MBMess3;
			
					MyButton(BRect rect, char *name, char *label,
				 		BMessage *mess1, BMessage *mess2,
				 		BMessage *mess3, ulong resizeMode, ulong flags );
					~MyButton();

	virtual void	MouseDown(BPoint thePoint);
};

#endif