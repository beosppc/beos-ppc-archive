#ifndef _MODECTRL
#define _MODECTRL

#include "Gloub.h"

class KeyIndex;
class KeyVal;

class _GLOUBEXP ModeView: public BStringView
{
public:
					ModeView(BRect rec, char *label, long m,
						KeyVal *k, long nk,
						uint32 mo=B_FOLLOW_LEFT | B_FOLLOW_TOP,
						uint32 f=B_WILL_DRAW);
					~ModeView();
	virtual void	Draw(BRect area);
	virtual void	MouseDown(BPoint where);
	virtual void	MessageReceived(BMessage *message);
	virtual void	KeyDown(const char *c, int32 nb);
	virtual void	MakeFocus(bool mf);
	virtual BPopUpMenu *	BuildPopUpMenu();
	void			SetFont(BFont *f);
	void			SetValue(long m);
	void			SetFontSize(float f);

	long			mode;
	KeyIndex		*ki;
	BControl		*ctrl;	
};

class _GLOUBEXP ModeCtrl: public BControl
{
public:
friend class ModeView;
					ModeCtrl(BRect rec, char *label, long m,
						KeyVal *k, long nk,
						BMessage *msg,
						uint32 mo=B_FOLLOW_LEFT | B_FOLLOW_TOP,
						uint32 f=B_WILL_DRAW);
					~ModeCtrl();
	void			SetFont(BFont *f);
	void			SetFontSize(float f);
	void			SetKeyIndex(KeyIndex *k);
	long			Value();
	void			SetValue(long m);
	virtual void	Draw(BRect reg);
						
	ModeView		*mv;
};

#endif