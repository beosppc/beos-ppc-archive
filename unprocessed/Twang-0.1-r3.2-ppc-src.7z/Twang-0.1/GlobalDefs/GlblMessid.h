#ifndef _GLBLMESS
#define _GLBLMESS

enum {
	SET_MODE = 'mode',
	SET_COLOR = 'setc'
};

#endif