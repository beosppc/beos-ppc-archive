#ifndef _TRICHECKBOX
#define _TRICHECKBOX

#include "Gloub.h"

class _GLOUBEXP NValSwitch: public BControl
{
public:
					NValSwitch(BRect rect, char *na,
						long cv,
				 		BMessage *mess, ulong resizeMode, ulong flags,
				 		short nval, ... );
					~NValSwitch();
					
	void			SetButtonColor(rgb_color col);
	void			SetLampColor(rgb_color col);
	void			SetWidth(float wid);
	virtual void	Draw(BRect r);
	void			DrawShit(BRect r);
	virtual void	MouseDown(BPoint p);

	BRect			bnd;
	BRect			inBnd;
	rgb_color		button_color;
	rgb_color		lamp_color;
	
	bool			mouseDown;
	short			nVal;
	rgb_color		*hilight;
	long			*value;
	char			**label;
	
	int32			lastValue;
	float			width;
	long			currentValue;
};

class _GLOUBEXP  TriSwitch:	public NValSwitch
{
	public:
			
					TriSwitch(BRect rect, char *name,
						char *lab1, long val1, rgb_color hilite11,
						char *lbl2, long val2, rgb_color hilite12,
						char *lbl3, long val3, rgb_color hilite13,
						long currentValue,
				 		BMessage *mess, ulong resizeMode, ulong flags );
				 	~TriSwitch();
};

#endif