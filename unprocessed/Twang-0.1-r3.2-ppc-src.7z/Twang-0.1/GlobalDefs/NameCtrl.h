#ifndef _NAMECTRL
#define _NAMECTRL

#include "Gloub.h"

enum {
	SET_NAME = 'name'
};

class NameCtrl;

class _GLOUBEXP NameView: public BTextView
{
public:
					NameView(BRect frame, const char *name,
							BMessage *m, BView *t, NameCtrl *c,
         					ulong resizingMode=NULL, ulong flags=NULL);
    				~NameView();
    virtual void	KeyDown(const char *c, int32 nb);
	virtual void	MakeFocus(bool flag = TRUE);
	virtual bool	AcceptsDrop(BMessage *m);
	BView			*target;
	NameCtrl		*controller;
	BMessage		*message;
};

class _GLOUBEXP NameCtrl: public BStringView
{
public:
					NameCtrl(BRect rec, char *label, char *name, BMessage *, BHandler *t,
							ulong md=NULL, ulong bf=B_WILL_DRAW);
					~NameCtrl();
	virtual void	Draw(BRect area);
	virtual void	MouseDown(BPoint where);
	virtual void	MessageReceived(BMessage *message);
	virtual void	KeyDown(const char *c, int32 nb);
	virtual void	MakeFocus(bool mf);
	void			SetFont(BFont *f);
	void			SetFontSize(float f);
	
	NameView		*edit;
	BHandler		*target;
};

#endif