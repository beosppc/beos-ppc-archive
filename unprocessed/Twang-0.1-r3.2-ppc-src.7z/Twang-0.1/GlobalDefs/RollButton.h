#ifndef _ROLLBUTTON
#define _ROLLBUTTON

#include "Gloub.h"

class _GLOUBEXP RollButton:	public BButton
{
	public:
			
					RollButton(BRect rect, char *name, char *label,
				 		BMessage *mess1, ulong resizeMode, ulong flags );
					~RollButton();
	void			SetButtonColor(rgb_color col);
	void			SetLampColor(rgb_color col);
	virtual void	MouseDown(BPoint thePoint);
	virtual void	Draw(BRect r);
	
	rgb_color		button_color;
	rgb_color		lamp_color;
};

#endif