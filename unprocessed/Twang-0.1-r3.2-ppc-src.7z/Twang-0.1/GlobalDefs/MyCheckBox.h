#ifndef _MYCHECKBOX
#define _MYCHECKBOX

#include "Gloub.h"

class _GLOUBEXP  MyCheckBox:	public BCheckBox
{
	public:
			
					MyCheckBox(BRect rect, char *name, char *label,
				 		BMessage *mess1, ulong resizeMode, ulong flags );
					~MyCheckBox();
	void			SetButtonColor(rgb_color col);
	void			SetLampColor(rgb_color col);
	void			SetDivider(float d);
	virtual void	Draw(BRect r);
	
	rgb_color		button_color;
	rgb_color		lamp_color;
	int32			lastValue;
	float			divider;
};

#endif