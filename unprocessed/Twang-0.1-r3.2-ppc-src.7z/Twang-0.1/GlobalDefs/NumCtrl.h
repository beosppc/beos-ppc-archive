#ifndef _NUMCTRL
#define _NUMCTRL

class NumCtrl;

#include "Gloub.h"

class _GLOUBEXP NumView: public BTextView
{
public:
					NumView(BRect frame, const char *name,
         					ulong resizingMode, ulong flags, short isi=0,
         					short pl=5);
    				~NumView();
    virtual void	KeyDown(const char *c, int32 nb);
	virtual void	MakeFocus(bool flag = TRUE);
	virtual bool	AcceptsDrop(BMessage *m);
	void			SetValue(float v);
	void			SetInc(float inc);
	void			SetRanges(float m1, float m2, float m3);
	void			SetKeyVal(KeyVal *l, ushort n);
	void			SetType(short isint);
	void			SetSibling(BView *v);
	float			Value();

	KeyIndex		labels;
	short			isInt;
	short			places;
	NumCtrl			*controller;
    BView			*sibling;
    float			stepInc;
    float			min,
    				med,
    				max;
};

class _GLOUBEXP NumCtrl: public BControl
{
public:
					NumCtrl(BRect frame, const char *name,
		         			 char *label, 
		         			 const char *text,
							BMessage *msg,
							ulong f1, ulong f2, short isi=0,
							float v=0, short dp=5);
					~NumCtrl();
	void 			SetDivider(float xCoordinate);
	void			SetType(short isint);
	char			*Text();
	void			SetText(const char *txt);
	void			SetRanges(float m1, float m2, float m3);
	void			SetValue(float v);
	virtual void	MakeFocus(bool flag = TRUE);
	virtual void	Draw(BRect reg);
	void			SetInc(float inc);
	void			SetKeyVal(KeyVal *l, ushort n);
	void			SetSibling(BView *v);
	float			Value();
	void			MakeEditable(bool wh=FALSE);
	
	void			Invoke() { BControl::Invoke(); }
	NumView			*textview;
	BRect			textrect;
	float			divider;
};

#endif