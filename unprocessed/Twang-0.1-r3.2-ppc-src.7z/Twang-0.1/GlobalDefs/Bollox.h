#ifndef _BOLLOX
#define _BOLLOX

int32	_get_message_target_(BMessage *m);

inline int32
_get_message_target_(BMessage *m)
{
	return m->fTarget;
}


int32	_get_object_token_(const BHandler *m);

inline int32
_get_object_token_(const BHandler *m)
{
	return m->fToken;
}

#include "Gloub.h"

_GLOUBEXP	BHandler	*HandlerOf(BMessage *m, BLooper *l);
_GLOUBEXP	BView		*HandlingViewOf(BMessage *m, BWindow *l);
_GLOUBEXP	bool		BeAGoodSocialist(BView *v, bigtime_t usec=20000);

#endif