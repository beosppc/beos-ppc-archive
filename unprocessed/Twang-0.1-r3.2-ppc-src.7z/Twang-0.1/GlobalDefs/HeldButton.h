#ifndef HELDBUTTON
#define HELDBUTTON

#include "Gloub.h"

class _GLOUBEXP HeldButton:	public BButton
{
public:
	BMessage		*MBMess1, *MBMess2;
			
					HeldButton(BRect rect, char *name,
						char *label1,
				 		BMessage *mess1, BMessage *mess2,
				 		ulong resizeMode, ulong flags );
					~HeldButton();

	virtual void	MouseDown(BPoint thePoint);
};

#endif