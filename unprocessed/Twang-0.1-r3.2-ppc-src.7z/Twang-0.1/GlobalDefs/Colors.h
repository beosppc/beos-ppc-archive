#pragma once

#include "Gloub.h"

extern rgb_color white;
extern rgb_color wtGray;
extern rgb_color ltGray;
extern rgb_color mdGray;
extern rgb_color dkGray;
extern rgb_color black;
extern rgb_color red;
extern rgb_color green;
extern rgb_color blue;
extern rgb_color purple;
extern rgb_color pink;
extern rgb_color yellow;
extern rgb_color brown;
extern rgb_color reddish;
extern rgb_color yellowish;
extern rgb_color greenish;
extern rgb_color turqoiseish;
extern rgb_color bluish;
extern rgb_color purplish;
extern rgb_color lightbrown;
extern rgb_color aqua;
extern rgb_color lavender;
extern rgb_color seablue;
extern rgb_color lime;
extern rgb_color mauve;
extern rgb_color orange;
extern rgb_color violet;
extern rgb_color indigo;
extern pattern stripes;

_GLOUBEXP rgb_color	Inverse(rgb_color);
_GLOUBEXP rgb_color	Darker(rgb_color, uint8 amt=30);
_GLOUBEXP rgb_color	Lighter(rgb_color, uint8 amt=15);
_GLOUBEXP rgb_color	RedEr(rgb_color, int8 amt=15);
_GLOUBEXP rgb_color	GreenEr(rgb_color, int8 amt=15);
_GLOUBEXP rgb_color	BlueEr(rgb_color, int8 amt=15);
_GLOUBEXP void		RaisedBox(BView *, BRect, rgb_color, bool fill=true);
_GLOUBEXP void		LoweredBox(BView *, BRect, rgb_color, bool fill=true);
_GLOUBEXP rgb_color	StrColor(char *str);
_GLOUBEXP char		*ColorStr(rgb_color color);