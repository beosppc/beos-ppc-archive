#ifndef _TEXTSLIDER
#define _TEXTSLIDER

#include "TSlider.h"

class KeyIndex;

class TextSlider: public TSliderView
{
public:
					TextSlider(BRect rect, char *name, char *label,
				 			BMessage *message, BStringView *val,
							ulong resizeMode, ulong flags );
					~TextSlider();
	virtual void	SetFloatValue(float val);
	virtual void	MouseDown(BPoint);
	void			SetIndValue(int	ind);
	KeyIndex		*Labels;
};

class TParamControl : public BView
{
public:
	NumCtrl			*mDataField;
	TextSlider		*mSlider;
	BHandler		*mHandler;
	KeyIndex		*Labels;

public:
					TParamControl(	BRect rect, int paramtype,
									char *name, char *labelstr,
									char *initstr,
									int  nlbl,
									KeyVal *kv);
									
					~TParamControl();
	virtual void	MessageReceived( BMessage* inMsg );
	void			SetFloatValue(float val);
	virtual void	SetViewColor(rgb_color color);
	virtual void	SetTarget(BHandler *handler);
	virtual void	Draw(BRect R);
};

#endif