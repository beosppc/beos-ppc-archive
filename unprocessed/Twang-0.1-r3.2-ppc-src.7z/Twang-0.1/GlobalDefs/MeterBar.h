#ifndef _METERBAR
#define _METERBAR

#include "Gloub.h"

class _GLOUBEXP MeterBar: public BView
{
public:
					MeterBar(BRect, char *, int ns, float mi, float ma, ulong, ulong);
	virtual void	Draw(BRect r);
	void			SetColor(rgb_color,rgb_color,rgb_color,rgb_color);
	void			SetRange(float min, float point, float max);
	void			SetRange(float min, float point1, float point2, float max);
	void			SetValue(float value);

	float			max;
	float			min;
	float			value;
	float			point1;
	float			point2;
	short			step1;
	short			step2;
	short			stepv;
	int				nStep;
	
	rgb_color		back;
	rgb_color		range1;
	rgb_color		range2;
	rgb_color		range3;
};

#endif