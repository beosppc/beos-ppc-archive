//--------------------------------------------------------------------
//	
//	Slider.h
//
//	Written by: Robert Polic
//	
//	Copyright 1996 Be, Inc. All Rights Reserved.
//	
//--------------------------------------------------------------------

#ifndef TPOT
#define TPOT

#define SLIDER_BACK_WIDTH	 216
#define SLIDER_BACK_HEIGHT	 10

//#define BACK_COLOR			216
#define BACK_COLOR			255

#define	BROWSER_WIND		 82
#define	TITLE_BAR_HEIGHT	 25
#define WIND_WIDTH			 96
#define WIND_HEIGHT			 40

#include "Gloub.h"

class _GLOUBEXP TPot : public BControl {

private:

public:
	float			fValue;
	float			*fValueP;
	float			fMaxValue;
	float			fMinValue;
	float			fPotBackWidth;
	BBitmap*		fPot;
	BView*			fOffView;
	BTextView		*fTextView;
	BStringView		*fMUpView;
	BRect			fTextRect;
	BRect			fBounds;
	float			fDivider;
	float			fAmbit;
	float			fRadius;
	BPoint			fCenter;

					TPot(BRect rect, char *name, char *label,
							 BMessage *message, BStringView *sv, ulong resizeMode, ulong flags );
					~TPot();
	virtual	void	Draw(BRect);
	virtual void	MouseDown(BPoint);
	void			DrawPot();
	void			SetDivider(float);
	void			SetAmbit(float);
	void			SetValueP(float *);
	void			SetRadius(float);
	void			SetBounds(float, float);
	void			SetCenter(float, float);
	float			PointToValue(BPoint);

	virtual void	SetFloatValue(float);
	void			DoInvoke();
	float			FloatValue();
};
#endif
