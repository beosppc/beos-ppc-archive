#ifndef _REFCTRL
#define _REFCTRL

#include "Gloub.h"

class _GLOUBEXP RefCtrl: public BStringView
{
public:
					RefCtrl(BRect rec, char *label, char *title, entry_ref *f,
							BHandler *t,
							uint32 m=B_FOLLOW_LEFT | B_FOLLOW_TOP,
							 uint32 fl=B_WILL_DRAW);
					~RefCtrl();
	virtual void	Draw(BRect area);
	virtual void	MouseDown(BPoint where);
	virtual void	MessageReceived(BMessage *message);
	virtual void	KeyDown(const char *c, int32 nb);
	virtual void	MakeFocus(bool mf);
	void			SetFont(BFont *f);
	void			SetFontSize(float f);
	
	entry_ref		file_ref;
	BHandler		*target;
	BFilePanel		*panel;
	char 			*title;
	bool			SelectionMade;
};

#endif