//--------------------------------------------------------------------
//	
//	Slider.h
//
//	Written by: Robert Polic
//	
//	Copyright 1996 Be, Inc. All Rights Reserved.
//	
//--------------------------------------------------------------------

#ifndef SLIDER_H
#define SLIDER_H

#define SLIDER_BACK_WIDTH	 216
#define SLIDER_BACK_HEIGHT	 10

//#define BACK_COLOR			216
#define BACK_COLOR			255

#define	BROWSER_WIND		 82
#define	TITLE_BAR_HEIGHT	 25
#define WIND_WIDTH			 96
#define WIND_HEIGHT			 40

#include "Gloub.h"

class NumView;

class _GLOUBEXP TSliderView : public BControl {

private:

public:
	float			fValue;
	float			fFactor;
	float			fBase;
	float			fSliderBackWidth;
	BBitmap*		fSlider;
	BBitmap*		fKnob;
	BView*			fOffView;
	NumView			*fTextView;
	BStringView		*fview;
	BRect			fTextRect;
	BRect			fBounds;

				TSliderView(BRect rect, char *name, char *label,
				 BMessage *message, BStringView *sv, ulong resizeMode, ulong flags );
				~TSliderView();
	virtual	void	Draw(BRect);
	virtual void	MouseDown(BPoint);
	void			DrawSlider();

	virtual void	SetFloatValue(float);
	void			SetRange(float, float);
	void			DoInvoke();
	float			FloatValue();
};
#endif
