#ifndef _TILEDVIEW
#define _TILEDVIEW

#include "Gloub.h"

class _GLOUBEXP TiledView: public BView
{
public:
					TiledView(BRect, char *, ulong, ulong);
	virtual void	Draw(BRect r);
	long			SetTilingPattern(BBitmap &b);
	
	BBitmap			*bitmap;
};

#endif