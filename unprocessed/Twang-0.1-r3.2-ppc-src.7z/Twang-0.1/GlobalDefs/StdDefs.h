/*
 * dull but useful.
 */
#ifndef STD_DEFS

#define STD_DEFS

typedef unsigned char	flag;

#define	TRUE	1
#define FALSE	0

#define Min(X,Y)	((X)>(Y)?(Y):(X))
#define Max(X,Y)	((X)>(Y)?(X):(Y))
#define Sign(X,Y)	((Y)>=0? Abs(X) : -Abs(X))
#define Abs(X)	((X)>0?(X):-(X))

#define MAJORLY_BIG	2147483648

#include "Gloub.h"

_GLOUBEXP	char *ErrorStr(int no);

_GLOUBEXP	void		TragicError(char *str, ...);
_GLOUBEXP	void		ReportError(char *str, ...);
_GLOUBEXP	bool		RetryError(char *str, ...);
_GLOUBEXP	int			OptionWin(int, char *str, ...);
_GLOUBEXP	int			bprintf(BFile *f, char *str, ...);
_GLOUBEXP	long		WriteChunkId(BFile *f, uint32, uint32);
_GLOUBEXP	long		ReadChunkId(BFile *f, uint32&, uint32&);

_GLOUBEXP	status_t	tab(BFile *f, short in);
_GLOUBEXP	char		*uintstr(uint32);
_GLOUBEXP	BBitmap 	*GetBitmapForImage(char *path);

#endif
