#ifndef TOGGLEBUTTON
#define TOGGLEBUTTON

#include "Gloub.h"

class _GLOUBEXP ToggleButton:	public BButton
{
public:
	BMessage		*MBMess1, *MBMess2;
	char			*MBlbl1, *MBlbl2;
	short			State, state1, state2;
			
					ToggleButton(BRect rect, char *name,
						char *label1, char *label2,
				 		BMessage *mess1, BMessage *mess2,
				 		short s1, short s2,
				 		ulong resizeMode, ulong flags );
					~ToggleButton();
	void			SetState(short s);

	virtual void	MouseDown(BPoint thePoint);
};

#endif