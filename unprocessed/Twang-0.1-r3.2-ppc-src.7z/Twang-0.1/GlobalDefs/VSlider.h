//--------------------------------------------------------------------
//	
//	Slider.h
//
//	Written by: Robert Polic
//	
//	Copyright 1996 Be, Inc. All Rights Reserved.
//	
//--------------------------------------------------------------------

#ifndef VSLIDER_H
#define VSLIDER_H

#define SLIDER_BACK_WIDTH	 216
#define SLIDER_BACK_HEIGHT	 10

//#define BACK_COLOR			216
#define BACK_COLOR			255

#define	BROWSER_WIND		 82
#define	TITLE_BAR_HEIGHT	 25
#define WIND_WIDTH			 96
#define WIND_HEIGHT			 40

#include "Gloub.h"

class _GLOUBEXP VSlider : public BControl {

private:

public:
	float			fValue;
	float			fFactor;
	float			fBase;
	float			fSliderBackHeight;
	BBitmap*		fSlider;
	BBitmap*		fKnob;
	BView*			fOffView;
	BTextView		*fTextView;
	BRect			fTextRect,
					fBounds;

					VSlider(BRect rect, char *name, char *label,
				 		BMessage *message, ulong resizeMode, ulong flags );
					~VSlider();
	virtual	void	Draw(BRect);
	virtual void	MouseDown(BPoint);
	void			DrawSlider();

	void			SetFloatValue(float);
	void			DoInvoke();
	float			FloatValue();
};
#endif
