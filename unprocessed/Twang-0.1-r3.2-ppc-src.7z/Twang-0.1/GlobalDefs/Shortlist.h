#ifndef SHORTLIST
#define SHORTLIST

#include "Gloub.h"

#define MAX_SHORTLIST	50

class _GLOUBEXP Shortlist
{
public:
					Shortlist(short max);
	bool			Add(int i);
	int				CountItems();
	int				ItemAt(int i);
	void			MakeEmpty();
	bool			Has(int i);
	char			*PrintString();
	bool			operator == (Shortlist &s2);
	bool			operator != (Shortlist &s2);
		
	int				items[MAX_SHORTLIST];
	int				maxitem;
	int				nitems;
};

#endif