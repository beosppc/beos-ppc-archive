#ifndef _PCONTROL_H
#define _PCONTROL_H

class NumCtrl;
class TSliderView;
class VSlider;
class TextSlider;

#include "Gloub.h"

class _GLOUBEXP ParamControl : public BView
{
public:
	NumCtrl			*mDataField;
	TSliderView		*mSlider;
	BHandler		*mHandler;
	float			mMax, mMin;

public:
					ParamControl(	BRect rect, int paramtype,
									char *name, char *labelstr,
									char *initstr,
									float min, float med, float max,
									float inc,
									BStringView *v,
									float d1=55, float d2=115, short dp=5);
					~ParamControl();
	virtual void	MessageReceived( BMessage* inMsg );
	void			SetFloatValue(float val);
	virtual void	SetViewColor(rgb_color color);
	void			SetBounds(float m1, float m2);
	void			SetLabel(char *s);
	float			FloatValue();
	virtual void	SetTarget(BHandler *handler);
	void			SetMouseUpView(BStringView *sv);
	void			SetRanges(float, float, float);
};

#endif

