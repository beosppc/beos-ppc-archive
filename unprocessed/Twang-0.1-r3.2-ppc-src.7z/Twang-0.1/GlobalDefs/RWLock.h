#ifndef _RWLOCK
#define _RWLOCK

#include "Gloub.h"

class _GLOUBEXP RWLock
{
public:
					RWLock();
					~RWLock();
	bool			RdLock();
	void			RdUnlock();
	bool			Lock();
	void			Unlock();
	
	sem_id			mySem;
	int32			readCount;
};

class _GLOUBEXP RWLockList: public RWLock, public BList
{
public:
};

#endif