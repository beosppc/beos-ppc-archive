#ifndef _LBLCHECKBOX
#define _LBLCHECKBOX

#include "Gloub.h"

class _GLOUBEXP  LblCheckBox:	public BCheckBox
{
	public:
			
					LblCheckBox(BRect rect, char *name, char *label,
				 		BMessage *mess1, ulong resizeMode, ulong flags );
					~LblCheckBox();
	void			SetButtonColor(rgb_color col);
	void			SetDivider(float d);
	virtual void	Draw(BRect r);
	
	rgb_color		button_color;
	int32			lastValue;
	float			divider;
};

#endif