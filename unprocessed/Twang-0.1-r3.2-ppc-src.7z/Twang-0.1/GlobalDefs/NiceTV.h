#ifndef _NICETV
#define _NICETV

#include "Gloub.h"

class _GLOUBEXP NiceTV: public BView
{
public:
					NiceTV(BRect, const char *, BRect, ulong, ulong);
	virtual void	Draw(BRect r);
	virtual void	ScrollToOffset(long o);
	virtual void	MakeEditable(bool fl=TRUE);
	void			AppendText(char *str);
	BScrollBar		*Scroll;
	BTextView		*tv;
};
#endif