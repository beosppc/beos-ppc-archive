#include "TwangWindow.h"
#include "Twang.h"
#include "KeyVal.h"
#include "TPot.h"
#include "NumCtrl.h"
#include "Colors.h"
#include "TiledView.h"
/*
 *  Window creator
 */

TwangWindow::TwangWindow(short id)
	: BWindow(BRect(100, 100, 240,125), "Twang!", B_TITLED_WINDOW,
				B_WILL_ACCEPT_FIRST_CLICK|B_NOT_CLOSABLE|B_NOT_RESIZABLE | B_NOT_ZOOMABLE)
{
	char	buf[30];
	sprintf(buf, "TB%d:Twang! (v0.1)", id);
	SetTitle(buf);
	back = new TiledView(BRect(0,0,140,25), "", B_FOLLOW_ALL, B_WILL_DRAW);
	AddChild(back);
	back->SetViewColor(green);

	gainKnob = new TPot(BRect(5, 5, 50, 20), "", "Gain", new BMessage(GAIN), NULL, NULL, B_WILL_DRAW);
	gainKnob->SetDivider(22);
	gainKnob->SetBounds(0, 1);
	gainKnob->SetFont(be_bold_font);
	gainKnob->SetFontSize(11);
	gainKnob->SetFloatValue(twang->gain);
	gainKnob->SetValueP(&twang->gain);
	back->AddChild(gainKnob);
	
	durKnob = new TPot(BRect(55, 5, 125, 20), "", "Distortion", new BMessage(DURATION), NULL, NULL, B_WILL_DRAW);
	durKnob->SetDivider(54);
	durKnob->SetBounds(0, 1);
	durKnob->SetFont(be_bold_font);
	durKnob->SetFontSize(11);
	durKnob->SetFloatValue(twang->dist);
	durKnob->SetValueP(&twang->dist);
	back->AddChild(durKnob);
	
	SetPulseRate(0);
	Show();
}

TwangWindow::~TwangWindow()
{
	release_sem(twang->winSem);
}


/*
 *  Quit requested, close all and quit program
 */
 
void
TwangWindow::MessageReceived(BMessage *inMsg)
{
	switch (inMsg->what) {
	case GAIN:
//		twang->amp = inMsg->FindFloat("control value");
		break;
	case SQUISH:
		break;
	case DURATION:
//		twang->dur = inMsg->FindFloat("control value");
		break;
	default:
		BWindow::MessageReceived(inMsg);
	}
}

bool
TwangWindow::QuitRequested(void)
{
	fprintf(stderr, "bailing twang\n");
	return TRUE;
}
