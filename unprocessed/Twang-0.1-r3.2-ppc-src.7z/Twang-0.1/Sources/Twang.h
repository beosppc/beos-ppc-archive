#ifndef _TWANG
#define _TWANG

/* For plucked string instruments using 'strum' */
#define maxlen 2000
#define maxdl 14000

class TwangDelay {
public:
	float	Delay(float xin);
	
    int		p,
      		del;
    float	d[maxdl],
        	c1,
        	c2;
};

class TwangWindow;

class Twang
{
public:
	 				Twang(short id);
	 				~Twang();
	float			Strum(float);
	void			RandFill() ;
	void			Squisher();
	void			SSet();
	void			calc_buffer(short *buf, long count);
	inline float	rrand(void);
	inline float	Distortion(float);	
	inline float	TubeDistortion(float);
	
	short			myId;

	float 			freq ;
	float			tf0  ;
	float			tNy  ;
	float			amp;
	
	float			dist ;
	float			gain;
	int				squish  ;

// ex strumq structure:
    int				n,
    				p;
	float			d[maxlen],
        			a[4],
        			dcz1,
        			dcb1,
        			dca1,
        			dca0;
	TwangDelay		delayLine;
	TwangWindow		*window;
	sem_id			winSem;
};

extern Twang	*twang;

#endif
