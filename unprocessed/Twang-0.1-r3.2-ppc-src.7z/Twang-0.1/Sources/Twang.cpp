/*
 * Plucked string algorithm, shamelessly plucked from cmix
 */
 
#include "macros.h"
#include "Twang.h"
#include "TwangWindow.h"
#include "StdDefs.h"
#include "TiledView.h"

// explicit exports for addons.

extern "C" __declspec(dllexport) bool		init_addon(short id);
extern "C" __declspec(dllexport) void		set_frequency(float f);
extern "C" __declspec(dllexport) void		start_note();
extern "C" __declspec(dllexport) void		generate(float d[], short c);
extern "C" __declspec(dllexport) bool		disinit_addon(bool f);
extern "C" __declspec(dllexport) uint32		addon_id='twng';
extern "C" __declspec(dllexport) char		*addon_name="Twang";
extern "C" __declspec(dllexport) void		set_tiling(BBitmap *b);

Twang	*twang;

// hooks for addons.

bool
init_addon(short id)
{
	fprintf(stderr, "inittin twang\n");
	if ((twang = new Twang(id)) == NULL)
		return false;
	fprintf(stderr, "created twang\n");
	twang->SSet();
	fprintf(stderr, "done an sset\n");
	return true;
}

bool
disinit_addon(bool f)
{
	fprintf(stderr, "dis-inittin twang\n");
	delete twang;
	return true;
}

void
set_tiling(BBitmap *b)
{
	if (b) {
		twang->window->back->SetTilingPattern(*b);
	}
}

void
set_frequency(float f)
{
	if (twang->freq != f) {
		twang->freq = f;
		twang->SSet();
	}
}

void
start_note()
{
	twang->RandFill();
}

void
generate(float buf[], short count)
{

	static float phi = 0.0;	// Phase angle

//	SSet(freq,tf0,tNy,&strumq1);
//	RandFill( amp, squish,&strumq1);
	while (count--) {
		*buf = twang->Strum(0.) * 2;
		buf++;
	}
}


// Sample frequency in Hz
const int SAMPLE_FREQ = 44100;

// Highest output frequency = SAMPLE_FREQ / DIVISOR
int DIVISOR = 15;

/*
 *	Create application object and start it
 */

int main(int argc, char **argv)
{
	return 0;
}

/*
 *	Constructor
 */
/*
 *	Arguments processed
 */

Twang::Twang(short id)
{
	twang = this;
	
	myId = id;
	
	freq	= 440;
	amp	= 6;

	gain	= 0.15;
	squish	= 1;
	dist = 0;
	
	tf0	= 100000;
	tNy	= 0.7;
	if ((winSem = create_sem(0, "Twang window")) < B_NO_ERROR) {
		TragicError("Twang: can't init");
	}
	window = new TwangWindow(myId);
}

Twang::~Twang()
{
	thread_id	wt = window->Thread();
	status_t	st;
	window->PostMessage(B_QUIT_REQUESTED);
	fprintf(stderr, "waiting for twang sem\n");
	acquire_sem(winSem); // if this fails i'll nosedive into debaug anyway
	fprintf(stderr, "got it and outta here\n");
	wait_for_thread(wt, &st);	// awful hack
}

float
Twang::Strum(float xin) 
{
	float	x;
	int		p1,
			p2,
			p3,
			p4;

	if( ++p >= maxlen)
		p = 0;
	if((p1 = p - n) < 0)
		p1 += maxlen;
	if((p2 = p1 - 1) < 0)
		p2 += maxlen;
	if((p3 = p2 - 1) < 0)
		p3 += maxlen;
	if((p4 = p3 - 1) < 0)
		p4 += maxlen;

	/*averaging filter*/
	x = a[3]*d[p4];
	x += a[2]*d[p3];
	x += a[1]*d[p2];
	x += a[0]*d[p1];

	/*dc blocking filter, for which xin+x is input, d[p] output*/
	d[p] = dca1 * dcz1;
	dcz1 = dcb1 * dcz1 + xin + x;
	d[p] += dca0 * dcz1;

	if (dist > 0) {
		float strum = gain*(d[p]);
		float d = TubeDistortion(strum);
		return ((1-dist)*strum + dist*d);
	} else {
		return gain*(d[p]);
	}
}

//--------------------------------------------------------------------
void Twang::RandFill() 
{
//	Fills plucked string structure q with random values, and intitialize things.
//	 Call only after a call to sset.
//	 Can be used with zero amplitude to just initialize things.
//	 Squish models the softness of a plucking implement by filtering
//	 the values put in the string with an averaging filter.
//	 The filter makes squish passes.  The loss of amplitude at the fundamental
//	 frequency is compensated for, but the overall amplitude of the squished
//	 string is lowered, as the energy at other frequencies is decreased. 

	float total,average;
	int i;

	p = n;
	dcz1=0;

/*set all values of array to zero*/
	for(i=0;i<maxlen;i++) {
		  d[i]=0.;
	}

 //	    for (i=1;i<100;i++) fprintf(stderr, "%f\n",d[i]); 

/* fill with white noise and subtract any dc component */
	total = 0.;
	for(i=0;i<n;i++) {
		d[i]=rrand()*amp;
		total=total+d[i];
	}

//      for (i=1;i<100;i++) fprintf(stderr, "q-d %f\n",d[i]);

	average=total/((float)n);

	for(i=0;i<n;i++) {
		d[i]= d[i] - average;
	}
	Squisher();
}

//--------------------------------------------------------------------
void Twang::SSet() 
{
// Sets up strumq structure for strum to use as plucked string.
//	 Uses a two point averaging filter to adjust the phase for exact
//	 correct pitch, and then uses a linear phase three point averaging
//	 filter to adjust the fundamental frequency to decay in time tf0,
//	 and in time tNy at the Nyquist frequency.  In some cases, the 
//	 decay time at the Nyquist frequency (which always must be less than 
//	 tf0) will not be exactly as requested, but a wide range of variation
//	 is possible.  The two point and three point filters are combined into
//	 a single four point filter.  A single pole dc-blocking filter is added
//	 because the four point filter may have some gain a dc, and non-zero dc
//	 response can cause problems with clicks and what not.     
//	 Randfill must be called after (and not before) this routine is called the 
//	 first time, as it initializes some things in the strumq structure.
//	 This routine does not initialize them so it may be used to change parameters
//	 during the course of a note.

	float xlen,xerr,dH0,dHNy,H01,H02,HNy1,HNy2,H,a0,a1,c1,c2;
	float ncycles0,ncyclesNy;
	float tgent,c,s,del,temp,g;
	double w0;

	xlen =SAMPLE_FREQ/freq;
	w0 = freq/SAMPLE_FREQ*2.*PI;

	ncycles0 = freq * tf0;
	ncyclesNy = freq * tNy;

	/*ncylces is not an integer,and is number of cycles to decay*/
	dH0 = pow(.1,(double)1./ncycles0); /* level will be down to -20db after t*/
	dHNy = pow(.1,(double)1./ncyclesNy); 

	del = 1.;	/*delay of 1 from three point filter to be added later */
	n = floor(xlen - del);
//fprintf(stderr, "n = %d %d %d\n", n, xlen, del);
	xerr = n - xlen + del;	 /*xerr will be a negative number*/

	/* Calculate the phase shift needed from two-point averaging filter,
		 calculate the
		 filter coefficient c1:  y = c1*xn + (1-c1)*x(n-1)  */
	tgent = tan((double)xerr*w0);	/* tan of theta */
	c = cos(w0);
	s = sin(w0);
	c1 = (-s-c*tgent)/(tgent*(1.-c)-s);
	c2 = 1. - c1;

	/*effect of this filter on amplitude response*/
	H01 = sqrt( (c2)*(c2)*s*s + (c1*(1.-c)+c)*(c1*(1.-c)+c) );
	HNy1 = fabs(2.*c1 - 1.);

	/*Now add three point linear phase averaging filter with delay of 1, */
	/* y = xn*a0 + xn-1*a1 + xn-2*a0	*/
	/* and a gain or loss factor, g, so that the filter*g has repsonse H02 and*/
	/* HNy2 to make the total response of all the filters dH0 and dHNy	*/
	H02 = dH0/H01;
	if (HNy1 >0)
		HNy2 = dHNy/HNy1;
	else {
		 HNy2 = 1.e10;
		 /*printf("unable to meet specs exactly--you requested a magic frequency\n");*/
	}
	/*printf("dHNy=%f,HNy2=%f,HNy1=%f\n",dHNy,HNy2,HNy1);*/
	g = (2*H02 - (1.-c)*HNy2)/(1.+c);
	a1 = (HNy2/g + 1.)/2.;
	/*a1 = (H02/g - c)/(1.-c);*/ /*alternate equivalent expression*/

	/*However, for this filter to be monotonic low pass, a1 must be between */
	/* 1/2 and 1, if it isn't response at Nyquist won't be as specified, */
	/*but it will be set as close as is feasible*/
	if( a1<.5) {
		a1 = .5;
		H = (1.-a1)*c + a1;
		g = H02/H;
		/*printf("specs won't be met exactly, too fast a Nyquist freq. decay was requested.\n");*/
	}
	
	if( a1>1.) {
		a1 = 1.;
		g = H02;
		/*printf("specs won't be met exactly, too slow a Nyquist decay was requested\n");*/
	}

	a0 = (1.-a1)/2.;
	a0 *= g;
	a1 *= g;


	/* Now combine the two and three point averaging filters into one */
	/* four point filter with coefficients a[0]-a[3] */
	a[0] = a0*c1;
	a[1] = a0*c2 + a1*c1;
	a[2] = a0*c1 + a1*c2;
	a[3] = a0*c2;

	/*set up dc blocking filter*/
	temp=PI*(float)(freq/18./SAMPLE_FREQ);	/*cutoff frequency at freq/18 */
	dca0=1./(1.+temp);
	dca1= -dca0;
	dcb1=dca0*(1-temp);
}

//--------------------------------------------------------------------
void Twang::Squisher() 
{
	int i,j,p1,p2;
	float mult;

// Routine for use with 'strum' plucked string.	Called by randfill
// Low- pass filters vales of string, squish times.
// Compensates for loss of level at fundamental, but not for overall loss.

	p1 = n-1;
	p2 = n-2;

	mult = fabs(1./( 2.*cos((double)2.*PI/n) + 1.));

	for(j=0; j<squish; j++){
		for(i=0;i<n;i++) {
			d[i] = mult*(d[p2]+d[i]+d[p1]);
			p2 = p1;
			p1 = i;
		}
	}
}

//--------------------------------------------------------------------
inline float
Twang::rrand()
{
		long randx = rand();
		   int i = ((randx = randx*1103515245 + 12345)>>16) & 077777;
		   return((float)i/16384. - 1.);
}

//--------------------------------------------------------------------
inline float
Twang::Distortion(float x) 
{
/* Soft clipping: dist = x - 1/3 * x^3	*/
	if(x>1.0) {
		return(.66666667);
	} else if(x>-1.0) {
		return(x - .33333333 * x*x*x);
	} else {
		return(-.66666667);
	}
}

inline float
Twang::TubeDistortion(float x)
{
/* Tube-ish distortion: dist = (x +.5)^2 -.25	*/
/* this does not work with a feedback guitar */
	return ((x+.5)*(x+.5) - .25);
	 
}

//--------------------------------------------------------------------
/* simple interpolating delay line, uses structure as set up by delayset */
float TwangDelay::Delay(float xin) 
{
	int pout,pout1;
	if( ++p >= maxdl) p = 0;
	pout = p - del;
	if ( pout < 0 )	pout = pout + maxdl;
	pout1 = pout-1;
	if ( pout1 < 0 )	pout = pout + maxdl;

	d[p] = xin;
	return(c1*d[pout] + c2*d[pout1]);
}
