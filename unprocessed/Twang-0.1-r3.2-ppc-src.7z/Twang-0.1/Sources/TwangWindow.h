#ifndef _TWANGWIN
#define _TWANGWIN

class NumCtrl;
class TPot;
class TiledView;

class TwangWindow: public BWindow
{
public:
					TwangWindow(short id);
					~TwangWindow();
				
	virtual bool	QuitRequested();
	virtual void	MessageReceived(BMessage *inMsg);
	
	TiledView		*back;
	NumCtrl			*squishCtrl;
	TPot			*gainKnob;
	TPot			*durKnob;
};

enum {
	GAIN		= 'gain',
	SQUISH		= 'sqsh',
	DURATION	= 'durn'
};

#endif