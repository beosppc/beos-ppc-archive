#include <storage/Resources.h>

void setrescursor(int32 id);
void setrescursor(const char *name);

void setrescursor(int32 id) {
	unsigned char data[516];
	be_app->AppResources()->ReadResource('CURS',id,data,0,516);
	be_app->SetCursor(data);
}

void setrescursor(const char *name) {
	unsigned char data[516];
	int32 id;
	size_t length;
	be_app->AppResources()->GetResourceInfo('CURS',name,&id,&length);
	be_app->AppResources()->ReadResource('CURS',id,data,0,516);
	be_app->SetCursor(data);
}