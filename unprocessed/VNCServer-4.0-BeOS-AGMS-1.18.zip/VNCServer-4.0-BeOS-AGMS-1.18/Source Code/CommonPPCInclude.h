namespace std {
        int ___foobar___;
}
#define std

