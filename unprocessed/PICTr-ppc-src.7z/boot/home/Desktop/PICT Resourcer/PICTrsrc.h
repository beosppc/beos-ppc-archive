//requires libtranslation.so

#include <translation/TranslationUtils.h>
#include <interface/View.h>

class PICTResource : public BView {
	public:
		PICTResource(const char *resourceName,const char *name,BRect frame,uint32 resize = B_FOLLOW_ALL_SIDES,uint32 flags = B_WILL_DRAW | B_FULL_UPDATE_ON_RESIZE | B_FRAME_EVENTS) : BView(frame,name,resize,flags) {
			image = BTranslationUtils::GetBitmap(B_TRANSLATOR_BITMAP,resourceName);
			if (image == NULL)
				return;
			if (Window() != NULL) {
				Window()->Lock();
				DrawBitmap(image);
				Window()->Unlock();
			}}
		void Draw(BRect updateRect) {if(image == NULL) {return;}if(Window() != NULL) {Window()->Lock();DrawBitmap(image);Window()->Unlock();}}
		~PICTResource(void) {delete image;}
	private:
		BBitmap *image;
};