DeskPad 1.0 for BeOS Preveiw Release

Thank you for downloading DeskPad!

DeskPad can be used for temporary storage for things such as phone numbers, web addresses, email addresses, and things that the human brain just can't remember in a hurry.

If you havn't noticed already, this is my first application for BeOS.  More functions will be added in future versions.  The source is included with hopes that I can someday help a begginer like myself.  If you find any bugs or if you have anything to say about DeskPad please email me.

Contact Info:
Derek White
funksta@earthlink.net
Daz Pimpin' Software
http://home.earthlink.net/~funksta

©1997 Daz Pimpin' Software