//	main.cc

#include "img2rsrc.h"

main()
{
	BApplication *app = new Img2Rsrc();
	app->Run();
	delete app;
}
