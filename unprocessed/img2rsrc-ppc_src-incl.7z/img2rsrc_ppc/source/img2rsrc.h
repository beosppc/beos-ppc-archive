//	img2rsrc.hh

#pragma once

#define		I2R_SIGNATURE			"application/x-vnd.et-img2rsrc"

class Img2Rsrc : public BApplication
{
	public:
	
		Img2Rsrc();
		
		void ArgvReceived(int32, char **);
		void ReadyToRun(void);
		
	private:
	
		char *fileName;
		BBitmap *iconBmap;
		BBitmap *micnBmap;
		bool append;
		bool force;
		
		status_t process_option(char *, int *, char **);
};
