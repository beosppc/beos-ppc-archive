/*	GetBitmap.h			*/
/*	datatypes@mindcontrol.org	*/

#pragma once


#if !defined(_GETBITMAP_H_)
#define _GETBITMAP_H_

#include <SupportDefs.h>

class BBitmap;


/*	Get bitmap - first try as file name, then as DATA_BITMAP resource from app file */
BBitmap *		GetBitmap(
					const char			*name);

/*	Get bitmap - from app resource file */
BBitmap *		GetBitmap(
					uint32				type,
					int32				id);
BBitmap *		GetBitmap(
					uint32				type,
					const char			*name);

/*	Get bitmap - from file only	*/
BBitmap *		GetBitmapFile(
					const char *		path);

#endif

