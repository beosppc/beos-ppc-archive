Zorkwork BeOS Port by patrik.lantz@microdatahbg.se

---------

What is this?

 Zorkword -- an Infocom(tm) game vocabulary dumper.

 In 1992, there were no Z-machines greater than 6, and with
 Infocom dead, no reason to expect any. Over the last 5 years,

 Graham Nelson's outstanding Inform compiler has completely
 changed Z-machineology, and introducted the v7 and z8 game.

 Accordingly, I have relaxed the sanity check to allow greater
 range in Z-machine versions.

 Zorkword is rather obsolete now. More versatile programs can
 do the same task. The Z-machine specification supercedes the
 comments in the source. But since it's still preserved for
 posterity on the if-archive (as a historical artifact?), I
 feel it is my duty to make the one-line change that will
 enable it to function with the new breed of Z-machine games.

 Warning:	Using this program on games you haven't solved can result in
		giving away passwords, spoiling surprises, and just maybe
		relieving the frustration of Dave Lebling's "what verb does
		this stupid game want me to use?" puzzles.

 For compilers, interpreters, specifications, and more Z-machine games
 than you can wave a scepter at, go to the interactive fiction archive
 at ftp.gmd.de.
 
 Some things to use this program for:
    read every last Encyclopedia Frobizzica entry,
    be sure you've learned every spell in the Enchanter series,
    know all the Wizard of Frobozz's wand's F-words,
    discover obscure synonyms (like Glamdring for the Zorkian elvish sword)
    learn trivia about internal operations (like the `intnum' noun, used
    when you type a number)
    play with debugging commands in some games (Stu Galley's especially)

---------

Changes

 Changes in BeOS release 10b (971108):
     Very small changes.		

 Works on BeBox Dual 133MHz with BeOS PR2, should work on all BeOS clones.
  Just a quick port for I like Infocom games and love BeOS!
  Contact me for anything: patrik.lantz@microdatahbg.se

 Changes in release 10 (970824):
      Dump the vocabulary of Inform-made v7 and v8 Z-machine files.
	Add new info about internal structures.-
      Try adding .z3-.z8 extensions if a file name is not found.
	Bring my contact info up to date.

 Changes in release 9 (920920):
	Added new info about internal structures.
      In show-flags mode, enclose in brackets any vocabulary words without
      the end-of-string bit set, since they can't really be used.

 Changes in release 8:
	Add a sanity check to make sure a file is really a data file, before
	trying to frob it and usually crashing.
      Try adding .data extension if a file name is not found.
      Revise some comments.

 Changes in release 7:
	Add comments about the file format.
      Correct my mistaken assumption that every entry in the vocabulary
      table has 3 data bytes -- Sherlock has only 2, and Shogun has 4.
      Add support for non-standard text compression alphabets in the
      data file, which Shogun uses.
      Make -# and -f ordinary switches instead of toggles.
      Rename program to something more unique than "vocab".
      Show version number of pix data files.

---------
Contact me at:

 Original author:

 Questions? Comments? Send Internet e-mail to lionheart@mad.scientist.com.

