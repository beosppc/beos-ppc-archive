//
// ClockRAM.h
//

#pragma once

#include <Application.h>
#include "ClockWindow.h"

class ClockRAM : public BApplication
{
	public:
		ClockRAM( bool install );

	private:
		ClockWindow		*mClockWindow;
};
