//
// ClockWindow.h
//

#pragma once

#include <Window.h>
#include "ClockView.h"

class ClockWindow : public BWindow
{
	public:
		ClockWindow( BRect r );

	private:
		ClockView	*mClockView;
};
