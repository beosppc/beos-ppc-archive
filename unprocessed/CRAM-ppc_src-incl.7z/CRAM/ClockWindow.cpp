//
// ClockWindow.cpp
//

#include "ClockWindow.h"

// Does sub-classing BWindow really serve any purpose?
ClockWindow::ClockWindow( BRect r )
	: BWindow( r, "CRM", B_MODAL_WINDOW_LOOK, B_FLOATING_ALL_WINDOW_FEEL,
				B_NOT_RESIZABLE | B_WILL_ACCEPT_FIRST_CLICK,
				B_ALL_WORKSPACES )
{
	SetPulseRate( 1000000 );	// 1 sec pulse interval
	// However, nothing bigger than below will render into Status View as of R3.
	BRect vr(0, 0, 88, 16);
	mClockView = new ClockView( vr );

	if ( Lock() ) {
		AddChild( mClockView );
		Unlock();
	}
}
