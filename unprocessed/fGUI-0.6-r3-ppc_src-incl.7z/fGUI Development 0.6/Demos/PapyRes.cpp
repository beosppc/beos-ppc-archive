//___ PapyRes.cpp _____________________________________________________________

#include "PapyRes.h"
// Factory
#include "fFactory.h"
// Groups
#include "fFrame.h"
#include "fVerticalGroup.h"
#include "fHorizontalGroup.h"
#include "fEqualHorizontalGroup.h"
#include "fHorizontalSpace.h"
#include "fVerticalSpace.h"
// Tabs
#include "fTabGroup.h"
#include "fTabItem.h"
// Objects
#include "fString.h"
#include "fButton.h"
#include "fCheckBox.h"
#include "fRadioButton.h"
#include "fHorizontalScrollBar.h"
#include "fVerticalScrollBar.h"
#include "fTextInput.h"

#include "fCycleButton.h"
#include "fScrollPane.h"

// Misc
#include "fGroupDispatcher.h"
#include "fWindow.h"

#include "fReturnValue.h"

const char* const	NUMBERS = "0123456789";


#pragma mark ### Toolbox ######################################################

const char* const F_NO_FRAME = NULL;
const char* const F_NO_LABEL = "";

inline fObject* new_fFrame( fObject *Object, const char* Frame)
{
	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "Frame");
	fFrame *frame = dynamic_cast<fFrame *>( ClassInfo);

	if( frame == NULL)
		exit( -1);

	if( *Frame != *F_NO_LABEL)
		frame->setText( Frame);

	frame->setObject( Object);
	return( frame);
}

inline fGroup* new_fVerticalGroup( float Weights=100.0)
{
	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "VerticalGroup");
	fVerticalGroup* v_grp = dynamic_cast<fVerticalGroup *>( ClassInfo);

	if( v_grp == NULL)
		exit( -1);

	v_grp->setWeights(Weights);
	return v_grp;
}

inline fHorizontalGroup* new_fHorizontalGroup(float Weights=100.0)
{
	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "HorizontalGroup");
	fHorizontalGroup* h_grp = dynamic_cast<fHorizontalGroup *>( ClassInfo);

	if( h_grp == NULL)
		exit( -1);

	h_grp->setWeights(Weights);
	return h_grp;
}

inline fString* new_fString(const char* Label, float Weights=100.0, fColor* Color=NULL)
{
	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "String");
	fString* string = dynamic_cast<fString *>( ClassInfo);

	if( string == NULL)
		exit( -1);

	string->setText( Label);
	string->setWeights(Weights);
	string->setVerticalAlignment(fObject::F_VALIGN_CENTER);
	if (Color != NULL)  string->setFontColor(*Color);
	return string;
}

inline fGroup *new_fTextInputGrp(const char* Text=NULL, const char* Label=NULL, bool LabelPlacement=true, const char* Accept=NULL, const char* MinW=NULL)
{
	fGroup*		grp = new_fHorizontalGroup();

	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "TextInput");
	fTextInput* inp = dynamic_cast<fTextInput *>( ClassInfo);

	if( inp == NULL)
		exit( -1);

	grp->setBorders(0.0);
	grp->addObject(inp);
	if (Text)	inp->setText(Text);
	if (Accept)	inp->setAcceptCharacters(Accept);
	if (MinW)	inp->setMinimumWidthText(MinW);

	if (Label)
	{
		fString* lab = new_fString( Label);

		if (LabelPlacement)
			grp->addObject(lab);
		else
		{
			grp->insertObject(lab);
			lab->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
		}
	}
	return grp;
}

inline fGroup *new_fCycleGrp(const char** Choices, int32 Count, const char* Label=NULL, bool LabelPlacement=true)
{
	fGroup*			grp = new_fHorizontalGroup();

	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "CycleButton");
	fCycleButton* obj = dynamic_cast<fCycleButton *>( ClassInfo);

	if( obj == NULL)
		exit( -1);

	for( int i = 0; i < Count; i++)
		obj->addText( Choices[ i]);

	grp->setBorders(0.0);
	grp->addObject(obj);

	if (Label)
	{
		fString* lab = new_fString( Label);

		if (LabelPlacement)
			grp->addObject(lab);
		else
		{
			grp->insertObject(lab);
			lab->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
		}
	}
	return grp;
}

inline fCheckBox* new_fCheckBox(const char* Label, bool IsActive=false, float HorizontalWeight=100.0)
{
	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "CheckBox");
	fCheckBox* chk_box = dynamic_cast<fCheckBox *>( ClassInfo);

	if( chk_box == NULL)
		exit( -1);

	chk_box->setText( Label);
	chk_box->setActive(IsActive);
	chk_box->setHorizontalWeight(HorizontalWeight);
	return chk_box;
}


inline fRadioButton* new_fRadioButton(const char* Label, bool IsActive=false, float HorizontalWeight=100.0, char* ExGroup=NULL)
{
	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "RadioButton");
	fRadioButton* radio = dynamic_cast<fRadioButton *>( ClassInfo);

	if( radio == NULL)
	{
		fprintf( stderr, "Scheiss\n");
		exit( -1);
	}

	radio->setText( Label);
	radio->setActive(IsActive);
	radio->setHorizontalWeight(HorizontalWeight);
	if (ExGroup != NULL)  radio->setExclusiveGroup(ExGroup);
	return radio;
}


inline fTabItem* new_fTabItem(const char* Label=NULL, fObject* Object=NULL, float HorizontalWeight=100.0)
{
	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "TabItem");
	fTabItem* tab_item = dynamic_cast<fTabItem *>( ClassInfo);

	if( tab_item == NULL)
		exit( -1);

	tab_item->setText( Label);
	if (Label != NULL)  tab_item->setObject(Object);
	tab_item->setHorizontalWeight(HorizontalWeight);
	return tab_item;
}

inline fButton *new_fButton( const char *Label)
{
	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "Button");
	fButton* button = dynamic_cast<fButton *>( ClassInfo);

	if( button == NULL)
		exit( -1);

	button->setText( Label);
	return button;
}

#pragma mark ### Application ##################################################



int main(void)
{
	PapyRes Application;
	Application.Run();
	return 0;
}


PapyRes::PapyRes(void)
:	fApplication("application/x-vnd.fgui.papyres")
{
}


void PapyRes::ReadyToRun(void)
{
	fTabGroup*	tab_grp;
	fGroup*		grp0;
	fGroup*		grp1;
	fGroup*		grp2;
	fButton*	but;

	// Create TabGroup
	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "TabGroup");
	tab_grp = dynamic_cast<fTabGroup *>( ClassInfo);

	if( tab_grp == NULL)
		exit( -1);

	fprintf( stderr, "--------- Test start --------\n");

	// Test of the calling of methods by name using doMethod()

	BList Arguments;
	fReturnValue Result = tab_grp->doMethod( "getClassName", Arguments);
	
	if( Result.getValid())
		fprintf( stderr, "tab_grp->doMethod() %s\n", Result);
	else
		fprintf( stderr, "Invalid! (%s)\n", Result);

	fprintf( stderr, "--------- Test ende --------\n");

	AddTab_Einstellungen_Test		(tab_grp);
	AddTab_Einstellungen_Lineale	(tab_grp);
	AddTab_Einstellungen_Zoom		(tab_grp);
	AddTab_Einstellungen_Cursor		(tab_grp);
	AddTab_Einstellungen_Ascii		(tab_grp);
	AddTab_Einstellungen_Rtf		(tab_grp);
	AddTab_Einstellungen_Bilder		(tab_grp);
	AddTab_Einstellungen_Dialoge	(tab_grp);
	AddTab_Einstellungen_Meldungen	(tab_grp);
	AddTab_Einstellungen_Diverses	(tab_grp);

	// Create Window
	grp0 = new_fVerticalGroup();
	grp0->addObject(grp1 = new_fHorizontalGroup());		
		grp1->addObject(tab_grp);
	grp0->addObject(grp1 = new_fHorizontalGroup());
		grp1->setVerticalWeight(0.0);
		grp1->addObject(new fHorizontalSpace(2.0));
		grp1->addObject(but = new_fButton(" Hilfe "));
			but->setHorizontalWeight(0.0);
			but->setVerticalWeight(0.0);
			but->setVerticalAlignment(fObject::F_VALIGN_CENTER);
		grp1->addObject(new fVerticalSpace());
		ClassInfo = fFactory::getFactory()->createInstance( "EqualHorizontalGroup");
		grp2 = dynamic_cast<fGroup *>( ClassInfo);

		if( grp2 == NULL)
			exit( -1);

		grp1->addObject(grp2);	grp1->setBorders(0.0);
			grp2->addObject(but = new_fButton("Zurück"));
				but->setVerticalWeight(0.0);
				but->setVerticalAlignment(fObject::F_VALIGN_CENTER);
			grp2->addObject(new fHorizontalSpace(10.0));
			grp2->addObject(but = new_fButton("Setzen"));
				but->setVerticalWeight(0.0);
				but->setVerticalAlignment(fObject::F_VALIGN_CENTER);
			grp2->addObject(but = new_fButton("Ok"));
			grp2->addObject(new fHorizontalSpace(0.0));


	ClassInfo = fFactory::getFactory()->createInstance( "Window");
	mWindow = dynamic_cast<fWindow *>( ClassInfo);

	if( mWindow == NULL)
		exit( -1);

	mWindow->setWindowTitle( "Papyrus - Einstellungen");
	mWindow->setWindowType( B_TITLED_WINDOW);
//	mWindow->setWindowFlags( B_NOT_RESIZABLE);
	mWindow->setObject( grp0);

	mWindow->moveWindowTo( fPoint( 20.0, 50.0));
	mWindow->setDefaultButton( but);
	mWindow->showWindow();
}


PapyRes::~PapyRes(void)
{
}



#pragma mark ### Tabs: Einstellungen ##########################################



void PapyRes::AddTab_Einstellungen_Lineale(fTabGroup* TabGrp)
{
	fGroup*	grp0;

	TabGrp->addObject(new_fTabItem("Lineale", grp0 = new_fVerticalGroup( 0.0)));
		grp0->addObject( new_fFrame( new_fCheckBox("Vertikales Lineal"), "Zeige"));
		char *Einheiten[] = { "Millimeter", "Centimeter", "Inch"};
		grp0->addObject(new_fCycleGrp( Einheiten, 3, "Einheit:", false));
		grp0->addObject(new_fCheckBox("Mausposition zeigen", true));
}


void PapyRes::AddTab_Einstellungen_Zoom(fTabGroup* TabGrp)
{
	fRadioButton*		rad;
	fGroup*				grp0;
	fGroup*				grp1;
	fGroup*				grp2;
	fObject*			obj0;
	fString*			str;
	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "GroupDispatcher");
//	fGroupDispatcher*	dsp = dynamic_cast<fGroupDispatcher *>( ClassInfo);

	char *dsp = "Hallo 1";

//	if( dsp == NULL)
//		exit( -1);

	fColor				fcol(128, 128, 128);
	const char* const	MIN_W = "00000";

	TabGrp->setInset(4.0);

	TabGrp->addObject(new_fTabItem("Zoom", grp0 = new_fHorizontalGroup( 0.0)));
		grp0->setName( "Hallo 1");
		grp0->addObject(grp1 = new_fVerticalGroup( 0.0));
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Vorwahl 1  ", false, 100.0, dsp));		rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(new_fTextInputGrp("25", "%", true, NUMBERS, MIN_W));
				grp2->addObject(str = str = new_fString("CTRL+F1", 100.0, &fcol));					str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Vorwahl 2  ", false, 100.0, dsp));		rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(new_fTextInputGrp("33", "%", true, NUMBERS, MIN_W));
				grp2->addObject(str = new_fString("CTRL+F2", 100.0, &fcol));						str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Vorwahl 3  ", false, 100.0, dsp));		rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(new_fTextInputGrp("50", "%", true, NUMBERS, MIN_W));
				grp2->addObject(str = new_fString("CTRL+F3", 100.0, &fcol));						str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Vorwahl 4  ", false, 100.0, dsp));		rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(new_fTextInputGrp("75", "%", true, NUMBERS, MIN_W));
				grp2->addObject(str = new_fString("CTRL+F4", 100.0, &fcol));						str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Vorwahl 5  ", false, 100.0, dsp));		rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(new_fTextInputGrp("86", "%", true, NUMBERS, MIN_W));
				grp2->addObject(str = new_fString("CTRL+F5", 100.0, &fcol));						str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Vorwahl 6  ", false, 100.0, dsp));		rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(new_fTextInputGrp("110", "%", true, NUMBERS, MIN_W));
				grp2->addObject(str = new_fString("CTRL+F6", 100.0, &fcol));						str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Vorwahl 7  ", false, 100.0, dsp));		rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(new_fTextInputGrp("125", "%", true, NUMBERS, MIN_W));
				grp2->addObject(str = new_fString("CTRL+F7", 100.0, &fcol));						str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Vorwahl 8  ", false, 100.0, dsp));		rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(new_fTextInputGrp("150", "%", true, NUMBERS, MIN_W));
				grp2->addObject(str = new_fString("CTRL+F8", 100.0, &fcol));						str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Vorwahl 9  ", false, 100.0, dsp));		rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(new_fTextInputGrp("200", "%", true, NUMBERS, MIN_W));
				grp2->addObject(str = new_fString("CTRL+F9", 100.0, &fcol));						str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Vorwahl 10", false, 100.0, dsp));			rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(new_fTextInputGrp("300", "%", true, NUMBERS, MIN_W));
				grp2->addObject(str = new_fString("CTRL+F10", 100.0, &fcol));						str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
		grp0->addObject(new fHorizontalSpace(30.0));
		grp0->addObject(grp1 = new_fVerticalGroup( 0.0));
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Normal", true, 100.0, dsp));				rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(str = new_fString("(CMD+0)", 100.0, &fcol));						str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Druckerauflösung", false, 100.0, dsp));	rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(str = new_fString("CTRL+>", 100.0, &fcol));							str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(obj0 = rad = new_fRadioButton("Ganze Seite", false, 100.0, dsp));	rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(str = new_fString("CTRL+<", 100.0, &fcol));							str->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(rad = new_fRadioButton("Aktuelle Auflösung", false, 100.0, dsp));	rad->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(new_fTextInputGrp("100", "%", true, NUMBERS, MIN_W));
}


void PapyRes::AddTab_Einstellungen_Cursor(fTabGroup* TabGrp)
{
	fGroup*	grp0;
	fGroup*	grp1;

	TabGrp->addObject(new_fTabItem("Cursor", grp0 = new_fVerticalGroup( 0.0)));
		grp0->addObject(new_fFrame( grp1 = new_fVerticalGroup(), "Form des Textcursors"));
			grp1->addObject(new_fRadioButton("Dünne Linie", true));
			grp1->addObject(new_fRadioButton("Dicke Linie"));
			grp1->addObject(new_fRadioButton("I-Linie"));
}


void PapyRes::AddTab_Einstellungen_Ascii(fTabGroup* TabGrp)
{
	fGroup*	grp0;
	fGroup*	grp1;
	fGroup*	grp2;

	char *Belegung[] = { "Standard-Windows-Belegung", "Macintosh-Belegung", "BeOS-Belegung"};

	TabGrp->addObject(new_fTabItem("ASCII", grp0 = new_fHorizontalGroup( 0.0)));
		grp0->addObject(grp1 = new_fVerticalGroup());
			grp1->addObject(new_fFrame( grp2 = new_fVerticalGroup(), "ASCII Import/Laden"));
				grp2->addObject(new_fCycleGrp( Belegung, 3, "Belegung:", false));
				grp2->addObject(new_fCheckBox("Fließtext (CR nach Leerzeichen ignorieren)", true));
				grp2->addObject(new_fCheckBox("Leerzeichen am Zeilenanfang entfernen", true));
				grp2->addObject(new_fCheckBox("Nur Leerzeile gilt als Absatzende"));
			grp1->addObject(new_fFrame( grp2 = new_fVerticalGroup(), "ASCII Export: Zeilenvorschub-Typ"));
				grp2->addObject(new_fCycleGrp( Belegung, 3, "Belegung:", false));
				grp2->addObject(new_fRadioButton("DOS  (LF)", true));
				grp2->addObject(new_fRadioButton("MacOS  (CR)"));	
				grp2->addObject(new_fRadioButton("BeOS/UNIX  (LF)"));
				grp2->addObject(new_fCheckBox("Fließtext (CR nach Leerzeichen ignorieren)", true));
		grp0->addObject(grp1 = new_fVerticalGroup());
			grp1->addObject(new_fFrame( grp2 = new_fVerticalGroup(), "ASCII Import/Laden"));
				grp2->addObject(new_fRadioButton("Import-Texte wandeln in *.PAP", true));
				grp2->addObject(new_fRadioButton("RTF/ASCII gleichwertig zu *.PAP"));
}


void PapyRes::AddTab_Einstellungen_Rtf(fTabGroup* TabGrp)
{
	fGroup*	grp0;
	fGroup*	grp1;

	char *Belegung[] = { "Standard-Windows-Belegung", "Macintosh-Belegung", "BeOS-Belegung"};

	TabGrp->addObject(new_fTabItem("RTF", grp0 = new_fVerticalGroup( 0.0)));
		grp0->addObject(new_fFrame( grp1 = new_fVerticalGroup(), "Zeichenbelegung beim RTF-Export"));
			grp1->addObject(new_fCycleGrp( Belegung, 3, "Belegung:", false));
		grp0->addObject(new_fFrame( grp1 = new_fVerticalGroup(), "Export von Pixel-Bildern"));
			grp1->addObject(new_fRadioButton("Hexadezimal-Format (kompatibler)", true));
			grp1->addObject(new_fRadioButton("Binär (spart ca. 50% Platz)"));
}


void PapyRes::AddTab_Einstellungen_Bilder(fTabGroup* TabGrp)
{
	fGroup*	grp0;
	fGroup*	grp1;
	fGroup*	grp2;

	char *Import[] = { "nur Dateipfad und -name speichern", "Bild in Dokument integrieren"};
	char *Loeschen[] = { "Abfrage", "Bild entfernen"};

	TabGrp->addObject(new_fTabItem("Bilder", grp0 = new_fHorizontalGroup()));
		grp0->addObject(grp1 = new_fVerticalGroup());
			grp1->addObject(new_fFrame( grp2 = new_fVerticalGroup(), "Beim Import neuer Bilder"));
				grp2->addObject(new_fCycleGrp( Import, 2));
			grp1->addObject(new fVerticalSpace());
			grp1->addObject(new_fFrame( grp2 = new_fVerticalGroup(), "Löschen des letzten Ausschnitts eines Bildes"));
				grp2->addObject(new_fCycleGrp( Loeschen, 2));
		grp0->addObject( new fVerticalSpace());
}


void PapyRes::AddTab_Einstellungen_Dialoge(fTabGroup* TabGrp)
{
	fGroup*	grp0;
	fGroup*	grp1;

	TabGrp->addObject(new_fTabItem("Dialoge", grp0 = new_fVerticalGroup( 0.0)));
		grp0->addObject(new_fFrame( grp1 = new_fVerticalGroup(), "Default Knopf"));
			grp1->addObject(new_fRadioButton("OK (schließt den Dialog)", true));
			grp1->addObject(new_fRadioButton("Setzen (läßt den Dialog offen"));
		grp0->addObject(new_fFrame( grp1 = new_fVerticalGroup(), "Dritter Knopf"));
			grp1->addObject(new_fRadioButton("Abbruch (schließt den Dialog)"));
			grp1->addObject(new_fRadioButton("Zurück (setzt nur Eingaben zurück)", true));
		grp0->addObject(new fVerticalSpace(5.0));
		grp0->addObject(new_fCheckBox("Dialoge schweben vor Dokument-Fenstern", true));
}


void PapyRes::AddTab_Einstellungen_Meldungen(fTabGroup* TabGrp)
{
	fGroup*	grp0;
	fGroup*	grp1;

	TabGrp->addObject(new_fTabItem("Meldungen", grp0 = new_fHorizontalGroup( 0.0)));
		grp0->addObject(grp1 = new_fVerticalGroup());
			grp1->addObject(new_fCheckBox("Abfrage beim Schließen des letzten Dokumentfensters", true));
			grp1->addObject(new_fCheckBox("Ungewöhnliche Rückgabewerte von Systemaufrufen melden", true));
			grp1->addObject(new_fCheckBox("Expertenmodus (keine Hinweis-Meldungen)"));
}

void PapyRes::AddTab_Einstellungen_Diverses(fTabGroup* TabGrp)
{
	fGroup*			grp0;
	fGroup*			grp1;
	fGroup*			grp2;
	fGroup*			txt;
	fObject*		master;
	fObject*		slave;
	fEventRoute*	route;

	TabGrp->addObject(new_fTabItem("Diverses", grp0 = new_fVerticalGroup( 0.0)));
		grp0->addObject(new_fCheckBox("Anführungszeichen-Automatik", true));
		grp0->addObject(grp1 = new_fVerticalGroup());
			grp1->setBorders( 0.0);
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->setBorders( 0.0);
				grp2->addObject(master = new_fCheckBox("Automatisch sichern alle", true));	master->setVerticalAlignment(fObject::F_VALIGN_CENTER);
				grp2->addObject(txt = new_fTextInputGrp("5", "Minuten", true, NUMBERS, "1234"));
			grp1->addObject(grp2 = new_fHorizontalGroup());
				grp2->addObject(new fHorizontalSpace(19.0));
				grp2->addObject(slave = new_fCheckBox("Mit Abfrage", true));
		grp0->addObject(new_fCheckBox("Automatisch horizontales Scrollen", true));
		grp0->addObject(new_fCheckBox("Speichern mit Sicherheitskopien", true));
		grp0->addObject(new_fCheckBox("Bei Programmende Einstellungen sichern", true));
		grp0->addObject(new_fCheckBox("Einstellung sichern mit Arbeitsumgebung", true));
		grp0->addObject(new_fCheckBox("Textattribute immer vom Textcursor holen", true));

	// create eventroutes
	fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "EventRoute");
	route = dynamic_cast<fEventRoute *>( ClassInfo);

	if( route == NULL)
		exit( -1);

		route->setEvent(F_CHECKBOX_CHECKED);
		route->setAction(F_ENABLE_OBJECT);
		route->setTargetPointer(slave);
		master->addEventRoute(route);
	ClassInfo = fFactory::getFactory()->createInstance( "EventRoute");
	route = dynamic_cast<fEventRoute *>( ClassInfo);

	if( route == NULL)
		exit( -1);

		route->setEvent(F_CHECKBOX_CHECKED);
		route->setAction(F_ENABLE_OBJECT);
		route->setTargetPointer(txt);
		master->addEventRoute(route);

	ClassInfo = fFactory::getFactory()->createInstance( "EventRoute");
	route = dynamic_cast<fEventRoute *>( ClassInfo);

	if( route == NULL)
		exit( -1);

		route->setEvent(F_CHECKBOX_UNCHECKED);
		route->setAction(F_DISABLE_OBJECT);
		route->setTargetPointer(slave);
		master->addEventRoute(route);
	ClassInfo = fFactory::getFactory()->createInstance( "EventRoute");
	route = dynamic_cast<fEventRoute *>( ClassInfo);

	if( route == NULL)
		exit( -1);

		route->setEvent(F_CHECKBOX_UNCHECKED);
		route->setAction(F_DISABLE_OBJECT);
		route->setTargetPointer(txt);
		master->addEventRoute(route);
}


void PapyRes::AddTab_Einstellungen_Test(fTabGroup* TabGrp)
{
	fHorizontalScrollBar*	hscrollbar;
	fVerticalScrollBar*	vscrollbar;
	fObject*				obj_h;
	fObject*				obj_v;
	fEventRoute*			route;
	fGroup*					grp0;
	fGroup*					grp1;
	fGroup*					grp2;

	TabGrp->addObject(new_fTabItem("Test", grp0 = new_fVerticalGroup()));
		fClassInfo *ClassInfo = fFactory::getFactory()->createInstance( "ScrollPane");
		fScrollPane *pane = dynamic_cast<fScrollPane *>( ClassInfo);
	
		if( pane == NULL)
			exit( -1);

		pane->setObject(grp1 = new_fVerticalGroup( 0.0));
			grp1->addObject(new_fFrame( grp2 = new_fVerticalGroup(), "Default Knopf"));
				grp2->addObject(new_fRadioButton("OK (schließt den Dialog)", true));
				grp2->addObject(new_fRadioButton("Setzen (läßt den Dialog offen"));
			grp1->addObject(new_fFrame( grp2 = new_fVerticalGroup(), "Dritter Knopf"));
				grp2->addObject(new_fRadioButton("Abbruch (schließt den Dialog)"));
				grp2->addObject(new_fRadioButton("Zurück (setzt nur Eingaben zurück)", true));
			grp1->addObject(new fVerticalSpace(5.0));
			grp1->addObject(new_fCheckBox("Dialoge schweben vor Dokument-Fenstern", true));

		grp0->addObject( pane);

		grp0->addObject(grp1 = new_fHorizontalGroup());	grp1->setHorizontalAlignment(fObject::F_HALIGN_RIGHT);
			grp1->addObject(obj_v = new_fString("Vert", 0.0));
			ClassInfo = fFactory::getFactory()->createInstance( "VerticalScrollBar");
			vscrollbar = dynamic_cast<fVerticalScrollBar *>( ClassInfo);
		
			if( vscrollbar == NULL)
				exit( -1);

			grp1->addObject(vscrollbar);
				vscrollbar->setMaximum(230.0);
				vscrollbar->setVisible(30.0);
				vscrollbar->setBigJump(30.0);
		grp0->addObject(grp1 = new_fVerticalGroup());
			ClassInfo = fFactory::getFactory()->createInstance( "HorizontalScrollBar");
			hscrollbar = dynamic_cast<fHorizontalScrollBar *>( ClassInfo);
		
			if( hscrollbar == NULL)
				exit( -1);

			grp1->addObject(hscrollbar);
				hscrollbar->setHorizontalBorder(2.0);
				hscrollbar->setMinimum(-100.0);
				hscrollbar->setMaximum(120.0);
				hscrollbar->setVisible(20.0);
				hscrollbar->setBigJump(20.0);
			grp1->addObject(obj_h = new_fString("Horz", 0.0));	obj_h->setHorizontalAlignment(fObject::F_HALIGN_CENTER);

	// Create eventroutes
	ClassInfo = fFactory::getFactory()->createInstance( "EventRoute");
	route = dynamic_cast<fEventRoute *>( ClassInfo);

	if( route == NULL)
		exit( -1);

		route->setEvent(F_SCROLLBAR_VALUE_CHANGED);
		route->setAction(F_SET_VALUE);
		route->setTargetPointer(obj_h);
		hscrollbar->addEventRoute(route);
	ClassInfo = fFactory::getFactory()->createInstance( "EventRoute");
	route = dynamic_cast<fEventRoute *>( ClassInfo);

	if( route == NULL)
		exit( -1);

		route->setEvent(F_SCROLLBAR_VALUE_CHANGED);
		route->setAction(F_SET_VALUE);
		route->setTargetPointer(obj_v);
		vscrollbar->addEventRoute(route);
}

