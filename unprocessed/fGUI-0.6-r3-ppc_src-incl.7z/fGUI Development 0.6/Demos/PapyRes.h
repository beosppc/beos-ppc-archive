//___ PapyRes.h _______________________________________________________________
#pragma once

#include "fApplication.h"
class fTabGroup;
class fWindow;


class PapyRes : public fApplication 
{

	public:
					PapyRes(void);
					~PapyRes(void);
	virtual void	ReadyToRun(void);

	private:

	inline void		AddTab_Einstellungen_Lineale	(fTabGroup* TabGrp);
	inline void		AddTab_Einstellungen_Zoom		(fTabGroup* TabGrp);
	inline void		AddTab_Einstellungen_Cursor		(fTabGroup* TabGrp);
	inline void		AddTab_Einstellungen_Ascii		(fTabGroup* TabGrp);
	inline void		AddTab_Einstellungen_Rtf		(fTabGroup* TabGrp);
	inline void		AddTab_Einstellungen_Bilder		(fTabGroup* TabGrp);
	inline void		AddTab_Einstellungen_Dialoge	(fTabGroup* TabGrp);
	inline void		AddTab_Einstellungen_Meldungen	(fTabGroup* TabGrp);
	inline void		AddTab_Einstellungen_Diverses	(fTabGroup* TabGrp);
	inline void		AddTab_Einstellungen_Test		(fTabGroup* TabGrp);

	// Data
	fWindow*		mWindow;
};

