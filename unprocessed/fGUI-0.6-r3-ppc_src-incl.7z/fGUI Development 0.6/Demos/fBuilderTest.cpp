// Test.cpp

#include "fBuilderTest.h"
#include "fBuilder.h"
#include "fWindow.h"
#include "fFactory.h"

#include <unistd.be.h>

int main( int /*ArgumentCount*/, char */*Arguments[]*/)
{
	Test TestApp;
	TestApp.Run();

	return( 0);
}

void Test::ReadyToRun( void)
{
	if( fFactory::getFactory()->importGUIDescription( "PapyRes.gui"))
	{
		if(( testWindow = dynamic_cast< fWindow *>( fFactory::getFactory()->createInstance( "Main"))) != NULL);
			testWindow->showWindow();
	}
	else
	{
		fprintf( stderr, "Test::ReadyToRun() generateGUI() failed\n");
	}
}

Test::Test( void)
    : fApplication( "application/x-vnd.Stegemann.Test")
{
	app_info appinfo;
	
	if( GetAppInfo( &appinfo) == B_OK)
	{
		BEntry app( &appinfo.ref);
		BEntry dir;
		
		if( app.GetParent( &dir) == B_OK)
		{
			BPath path;
			if( dir.GetPath( &path) == B_OK)
			{
				fprintf( stderr, "Test::Test() Path: %s\n", path.Path());
				chdir( path.Path());
			}
		}
	}
}

Test::~Test( void)
{
}