// Test.h

#ifndef TEST_H
#define TEST_H

#include "fApplication.h"

class Test : public fApplication
{
	private:
		class fWindow	*testWindow;
//		class fBuilder	*testBuilder;
		class fObject	*mainObject;

	public:
		Test( void);
		virtual ~Test( void);

		virtual void ReadyToRun( void);
};

#endif