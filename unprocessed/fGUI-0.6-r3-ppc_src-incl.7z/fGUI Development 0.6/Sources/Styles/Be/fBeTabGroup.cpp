// fBeTabGroup.cpp

#include "fBeTabGroup.h"
#include "fFactory.h"

#include "fEvents.h"

#if DEBUG > 0
#define FTABGROUP_DEBUG DEBUG
#endif

//#undef FTABGROUP_DEBUG
//#define FTABGROUP_DEBUG 4

ClassDefinition( fBeTabGroup, fTabGroup, "Be");

fBeTabGroup::fBeTabGroup( void)
{
	#if FTABGROUP_DEBUG > 0
	fprintf( stderr, "fBeTabGroup::fBeTabGroup()\n");
	#endif

	fOverlap = 19.0;	// 2 * 10.0 - 1.0

	fTabGroup::setSpacing( 0.0);

	#if FTABGROUP_DEBUG > 0
	fprintf( stderr, "fBeTabGroup::fBeTabGroup() end\n");
	#endif
}

fBeTabGroup::~fBeTabGroup( void)
{
	#if FTABGROUP_DEBUG > 0
	fprintf( stderr, "fBeTabGroup::~fBeTabGroup()\n");
	#endif

	#if FTABGROUP_DEBUG > 0
	fprintf( stderr, "fBeTabGroup::~fBeTabGroup() end\n");
	#endif
}

void fBeTabGroup::calculateMinimumSize( void)
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fBeTabGroup::calculateMinimumSize()\n");
	#endif

	int32 Item = 0;
	fTabItem *TempObject;

	fPoint TabItemSize;
	fPoint ObjectSize;

	while(( TempObject = static_cast<fTabItem *>( fObjects.ItemAt( Item++))) != NULL)
	{
		// get minimum size of tabitems
		fPoint minSize = TempObject->getMinimumSize();
		fPoint prefSize = TempObject->getPreferredSize();

		// add the width of the tab
		if( TempObject->getHorizontalWeight() == 0)
			TabItemSize.x += prefSize.x;
		else
			TabItemSize.x += minSize.x;

		float temp;

		// get height of the object
		if( TempObject->getVerticalWeight() == 0)
			temp = prefSize.y;
		else
			temp = minSize.y;

		// if higher than previous height, take the new height
		if( temp > TabItemSize.y)
			TabItemSize.y = temp;

		// get maximum of the minimum sizes of the objects in the tabitems
		const fObject *TempObject2 = TempObject->getObject();

		if( TempObject2)
		{
			fPoint NewObjectSize;	

			// get the minimum size of the object
			if( TempObject2->getHorizontalWeight() == 0)
				NewObjectSize.x = TempObject2->getPreferredSize().x;
			else
				NewObjectSize.x = TempObject2->getMinimumSize().x;

			if( TempObject2->getVerticalWeight() == 0)
				NewObjectSize.y = TempObject2->getPreferredSize().y;
			else
				NewObjectSize.y = TempObject2->getMinimumSize().y;

			// expand box for the Object if necessary
			if( NewObjectSize.x > ObjectSize.x)
				ObjectSize.x = NewObjectSize.x;

			if( NewObjectSize.y > ObjectSize.y)
				ObjectSize.y = NewObjectSize.y;
		}
	}

	// combine sizes
	fPoint Size = TabItemSize;

	// remove space not needed due to overlapping
	Size.x -= fOverlap * ( fObjects.CountItems() - 1);

	Size.y += ObjectSize.y;

	if( ObjectSize.x > Size.x)
		Size.x = ObjectSize.x;

	// add space for the frame around the object
	Size += fPoint( 4.0, 4.0);

	// position the contained object a little bit more in the group
	Size += fPoint( 8.0, 8.0);

	setMinimumSize( Size);

	#if FTABGROUP_DEBUG > 1
	Size.printToStream( "fBeTabGroup::calculateMinimumSize() ");
	fprintf( stderr, "fBeTabGroup::calculateMinimumSize() end\n");
	#endif
}

void fBeTabGroup::calculateMaximumSize( void)
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fBeTabGroup::calculateMaximumSize()\n");
	#endif

	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fBeTabGroup::calculateMaximumSize() end\n");
	#endif  
}

void fBeTabGroup::calculatePreferredSize( void)
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fBeTabGroup::calculatePreferredSize()\n");
	#endif

	int32 Item = 0;
	fTabItem *TempObject;

	fPoint TabItemSize;
	fPoint ObjectSize;

	while(( TempObject = static_cast<fTabItem *>( fObjects.ItemAt( Item++))) != NULL)
	{
		// get preferred size of tabitems
		fPoint PreferredSize = TempObject->getPreferredSize();

		TabItemSize.x += PreferredSize.x;

		if( PreferredSize.y > TabItemSize.y)
			TabItemSize.y = PreferredSize.y;

		// get maximum of the preferred sizes of the objects in the tabitems
		fObject *TempObject2 = TempObject->getObject();

		if( TempObject2)
		{
			PreferredSize = TempObject2->getPreferredSize();

			if( PreferredSize.x > ObjectSize.x)
				ObjectSize.x = PreferredSize.x;

			if( PreferredSize.y > ObjectSize.y)
				ObjectSize.y = PreferredSize.y;
		}
	}

	// add sizes
	fPoint Size = TabItemSize;

	// remove space not needed due to overlapping
	Size.x -= fOverlap * ( fObjects.CountItems() - 1);

	Size.y += ObjectSize.y;

	if( ObjectSize.x > Size.x)
		 Size.x = ObjectSize.x;

	// add space for the frame around the object
	Size += fPoint( 4.0, 4.0);

	// position the contained object a little bit more in the group
	Size += fPoint( 8.0, 8.0);

/*
	// sanity check
	
	fPoint MinimumSize = getMinimumSize() - fPoint( 2 * getHorizontalBorder(),
										2 * getVerticalBorder());

	if( Size.x < MinimumSize.x)
		Size.x = MinimumSize.x;

	if( Size.y < MinimumSize.y)
		Size.y = MinimumSize.y;
*/
	setPreferredSize( Size);

	#if FTABGROUP_DEBUG > 1
	getPreferredSize().printToStream( "fBeTabGroup::calculatePreferredSize() ");
	fprintf( stderr, "fBeTabGroup::calculatePreferredSize() end\n");
	#endif
}

void fBeTabGroup::setSize( const fPoint &SetSize)
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fBeTabGroup::setSize() Setting Size to: ");
	SetSize.printToStream();
	#endif

	fObject::setSize( SetSize);

	fPoint Borders( getHorizontalBorder(), getVerticalBorder());

	fPoint NewSize = SetSize;

	NewSize -= Borders;
	NewSize -= Borders;

	float NewWidth  = NewSize.x;
	float NewHeight = NewSize.y;

	int32 Item = 0;
	fObject *SomeObject;

	int32 ItemCount = fObjects.CountItems();

	if( ItemCount == 0)
	{
		#if FTABGROUP_DEBUG > 3
		fprintf( stderr, "fBeTabGroup::setSize() No Items to layout. Exiting...\n");
		#endif

		return;
	}

	// add room for spacing of tabitems
	NewWidth -= ( ItemCount - 1) * fSpacing;

	// because we oberlap the items later we have virtually more room
	NewWidth += ( ItemCount - 1) * fOverlap - 2.0;

	#if FTABGROUP_DEBUG > 3
	fprintf( stderr, "fBeTabGroup::setSize() %d Items to layout. Layoutsize: ", ItemCount);
	NewSize.printToStream();
	#endif

	fPoint *Sizes		= new fPoint[ ItemCount];

	float maxWidth = 0.0;

	// search maximum width
	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		float ObjectWidth = SomeObject->getPreferredSize().x;
		
		if( ObjectWidth > maxWidth)
			maxWidth = ObjectWidth;
	}

	// make all tabs the same size if there is enough room
	if( ItemCount * maxWidth < NewWidth)
	{
		#if FTABGROUP_DEBUG > 3
		fprintf( stderr, "fBeTabGroup::setSize() ItemCount * maxWidth < NewWidth\n");
		#endif

		NewWidth = ItemCount * maxWidth;
	}

	// Run 1:		Use preferred size for objects with HorizontalWeight == 0
	//			center these objekts (if vertical weight == 0)
	//			add weights

	#if FTABGROUP_DEBUG > 3
	fprintf( stderr, "fBeTabGroup::setSize() Pass 1\n");
	#endif

	float TotalWeight = 0.0;

	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		if( SomeObject->getHorizontalWeight() == 0)
		{
			// set horizontal size, subtract object width from total width
			Sizes[ Item].x = SomeObject->getPreferredSize().x;
			NewWidth -= Sizes[ Item].x;

			#if FTABGROUP_DEBUG > 3
			fprintf( stderr, "fBeTabGroup::setSize() Weigth == 0 -> Setting Object %d Size to:", Item);
			Sizes[Item].printToStream();
			#endif
		}
		else
			TotalWeight += SomeObject->getHorizontalWeight();
	}

	// Run 2:		Objects which should get a size smaller or bigger than their min/max size
	//			will be set to min/max size, respectively.

	#if FTABGROUP_DEBUG > 3
	fprintf( stderr, "fBeTabGroup::setSize() Pass 2\n");
	#endif

	bool minmaxfound = true;

	while( minmaxfound)
	{
		minmaxfound = false;

		for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
		{
			// Noch keine Groesse zugewiesen ?
			if( Sizes[ Item].x == 0.0)
			{
				float ObjectWidth = NewWidth * SomeObject->getHorizontalWeight() / TotalWeight;

				fPoint minSize = SomeObject->getMinimumSize();
				fPoint maxSize = SomeObject->getMaximumSize();

				if( ObjectWidth < minSize.x)
				{
					#if FTABGROUP_DEBUG > 3
					fprintf( stderr, "fBeTabGroup::setSize() ObjectWidth < minSize.x\n");
					#endif

					minmaxfound = true;

					NewWidth -= minSize.x;
					TotalWeight -= SomeObject->getHorizontalWeight();

					Sizes[ Item].x = minSize.x;
				}
				else if( ObjectWidth > maxSize.x)
				{
					#if FTABGROUP_DEBUG > 3
					fprintf( stderr, "fBeTabGroup::setSize() ObjectWidth > maxSize.x\n");
					#endif

					minmaxfound = true;

					NewWidth -= maxSize.x;
					TotalWeight -= SomeObject->getHorizontalWeight();

					Sizes[ Item].x = maxSize.x;
				}
			}
		}
	}

	// 3.Durchgang: Allen uebrigen Objekten beliebige Groesse zuweisen.

	#if FTABGROUP_DEBUG > 3
	fprintf( stderr, "fBeTabGroup::setSize() Pass 3\n");
	#endif

	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		// Noch keine Groesse zugewiesen ?
		if( Sizes[ Item].x == 0.0)
		{
			Sizes[ Item].x = NewWidth * SomeObject->getHorizontalWeight() / TotalWeight;

			#if FTABGROUP_DEBUG > 3
			fprintf( stderr, "fBeTabGroup::setSize() Setting horizontal size for Object %d to %f\n", Item, Sizes[ Item].x);
			#endif
		}
	}

	#if FTABGROUP_DEBUG > 3
	fprintf( stderr, "fBeTabGroup::setSize() Pass 4\n");
	#endif

	// Run 4:		Calculate vertical sizes and positions.
	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		fPoint maxSize = SomeObject->getMaximumSize();

		// if verticalweight == 0 set size to preferred size and center
		// else set to new height if not > max height
		if( SomeObject->getVerticalWeight() == 0)
			Sizes[ Item].y = SomeObject->getPreferredSize().y;
		else
		{
			if( NewHeight > maxSize.y)
				Sizes[ Item].y = maxSize.y;				
			else
				Sizes[ Item].y = NewHeight;
		}

		#if FTABGROUP_DEBUG > 3
		fprintf( stderr, "fBeTabGroup::setSize() Setting vertical size for object %d to %f\n", Item, Sizes[ Item].y);
		#endif
	}

	// Run 5: Set size and position
	#if FTABGROUP_DEBUG > 3
	fprintf( stderr, "fBeTabGroup::setSize() Pass 5\n");
	#endif

	// force all tabs to have the same height.
	float verticalSize = 0.0;

	for( Item = 0; Item < ItemCount; Item++)
		if( Sizes[ Item].y > verticalSize)
			verticalSize = Sizes[ Item].y;

	for( Item = 0; Item < ItemCount; Item++)
		Sizes[ Item].y = verticalSize;

	float leftPosition = 0.0;

	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		Sizes[ Item].roundToInteger();

		#if FTABGROUP_DEBUG > 3
		fprintf( stderr, "fBeTabGroup::setSize() Setting Object %d Size to: ", Item);
		Sizes[Item].printToStream();
		fprintf( stderr, "fBeTabGroup::setSize() Setting Object %d Position to: ", Item);
		(getPosition() + fPoint( leftPosition, 0.0) + Borders).printToStream();
		#endif

		SomeObject->setSize( Sizes[ Item]);
		SomeObject->setPosition( getPosition() + fPoint( leftPosition, 0.0) + Borders);

		#if FTABGROUP_DEBUG > 3
		fprintf( stderr, "fBeTabGroup::setSize() Object rectangle is: ");
		SomeObject->getObjectFrame().PrintToStream();
		#endif

		leftPosition += Sizes[ Item].x + fSpacing - fOverlap;
	}

	// Position object below the tabs
	fPoint NewPosition = fPoint( 4.0, Sizes[ 0].y + 6.0) + getPosition() + Borders;

	// And adjust the size (4 pixels on each side for the frame plus the height
	//						of the tabs)
	NewSize -= fPoint( 8.0, Sizes[ 0].y + 8.0);

	if( fActiveItem)
		if( fActiveItem->getObject()) // should *never* be NULL at this point !
		{
			fPoint NewObjectSize;	

			// get the size of the object
			if( fActiveItem->getObject()->getHorizontalWeight() == 0)
				NewObjectSize.x = fActiveItem->getObject()->getPreferredSize().x;
			else
				NewObjectSize.x = fActiveItem->getObject()->getMaximumSize().x;

			if( fActiveItem->getObject()->getVerticalWeight() == 0)
				NewObjectSize.y = fActiveItem->getObject()->getPreferredSize().y;
			else
				NewObjectSize.y = fActiveItem->getObject()->getMaximumSize().y;

			// align object horizontally
			if( NewObjectSize.x < NewSize.x)
			{
				switch( fActiveItem->getObject()->getHorizontalAlignment())
				{
					case fObject::F_HALIGN_LEFT:
						break;
					
					case fObject::F_HALIGN_CENTER:
						NewPosition.x += ( NewSize.x - NewObjectSize.x) / 2;
						break;
					
					case fObject::F_HALIGN_RIGHT:
						NewPosition.x += NewSize.x - NewObjectSize.x;
						break;
				}
	
				NewSize.x = NewObjectSize.x;
			}

			// align object vertically
			if( NewObjectSize.y < NewSize.y)
			{
				switch( fActiveItem->getObject()->getVerticalAlignment())
				{
					case fObject::F_VALIGN_TOP:
						break;
					
					case fObject::F_VALIGN_CENTER:
						NewPosition.y += ( NewSize.y - NewObjectSize.y) / 2;
						break;
					
					case fObject::F_VALIGN_BOTTOM:
						NewPosition.y += NewSize.y - NewObjectSize.y;
						break;
				}
	
				NewSize.y = NewObjectSize.y;
			}

			#if FTABGROUP_DEBUG > 3
			fprintf( stderr, "fBeTabGroup::setSize() Setting contained object size to: ");
			NewSize.printToStream();
			fprintf( stderr, "fBeTabGroup::setSize() Setting contained object position to: ");
			NewPosition.printToStream();
			#endif

			// set object size and position
			#if FTABGROUP_DEBUG > 4
			fprintf( stderr, "fBeTabGroup::setSize() Settings objects size and position.\n");
			#endif
			fActiveItem->getObject()->setSize( NewSize);
			fActiveItem->getObject()->setPosition( NewPosition);
		}

	delete [] Sizes;

	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fBeTabGroup::setSize() end\n");
	#endif
}

void fBeTabGroup::drawObject( const BRegion &ClippingRegion, bool FullUpdate) const
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fBeTabGroup::draw()\n");
	#endif

	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
	{
		#if FTABGROUP_DEBUG > 3
		fprintf( stderr, "fBeTabGroup::draw() Drawing to ");
		Frame.PrintToStream();
		#endif

		return;
	}

	if( getView()->Window() == NULL)
		return;

	if( getView()->Window()->Lock() == false)
		return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	#if FTABGROUP_DEBUG > 3
	fprintf( stderr, "fBeTabGroup::draw() %d items to draw.\n", fObjects.CountItems());
	#endif

	fTabItem *TempObject;

	fTabGroup::drawObject( ClippingRegion, FullUpdate);
	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	// draw the frame for the group
	if(( TempObject = static_cast<fTabItem *>( fObjects.ItemAt( 0))) != NULL)
	{
		fPoint yoffset( 0.0, TempObject->getSize().y - 1.0);

		int32 Item = fObjects.CountItems() - 1;

		TempObject = static_cast<fTabItem *>( fObjects.ItemAt( Item));
		float TabItemEnd = TempObject->getObjectFrame().right;

		// white line (top + left)
		getView()->SetHighColor( 0xff, 0xff, 0xff);
		if( Frame.Width() > TabItemEnd)
			getView()->StrokeLine( Frame.RightTop() + yoffset - BPoint( Frame.Width() - TabItemEnd + 2.0, 0.0),
									Frame.RightTop() + yoffset - fPoint( 2.0, 0.0));
		getView()->StrokeLine( Frame.LeftTop() + yoffset, Frame.LeftBottom());

		// inner line (right + bottom)
		getView()->SetHighColor( 0xb0, 0xb0, 0xb0);
		getView()->StrokeLine( Frame.LeftBottom() + BPoint( 1.0, -1.0), Frame.RightBottom() - BPoint( 1.0, 1.0));
		getView()->StrokeLine( Frame.RightTop() - BPoint( 1.0, 0.0) + yoffset);

		// outer line (right + bottom)
		getView()->SetHighColor( 0x60, 0x60, 0x60);
		getView()->StrokeLine( Frame.LeftBottom() + BPoint( 1.0, 0.0), Frame.RightBottom());
		getView()->StrokeLine( Frame.RightTop() + yoffset);
	}

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fBeTabGroup::draw() end\n");
	#endif
}