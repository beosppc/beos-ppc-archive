// fBeVerticalScrollBar.cpp

#include "fBeVerticalScrollBar.h"

#include "fEventRoute.h"

#include "fFactory.h"

#include "fScrollBarButton.h"

#include "BeScrollBarUp.h"
#include "BeScrollBarUpActive.h"
#include "BeScrollBarUpDisabled.h"
#include "BeScrollBarDown.h"
#include "BeScrollBarDownActive.h"
#include "BeScrollBarDownDisabled.h"

#if DEBUG > 0
#define FSCROLLBAR_DEBUG DEBUG
#endif
 
//#undef FSCROLLBAR_DEBUG
#define FSCROLLBAR_DEBUG -1

ClassDefinition( fBeVerticalScrollBar, fVerticalScrollBar, "Be");

fBeVerticalScrollBar::fBeVerticalScrollBar( void)
{
	recalculateSizeLimits();
}

fBeVerticalScrollBar::~fBeVerticalScrollBar( void)
{
}

void fBeVerticalScrollBar::recalculateSizeLimits( void)
{
	fPoint Size = fPoint( B_V_SCROLL_BAR_WIDTH + 1.0, 0.0);

	// there must be enough room for at least two arrows
	Size.y += 2 * ( 14.0 + 1.0) + 1.0;

	// then there must be room for the knob itself	
	scroll_bar_info scrollbarinfo;
	get_scroll_bar_info( &scrollbarinfo);

	fMinimumKnobSize	= scrollbarinfo.min_knob_size;
	fDoubleArrows		= scrollbarinfo.double_arrows;

	Size.y += fMinimumKnobSize;

	setMinimumSize( Size);
	setPreferredSize( Size);

	setMaximumSize( fPoint( B_V_SCROLL_BAR_WIDTH + 1.0, F_NO_SIZE_LIMIT));
}

void fBeVerticalScrollBar::createArrowButton( const void *PassiveData, const void *ActiveData,
											const void *DisabledData, int32 Which, int32 Action)
{
	if( fArrows[ Which])
		return;

	BRect bounds = BRect( 0.000000, 0.000000, 12.000000, 13.000000);

	BBitmap *bitmap1 = new BBitmap( bounds, B_RGB_32_BIT);
	bitmap1->SetBits( PassiveData, 546, 0, B_RGB_32_BIT);

	BBitmap *bitmap2 = new BBitmap( bounds, B_RGB_32_BIT);
	bitmap2->SetBits( ActiveData, 546, 0, B_RGB_32_BIT);

	BBitmap *bitmap3 = new BBitmap( bounds, B_RGB_32_BIT);
	bitmap3->SetBits( DisabledData, 546, 0, B_RGB_32_BIT);

	fArrows[ Which] = new fScrollBarButton( Action, this, bitmap1, bitmap2, bitmap3);

	fArrows[ Which]->setSize( fArrows[ Which]->getPreferredSize());
	
	if( getView())
		fArrows[ Which]->setView( getView());

	if( fParentWindow)
		fArrows[ Which]->attachedToWindow( fParentWindow);
		
	if( getEnabled() == false)
		fArrows[ Which]->setEnabled( false);

	// create eventroute
	fEventRoute *route = new fEventRoute( F_BUTTON_CLICKED);
	route->setAction( Action);
	route->setTargetPointer( this);
	fArrows[ Which]->addEventRoute( route);
}

void fBeVerticalScrollBar::drawType1KnobMarker( BPoint Position) const
{
	Position += BPoint( 4.0, -2.0);

	BRect Frame( Position, Position + BPoint( 4.0, 4.0));

	// top and left lines
	getView()->SetHighColor( 0xff, 0xff, 0xff);
	getView()->StrokeLine( Frame.RightTop(), Frame.LeftTop());
	getView()->StrokeLine( Frame.LeftBottom());

	// bottom and right lines
	if( getEnabled())
		getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
	else
		getView()->SetHighColor( 0xc8, 0xc8, 0xc8);
	getView()->StrokeLine( Frame.RightBottom());
	getView()->StrokeLine( Frame.RightTop());
}

void fBeVerticalScrollBar::drawType2KnobMarker( BPoint Position) const
{
	Position += BPoint( 3.0, -1.0);
	BRect Frame( Position, Position + BPoint( 6.0, 2.0));

	// top and left lines
	getView()->SetHighColor( 0xff, 0xff, 0xff);
	getView()->StrokeLine( Frame.LeftBottom(), Frame.LeftTop());
	getView()->StrokeLine( Frame.LeftTop(), Frame.RightTop() - BPoint( 1.0, 0.0));

	// bottom and right lines
	if( getEnabled())
		getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
	else
		getView()->SetHighColor( 0xc8, 0xc8, 0xc8);
	getView()->StrokeLine( Frame.RightTop(), Frame.RightBottom());
	getView()->StrokeLine( Frame.LeftBottom() + BPoint( 1.0, 0.0));
}

void fBeVerticalScrollBar::setSize( const fPoint &Size)
{
	fObject::setSize( Size);

	// make up for the borders
	fPoint ScrollBarPosition( getHorizontalBorder(), getVerticalBorder());

	fPoint ScrollBarSize = Size;

	ScrollBarSize -= ScrollBarPosition;
	ScrollBarSize -= ScrollBarPosition;

	// scrollbar frame
	// inset for frame
	ScrollBarSize.x -= 2.0;
	ScrollBarPosition.x += 1.0;

	// get scroll bar infos
	scroll_bar_info scrollbarinfo;
	get_scroll_bar_info( &scrollbarinfo);

	// we need two arrows in any case, create them if they don't exist
	createArrowButton( BeScrollBarUp, BeScrollBarUpActive, BeScrollBarUpDisabled, F_SINGLE_ARROW_UP, F_SCROLLBAR_SMALL_DECREASE);
	createArrowButton( BeScrollBarDown, BeScrollBarDownActive, BeScrollBarDownDisabled, F_SINGLE_ARROW_DOWN, F_SCROLLBAR_SMALL_INCREASE);

	ScrollBarSize.y -= fArrows[ F_SINGLE_ARROW_UP]->getSize().y + fArrows[ F_SINGLE_ARROW_DOWN]->getSize().y;

	fArrows[ F_SINGLE_ARROW_UP]->setPosition( getPosition() + ScrollBarPosition + fPoint( 0.0, 1.0));

	ScrollBarPosition.y += fArrows[ F_SINGLE_ARROW_UP]->getSize().y;

	fArrows[ F_SINGLE_ARROW_DOWN]->setPosition( getPosition() + ScrollBarPosition + fPoint( 0.0, ScrollBarSize.y - 1.0));

	// inset for space between buttons
	ScrollBarSize.y -= 2.0;
	ScrollBarPosition.y += 1.0;

	if( fDoubleArrows)
	{
		// check if there is enough space
		if( ScrollBarSize.y > fMinimumKnobSize + 2 * ( 14.0 + 1.0))
		{
			// create arrows if they don't exist
			createArrowButton( BeScrollBarUp, BeScrollBarUpActive, BeScrollBarUpDisabled, F_DOUBLE_ARROW_UP, F_SCROLLBAR_SMALL_DECREASE);
			createArrowButton( BeScrollBarDown, BeScrollBarDownActive, BeScrollBarDownDisabled, F_DOUBLE_ARROW_DOWN, F_SCROLLBAR_SMALL_INCREASE);
	
			ScrollBarSize.y -= fArrows[ F_DOUBLE_ARROW_DOWN]->getSize().y + fArrows[ F_DOUBLE_ARROW_UP]->getSize().y;
	
			fArrows[ F_DOUBLE_ARROW_DOWN]->setPosition( getPosition() + ScrollBarPosition + fPoint( 0.0, 1.0));
	
			ScrollBarPosition.y += fArrows[ F_DOUBLE_ARROW_DOWN]->getSize().y;
	
			fArrows[ F_DOUBLE_ARROW_UP]->setPosition( getPosition() + ScrollBarPosition + fPoint( 0.0, ScrollBarSize.y - 1.0));
	
			// inset for space between buttons
			ScrollBarSize.y -= 2.0;
			ScrollBarPosition.y += 1.0;
		}
	}

	// inset for left and right border
//	ScrollBarSize.x -= 2.0;
//	ScrollBarPosition.x += 1.0;

	// set scrollbar frame
	fScrollBarFrame = BRect( ScrollBarPosition, ScrollBarPosition + ScrollBarSize - BPoint( 1.0, 1.0));

	recalculateKnobFrame();
}

void fBeVerticalScrollBar::recalculateKnobFrame( void)
{
	// get scroll bar infos
	scroll_bar_info scrollbarinfo;
	get_scroll_bar_info( &scrollbarinfo);

	double Total = fMaximum - fMinimum;

	// calculate knob position
	fPoint KnobSize;

	if( Total != 0.0 && (( abs( Total) - fVisible) != 0.0))
		KnobSize = fPoint( fScrollBarFrame.Width() + 1.0, ( fDirection * fVisible) / Total * ( fScrollBarFrame.Height() + 1.0));

	// if horizontal size is 0.0, all is visible
	if( KnobSize.y == 0.0)
	{
		fKnobFrame = BRect();
		return;
	}

	if( KnobSize.y < fMinimumKnobSize)
	{
		fUseMinimumKnobSize = true;
		KnobSize.y = fMinimumKnobSize;
	}
	else
	{
		if( scrollbarinfo.proportional == false)
			KnobSize.y = fMinimumKnobSize;
		else
			fUseMinimumKnobSize = false;
	}

	// calculate new position (on screen)
	// fKnobPosition * ( Height - KnobHeight) / ( fTotal - fVisible)
	double NewKnobPosition = ( fKnobPosition - fMinimum) * ( fScrollBarFrame.Height() + 1.0 - KnobSize.y) / ( Total - ( fDirection * fVisible));

	// position rrelativ to frame of scrollbar
	fPoint KnobPosition = fScrollBarFrame.LeftTop();
	KnobPosition.y += NewKnobPosition;

/*
	fprintf( stderr, "Showing %f to %f\n", fKnobPosition, fKnobPosition + fVisible);
	fprintf( stderr, "Showing %f to %f\n", NewKnobPosition, NewKnobPosition + fKnobFrame.Width() + 1.0);

	fprintf( stderr, "KnobSize: ");
	KnobSize.PrintToStream();

	fprintf( stderr, "KnobStart: ");
	KnobPosition.PrintToStream();
*/
	fKnobFrame = BRect( KnobPosition, KnobPosition + KnobSize - BPoint( 1.0, 1.0));
}

void fBeVerticalScrollBar::drawObject( const BRegion &ClippingRegion, bool FullUpdate) const
{
	#if FSCROLLBAR_DEBUG > 1
	fprintf( stderr, "fBeVerticalScrollBar::draw()\n");
	#endif

	if( getView() == NULL)
		return;
	
	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
	{
		#if FSCROLLBAR_DEBUG > 2
		fprintf( stderr, "fBeVerticalScrollBar::draw() Invalid rectangle\n");
		#endif
	
		return;
	}
	
	#if FSCROLLBAR_DEBUG > 2
	fprintf( stderr, "fBeVerticalScrollBar::draw() Drawing to: ");
	ClippingRegion->PrintToStream();
	#endif

	if( getView()->Window() == NULL)
		return;

	if( getView()->Window()->Lock() == false)
		return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	#if FSCROLLBAR_DEBUG >= 0
	ShowObjectLayout;
	#endif

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());
/*
	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRect( Frame, B_SOLID_LOW);
*/

	// frame background
	getView()->SetHighColor( 0x98, 0x98, 0x98);
	getView()->FillRect( Frame);

	// Scrollbar background	
	if( getEnabled() && getWindowActivated())
		getView()->SetHighColor( 0xc8, 0xc8, 0xc8);
	else
		getView()->SetHighColor( 0xf5, 0xf5, 0xf5);
	BRect ScrollBarFrame = fScrollBarFrame;
	ScrollBarFrame.OffsetBy( getPosition());
	ScrollBarFrame.InsetBy( 0.0, 1.0);
	getView()->FillRect( ScrollBarFrame);

	// top and left stripes
	if( getEnabled() && getWindowActivated())
	{
		getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
		getView()->StrokeLine( ScrollBarFrame.LeftBottom(), ScrollBarFrame.LeftTop());
		getView()->StrokeLine( ScrollBarFrame.RightTop());
		getView()->StrokeLine( ScrollBarFrame.LeftBottom() + BPoint( 1.0, 0.0) , ScrollBarFrame.LeftTop() + BPoint( 1.0, 1.0));
		getView()->StrokeLine( ScrollBarFrame.RightTop() + BPoint( 0.0, 1.0));
	}

	if( fKnobFrame.IsValid())
	{
		// draw knob
		BRect KnobFrame = fKnobFrame;
		KnobFrame.OffsetBy( getPosition());

		// knob background
		if( getEnabled() && getWindowActivated())
			getView()->FillRect( KnobFrame, B_SOLID_LOW);

		// left and right border
		getView()->SetHighColor( 0x98, 0x98, 0x98);
		getView()->StrokeLine( KnobFrame.LeftTop(), KnobFrame.RightTop());
		KnobFrame.top += 1.0;
	
		if( getEnabled() && getWindowActivated())
		{
			getView()->SetHighColor( 0x60, 0x60, 0x60);
			getView()->StrokeLine( KnobFrame.LeftBottom(), KnobFrame.RightBottom());
			KnobFrame.bottom -= 1.0;
		}
	
		// top and left lines
		getView()->SetHighColor( 0xff, 0xff, 0xff);
		getView()->StrokeLine( KnobFrame.RightTop(), KnobFrame.LeftTop());
		getView()->StrokeLine( KnobFrame.LeftBottom() - BPoint( 0.0, 2.0));
	
		// bottom and right lines
		getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
		getView()->StrokeLine( KnobFrame.LeftBottom(), KnobFrame.RightBottom());
		getView()->StrokeLine( KnobFrame.RightTop());
	
		scroll_bar_info scrollbarinfo;
		get_scroll_bar_info( &scrollbarinfo);
		
		if( fUseMinimumKnobSize == false)
		{
			float KnobHeight = KnobFrame.Height();
			if( !getEnabled() || !getWindowActivated())
				KnobHeight -= 1.0;
					
			BPoint MarkerPosition = KnobFrame.LeftTop() + BPoint( 0.0, KnobHeight / 2.0);

			// draw markers within knob
			switch( scrollbarinfo.knob)
			{
				case 1:
				{
					// There should be enough room for 2 markers for 1 to be visible
					if( KnobHeight > 2 * 7.0)
						drawType1KnobMarker( MarkerPosition);
		
					// There should be enough room for 4 markers for 3 to be visible
					if( KnobHeight > 4 * 7.0)
					{
						drawType1KnobMarker( MarkerPosition + BPoint( 0.0, 7.0));
						drawType1KnobMarker( MarkerPosition - BPoint( 0.0, 7.0));	
					}
				}
				break;
		
				case 2:
				{
					// There should be enough room for 2 markers for 1 to be visible
					if( KnobHeight > 2 * 5.0)
						drawType2KnobMarker( MarkerPosition);
		
					// There should be enough room for 4 markers for 3 to be visible
					if( KnobHeight > 4 * 5.0)
					{
						drawType2KnobMarker( MarkerPosition + BPoint( 0.0, 4.0));
						drawType2KnobMarker( MarkerPosition - BPoint( 0.0, 4.0));	
					}
				}
				break;
		
				default:
					break;
			}
		}
	}

	for( int32 Item = 0; Item < 4; Item++)
		if( fArrows[ Item])
			if( ClippingRegion.Intersects( fArrows[ Item]->getObjectFrame()))
			{
				getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));
				if( FullUpdate)
					fArrows[ Item]->setClippingRegion( ClippingRegion);
				fArrows[ Item]->drawObject( ClippingRegion, FullUpdate);
			}

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FSCROLLBAR_DEBUG > 1
	fprintf( stderr, "fBeVerticalScrollBar::draw() end\n");
	#endif
}
