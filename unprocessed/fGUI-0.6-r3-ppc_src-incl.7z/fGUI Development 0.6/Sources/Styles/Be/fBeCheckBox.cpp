// fBeCheckBox.cpp

#include "fBeCheckBox.h"

#include "fEvents.h"

#include "fFactory.h"

#if DEBUG > 0
#define FCHECKBOX_DEBUG DEBUG
#endif
 
//#undef FCHECKBOX_DEBUG
#define FCHECKBOX_DEBUG -1

ClassDefinition( fBeCheckBox, fCheckBox, "Be");

fBeCheckBox::fBeCheckBox( const char *CheckBoxText)
			: fCheckBox( CheckBoxText)
{
	#if FCHECKBOX_DEBUG > 0
	fprintf( stderr, "fBeCheckBox::fBeCheckBox()\n");
	#endif

	recalculateSizeLimits();

	#if FCHECKBOX_DEBUG > 0
	fprintf( stderr, "fBeCheckBox::fBeCheckBox() end\n");
	#endif
}

fBeCheckBox::~fBeCheckBox()
{
	#if FCHECKBOX_DEBUG > 0
	fprintf( stderr, "fBeCheckBox::~fBeCheckBox()\n");
	#endif  

	#if FCHECKBOX_DEBUG > 0
	fprintf( stderr, "fBeCheckBox::~fBeCheckBox() end\n");
	#endif  
}

void fBeCheckBox::invalidateCheckBox( void)
{
	// force redraw
	redraw( BRect( getPosition(), getPosition() + BPoint( getSize().y - 1.0, getSize().y - 1.0)));
}

void fBeCheckBox::recalculateSizeLimits( void)
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fBeCheckBox::recalculateSizeLimits()\n");
	#endif

	if( fFont == NULL)
	{
		setMinimumSize( fPoint( 10.0, 10.0));
		setPreferredSize( fPoint( 10.0, 10.0));
		setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

		return;
	}

	font_height fontheight;
	fFont->GetHeight( &fontheight);

	fPoint BoxSize = fPoint( fFont->StringWidth( fCheckBoxText), fontheight.ascent + fontheight.descent + fontheight.leading + 1.0);

	// Remember font size
	fTextSize = BoxSize;

	fPoint TextPosition = fPoint( fFont->StringWidth( "M") / 2.0, fontheight.ascent);

	// Move text to make room for the checkbox
	TextPosition.x += fTextSize.y * 1.25;

	// Remember font Position
	fTextPosition = TextPosition;

	// Add space for underline when focused...
	BoxSize += fPoint( 0.0, 3.0);

	// Add space for the checkbox
	BoxSize += fPoint( fTextSize.y * 1.25, 0.0);

	setMinimumSize( BoxSize);
	setPreferredSize( BoxSize);
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

//	TextPosition.PrintToStream( "TextPosition: ");
//	BoxSize.PrintToStream( "BoxSize: ");

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fBeCheckBox::recalculateSizeLimits() end\n");
	#endif
}

void fBeCheckBox::keyDown( const char *Input, int32 Length)
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fBeCheckBox::keyDown()\n");
	#endif

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
		setActive( !fActivated);

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fBeCheckBox::keyDown()\n");
	#endif
}

void fBeCheckBox::keyUp( const char */*Input*/, int32 /*Length*/)
{
}

void fBeCheckBox::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fBeCheckBox::draw()\n");
	#endif

	if( getView() == NULL)
		return;
	
	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;
		
	#if FCHECKBOX_DEBUG > 2
	fprintf( stderr, "fBeCheckBox::draw() Drawing to: ");
	Frame.PrintToStream();
	#endif

	if( getView()->Window() == NULL)
		return;

	if( getView()->Window()->Lock() == false)
		return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	#if FCHECKBOX_DEBUG >= 0
	ShowObjectLayout;
	#endif

	// set drawing environment
	getView()->SetDrawingMode( B_OP_COPY);
	getView()->SetPenSize( 1.0);

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRect( Frame, B_SOLID_LOW);

	// print text
	fPoint TextPosition = getPosition();
	TextPosition += fTextPosition;

//	TextPosition.x += ( getSize().x - fTextSize.x) / 2;
	TextPosition.y += ( getSize().y - fTextSize.y) / 2;

	if( getEnabled())
		getView()->SetHighColor( getFontColor());
	else
		getView()->SetHighColor( 0x78, 0x78, 0x78);

	getView()->SetFont( fFont);
	getView()->DrawString( fCheckBoxText, TextPosition);

	float CheckBoxOffset = 0.0;
	float CheckBoxSize = fTextSize.y + 1.0;
	BPoint CheckBoxLeftTop = Frame.LeftTop() + BPoint( 0.0, CheckBoxOffset);
	BPoint CheckBoxLeftBottom = CheckBoxLeftTop + BPoint( 0.0, CheckBoxSize);
	BPoint CheckBoxRightTop = CheckBoxLeftTop + BPoint( CheckBoxSize, 0.0);
	BPoint CheckBoxRightBottom = CheckBoxLeftTop + BPoint( CheckBoxSize, CheckBoxSize);

	fColor color = getBackgroundColor();
	
	float colorval = ( color.fRed + color.fGreen + color.fBlue) / 3;

	// upper left
	fColor color1 = fColor( colorval * 3 / 4,
						colorval * 3 / 4,
						colorval * 3 / 4);
	// lower right
	fColor color2 = fColor( 176 + colorval * 0.3125,
						176 + colorval * 0.3125,
						176 + colorval * 0.3125);
	// inner rectangle
	fColor color3 = fColor( colorval * 0.5625,
						colorval * 0.5625,
						colorval * 0.5625);
	// highlight
	fColor color4 = fColor( colorval / 2,
						colorval / 2,
						colorval / 2);

	// inner space
	getView()->SetHighColor( 0xff, 0xff, 0xff);
	getView()->FillRect( BRect( CheckBoxLeftTop + BPoint( 2.0, 2.0),
						CheckBoxRightBottom - BPoint( 2.0, 2.0)));

	// inner rectangle
	if( getEnabled())
		getView()->SetHighColor( color3);
	else
		getView()->SetHighColor( 0xc0, 0xc0, 0xc0);
	
	getView()->StrokeRect( BRect( CheckBoxLeftTop + BPoint( 1.0, 1.0),
						CheckBoxRightBottom - BPoint( 1.0, 1.0)));

	if( getEnabled())
	{
		// outer rectangle
		if( fHighlighted)
		{
			getView()->SetHighColor( color4);
			getView()->StrokeRect( BRect( CheckBoxLeftTop, CheckBoxRightBottom));
		}
		else
		{
			// lower right
			getView()->SetHighColor( color2);
			getView()->StrokeLine( CheckBoxRightTop, CheckBoxRightBottom);
			getView()->StrokeLine( CheckBoxLeftBottom);
	
			// upper left
			getView()->SetHighColor( color1);
			getView()->StrokeLine( CheckBoxLeftTop);
			getView()->StrokeLine( CheckBoxRightTop);		
		}
	}

	// draw the cross
	if( fActivated)
	{
		if( getEnabled())
			getView()->SetHighColor( keyboard_navigation_color());
		else
			getView()->SetHighColor( 0x98, 0x98, 0xff);

		getView()->StrokeLine( CheckBoxLeftTop + BPoint( 3.0, 3.0),
								CheckBoxRightBottom - BPoint( 3.0, 3.0));

		getView()->StrokeLine( CheckBoxLeftTop + BPoint( 3.0, 4.0),
								CheckBoxRightBottom - BPoint( 4.0, 3.0));

		getView()->StrokeLine( CheckBoxLeftTop + BPoint( 4.0, 3.0),
								CheckBoxRightBottom - BPoint( 3.0, 4.0));


		getView()->StrokeLine( CheckBoxRightTop + BPoint( -3.0, 3.0),
								CheckBoxLeftBottom - BPoint( -3.0, 3.0));

		getView()->StrokeLine( CheckBoxRightTop + BPoint( -3.0, 4.0),
								CheckBoxLeftBottom - BPoint( -4.0, 3.0));

		getView()->StrokeLine( CheckBoxRightTop + BPoint( -4.0, 3.0),
								CheckBoxLeftBottom - BPoint( -3.0, 4.0));
	}

	if( getFocus())
	{
			font_height fontheight;
			fFont->GetHeight( &fontheight);

			float FontWidth = fFont->StringWidth( fCheckBoxText);

			getView()->SetHighColor( keyboard_navigation_color());
			getView()->StrokeLine( TextPosition + fPoint( 0.0, fontheight.descent),
										TextPosition + fPoint( FontWidth, fontheight.descent));

			getView()->SetHighColor( 0xff, 0xff, 0xff);
			getView()->StrokeLine( TextPosition + fPoint( 0.0, fontheight.descent + 1.0),
										TextPosition + fPoint( FontWidth, fontheight.descent + 1.0));
	}

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fBeCheckBox::draw() end\n");
	#endif
}