// fBeHorizontalScrollBar.h

#ifndef fBeHorizontalScrollBar_h
#define fBeHorizontalScrollBar_h

#include "fHorizontalScrollBar.h"

#pragma export on

class fBeHorizontalScrollBar : public fHorizontalScrollBar
{
	private:

		fBeHorizontalScrollBar( const fBeHorizontalScrollBar &CopyObject);
		fBeHorizontalScrollBar &operator=( const fBeHorizontalScrollBar &CopyObject);
	
		ClassDeclaration( fBeHorizontalScrollBar);

	protected:


		virtual void recalculateKnobFrame( void);

		virtual void createArrowButton( const void *PassiveData, const void *ActiveData,
										const void *DisabledData, int32 Which, int32 Action);

		virtual void drawType1KnobMarker( BPoint Position) const;
		virtual void drawType2KnobMarker( BPoint Position) const;

		virtual void recalculateSizeLimits( void);

	public:

		fBeHorizontalScrollBar( void);
		virtual ~fBeHorizontalScrollBar( void);

		virtual void setSize( const fPoint &NewSize);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif