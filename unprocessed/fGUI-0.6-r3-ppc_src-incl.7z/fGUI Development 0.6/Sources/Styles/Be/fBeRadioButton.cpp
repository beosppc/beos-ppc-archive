// fBeRadioButton.cpp

#include "fBeRadioButton.h"

#include "fEventRoute.h"

#include "fFactory.h"

#if DEBUG > 0
#define FRADIOBUTTON_DEBUG DEBUG
#endif
 
//#undef FRADIOBUTTON_DEBUG
#define FRADIOBUTTON_DEBUG -1

ClassDefinition( fBeRadioButton, fRadioButton, "Be");

fBeRadioButton::fBeRadioButton( const char *RadioButtonText)
			: fRadioButton( RadioButtonText)
{
	#if FRADIOBUTTON_DEBUG > 0
	fprintf( stderr, "fBeRadioButton::fBeRadioButton()\n");
	#endif

	recalculateSizeLimits();

	#if FRADIOBUTTON_DEBUG > 0
	fprintf( stderr, "fBeRadioButton::fBeRadioButton() end\n");
	#endif
}

fBeRadioButton::~fBeRadioButton()
{
	#if FRADIOBUTTON_DEBUG > 0
	fprintf( stderr, "fBeRadioButton::~fBeRadioButton()\n");
	#endif  

	#if FRADIOBUTTON_DEBUG > 0
	fprintf( stderr, "fBeRadioButton::~fBeRadioButton() end\n");
	#endif  
}

void fBeRadioButton::invalidateRadioButton( void)
{
	// force redraw
	redraw( BRect( getPosition(), getPosition() + BPoint( getSize().y - 1.0, getSize().y - 1.0)));
}

void fBeRadioButton::recalculateSizeLimits( void)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fBeRadioButton::recalculateSizeLimits()\n");
	#endif

	if( fFont == NULL)
	{
		setMinimumSize( fPoint( 10.0, 10.0));
		setPreferredSize( fPoint( 10.0, 10.0));
		setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

		return;
	}

	font_height fontheight;
	fFont->GetHeight( &fontheight);

	fPoint BoxSize = fPoint( fFont->StringWidth( fRadioButtonText), fontheight.ascent + fontheight.descent + fontheight.leading + 1.0);

	// Remember text size
	fTextSize = BoxSize;

	// Move text to make room for half an "Em" on both sides
	fPoint TextPosition = fPoint( fFont->StringWidth( "M") / 2.0, fontheight.ascent);

	// Move text to make room for the checkbox
	TextPosition.x += fTextSize.y * 1.25;

	// Remember text Position
	fTextPosition = TextPosition;

	// Add space for underline when focused...
	BoxSize += fPoint( 0.0, 3.0);

	// Add space for the checkbox
	BoxSize += fPoint( fTextSize.y * 1.25, 0.0);

	setMinimumSize( BoxSize);
	setPreferredSize( BoxSize);
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fBeRadioButton::recalculateSizeLimits() end\n");
	#endif
}

void fBeRadioButton::keyDown( const char *Input, int32 Length)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fBeRadioButton::keyDown()\n");
	#endif

	if( getEnabled() == false)
		return;

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
		processEvent( F_RADIOBUTTON_ACTIVATED);

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fBeRadioButton::keyDown()\n");
	#endif
}

void fBeRadioButton::keyUp( const char */*Input*/, int32 /*Length*/)
{
}

void fBeRadioButton::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fBeRadioButton::draw()\n");
	#endif

	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;
		
	#if FRADIOBUTTON_DEBUG > 2
	fprintf( stderr, "fBeRadioButton::draw() Drawing to: ");
	Frame.PrintToStream();
	#endif

	if( getView()->Window() == NULL)
		return;

	if( getView()->Window()->Lock() == false)
		return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	#if FRADIOBUTTON_DEBUG >= 0
	ShowObjectLayout;
	#endif

	// set drawing environment
	getView()->SetDrawingMode( B_OP_COPY);
	getView()->SetPenSize( 1.0);

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRect( Frame, B_SOLID_LOW);

	// print text
	fPoint TextPosition = getPosition();
	TextPosition += fTextPosition;

	TextPosition.y += ( getSize().y - fTextSize.y) / 2;

	if( getEnabled())
		getView()->SetHighColor( getFontColor());
	else
		getView()->SetHighColor( 0x78, 0x78, 0x78);

	getView()->SetFont( fFont);
	getView()->DrawString( fRadioButtonText, TextPosition);

	float RadioButtonSize = fTextSize.y + 1.0;
	BPoint RadioButtonLeftTop = Frame.LeftTop() + BPoint( 0.0, 0.0);
	BPoint RadioButtonRightBottom = RadioButtonLeftTop + BPoint( RadioButtonSize, RadioButtonSize);

	fColor color = getBackgroundColor();
	
	float colorval = ( color.fRed + color.fGreen + color.fBlue) / 3;

	// upper left
	rgb_color color1 = fColor( colorval * 3 / 4,
						colorval * 3 / 4,
						colorval * 3 / 4);
	// lower right
	rgb_color color2 = fColor( 176 + colorval * 0.3125,
						176 + colorval * 0.3125,
						176 + colorval * 0.3125);
	// inner circle
	rgb_color color3 = fColor( colorval * 0.5625,
						colorval * 0.5625,
						colorval * 0.5625);
	// highlight
	rgb_color color4 = fColor( colorval / 2,
						colorval / 2,
						colorval / 2);

	// outer circle
	if( fHighlighted)
	{
		getView()->SetHighColor( color4);
		getView()->StrokeEllipse( BRect( RadioButtonLeftTop, RadioButtonRightBottom));
	}
	else
	{
		// upper left
		getView()->SetHighColor( color1);
		getView()->StrokeArc( BRect( RadioButtonLeftTop, RadioButtonRightBottom), 45.0, 180.0);
	
		if( getEnabled())
		{
			// lower right
			getView()->SetHighColor( color2);
			getView()->StrokeArc( BRect( RadioButtonLeftTop, RadioButtonRightBottom), 225.0, 180.0);
		}
	}

	// inner circle
	getView()->SetHighColor( color3);
	getView()->StrokeEllipse( BRect( RadioButtonLeftTop + BPoint( 1.0, 1.0),
									RadioButtonRightBottom - BPoint( 1.0, 1.0)));

	if( fActivated)
	{
		// inner space
		// outer circle, upper left
		if( getEnabled())
			getView()->SetHighColor( 0x0, 0x0, 0x9a);
		else
			getView()->SetHighColor( 0x66, 0x66, 0x9a);
		
		getView()->StrokeArc( BRect( RadioButtonLeftTop + BPoint( 2.0, 2.0),
									RadioButtonRightBottom - BPoint( 2.0, 2.0)), 30.0, 210.0);
		// inner space
		if( getEnabled())
			getView()->SetHighColor( 0x0, 0x0, 0xe5);
		else
			getView()->SetHighColor( 0x66, 0x66, 0xe5);
	
		getView()->FillEllipse( BRect( RadioButtonLeftTop + BPoint( 3.0, 3.0),
										RadioButtonRightBottom - BPoint( 3.0, 3.0)));

		// outer circle, lower right (2 times)
		if( getEnabled())
			getView()->SetHighColor( 0x0, 0x0, 0x9a);
		else
			getView()->SetHighColor( 0x66, 0x66, 0x9a);
	
		getView()->StrokeArc( BRect( RadioButtonLeftTop + BPoint( 2.0, 2.0),
									RadioButtonRightBottom - BPoint( 2.0, 2.0)), 240.0, 150.0);
		getView()->StrokeArc( BRect( RadioButtonLeftTop + BPoint( 3.0, 3.0),
									RadioButtonRightBottom - BPoint( 3.0, 3.0)), 240.0, 150.0);

		// white reflexion
		getView()->SetHighColor( 0xff, 0xff, 0xff);
		getView()->StrokeArc( BRect( RadioButtonLeftTop + BPoint( 3.0, 3.0),
									RadioButtonRightBottom - BPoint( 3.0, 3.0)), 120.0, 30.0);
		getView()->StrokeArc( BRect( RadioButtonLeftTop + BPoint( 4.0, 4.0),
									RadioButtonRightBottom - BPoint( 4.0, 4.0)), 120.0, 30.0);
	}
	else
	{
		// white inner circle
		getView()->SetHighColor( 0xff, 0xff, 0xff);
		getView()->FillEllipse( BRect( RadioButtonLeftTop + BPoint( 2.0, 2.0),
										RadioButtonRightBottom - BPoint( 2.0, 2.0)));
	}

	if( getFocus())
	{
		font_height fontheight;
		fFont->GetHeight( &fontheight);

		float FontWidth = fFont->StringWidth( fRadioButtonText);

		getView()->SetHighColor( keyboard_navigation_color());
		getView()->StrokeLine( TextPosition + fPoint( 0.0, fontheight.descent),
									TextPosition + fPoint( FontWidth, fontheight.descent));

		getView()->SetHighColor( 0xff, 0xff, 0xff);
		getView()->StrokeLine( TextPosition + fPoint( 0.0, fontheight.descent + 1.0),
										TextPosition + fPoint( FontWidth, fontheight.descent + 1.0));
	}

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fBeRadioButton::draw() end\n");
	#endif
}