// fBeHorizontalScrollBar.cpp

#include "fBeHorizontalScrollBar.h"

#include "fEventRoute.h"

#include "fFactory.h"

#include "fScrollBarButton.h"

#include "BeScrollBarLeft.h"
#include "BeScrollBarLeftActive.h"
#include "BeScrollBarLeftDisabled.h"
#include "BeScrollBarRight.h"
#include "BeScrollBarRightActive.h"
#include "BeScrollBarRightDisabled.h"

#if DEBUG > 0
#define FSCROLLBAR_DEBUG DEBUG
#endif
 
//#undef FSCROLLBAR_DEBUG
#define FSCROLLBAR_DEBUG -1

ClassDefinition( fBeHorizontalScrollBar, fHorizontalScrollBar, "Be");

fBeHorizontalScrollBar::fBeHorizontalScrollBar( void)
{
	recalculateSizeLimits();
}

fBeHorizontalScrollBar::~fBeHorizontalScrollBar( void)
{
}

void fBeHorizontalScrollBar::recalculateSizeLimits( void)
{
	fPoint Size = fPoint( 0.0, B_H_SCROLL_BAR_HEIGHT + 1.0);

	// there must be enough room for at least two arrows
	Size.x += 2 * ( 14.0 + 1.0) + 1.0;

	// then there must be room for the knob itself	
	scroll_bar_info scrollbarinfo;
	get_scroll_bar_info( &scrollbarinfo);

	fMinimumKnobSize	= scrollbarinfo.min_knob_size;
	fDoubleArrows		= scrollbarinfo.double_arrows;

	Size.x += fMinimumKnobSize;

	setMinimumSize( Size);
	setPreferredSize( Size);

	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, B_H_SCROLL_BAR_HEIGHT + 1.0));
}

void fBeHorizontalScrollBar::createArrowButton( const void *PassiveData, const void *ActiveData,
											const void *DisabledData, int32 Which, int32 Action)
{
	if( fArrows[ Which])
		return;

	BRect bounds = BRect( 0.000000, 0.000000, 13.000000, 12.000000);

	BBitmap *bitmap1 = new BBitmap( bounds, B_RGB_32_BIT);
	bitmap1->SetBits( PassiveData, 546, 0, B_RGB_32_BIT);

	BBitmap *bitmap2 = new BBitmap( bounds, B_RGB_32_BIT);
	bitmap2->SetBits( ActiveData, 546, 0, B_RGB_32_BIT);

	BBitmap *bitmap3 = new BBitmap( bounds, B_RGB_32_BIT);
	bitmap3->SetBits( DisabledData, 546, 0, B_RGB_32_BIT);

	fArrows[ Which] = new fScrollBarButton( Action, this, bitmap1, bitmap2, bitmap3);

	fArrows[ Which]->setSize( fArrows[ Which]->getPreferredSize());
	
	if( getView())
		fArrows[ Which]->setView( getView());

	if( fParentWindow)
		fArrows[ Which]->attachedToWindow( fParentWindow);
		
	if( getEnabled() == false)
		fArrows[ Which]->setEnabled( false);

	// create eventroute
	fEventRoute *route = new fEventRoute( F_PRIMARY_MOUSE_DOWN);
	route->setAction( Action);
	route->setTargetPointer( this);
	fArrows[ Which]->addEventRoute( route);
}

void fBeHorizontalScrollBar::drawType1KnobMarker( BPoint Position) const
{
	Position += BPoint( -2.0, 4.0);

	BRect Frame( Position, Position + BPoint( 4.0, 4.0));

	// top and left lines
	getView()->SetHighColor( 0xff, 0xff, 0xff);
	getView()->StrokeLine( Frame.RightTop(), Frame.LeftTop());
	getView()->StrokeLine( Frame.LeftBottom());

	// bottom and right lines
	if( getEnabled())
		getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
	else
		getView()->SetHighColor( 0xc8, 0xc8, 0xc8);
	getView()->StrokeLine( Frame.RightBottom());
	getView()->StrokeLine( Frame.RightTop());
}

void fBeHorizontalScrollBar::drawType2KnobMarker( BPoint Position) const
{
	Position += BPoint( -1.0, 3.0);
	BRect Frame( Position, Position + BPoint( 2.0, 6.0));

	// top and left lines
	getView()->SetHighColor( 0xff, 0xff, 0xff);
	getView()->StrokeLine( Frame.LeftBottom(), Frame.LeftTop());
	getView()->StrokeLine( Frame.LeftTop(), Frame.RightTop() - BPoint( 1.0, 0.0));

	// bottom and right lines
	if( getEnabled())
		getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
	else
		getView()->SetHighColor( 0xc8, 0xc8, 0xc8);
	getView()->StrokeLine( Frame.RightTop(), Frame.RightBottom());
	getView()->StrokeLine( Frame.LeftBottom() + BPoint( 1.0, 0.0));
}

void fBeHorizontalScrollBar::setSize( const fPoint &Size)
{
	fObject::setSize( Size);

	// make up for the borders
	fPoint ScrollBarPosition( getHorizontalBorder(), getVerticalBorder());

	fPoint ScrollBarSize = Size;

	ScrollBarSize -= ScrollBarPosition;
	ScrollBarSize -= ScrollBarPosition;

	// scrollbar frame
	// inset for frame
	ScrollBarSize.y -= 2.0;
	ScrollBarPosition.y += 1.0;

	// get scroll bar infos
	scroll_bar_info scrollbarinfo;
	get_scroll_bar_info( &scrollbarinfo);

	// we need two arrows in any case, create them if they don't exist
	createArrowButton( BeScrollBarLeft, BeScrollBarLeftActive, BeScrollBarLeftDisabled, F_SINGLE_ARROW_LEFT, F_SCROLLBAR_SMALL_DECREASE);
	createArrowButton( BeScrollBarRight, BeScrollBarRightActive, BeScrollBarRightDisabled, F_SINGLE_ARROW_RIGHT, F_SCROLLBAR_SMALL_INCREASE);

	ScrollBarSize.x -= fArrows[ F_SINGLE_ARROW_LEFT]->getSize().x + fArrows[ F_SINGLE_ARROW_RIGHT]->getSize().x;

	fArrows[ F_SINGLE_ARROW_LEFT]->setPosition( getPosition() + ScrollBarPosition + fPoint( 1.0, 0.0));

	ScrollBarPosition.x += fArrows[ F_SINGLE_ARROW_LEFT]->getSize().x;

	fArrows[ F_SINGLE_ARROW_RIGHT]->setPosition( getPosition() + ScrollBarPosition + fPoint( ScrollBarSize.x - 1.0, 0.0));

	// inset for space between buttons
	ScrollBarSize.x -= 2.0;
	ScrollBarPosition.x += 1.0;

	if( fDoubleArrows)
	{
		// check if there is enough space
		if( ScrollBarSize.x > fMinimumKnobSize + 2 * ( 14.0 + 1.0))
		{
			// create arrows if they don't exist
			createArrowButton( BeScrollBarLeft, BeScrollBarLeftActive, BeScrollBarLeftDisabled, F_DOUBLE_ARROW_LEFT, F_SCROLLBAR_SMALL_DECREASE);
			createArrowButton( BeScrollBarRight, BeScrollBarRightActive, BeScrollBarRightDisabled, F_DOUBLE_ARROW_RIGHT, F_SCROLLBAR_SMALL_INCREASE);
	
			ScrollBarSize.x -= fArrows[ F_DOUBLE_ARROW_RIGHT]->getSize().x + fArrows[ F_DOUBLE_ARROW_LEFT]->getSize().x;
	
			fArrows[ F_DOUBLE_ARROW_RIGHT]->setPosition( getPosition() + ScrollBarPosition + fPoint( 1.0, 0.0));
	
			ScrollBarPosition.x += fArrows[ F_DOUBLE_ARROW_RIGHT]->getSize().x;
	
			fArrows[ F_DOUBLE_ARROW_LEFT]->setPosition( getPosition() + ScrollBarPosition + fPoint( ScrollBarSize.x - 1.0, 0.0));
	
			// inset for space between buttons
			ScrollBarSize.x -= 2.0;
			ScrollBarPosition.x += 1.0;
		}
	}

	// set scrollbar frame
	fScrollBarFrame = BRect( ScrollBarPosition, ScrollBarPosition + ScrollBarSize - BPoint( 1.0, 1.0));

	recalculateKnobFrame();
}

void fBeHorizontalScrollBar::recalculateKnobFrame( void)
{
//	fprintf( stderr, "fBeHorizontalScrollBar::recalculateKnobFrame() Width: %f\n", fScrollBarFrame.Width());

	// get scroll bar infos
	scroll_bar_info scrollbarinfo;
	get_scroll_bar_info( &scrollbarinfo);

//	fprintf( stderr, "fBeHorizontalScrollBar::recalculateKnobFrame() fKnobPosition: %f, fMinimum: %f, fMaximum: %f, fVisible: %f\n", fKnobPosition, fMinimum, fMaximum, fVisible);

	double Total = fMaximum - fMinimum;

	// calculate knob position
	fPoint KnobSize;

	if( Total != 0.0 && (( abs( Total) - fVisible) != 0.0))
		KnobSize = fPoint(( fDirection * fVisible) / Total * ( fScrollBarFrame.Width() + 1.0), fScrollBarFrame.Height() + 1.0);

	// if horizontal size is 0.0, all is visible
	if( KnobSize.x == 0.0)
	{
		fKnobFrame = BRect();
		return;
	}

	if( KnobSize.x < fMinimumKnobSize)
	{
		fUseMinimumKnobSize = true;
		KnobSize.x = fMinimumKnobSize;
	}
	else
	{
		if( scrollbarinfo.proportional == false)
			KnobSize.x = fMinimumKnobSize;
		else
			fUseMinimumKnobSize = false;
	}

	// calculate new position (on screen)
	// fKnobPosition * ( Width - KnobWidth) / ( Total - fVisible)
	double NewKnobPosition = ( fKnobPosition - fMinimum) * ( fScrollBarFrame.Width() + 1.0 - KnobSize.x) / ( Total - ( fDirection * fVisible));

//	fprintf( stderr, "NewKnobPosition: %f, ScrollBarSize: %f\n", NewKnobPosition, fScrollBarFrame.Width());

	// position relativ to frame of scrollbar
	fPoint KnobPosition = fScrollBarFrame.LeftTop();
	KnobPosition.x += NewKnobPosition;

/*
	fprintf( stderr, "Showing %f to %f\n", fKnobPosition, fKnobPosition + ( fDirection * fVisible));

	fprintf( stderr, "Showing %f to %f\n", NewKnobPosition, NewKnobPosition + fKnobFrame.Width() + 1.0);

	fprintf( stderr, "KnobSize: ");
	KnobSize.PrintToStream();

	fprintf( stderr, "KnobStart: ");
	KnobPosition.PrintToStream();
*/
	fKnobFrame = BRect( KnobPosition, KnobPosition + KnobSize - BPoint( 1.0, 1.0));
}

void fBeHorizontalScrollBar::drawObject( const BRegion &ClippingRegion, bool FullUpdate) const
{
	#if FSCROLLBAR_DEBUG > 1
	fprintf( stderr, "fBeHorizontalScrollBar::draw()\n");
	#endif

	if( getView() == NULL)
		return;
	
	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;
		
	#if FSCROLLBAR_DEBUG > 2
	fprintf( stderr, "fBeHorizontalScrollBar::draw() Drawing to: ");
	Frame.PrintToStream();
	#endif

	if( getView()->Window() == NULL)
		return;

	if( getView()->Window()->Lock() == false)
		return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	#if FSCROLLBAR_DEBUG >= 0
	ShowObjectLayout;
	#endif

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());
/*
	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRect( Frame, B_SOLID_LOW);
*/
	BRegion Region;

	// SrollBar frame
	BRect ScrollBarFrame = fScrollBarFrame;
	ScrollBarFrame.OffsetBy( getPosition());
	ScrollBarFrame.InsetBy( 1.0, 0.0);

	// knob frame
	BRect KnobFrame = fKnobFrame;
	KnobFrame.OffsetBy( getPosition());

	// frame background
	getView()->SetHighColor( 0x98, 0x98, 0x98);
	Region.Set( Frame);
	getView()->FillRect( Frame);

	// Scrollbar background	
	if( getEnabled() && getWindowActivated())
		getView()->SetHighColor( 0xc8, 0xc8, 0xc8);
	else
		getView()->SetHighColor( 0xf5, 0xf5, 0xf5);
	Region.Set( ScrollBarFrame);
	getView()->FillRect( ScrollBarFrame);

	// top and left stripes
	if( getEnabled() && getWindowActivated())
	{
		getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
		getView()->StrokeLine( ScrollBarFrame.LeftBottom(), ScrollBarFrame.LeftTop());
		getView()->StrokeLine( ScrollBarFrame.RightTop());
		getView()->StrokeLine( ScrollBarFrame.LeftBottom() + BPoint( 1.0, 0.0) , ScrollBarFrame.LeftTop() + BPoint( 1.0, 1.0));
		getView()->StrokeLine( ScrollBarFrame.RightTop() + BPoint( 0.0, 1.0));
	}

	if( fKnobFrame.IsValid())
	{
		// draw knob
		// knob background
		if( getEnabled() && getWindowActivated())
			getView()->FillRect( KnobFrame, B_SOLID_LOW);

		// left and right border
		getView()->SetHighColor( 0x98, 0x98, 0x98);
		getView()->StrokeLine( KnobFrame.LeftBottom(), KnobFrame.LeftTop());
		KnobFrame.left += 1.0;
	
		if( getEnabled() && getWindowActivated())
		{
			getView()->SetHighColor( 0x60, 0x60, 0x60);
			getView()->StrokeLine( KnobFrame.RightBottom(), KnobFrame.RightTop());
			KnobFrame.right -= 1.0;
		}
	
		// top and left lines
		getView()->SetHighColor( 0xff, 0xff, 0xff);
		getView()->StrokeLine( KnobFrame.RightTop(), KnobFrame.LeftTop());
		getView()->StrokeLine( KnobFrame.LeftBottom() - BPoint( 0.0, 2.0));
	
		// bottom and right lines
		getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
		getView()->StrokeLine( KnobFrame.LeftBottom(), KnobFrame.RightBottom());
		getView()->StrokeLine( KnobFrame.RightTop());
	
		scroll_bar_info scrollbarinfo;
		get_scroll_bar_info( &scrollbarinfo);
		
		if( fUseMinimumKnobSize == false)
		{
			float KnobWidth = KnobFrame.Width();
			if( !getEnabled() || !getWindowActivated())
				KnobWidth -= 1.0;
					
			BPoint MarkerPosition = KnobFrame.LeftTop() + BPoint( KnobWidth / 2.0, 0.0);

			// draw markers within knob
			switch( scrollbarinfo.knob)
			{
				case 1:
				{
					// There should be enough room for 2 markers for 1 to be visible
					if( KnobWidth > 2 * 7.0)
						drawType1KnobMarker( MarkerPosition);
		
					// There should be enough room for 4 markers for 3 to be visible
					if( KnobWidth > 4 * 7.0)
					{
						drawType1KnobMarker( MarkerPosition + BPoint( 7.0, 0.0));
						drawType1KnobMarker( MarkerPosition - BPoint( 7.0, 0.0));	
					}
				}
				break;
		
				case 2:
				{
					// There should be enough room for 2 markers for 1 to be visible
					if( KnobWidth > 2 * 5.0)
						drawType2KnobMarker( MarkerPosition);
		
					// There should be enough room for 4 markers for 3 to be visible
					if( KnobWidth > 4 * 5.0)
					{
						drawType2KnobMarker( MarkerPosition + BPoint( 4.0, 0.0));
						drawType2KnobMarker( MarkerPosition - BPoint( 4.0, 0.0));	
					}
				}
				break;
		
				default:
					break;
			}
		}
	}

	for( int32 Item = 0; Item < 4; Item++)
		if( fArrows[ Item])
			if( ClippingRegion.Intersects( fArrows[ Item]->getObjectFrame()))
			{
				getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));
				if( FullUpdate)
					fArrows[ Item]->setClippingRegion( ClippingRegion);
				fArrows[ Item]->drawObject( ClippingRegion, FullUpdate);
			}

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FSCROLLBAR_DEBUG > 1
	fprintf( stderr, "fBeHorizontalScrollBar::draw() end\n");
	#endif
}
