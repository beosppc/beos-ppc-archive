// fAddOn.h

#ifndef fAddOn_h
#define fAddOn_h

#pragma export on

extern "C" __declspec(dllexport) void Fred( void);
 
#pragma export off

#endif