// fBeCheckBox.h

#ifndef fBeCheckBox_h
#define fBeCheckBox_h

#include "fCheckBox.h"
#include "fEventRoute.h"

#pragma export on

class fBeCheckBox : public fCheckBox
{
	private :

		fBeCheckBox( const fBeCheckBox &CopyObject);
		fBeCheckBox &operator=( const fBeCheckBox &CopyObject);
	
		ClassDeclaration( fBeCheckBox);

	protected:

		virtual void recalculateSizeLimits( void);
		virtual void invalidateCheckBox( void);

	public :

		fBeCheckBox( const char *CheckBoxText = NULL);
		virtual ~fBeCheckBox( void);

		virtual void keyDown( const char *Input, int32 Length);
		virtual void keyUp( const char *Input, int32 Length);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
