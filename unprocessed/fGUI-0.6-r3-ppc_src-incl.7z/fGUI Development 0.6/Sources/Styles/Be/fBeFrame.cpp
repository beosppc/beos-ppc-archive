// fBeFrame.cpp

#include "fBeFrame.h"
#include "fFactory.h"

ClassDefinition( fBeFrame, fFrame, "Be");

fBeFrame::fBeFrame( const char *Label)
			: fFrame( Label)
{
	setFont( be_bold_font);

	setText( Label);
}

fBeFrame::~fBeFrame( void)
{
}

void fBeFrame::recalculateSizeLimits( void)
{
//	fprintf( stderr, "fBeFrame::recalculateSizeLimits()\n");

	fLeftInset		= 6.0;
	fTopInset		= 7.0;
	fRightInset		= 6.0;
	fBottomInset	= 5.0;

	fMinimumFrameSize = fPoint( fLeftInset + fRightInset, fTopInset + fBottomInset);

	if( fLabel)
	{
		font_height fontheight;
		fFont->GetHeight( &fontheight);
	
		float FontWidth = fFont->StringWidth( fLabel);
		float FontHeight = fontheight.ascent + fontheight.descent + fontheight.leading;
	
		fTextSize = fPoint( FontWidth, FontHeight);
		fTextPosition = fPoint( 10.0, fontheight.ascent);

		fPoint Size( FontWidth, FontHeight);
	
		Size += fPoint( 2 * 10.0, 10.0);

		fTopInset = FontHeight + 3.0;

		fMinimumFrameSize = fPoint( FontWidth + 2 * 10.0, FontHeight + 8.0);
//		fMinimumFrameSize.printToStream( "fBeFrame::recalculateSizeLimits() fMinimumFrameSize: ");
	}

	fPoint MinimumSize		= fMinimumFrameSize;
	fPoint PreferredSize	= fMinimumFrameSize;
	fPoint MaximumSize		= fMinimumFrameSize;

	if( fSomeObject)
	{
		fPoint ObjectMinimumSize;
		fPoint ObjectPreferredSize	= fSomeObject->getPreferredSize();
		fPoint ObjectMaximumSize;
	
		if( fSomeObject->getVerticalWeight() == 0.0)
		{
			ObjectMinimumSize.y = fSomeObject->getPreferredSize().y;
			ObjectMaximumSize.y = fSomeObject->getPreferredSize().y;
		}
		else
		{
			ObjectMinimumSize.y = fSomeObject->getMinimumSize().y;
			ObjectMaximumSize.y = fSomeObject->getMaximumSize().y;
		}

		if( fSomeObject->getHorizontalWeight() == 0.0)
		{
			ObjectMinimumSize.x = fSomeObject->getPreferredSize().x;
			ObjectMaximumSize.x = fSomeObject->getPreferredSize().x;
		}
		else
		{
			ObjectMinimumSize.x = fSomeObject->getMinimumSize().x;
			ObjectMaximumSize.x = fSomeObject->getMaximumSize().x;
		}

		if( ObjectMaximumSize.x < fMinimumFrameSize.x)
			MaximumSize.x = fMinimumFrameSize.x;
		else
			MaximumSize.x = ObjectMaximumSize.x + fLeftInset + fRightInset;
		MaximumSize.y = ObjectMaximumSize.y + fMinimumFrameSize.y;

		if( ObjectMinimumSize.x < fMinimumFrameSize.x)
			MinimumSize.x = fMinimumFrameSize.x;
		else
			MinimumSize.x = ObjectMinimumSize.x + fLeftInset + fRightInset;
		MinimumSize.y = ObjectMinimumSize.y + fMinimumFrameSize.y;

		if( ObjectPreferredSize.x < fMinimumFrameSize.x)
			PreferredSize.x = fMinimumFrameSize.x;
		else
			PreferredSize.x = ObjectPreferredSize.x + fLeftInset + fRightInset;
		PreferredSize.y = ObjectPreferredSize.y + fMinimumFrameSize.y;
	}

	setMinimumSize( MinimumSize);
	setPreferredSize( PreferredSize);
	setMaximumSize( MaximumSize);
/*
	MinimumSize.printToStream( "New minimum size: ");
	PreferredSize.printToStream( "New preferred size: ");
	MaximumSize.printToStream( "New maximum size: ");

	fprintf( stderr, "fBeFrame::recalculateSizeLimits() end\n");
*/
}

void fBeFrame::setFont( const BFont *Font)
{
	fFrame::setFont( Font);
	recalculateSizeLimits();
}

void fBeFrame::setText( const char *Label)
{
	fFrame::setText( Label);
	recalculateSizeLimits();
}

void fBeFrame::setSize( const fPoint &Size)
{
//	Size.printToStream( "fBeFrame::setSize() New size: ");

	fObject::setSize( Size);

	if( fSomeObject == NULL)
		return;

	fPoint Borders( getHorizontalBorder(), getVerticalBorder());

	fPoint NewSize = Size;

	NewSize -= Borders;
	NewSize -= Borders;

	NewSize -= fPoint( fLeftInset, fTopInset);
	NewSize -= fPoint( fRightInset, fBottomInset);

	fPoint ObjectMaximumSize;

	if( fSomeObject->getVerticalWeight() == 0.0)
		ObjectMaximumSize.y = fSomeObject->getPreferredSize().y;
	else
		ObjectMaximumSize.y = fSomeObject->getMaximumSize().y;

	if( fSomeObject->getHorizontalWeight() == 0.0)
		ObjectMaximumSize.x = fSomeObject->getPreferredSize().x;
	else
		ObjectMaximumSize.x = fSomeObject->getMaximumSize().x;

	float LeftInset		= 0.0;
	float RightInset	= 0.0;

	if( ObjectMaximumSize.x < NewSize.x)
	{
		fprintf( stderr, "fBeFrame::setSize() ObjectMaximumSize.x < NewSize.x\n");
	
		NewSize.x = ObjectMaximumSize.x;
	
		// align object horizontally
		switch( fSomeObject->getHorizontalAlignment())
		{
			case fObject::F_HALIGN_LEFT:
				LeftInset = 0.0;
				RightInset = NewSize.x - ObjectMaximumSize.x;
				break;

			case fObject::F_HALIGN_CENTER:
				LeftInset = RightInset = ( NewSize.x - ObjectMaximumSize.x) / 2.0;
				break;
			
			case fObject::F_HALIGN_RIGHT:
				LeftInset = NewSize.x - ObjectMaximumSize.x;
				RightInset = 0.0;
				break;
		}
	}

	fSomeObject->setSize( NewSize);
	fSomeObject->setPosition( getPosition() + fPoint( fLeftInset + LeftInset, fTopInset));

//	fprintf( stderr, "fBeFrame::setSize()\n");
}

void fBeFrame::drawObject( const BRegion &ClippingRegion, bool FullUpdate) const
{
	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;

    if( getView()->Window() == NULL)
        return;

    if( getView()->Window()->Lock() == false)
        return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	getView()->PushState();
	fFrame::drawObject( ClippingRegion, FullUpdate);
	getView()->PopState();

	if( fLabel)
	{
		getView()->SetHighColor( 0x0, 0x00, 0x0);
		getView()->SetFont( fFont);
		getView()->DrawString( fLabel, Frame.LeftTop() + fTextPosition);

		getView()->SetHighColor( 0xff, 0xff, 0xff);
		getView()->StrokeLine( Frame.LeftTop() + BPoint( 5.0, fTextSize.y / 2 + 1), Frame.LeftTop() + BPoint( 1.0, fTextSize.y / 2 + 1));
		getView()->StrokeLine( Frame.LeftBottom() + BPoint( 1.0, 0.0));
		getView()->StrokeLine( Frame.RightBottom());
		getView()->StrokeLine( Frame.RightTop() + BPoint( 0.0, fTextSize.y / 2 + 1));
		getView()->StrokeLine( Frame.LeftTop() + BPoint( fTextSize.x + 10.0 + 4.0, fTextSize.y / 2 + 1));

		getView()->SetHighColor( 0x68, 0x68, 0x68);
		getView()->StrokeLine( Frame.LeftTop() + BPoint( 5.0, fTextSize.y / 2), Frame.LeftTop() + BPoint( 0.0, fTextSize.y / 2));
		getView()->StrokeLine( Frame.LeftBottom() - BPoint( 0.0, 1.0));
		getView()->StrokeLine( Frame.RightBottom() - BPoint( 1.0, 1.0));
		getView()->StrokeLine( Frame.RightTop() + BPoint( -1.0, fTextSize.y / 2));
		getView()->StrokeLine( Frame.LeftTop() + BPoint( fTextSize.x + 10.0 + 4.0, fTextSize.y / 2));
	}
	else
	{
		getView()->SetHighColor( 0xff, 0xff, 0xff);
		getView()->StrokeRect( BRect( Frame.LeftTop() + BPoint( 1.0, 1.0), Frame.RightBottom()));

		getView()->SetHighColor( 0x68, 0x68, 0x68);
		getView()->StrokeRect( BRect( Frame.LeftTop(), Frame.RightBottom() - BPoint( 1.0, 1.0)));
	}		

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())    
		getView()->Window()->Unlock();
}