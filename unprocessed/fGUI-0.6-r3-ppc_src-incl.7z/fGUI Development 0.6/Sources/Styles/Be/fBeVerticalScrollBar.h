// fBeVerticalScrollBar.h

#ifndef fBeVerticalScrollBar_h
#define fBeVerticalScrollBar_h

#include "fVerticalScrollBar.h"

#pragma export on

class fBeVerticalScrollBar : public fVerticalScrollBar
{
	private:

		fBeVerticalScrollBar( const fBeVerticalScrollBar &CopyObject);
		fBeVerticalScrollBar &operator=( const fBeVerticalScrollBar &CopyObject);
	
		ClassDeclaration( fBeVerticalScrollBar);

	protected:


		virtual void recalculateKnobFrame( void);

		virtual void createArrowButton( const void *PassiveData, const void *ActiveData,
										const void *DisabledData, int32 Which, int32 Action);

		virtual void drawType1KnobMarker( BPoint Position) const;
		virtual void drawType2KnobMarker( BPoint Position) const;

		virtual void recalculateSizeLimits( void);

	public:

		fBeVerticalScrollBar( void);
		virtual ~fBeVerticalScrollBar( void);

		virtual void setSize( const fPoint &NewSize);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif