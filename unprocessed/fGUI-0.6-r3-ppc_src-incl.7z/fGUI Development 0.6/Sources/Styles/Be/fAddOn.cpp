// fAddOn.cpp

#include "fAddOn.h"

void Fred( void)
{
}