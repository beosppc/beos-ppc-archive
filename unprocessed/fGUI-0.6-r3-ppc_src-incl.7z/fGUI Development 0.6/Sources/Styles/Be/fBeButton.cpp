// fBeButton.cpp

#include "fBeButton.h"

#include "fEvents.h"

#include "fFactory.h"

#if DEBUG > 0
#define FBUTTON_DEBUG DEBUG
#endif
 
//#undef FBUTTON_DEBUG
//#define FBUTTON_DEBUG 3

ClassDefinition( fBeButton, fButton, "Be");

fBeButton::fBeButton( void)
{
	setBackgroundColor( 0xda, 0xda, 0xda);
	recalculateSizeLimits();
}

fBeButton::fBeButton( const char *ButtonText)
			: fButton( ButtonText)
{
	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fBeButton::fBeButton()\n");
	#endif

	setBackgroundColor( 0xeb, 0xeb, 0xeb);
	recalculateSizeLimits();

	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fBeButton::fBeButton() end\n");
	#endif
}

fBeButton::~fBeButton()
{
	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fBeButton::~fBeButton()\n");
	#endif  

	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fBeButton::~fBeButton() end\n");
	#endif  
}

void fBeButton::recalculateSizeLimits( void)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeButton::recalculateSizeLimits()\n");
	#endif

	if( fFont == NULL)
	{
		setMinimumSize( fPoint( 10.0, 10.0));
		setPreferredSize( fPoint( 10.0, 10.0));
		setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

		return;
	}

	font_height fontheight;
	fFont->GetHeight( &fontheight);

	fPoint BoxSize = fPoint( fFont->StringWidth( fButtonText), fontheight.ascent + fontheight.descent + fontheight.leading + 1.0);

	// Remember text size
	fTextSize = BoxSize;

	// Add space for half an "Em" on both sides
	BoxSize.x += fFont->StringWidth( "M");

	// Add space for the frame
	BoxSize += fPoint( 4.0 + 3.0, 4.0 + 3.0);

	// Add space for underline when focused...
	BoxSize += fPoint( 0.0, 2 * 1.0);

	// Add space for frame if default target
	if( getDefaultButton())
		BoxSize += fPoint( 2 * 4.0, 2 * 4.0);

	setMinimumSize( BoxSize);
	setPreferredSize( BoxSize);
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeButton::recalculateSizeLimits() end\n");
	#endif
}

void fBeButton::keyDown( const char *Input, int32 Length)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeButton::keyDown()\n");
	#endif

	if( getEnabled() == false)
		return;

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
	{
		fHighlighted = true;
		redraw( getObjectFrame());

		getView()->Sync();

		snooze( 100000);

		fHighlighted = false;
		redraw( getObjectFrame());

		processEvent( F_BUTTON_CLICKED);
	}

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeButton::keyDown() end\n");
	#endif
}

void fBeButton::keyUp( const char */*Input*/, int32 /*Length*/)
{
}

void fBeButton::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeButton::draw()\n");
	#endif

	if( getView() == NULL)
		return;
	
	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;
		
	#if FBUTTON_DEBUG > 2
	fprintf( stderr, "fBeButton::draw() Drawing to: ");
	Frame.PrintToStream();
	fprintf( stderr, "fBeButton::draw() ClippingRegion: ");
	ClippingRegion.PrintToStream();
	#endif

	if( getView()->Window() == NULL)
		return;

	if( getView()->Window()->Lock() == false)
		return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	// set drawing environment
	getView()->SetDrawingMode( B_OP_COPY);
	getView()->SetPenSize( 1.0);

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
	{
		BRect FillFrame = Frame;
		FillFrame.InsetBy( 1.0, 0.0);
		getView()->FillRect( FillFrame, B_SOLID_LOW);
	}

	// draw text
	font_height fontheight;
	fFont->GetHeight( &fontheight);

	fPoint TextPosition = getPosition();

	TextPosition.y += fontheight.ascent;

	TextPosition.x += ( getSize().x - fTextSize.x) / 2;
	TextPosition.y += ( getSize().y - fTextSize.y) / 2;

	if( getEnabled())
		getView()->SetHighColor( getFontColor());
	else
		getView()->SetHighColor( 0xa8, 0xa8, 0xa8);
	
	getView()->SetFont( fFont);
	getView()->DrawString( fButtonText, TextPosition);

	// default target frame
	if( getDefaultButton())
	{
		// outer frame
		if( getEnabled())
			getView()->SetHighColor( 0x70, 0x70, 0x70);
		else
			getView()->SetHighColor( 0xb8, 0xb8, 0xb8);

		getView()->StrokeLine( Frame.LeftBottom() + fPoint( 1.0, 0.0),
								Frame.RightBottom() - fPoint( 1.0, 0.0));
		getView()->StrokeLine( Frame.RightBottom() - fPoint( 0.0, 1.0),
								Frame.RightTop() + fPoint( 0.0, 1.0));
		getView()->StrokeLine( Frame.RightTop() - fPoint( 1.0, 0.0),
								Frame.LeftTop() + fPoint( 1.0, 0.0));
		getView()->StrokeLine( Frame.LeftTop() + fPoint( 0.0, 1.0),
								Frame.LeftBottom() - fPoint( 0.0, 1.0));
		Frame.InsetBy( 1.0, 1.0);

		// inner frames
		if( getEnabled())
			getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
		else
			getView()->SetHighColor( 0xe2, 0xe2, 0xe2);

		getView()->StrokeRect( Frame);		
		Frame.InsetBy( 1.0, 1.0);

		getView()->SetHighColor( 0xe2, 0xe2, 0xe2);
		getView()->StrokeRect( Frame);		
		Frame.InsetBy( 1.0, 1.0);

		getView()->SetHighColor( 0xd9, 0xd9, 0xd9);
		getView()->StrokeRect( Frame);		
		Frame.InsetBy( 1.0, 1.0);
	}

	// outer frame
	if( getEnabled())
		getView()->SetHighColor( 0x58, 0x58, 0x58);
	else
		getView()->SetHighColor( 0xa8, 0xa8, 0xa8);

	getView()->StrokeLine( Frame.LeftBottom() + fPoint( 1.0, 0.0),
							Frame.RightBottom() - fPoint( 1.0, 0.0));
	getView()->StrokeLine( Frame.RightBottom() - fPoint( 0.0, 1.0),
							Frame.RightTop() + fPoint( 0.0, 1.0));
	getView()->StrokeLine( Frame.RightTop() - fPoint( 1.0, 0.0),
							Frame.LeftTop() + fPoint( 1.0, 0.0));
	getView()->StrokeLine( Frame.LeftTop() + fPoint( 0.0, 1.0),
							Frame.LeftBottom() - fPoint( 0.0, 1.0));

	// bottom lines
	// dark grey (lower line)
	if( getEnabled())
		getView()->SetHighColor( 0x90, 0x90, 0x90);
	else
		getView()->SetHighColor( 0xc8, 0xc8, 0xc8);

	getView()->StrokeLine( Frame.LeftBottom() + fPoint( 2.0, -1.0),
							Frame.RightBottom() - fPoint( 1.0, 1.0));
	getView()->StrokeLine( Frame.RightTop() - fPoint( 1.0, -2.0));

	// light grey (upper line)
	if( getEnabled())
		getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
	else
		getView()->SetHighColor( 0xd0, 0xd0, 0xd0);

	getView()->StrokeLine( Frame.LeftBottom() + fPoint( 3.0, -2.0),
							Frame.RightBottom() - fPoint( 2.0, 2.0));
	getView()->StrokeLine( Frame.RightTop() - fPoint( 2.0, -2.0));

	// white lines
	getView()->SetHighColor( 0xf4, 0xf4, 0xf4);
	getView()->StrokeLine( Frame.LeftBottom() + fPoint( 2.0, -2.0),
							Frame.LeftTop() + fPoint( 2.0, 2.0));
	getView()->StrokeLine( Frame.RightTop() - fPoint( 2.0, -2.0));

	getView()->StrokeLine( Frame.LeftBottom() + fPoint( 3.0, -3.0),
							Frame.LeftTop() + fPoint( 3.0, 3.0));
	getView()->StrokeLine( Frame.RightTop() - fPoint( 3.0, -3.0));

	if( fHighlighted)
	{
		Frame.InsetBy( 2.0, 2.0);
		getView()->InvertRect( Frame);
	}
	else
	{
		if( getFocus())
		{
			float FontWidth = fFont->StringWidth( fButtonText);

			getView()->SetHighColor( keyboard_navigation_color());
			getView()->StrokeLine( TextPosition + fPoint( 0.0, fontheight.descent),
										TextPosition + fPoint( FontWidth, fontheight.descent));

			getView()->SetHighColor( 0xff, 0xff, 0xff);
			getView()->StrokeLine( TextPosition + fPoint( 0.0, fontheight.descent + 1.0),
										TextPosition + fPoint( FontWidth, fontheight.descent + 1.0));
		}
	}

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeButton::draw() end\n");
	#endif
}