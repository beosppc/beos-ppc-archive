// fBeCycleButton.cpp

#include "fBeCycleButton.h"

#include "fEvents.h"

#include "fFactory.h"

#if DEBUG > 0
#define FBUTTON_DEBUG DEBUG
#endif
 
//#undef FBUTTON_DEBUG
//#define FBUTTON_DEBUG 3

ClassDefinition( fBeCycleButton, fCycleButton, "Be");

fBeCycleButton::fBeCycleButton( void)
{
	recalculateSizeLimits();
}
/*
fBeCycleButton::fBeCycleButton( const char **Choices, int32 Count)
					: fCycleButton( Choices, Count)
{
	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fBeCycleButton::fBeCycleButton()\n");
	#endif

	recalculateSizeLimits();

	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fBeCycleButton::fBeCycleButton() end\n");
	#endif
}
*/
fBeCycleButton::~fBeCycleButton()
{
	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fBeCycleButton::~fBeCycleButton()\n");
	#endif  

	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fBeCycleButton::~fBeCycleButton() end\n");
	#endif  
}

void fBeCycleButton::recalculateSizeLimits( void)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeCycleButton::recalculateSizeLimits()\n");
	#endif

	if(( fFont == NULL) || ( fChoicesCount == 0))
	{
		setMinimumSize( fPoint( 10.0, 10.0));
		setPreferredSize( fPoint( 10.0, 10.0));
		
		return;
	}

	font_height fontheight;
	fFont->GetHeight( &fontheight);

	float EmWidth = fFont->StringWidth( "M");

	fPoint BoxSize = fPoint( 0.0, fontheight.ascent + fontheight.descent + fontheight.leading);

	for( int32 Count = 0; Count < fChoicesCount; Count++)
	{
		char *Text = static_cast<char*>( Texts.ItemAt( Count));
		fTextSizes[ Count] = fFont->StringWidth( Text) + EmWidth;

		if( fTextSizes[ Count] > BoxSize.x)
			BoxSize.x = fTextSizes[ Count];
	}	

	// Add space for the frame
	BoxSize += fPoint( 4.0 + 3.0, 4.0 + 3.0);

	// Add space for underline when focused...
	BoxSize += fPoint( 0.0, 3.0);

	// Add space for cycle symbol...
	BoxSize += fPoint( BoxSize.y * 1.25, 0.0);

	setMinimumSize( BoxSize);
	setPreferredSize( BoxSize);
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeCycleButton::recalculateSizeLimits() end\n");
	#endif
}

void fBeCycleButton::keyDown( const char *Input, int32 Length)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeCycleButton::keyDown()\n");
	#endif

	if( getEnabled() == false)
		return;

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
	{
		fHighlighted = true;
		redraw( getObjectFrame());

		getView()->Sync();

		snooze( 100000);

		fHighlighted = false;
		redraw( getObjectFrame());

		fCurrentChoice = ( fCurrentChoice + 1) % fChoicesCount;
		processEvent( F_BUTTON_CLICKED);
	}

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeCycleButton::keyDown() end\n");
	#endif
}

void fBeCycleButton::keyUp( const char */*Input*/, int32 /*Length*/)
{
}

void fBeCycleButton::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeCycleButton::draw()\n");
	#endif

	if( getView() == NULL)
		return;
	
	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	#if FBUTTON_DEBUG > 2
	fprintf( stderr, "fBeCycleButton::draw() Drawing to: ");
	Frame.PrintToStream();
	#endif

	if( Frame.IsValid() == false)
		return;
		
	if( getView()->Window() == NULL)
		return;

	if( getView()->Window()->Lock() == false)
		return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	// set drawing environment
	getView()->SetDrawingMode( B_OP_COPY);
	getView()->SetPenSize( 1.0);

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
	{
		BRect FillFrame = Frame;
		FillFrame.InsetBy( 1.0, 0.0);
		getView()->FillRect( FillFrame, B_SOLID_LOW);
	}

	// print text
	float EmWidth = fFont->StringWidth( "M");

	font_height fontheight;
	fFont->GetHeight( &fontheight);

	fPoint TextPosition = getPosition() + fPoint( EmWidth / 2.0, fontheight.ascent);

	TextPosition.x += ( getSize().x - ( getSize().y * 1.25) - fTextSizes[ fCurrentChoice]) / 2 + ( getSize().y * 1.25);
	TextPosition.y += ( getSize().y - ( fontheight.ascent + fontheight.descent + fontheight.leading)) / 2;

	if( getEnabled())
		getView()->SetHighColor( getFontColor());
	else
		getView()->SetHighColor( 0xa8, 0xa8, 0xa8);
	
	getView()->SetFont( fFont);
	getView()->DrawString( static_cast<char *>( Texts.ItemAt( fCurrentChoice)), TextPosition);

	// cycle symbol
	
	BRect CycleFrame = Frame;
	CycleFrame.right = CycleFrame.left + ( CycleFrame.Height() + 1.0) * 1.25;
	CycleFrame.OffsetBy( 4.0, 0.0);
	CycleFrame.top += 5.0;
	CycleFrame.bottom -= 4.0;

	// left line to seperate the cycle symbol from the text
	if( getEnabled())
		getView()->SetHighColor( 0x0, 0x0, 0x0);
	else
		getView()->SetHighColor( 0xa8, 0xa8, 0xa8);
	
	getView()->StrokeLine( CycleFrame.RightTop(), CycleFrame.RightBottom());
	getView()->SetHighColor( 0xff, 0xff, 0xff);
	getView()->StrokeLine( CycleFrame.RightTop() + BPoint( 1.0, 0.0),
								CycleFrame.RightBottom() + BPoint( 1.0, 0.0));

	float Temp = rint( CycleFrame.Height() / 2.0);
	Temp = 2.0 * ceil( Temp / 2.0);

	CycleFrame.left += floor(( CycleFrame.Width() - CycleFrame.Height() - 2.0 - Temp / 2.0) / 2.0);
	CycleFrame.right = CycleFrame.left + CycleFrame.Height() + 1.0;
	if( getEnabled())
		getView()->SetHighColor( 0x0, 0x0, 0x0);
	else
		getView()->SetHighColor( 0xa8, 0xa8, 0xa8);
	getView()->FillArc( CycleFrame, 45.0, 315.0);

	float Inset = floor( Temp / 3.0);

	CycleFrame.InsetBy( Inset, Inset);
	getView()->SetHighColor( 0xe9, 0xe9, 0xe9);
	getView()->FillArc( CycleFrame, 45.0, 315.0);

	CycleFrame.InsetBy( -Inset, -Inset);
	if( getEnabled())
		getView()->SetHighColor( 0x0, 0x0, 0x0);
	else
		getView()->SetHighColor( 0xa8, 0xa8, 0xa8);
	
	BPoint Point1 = CycleFrame.RightTop() + BPoint( - rint( Temp / 2) - floor( Inset / 2.0) + 1.0, Temp);

	while( Temp >= 2.0)
	{
		getView()->StrokeLine( Point1, Point1 + BPoint( Temp - 1.0, 0.0));
	
		Temp -= 2.0;
		Point1 += BPoint( 1.0, -1.0);
	}

	// outer frame
	if( getEnabled())
		getView()->SetHighColor( 0x58, 0x58, 0x58);
	else
		getView()->SetHighColor( 0xa8, 0xa8, 0xa8);

	getView()->StrokeLine( Frame.LeftBottom() + fPoint( 1.0, 0.0),
							Frame.RightBottom() - fPoint( 1.0, 0.0));
	getView()->StrokeLine( Frame.RightBottom() - fPoint( 0.0, 1.0),
							Frame.RightTop() + fPoint( 0.0, 1.0));
	getView()->StrokeLine( Frame.RightTop() - fPoint( 1.0, 0.0),
							Frame.LeftTop() + fPoint( 1.0, 0.0));
	getView()->StrokeLine( Frame.LeftTop() + fPoint( 0.0, 1.0),
							Frame.LeftBottom() - fPoint( 0.0, 1.0));

	// bottom lines
	// dark grey (lower line)
	if( getEnabled())
		getView()->SetHighColor( 0x90, 0x90, 0x90);
	else
		getView()->SetHighColor( 0xc8, 0xc8, 0xc8);

	getView()->StrokeLine( Frame.LeftBottom() + fPoint( 2.0, -1.0),
							Frame.RightBottom() - fPoint( 1.0, 1.0));
	getView()->StrokeLine( Frame.RightTop() - fPoint( 1.0, -2.0));

	// light grey (upper line)
	if( getEnabled())
		getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
	else
		getView()->SetHighColor( 0xd0, 0xd0, 0xd0);

	getView()->StrokeLine( Frame.LeftBottom() + fPoint( 3.0, -2.0),
							Frame.RightBottom() - fPoint( 2.0, 2.0));
	getView()->StrokeLine( Frame.RightTop() - fPoint( 2.0, -2.0));

	// white lines
	getView()->SetHighColor( 0xf4, 0xf4, 0xf4);
	getView()->StrokeLine( Frame.LeftBottom() + fPoint( 2.0, -2.0),
							Frame.LeftTop() + fPoint( 2.0, 2.0));
	getView()->StrokeLine( Frame.RightTop() - fPoint( 2.0, -2.0));

	getView()->StrokeLine( Frame.LeftBottom() + fPoint( 3.0, -3.0),
							Frame.LeftTop() + fPoint( 3.0, 3.0));
	getView()->StrokeLine( Frame.RightTop() - fPoint( 3.0, -3.0));

	if( fHighlighted)
	{
		Frame.InsetBy( 2.0, 2.0);
		getView()->InvertRect( Frame);
	}
	else
	{
		if( getFocus())
		{
			float FontWidth = fFont->StringWidth( static_cast<char *>( Texts.ItemAt( fCurrentChoice)));

			getView()->SetHighColor( keyboard_navigation_color());
			getView()->StrokeLine( TextPosition + fPoint( 0.0, fontheight.descent),
										TextPosition + fPoint( FontWidth, fontheight.descent));

			getView()->SetHighColor( 0xff, 0xff, 0xff);
			getView()->StrokeLine( TextPosition + fPoint( 0.0, fontheight.descent + 1.0),
										TextPosition + fPoint( FontWidth, fontheight.descent + 1.0));
		}
	}

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fBeCycleButton::draw() end\n");
	#endif
}