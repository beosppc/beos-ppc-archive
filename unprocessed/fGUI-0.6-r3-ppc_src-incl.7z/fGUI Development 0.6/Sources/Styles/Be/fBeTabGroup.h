// fBeTabGroup.h

#ifndef fBeTabGroup_h
#define fBeTabGroup_h

#include "fTabGroup.h"
#include "fTabItem.h"

#pragma export on

class fBeTabGroup : public fTabGroup
{
	private:

		fBeTabGroup( const fBeTabGroup &CopyObject);
		fBeTabGroup &operator=( const fBeTabGroup &CopyObject);

		ClassDeclaration( fBeTabGroup);

	protected:

		float fOverlap;

		virtual void calculateMinimumSize( void);
		virtual void calculateMaximumSize( void);
		virtual void calculatePreferredSize( void);

	public:

		fBeTabGroup( void);
		virtual ~fBeTabGroup( void);

		virtual void setSize( const fPoint &NewSize);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
