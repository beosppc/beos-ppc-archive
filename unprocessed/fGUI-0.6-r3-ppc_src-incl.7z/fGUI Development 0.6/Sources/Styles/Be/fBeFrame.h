// fBeFrame.h

#ifndef fBeFrame_h
#define fBeFrame_h

#include "fFrame.h"

#pragma export on

class fBeFrame : public fFrame
{
	private:

		fBeFrame( const fBeFrame &CopyObject);
		fBeFrame &operator=( const fBeFrame &CopyObject);

		ClassDeclaration( fBeFrame);

	protected:
	
		fPoint	 fTextSize;
		fPoint	 fTextPosition;
		
		fPoint fMinimumFrameSize;

		virtual void recalculateSizeLimits( void);

	public:

		fBeFrame( const char *Label = NULL);
		virtual ~fBeFrame( void);

		virtual void setFont( const BFont *Font);
		virtual void setText( const char *Label);

		virtual void setSize( const fPoint &NewSize);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
