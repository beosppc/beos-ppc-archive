// fBeTabItem.cpp

#include "fBeTabItem.h"
#include "fFactory.h"

#include "fEvents.h"

#if DEBUG > 0
#define FTABITEM_DEBUG DEBUG
#endif

//#undef FTABITEM_DEBUG
//#define FTABITEM_DEBUG 2

ClassDefinition( fBeTabItem, fTabItem, "Be");

fBeTabItem::fBeTabItem( const char *Label)
		: fTabItem( Label)
{
	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fBeTabItem::fBeTabItem()\n");
	#endif

	recalculateSizeLimits();

	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fBeTabItem::fBeTabItem() end\n");
	#endif
}

fBeTabItem::~fBeTabItem( void)
{
	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fBeTabItem::~fBeTabItem()\n");
	#endif

	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fBeTabItem::~fBeTabItem() end\n");
	#endif
}

void fBeTabItem::recalculateSizeLimits( void)
{
	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fBeTabItem::recalculateSizeLimits()\n");
	#endif

	if( fFont == NULL)
	{
		setMinimumSize( fPoint( 4 * 10.0 + 7.0, 10.0));
		setPreferredSize( fPoint( 4 * 10.0 + 7.0, 10.0));
		setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

		return;
	}

	font_height fontheight;
	fFont->GetHeight( &fontheight);

	fPoint BoxSize = fPoint( fFont->StringWidth( fButtonText), fontheight.ascent + fontheight.descent + fontheight.leading + 1.0);

	// Remember font size
	fTextSize = BoxSize;

	// Add space for half an "Em" on both sides
	BoxSize.x += fFont->StringWidth( "M");

	// and space for the tab frame
	BoxSize += fPoint( 0.0, 2 * 1.0);

	// Hmm, just looks better :)
	BoxSize.y -= 1.0;

	// Add room for the outer rounded edges and the line
	BoxSize.x += 2 * 10.0;

	BoxSize.x *= 1.2;
	// set minimum size
	setMinimumSize( BoxSize);

	// Add room ( BeOS' tabs look that way...)
	BoxSize.y += 2 * 4.0;
	BoxSize.x *= 1.2;

	// set preferred size
	setPreferredSize( BoxSize);
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

	#if FTABITEM_DEBUG > 3
	fprintf( stderr, "fBeTabItem::recalculateSizeLimits() New minimum size: ");
	getMinimumSize().PrintToStream();
	fprintf( stderr, "fBeTabItem::recalculateSizeLimits() New preferred size: ");
	getPreferredSize().PrintToStream();
	#endif
	
	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fBeTabItem::recalculateSizeLimits() end\n");
	#endif
}

const fObject *fBeTabItem::containsPoint( const fPoint &Point) const
{
	if( getActive())
		if( fSomeObject)
		{
			const fObject *TempObject = fSomeObject->containsPoint( Point);
	
			if( TempObject)
				return( TempObject);
		}	

	BRect rect = getObjectFrame();
	
	rect.InsetBy( getHorizontalBorder() + 10.0, getVerticalBorder());
	
	if( rect.Contains( Point) == false)
		return( NULL);
		   
	return( this);
}

void fBeTabItem::mouseDown( MouseButton Button, const fPoint &Point, int32 NumClicks)
{
	if( Button != F_PRIMARY_MOUSE_BUTTON)
		return;

	if( NumClicks != 1)
		return;

	// trigger action !
	if( containsPoint( Point) == this)
		processEvent( F_BUTTON_CLICKED);		
}

void fBeTabItem::mouseUp( MouseButton /*Button*/, const fPoint &/*Point*/, int32 /*NumClicks*/)
{
}

void fBeTabItem::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fBeTabItem::draw()\n");
	#endif

	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	#if FTABITEM_DEBUG > 2
	fprintf( stderr, "fBeTabItem::draw() Drawing to: ");
	Frame.PrintToStream();
	#endif

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;

    if( getView()->Window() == NULL)
        return;

    if( getView()->Window()->Lock() == false)
        return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

/*
	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRect( Frame, B_SOLID_LOW);
*/

	BRect temp = getObjectFrame();
	temp.left += 9.0;
	temp.right -= 9.0;
	getView()->SetLowColor( getBackgroundColor());
	getView()->FillRect( temp, B_SOLID_LOW);

/*
	getView()->SetHighColor( 0xf, 0xf, 0xff);
	getView()->StrokeRect( getObjectFrame());
*/
	if( getActive())
	{
		getView()->SetHighColor( getBackgroundColor());
		getView()->StrokeLine( Frame.LeftBottom(), Frame.RightBottom());
	}

	// lower left
	getView()->SetHighColor( 0xff, 0xff, 0xff);
	getView()->StrokeArc( Frame.LeftBottom() + BPoint( 6.0, -4.0), 3.0, 3.0, 270.0, 90.0);
	getView()->StrokeLine( Frame.LeftBottom(), Frame.LeftBottom() + BPoint( 5.0, 0.0));

	// lower right
	getView()->StrokeLine( Frame.RightBottom(), Frame.RightBottom() + BPoint( -5.0, 0.0));

	BPoint Center = Frame.RightBottom() - BPoint( 7.0, 4.0);

	getView()->SetHighColor( 0xb0, 0xb0, 0xb0);
	getView()->StrokeArc( Center, 3.0, 3.0, 180.0, 40.0);
	getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
	getView()->StrokeArc( Center, 3.0, 3.0, 220.0, 10.0);
	getView()->SetHighColor( 0xc0, 0xc0, 0xc0);
	getView()->StrokeArc( Center, 3.0, 3.0, 230.0, 40.0);

	Center += BPoint( 1.0, 0.0);

	getView()->SetHighColor( 0x70, 0x70, 0x70);
	getView()->StrokeArc( Center, 3.0, 3.0, 180.0, 40.0);
	getView()->SetHighColor( 0x80, 0x80, 0x80);
	getView()->StrokeArc( Center, 3.0, 3.0, 220.0, 10.0);
	getView()->SetHighColor( 0x98, 0x98, 0x98);
	getView()->StrokeArc( Center, 3.0, 3.0, 230.0, 40.0);

	if( getActive() == false)
	{
		getView()->SetHighColor( 0xff, 0xff, 0xff);
		getView()->StrokeLine( Frame.LeftBottom(), Frame.RightBottom());
	}

	Frame.InsetBy( 9.0 + 1.0, 0.0);

	// draw text
	font_height fontheight;
	fFont->GetHeight( &fontheight);

	fPoint TextPosition = getPosition();

	TextPosition.y += fontheight.ascent;

	TextPosition.x += ( getSize().x - fTextSize.x) / 2;
	TextPosition.y += ( getSize().y - fTextSize.y) / 2;

	getView()->SetHighColor( getFontColor());
	getView()->SetFont( fFont);
	getView()->DrawString( fButtonText, TextPosition);

	// left line
	getView()->SetHighColor( 0xff, 0xff, 0xff);
	getView()->StrokeLine( Frame.LeftBottom() - BPoint( 0.0, 4.0 + 1.0),
							Frame.LeftTop() + BPoint( 0.0, 4.0));

	// upper left edge
	getView()->StrokeLine( Frame.LeftTop() + BPoint( 1.0, 2.0), Frame.LeftTop() + BPoint( 1.0, 3.0));
	getView()->StrokeLine( Frame.LeftTop() + BPoint( 2.0, 1.0), Frame.LeftTop() + BPoint( 3.0, 1.0));

	// top line
	getView()->StrokeLine( Frame.LeftTop() + BPoint( 4.0, 0.0),
							Frame.RightTop() - BPoint( 4.0, 0.0));

	// upper right edge
	getView()->StrokeLine( Frame.RightTop() + BPoint( -2.0, 1.0), Frame.RightTop() + BPoint( -3.0, 1.0));

	getView()->SetHighColor( 0x60, 0x60, 0x60);
	getView()->StrokeLine( Frame.RightTop() + BPoint( -1.0, 2.0), Frame.RightTop() + BPoint( -1.0, 3.0));

	// right line
	getView()->StrokeLine( Frame.RightTop() + BPoint( 0.0, 4.0),
							Frame.RightBottom() - BPoint( 0.0, 4.0 + 1.0));

	// upper right edge, second part
	getView()->SetHighColor( 0xb0, 0xb0, 0xb0);
	getView()->StrokeLine( Frame.RightTop() + BPoint( -2.0, 2.0), Frame.RightTop() + BPoint( -2.0, 3.0));

	// right line, second part
	getView()->StrokeLine( Frame.RightTop() + BPoint( -1.0, 4.0),
							Frame.RightBottom() - BPoint( 1.0, 4.0 + 1.0));

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())    
        getView()->Window()->Unlock();

	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fBeTabItem::draw() end\n");
	#endif
}
