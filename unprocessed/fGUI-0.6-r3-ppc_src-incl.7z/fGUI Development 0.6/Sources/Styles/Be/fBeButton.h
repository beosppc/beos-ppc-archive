// fBeButton.h

#ifndef fBeButton_h
#define fBeButton_h

#include "fButton.h"
#include "fEventRoute.h"

#pragma export on

class fBeButton : public fButton
{
	private :

		fBeButton( const fBeButton &CopyObject);
		fBeButton &operator=( const fBeButton &CopyObject);
	
		ClassDeclaration( fBeButton);

	protected:

		virtual void recalculateSizeLimits( void);

	public :

		fBeButton( void);
		fBeButton( const char *ButtonText);
		virtual ~fBeButton( void);

		virtual void keyDown( const char *Input, int32 Length);
		virtual void keyUp( const char *Input, int32 Length);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
