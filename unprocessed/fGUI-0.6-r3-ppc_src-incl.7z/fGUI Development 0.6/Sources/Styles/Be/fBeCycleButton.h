// fBeCycleButton.h

#ifndef fBeCycleButton_h
#define fBeCycleButton_h

#include "fCycleButton.h"
#include "fEventRoute.h"

#pragma export on

class fBeCycleButton : public fCycleButton
{
	private :

		fBeCycleButton( const fBeCycleButton &CopyObject);
		fBeCycleButton &operator=( const fBeCycleButton &CopyObject);
	
		ClassDeclaration( fBeCycleButton);

	protected:

		virtual void recalculateSizeLimits( void);

	public :

		fBeCycleButton( void);
		fBeCycleButton( const char **Choices, int32 Count);
		virtual ~fBeCycleButton( void);

		virtual void keyDown( const char *Input, int32 Length);
		virtual void keyUp( const char *Input, int32 Length);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
