// fBeTabItem.h

#ifndef fBeTabItem_h
#define fBeTabItem_h

#include "fTabItem.h"

#pragma export on

class fBeTabItem : public fTabItem
{
	private:

		fBeTabItem( const fBeTabItem &CopyObject);
		fBeTabItem &operator=( const fBeTabItem &CopyObject);

		ClassDeclaration( fBeTabItem);

	protected:

		virtual void recalculateSizeLimits( void);

	public:

		fBeTabItem( const char *Label = NULL);
		virtual ~fBeTabItem( void);

		virtual const fObject *containsPoint( const fPoint &Point) const;

		virtual void mouseDown( MouseButton Button, const fPoint &Point, int32 NumClicks);
		virtual void mouseUp( MouseButton Button, const fPoint &Point, int32 NumClicks);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
