// fEventRoute.cpp

#include "fEventRoute.h"
#include "fFactory.h"

#include "fWindow.h"

#if DEBUG > 0
#define FEVENTROUTE_DEBUG DEBUG
#endif

//#undef FEVENTROUTE_DEBUG
//#define FEVENTROUTE_DEBUG 3

ClassDefinition( fEventRoute, fClassInfo, "");

fEventRoute::fEventRoute( int32 Event)
{
	fEvent				= Event;

	fAction				= F_NO_EVENT;
	fTargetSignature	= NULL;
	fTargetName			= NULL;
	fTargetPointer		= NULL;
	fSourceName			= NULL;
	fSourcePointer		= NULL;

	fTemplateMessage	= NULL;
	
	fLaunchTarget		= true;
}

fEventRoute::~fEventRoute( void)
{
	delete [] fTargetSignature;
	delete [] fTargetName;
	delete [] fSourceName;
}

DoMethodBegin( fEventRoute)
	DoMethodDefinitionBegin( "Event", setEvent, 1)
		DoMethodVariable( int32, Event)
		DoMethodVoidCall( setEvent)( Event)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Action", setAction, 1)
		DoMethodVariable( int32, Action)
		DoMethodVoidCall( setAction)( Action)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "TargetSignature", setTargetSignature, 1)
		DoMethodVariable( char *, Signature)
		DoMethodVoidCall( setTargetSignature)( Signature)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "TargetName", setTargetName, 1)
		DoMethodVariable( char *, ObjectName)
		DoMethodVoidCall( setTargetName)( ObjectName)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "SourceName", setSourceName, 1)
		DoMethodVariable( char *, ObjectName)
		DoMethodVoidCall( setSourceName)( ObjectName)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "TemplateMessage", setTemplateMessage, 1)
		DoMethodVariableCast( BMessage *, char *, Message)
		DoMethodVoidCall( setTemplateMessage)( Message)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "LaunchTarget", setLaunchTarget, 1)
		DoMethodVariable( bool, LaunchTarget)
		DoMethodVoidCall( setLaunchTarget)( LaunchTarget)
	DoMethodDefinitionEnd
DoMethodEnd( fClassInfo)

void fEventRoute::addDefaultFields( BMessage *Message) const
{
	if( Message == NULL)
		return;

	Message->what = FGUI_EVENT;

	if( fEvent != F_NO_EVENT)
		if( Message->HasInt32( "fEvent"))
			Message->ReplaceInt32( "fEvent", fEvent);
		else
			Message->AddInt32( "fEvent", fEvent);

	if( fAction != F_NO_EVENT)
		if( Message->HasInt32( "fAction"))
			Message->ReplaceInt32( "fAction", fAction);
		else
			Message->AddInt32( "fAction", fAction);

	if( Message->HasInt64( "fTimeStamp"))
		Message->ReplaceInt64( "fTimeStamp", system_time());
	else
		Message->AddInt64( "fTimeStamp", system_time());

	if( fTargetName)
		if( Message->HasString( "fTargetName"))
			Message->ReplaceString( "fTargetName", fTargetName);
		else
			Message->AddString( "fTargetName", fTargetName);

	if( fTargetPointer)
		if( Message->HasPointer( "fTargetPointer"))
			Message->ReplacePointer( "fTargetPointer", fTargetPointer);
		else
			Message->AddPointer( "fTargetPointer", fTargetPointer);

	if( fSourceName)
		if( Message->HasString( "fSourceName"))
			Message->ReplaceString( "fSourceName", fSourceName);
		else
			Message->AddString( "fSourceName", fSourceName);

	if( fSourcePointer)
		if( Message->HasPointer( "fSourcePointer"))
			Message->ReplacePointer( "fSourcePointer", fSourcePointer);
		else
			Message->AddPointer( "fSourcePointer", fSourcePointer);
}

void fEventRoute::filterMessage( BMessage *Message) const
{
	if( Message == NULL)
		return;

	int32 Item = 0;
	fMessageFilter *MessageFilter = NULL;

	while(( MessageFilter = static_cast<fMessageFilter *>( fMessageFilters.ItemAt( Item++))) != NULL)
		MessageFilter->filterMessage( Message);
}

team_id fEventRoute::launchApplication( const char *TargetSignature) const
{
	#if FEVENTROUTE_DEBUG > 1
	fprintf( stderr, "fEventRoute::launchApplication()\n");
	#endif

	if( TargetSignature == NULL)
		return( -1);
		
	team_id team = be_roster->TeamFor( TargetSignature);
	
	if( team == B_ERROR)
		if( fLaunchTarget)
			if( be_roster->Launch( TargetSignature, static_cast<BMessage *>( NULL), &team) < B_OK)
				return( -1);
	
	#if FEVENTROUTE_DEBUG > 1
	fprintf( stderr, "fEventRoute::launchApplication() end\n");
	#endif

	return( team);
}

void fEventRoute::setEvent( int32 Event)
{
	fEvent = Event;
}

int32 fEventRoute::getEvent( void) const
{
	return( fEvent);
}

void fEventRoute::setAction( int32 Action)
{
	fAction = Action;
}

int32 fEventRoute::getAction( void) const
{
	return( fAction);
}
		
void fEventRoute::setTargetSignature( const char *Signature)
{
	delete [] fTargetSignature;

	if( Signature == NULL)
	{
		fTargetSignature = NULL;
		return;
	}

	fTargetSignature = new char[ strlen( Signature) + 1];
	strcpy( fTargetSignature, Signature);
}

const char *fEventRoute::getTargetSignature( void) const
{
	return( fTargetSignature);
}
		
void fEventRoute::setTargetName( const char *ObjectName)
{
	delete [] fTargetName;

	if( ObjectName == NULL)
	{
		fTargetName = NULL;
		return;
	}

	fTargetName = new char[ strlen( ObjectName) + 1];
	strcpy( fTargetName, ObjectName);
}

const char *fEventRoute::getTargetName( void) const
{
	return( fTargetName);
}
		
void fEventRoute::setTargetPointer( const class fObject *ObjectPointer)
{
	fTargetPointer = ObjectPointer;
}

const class fObject *fEventRoute::getTargetPointer( void) const
{
	return( fTargetPointer);
}
		
void fEventRoute::setSourceName( const char *ObjectName)
{
	delete [] fSourceName;

	if( ObjectName == NULL)
	{
		fSourceName = NULL;
		return;
	}

	fSourceName = new char[ strlen( ObjectName) + 1];
	strcpy( fSourceName, ObjectName);
}

const char *fEventRoute::getSourceName( void) const
{
	return( fSourceName);
}

void fEventRoute::setSourcePointer( const class fObject *ObjectPointer)
{
	fSourcePointer = ObjectPointer;
}

const class fObject *fEventRoute::getSourcePointer( void) const
{
	return( fSourcePointer);
}
		
void fEventRoute::setTemplateMessage( BMessage *Message)
{
	delete fTemplateMessage;
	fTemplateMessage = Message;
}

const BMessage *fEventRoute::getTemplateMessage( void) const
{
	return( fTemplateMessage);
}

void fEventRoute::addMessageFilter( fMessageFilter *MessageFilter)
{
	fMessageFilters.AddItem( MessageFilter);
}

BMessage *fEventRoute::getMessage( void) const
{
	if( fTemplateMessage)
		return( new BMessage( fTemplateMessage));
	else
		return( new BMessage( FGUI_EVENT));
}

bool fEventRoute::sendMessage( const BMessage *SendMessage, const class fWindow *SourceWindow) const
{
	#if FEVENTROUTE_DEBUG > 1
	fprintf( stderr, "fEventRoute::sendMessage()\n");
	#endif

	BMessage *Message;

	if( SendMessage)
	{
		Message = new BMessage( *SendMessage);
	}
	else
	{
		if( fTemplateMessage)
			Message = new BMessage( fTemplateMessage);
		else
			Message = new BMessage( FGUI_EVENT);
	}

	#if FEVENTROUTE_DEBUG > 4
	fprintf( stderr, "fEventRoute::sendMessage() Before addDefaultFields()\n");
	Message->PrintToStream();
	#endif

	// Add default message fields
	addDefaultFields( Message);

	#if FEVENTROUTE_DEBUG > 4
	fprintf( stderr, "fEventRoute::sendMessage() After addDefaultFields()\n");
	Message->PrintToStream();
	#endif

	// Filter message
	filterMessage( Message);

	#if FEVENTROUTE_DEBUG > 4
	fprintf( stderr, "fEventRoute::sendMessage() After filterMessage()\n");
	Message->PrintToStream();
	#endif

	status_t error = B_ERROR;
	BMessenger *Messenger = NULL;

	// If a signature is given try to localize the corresponding application
	if( Message->HasString( "fTargetSignature"))
	{
		#if FEVENTROUTE_DEBUG > 1
		fprintf( stderr, "fEventRoute::sendMessage() Looking for signature in message\n");
		#endif

		// Use fTargetSignature from message first if there is one
		const char *TargetSignature = Message->FindString( "fTargetSignature");
	
		if( TargetSignature == NULL)
		{
			#if FEVENTROUTE_DEBUG > 1
			fprintf( stderr, "fEventRoute::sendMessage() TargetSignature == NULL\n");
			#endif

			delete Message;
			return( false);
		}

		// find and launch app
		team_id team = launchApplication( TargetSignature);
		
		if( team == -1)
		{
			#if FEVENTROUTE_DEBUG > 2
			fprintf( stderr, "fEventRoute::sendMessage() team == -1\n");
			#endif

			delete Message;
			return( false);
		}

		// create new messenger to send message
		Messenger = new BMessenger( TargetSignature, team, &error);
	}
	else if( fTargetSignature)
	{
		#if FEVENTROUTE_DEBUG > 1
		fprintf( stderr, "fEventRoute::sendMessage() Using fTargetSignature\n");
		#endif

		// find and launch app
		team_id team = launchApplication( fTargetSignature);
		
		if( team == -1)
		{
			#if FEVENTROUTE_DEBUG > 2
			fprintf( stderr, "fEventRoute::sendMessage() team == -1\n");
			#endif

			delete Message;
			return( false);
		}

		// create new messenger to send message
		Messenger = new BMessenger( fTargetSignature, team, &error);
	}
	else if( Message->HasString( "fTargetName"))
	{
		#if FEVENTROUTE_DEBUG > 1
		fprintf( stderr, "fEventRoute::sendMessage() Looking for target name in message\n");
		#endif

		// Use TargetName in the message first
		const char *TargetName = Message->FindString( "fTargetName");
		const BLooper *TargetLooper;
		
		// find the window in which the target object is located.
		if( TargetName)
		{		
			if(( SourceWindow) && ( SourceWindow->findObject( TargetName)))
			{
				#if FEVENTROUTE_DEBUG > 1
				fprintf( stderr, "fEventRoute::sendMessage() Object local, doing local delivery.\n");
				#endif
				TargetLooper = SourceWindow->getWindow();
			}
			else
			{
				#if FEVENTROUTE_DEBUG > 1
				fprintf( stderr, "fEventRoute::sendMessage() Object remote or the window itself, doing remote delivery.\n");
				#endif
				TargetLooper = fApplication::getApplication()->locateObject( TargetName);
			}
		}
	
		if( TargetLooper == NULL)
		{
			#if FEVENTROUTE_DEBUG > 2
			fprintf( stderr, "fEventRoute::sendMessage() TargetLooper == NULL\n");
			#endif

			delete Message;
			return( false);
		}
			
		// create new messenger to send message
		Messenger = new BMessenger( TargetLooper, TargetLooper , &error);
	}
	else
	{
		#if FEVENTROUTE_DEBUG > 1
		fprintf( stderr, "fEventRoute::sendMessage() Using fTargetName\n");
		#endif

		// If no signature is given the message will be delivered locally
		// a target object must exist
		if( fTargetName == NULL && fTargetPointer == NULL)
		{
			delete Message;
			return( false);
		}

		const BLooper *TargetLooper;
		
		// find the window in which the target object is located.
		if( fTargetName)
		{		
			if(( SourceWindow) && ( SourceWindow->findObject( fTargetName)))
			{
				#if FEVENTROUTE_DEBUG > 1
				fprintf( stderr, "fEventRoute::sendMessage() Object local, doing local delivery.\n");
				#endif
				TargetLooper = SourceWindow->getWindow();
			}
			else
			{
				#if FEVENTROUTE_DEBUG > 1
				fprintf( stderr, "fEventRoute::sendMessage() Object remote or the window itself, doing remote delivery.\n");
				#endif
				TargetLooper = fApplication::getApplication()->locateObject( fTargetName);
			}
		}
		else
		{		
			if(( SourceWindow) && ( SourceWindow->findObject( fTargetPointer)))
			{
				#if FEVENTROUTE_DEBUG > 1
				fprintf( stderr, "fEventRoute::sendMessage() Object local, doing local delivery.\n");
				#endif
				TargetLooper = SourceWindow->getWindow();
			}
			else
			{
				#if FEVENTROUTE_DEBUG > 1
				fprintf( stderr, "fEventRoute::sendMessage() Object remote or the window itself, doing remote delivery.\n");
				#endif
				TargetLooper = fApplication::getApplication()->locateObject( fTargetPointer);
			}
		}

		if( TargetLooper == NULL)
		{
			#if FEVENTROUTE_DEBUG > 2
			fprintf( stderr, "fEventRoute::sendMessage() TargetLooper == NULL\n");
			#endif

			delete Message;
			return( false);
		}
			
		// create new messenger to send message
		Messenger = new BMessenger( TargetLooper, TargetLooper , &error);
	}

	if( error < B_OK)
	{
		#if FEVENTROUTE_DEBUG > 2
		fprintf( stderr, "fEventRoute::sendMessage() error < B_OK\n");
		#endif

		delete Messenger;
		delete Message;
	
		return( false);
	}

	bool result = false;

	#if FEVENTROUTE_DEBUG > 2
	fprintf( stderr, "fEventRoute::sendMessage() Message to send:\n");
	Message->PrintToStream();
	printToStream();
	#endif

	if( Messenger->SendMessage( Message) == B_OK)
		result = true;

	// get rid of the messenger
	delete Messenger;

	// delete the message
	delete Message;

	#if FEVENTROUTE_DEBUG > 1
	fprintf( stderr, "fEventRoute::sendMessage() end: %s\n", result ? "true" : "false");
	#endif

	return( result);
}

void fEventRoute::setLaunchTarget( bool LaunchTarget)
{
	fLaunchTarget = LaunchTarget;
}

void fEventRoute::printToStream( void) const
{
	char temp[5]; temp[ 4] = 0x0;

	fprintf( stderr, "fEventRoute::printToStream()\n");
	*((int32 *) temp) = fEvent;
	fprintf( stderr, "	fEvent: '%s'\n", temp);
	*((int32 *) temp) = fAction;
	fprintf( stderr, "	fAction: '%s'\n", temp);
	fprintf( stderr, "	fTargetSignature: %s\n", fTargetSignature);
	fprintf( stderr, "	fTargetName: %s\n", fTargetName);
	fprintf( stderr, "	fTargetPointer: %lx\n", fTargetPointer);
	fprintf( stderr, "	fSourceName: %s\n", fSourceName);
	fprintf( stderr, "	fSourcePointer: %lx\n", fSourcePointer);
	fprintf( stderr, "	fTemplateMessage: %lx\n", fTemplateMessage);
	if( fTemplateMessage)
		fTemplateMessage->PrintToStream();
}
