// fEventRoute.h

#ifndef fEventRoute_h
#define fEventRoute_h

#include "fClassInfo.h"

#include "fMessageFilter.h"
#include "fApplication.h"

#include "fEvents.h"

#pragma export on

class fEventRoute : public fClassInfo
{
	private:

		fEventRoute( const fEventRoute &CopyObject);
		fEventRoute &operator=( const fEventRoute &CopyObject);

		ClassDeclaration( fEventRoute);

	protected:

		int32					 fEvent;

		int32					 fAction;

		char					*fTargetSignature;
		char					*fTargetName;
		const class fObject		*fTargetPointer;
		char					*fSourceName;
		const class fObject		*fSourcePointer;

		BMessage				*fTemplateMessage;

		bool					 fLaunchTarget;

		BList					 fMessageFilters;

		virtual void addDefaultFields( BMessage *Message) const;
		virtual void filterMessage( BMessage *Message) const;
		virtual team_id launchApplication( const char *TargetSignature) const;

		DoMethodDeclaration;

	public:
	
		fEventRoute( int32 Event = F_NO_EVENT);
		virtual ~fEventRoute( void);

		// Event
		virtual void setEvent( int32 Event);
		virtual int32 getEvent( void) const;
		
		// Action
		virtual void setAction( int32 Action);
		virtual int32 getAction( void) const;
		
		// TargetSignature
		virtual void setTargetSignature( const char *Signature);
		virtual const char *getTargetSignature( void) const;
		
		// TargetName
		virtual void setTargetName( const char *ObjectName);
		virtual const char *getTargetName( void) const;
		
		// TargetPointer
		virtual void setTargetPointer( const class fObject *ObjectPointer);
		virtual const class fObject *getTargetPointer( void) const;

		// SourceName		
		virtual void setSourceName( const char *ObjectName);
		virtual const char *getSourceName( void) const;

		// SourcePointer
		virtual void setSourcePointer( const class fObject *ObjectPointer);
		virtual const class fObject *getSourcePointer( void) const;
		
		// Template Message
		virtual void setTemplateMessage( BMessage *Message);
		virtual const BMessage *getTemplateMessage( void) const;
		
		// Message Filter
		virtual void addMessageFilter( fMessageFilter *MessageFilter);		

		// send Message
		virtual BMessage *getMessage( void) const;
		virtual bool sendMessage( const BMessage *Message = NULL,
									const class fWindow *SourceWindow = NULL) const;		

		// launch app ?
		virtual void setLaunchTarget( bool fLaunchTarget);

		// debugging
		virtual void printToStream( void) const;
};

#pragma export off

#endif