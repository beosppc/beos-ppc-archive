// fMessageFilter.h

#ifndef fMessageFilter_h
#define fMessageFilter_h

#include "fClassInfo.h"

#pragma export on

class fMessageFilter : public fClassInfo
{
	private:

		fMessageFilter( const fMessageFilter &CopyObject);
		fMessageFilter &operator=( const fMessageFilter &CopyObject);

		VirtualClassDeclaration( fMessageFilter);

	public:
	
		fMessageFilter( void);
		virtual ~fMessageFilter( void);

		virtual bool filterMessage( BMessage *Message) = 0;
};

#pragma export off

#endif