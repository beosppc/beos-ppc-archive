// fGroupDispatcher.h

#ifndef fGroupDispatcher_h
#define fGroupDispatcher_h

#include "fClassInfo.h"

#pragma export on

class fGroupDispatcher : public fClassInfo
{
	private:

		fGroupDispatcher( const fGroupDispatcher &CopyObject);
		fGroupDispatcher &operator=( const fGroupDispatcher &CopyObject);

		ClassDeclaration( fGroupDispatcher);

	protected:
	
		BList	fObjects;

		DoMethodDeclaration;

	public:

		fGroupDispatcher( void);
		virtual ~fGroupDispatcher( void);

		virtual void addToGroup( class fObject *Object);
		virtual void removeFromGroup( class fObject *Object);

		virtual void sendMessage( int32 Event, int32 Action, const BMessage *Message, const fObject *Source = NULL) const;
};

#pragma export off

#endif