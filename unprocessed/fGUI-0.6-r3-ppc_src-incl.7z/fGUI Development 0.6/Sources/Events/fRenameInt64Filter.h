// fRenameInt64Filter.h

#ifndef fRenameInt64Filter_h
#define fRenameInt64Filter_h

#include "fRenameFilter.h"

#pragma export on

class fRenameInt64Filter : public fRenameFilter
{
	private:

		fRenameInt64Filter( const fRenameInt64Filter &CopyObject);
		fRenameInt64Filter &operator=( const fRenameInt64Filter &CopyObject);

		ClassDeclaration( fRenameInt64Filter);

	public:
	
		fRenameInt64Filter( void);
		fRenameInt64Filter( const char *From, const char *To);
		virtual ~fRenameInt64Filter( void);

		virtual bool filterMessage( BMessage *Message);
};

#pragma export off

#endif