// fWhatFilter.h

#ifndef fWhatFilter_h
#define fWhatFilter_h

#include "fMessageFilter.h"

#pragma export on

class fWhatFilter : public fMessageFilter
{
	private:

		fWhatFilter( const fWhatFilter &CopyObject);
		fWhatFilter &operator=( const fWhatFilter &CopyObject);

		ClassDeclaration( fWhatFilter);

	protected:
	
		int32	fWhat;

		DoMethodDeclaration;

	public:
	
		fWhatFilter( void);
		fWhatFilter( int32 What);
		virtual ~fWhatFilter( void);

		void setWhat( int32 What);

		virtual bool filterMessage( BMessage *Message);
};

#pragma export off

#endif