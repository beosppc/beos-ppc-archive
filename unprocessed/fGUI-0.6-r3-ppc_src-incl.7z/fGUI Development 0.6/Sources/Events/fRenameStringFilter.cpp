// fRenameStringFilter.cpp

#include "fRenameStringFilter.h"
#include "fFactory.h"

ClassDefinition( fRenameStringFilter, fRenameFilter, "");

fRenameStringFilter::fRenameStringFilter( void)
{
}

fRenameStringFilter::fRenameStringFilter( const char *From, const char *To)
					: fRenameFilter( From, To)
{
}

fRenameStringFilter::~fRenameStringFilter( void)
{
}

bool fRenameStringFilter::filterMessage( BMessage *Message)
{
	if( Message == NULL)
		return( false);

	if( fFromName == NULL)
		return( false);

	if( fToName == NULL)
		return( false);

	const char *string = Message->FindString( fFromName);

	if( string == NULL)
		return( false);

	if( Message->AddString( fToName, string) < B_OK)
		return( false);

	Message->RemoveData( fFromName);

	return( true);
}
