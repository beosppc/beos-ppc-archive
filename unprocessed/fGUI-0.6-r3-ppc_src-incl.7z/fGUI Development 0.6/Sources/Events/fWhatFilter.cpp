// fWhatFilter.cpp

#include "fWhatFilter.h"
#include "fFactory.h"

ClassDefinition( fWhatFilter, fMessageFilter, "");

fWhatFilter::fWhatFilter( void)
{
	fWhat = 0;
}

fWhatFilter::fWhatFilter( int32 What)
{
	fWhat = What;
}

fWhatFilter::~fWhatFilter( void)
{
}

DoMethodBegin( fWhatFilter)
	DoMethodDefinitionBegin( "Text", setWhat, 1)
		DoMethodVariable( int32, What)
		DoMethodVoidCall( setWhat)( What)
	DoMethodDefinitionEnd
DoMethodEnd( fClassInfo)

void fWhatFilter::setWhat( int32 What)
{
	fWhat = What;
}

bool fWhatFilter::filterMessage( BMessage *Message)
{
	if( Message == NULL)
		return( false);

	if( fWhat == 0)
		return( false);

	Message->what = fWhat;
	
	return( true);
}