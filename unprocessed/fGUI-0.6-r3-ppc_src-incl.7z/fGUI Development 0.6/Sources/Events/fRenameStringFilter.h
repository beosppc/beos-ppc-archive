// fRenameStringFilter.h

#ifndef fRenameStringFilter_h
#define fRenameStringFilter_h

#include "fRenameFilter.h"

#pragma export on

class fRenameStringFilter : public fRenameFilter
{
	private:

		fRenameStringFilter( const fRenameStringFilter &CopyObject);
		fRenameStringFilter &operator=( const fRenameStringFilter &CopyObject);

		ClassDeclaration( fRenameStringFilter);

	public:
	
		fRenameStringFilter( void);
		fRenameStringFilter( const char *From, const char *To);
		virtual ~fRenameStringFilter( void);

		virtual bool filterMessage( BMessage *Message);
};

#pragma export off

#endif