// fGroupDispatcher.cpp

#include "fGroupDispatcher.h"

#include "fFactory.h"

#include "fObject.h"
#include "fEventRoute.h"

ClassDefinition( fGroupDispatcher, fClassInfo, "");

fGroupDispatcher::fGroupDispatcher( void)
{
}

fGroupDispatcher::~fGroupDispatcher( void)
{
}	

DoMethodBegin( fGroupDispatcher)
	DoMethodDefinitionBegin( "Child", addToGroup, 1)
		DoMethodVariableCast( fObject *, fClassInfo *, Object)
		DoMethodVoidCall( addToGroup)( Object)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "RemoveObject", removeFromGroup, 1)
		DoMethodVariableCast( fObject *, fClassInfo *, Object)
		DoMethodVoidCall( removeFromGroup)( Object)
	DoMethodDefinitionEnd
DoMethodEnd( fClassInfo)
	
void fGroupDispatcher::addToGroup( class fObject *Object)
{
	fObjects.AddItem( Object);
}

void fGroupDispatcher::removeFromGroup( class fObject *Object)
{
	fObjects.RemoveItem( Object);

	if( fObjects.CountItems() == 0)
		delete this;
}

void fGroupDispatcher::sendMessage( int32 Event, int32 Action, const BMessage *Message, const fObject *Source) const
{
	const class fWindow *ParentWindow = NULL;
	
	if( Source != NULL)
		ParentWindow = Source->getWindow();

	fEventRoute EventRoute( Event);
	EventRoute.setAction( Action);
	EventRoute.setSourcePointer( Source);

	int32 Item = 0;
	fObject *SomeObject;
	
	while(( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		if( SomeObject != Source)
		{
			EventRoute.setTargetPointer( SomeObject);
			EventRoute.sendMessage( Message, ParentWindow);
		}
	}
}