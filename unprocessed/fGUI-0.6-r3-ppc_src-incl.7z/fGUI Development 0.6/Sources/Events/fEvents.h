// fEvents.h

#ifndef fEvents_h
#define fEvents_h

enum {
	// FGUI event (in Message->what)
	FGUI_EVENT				= 'fGUI',
	F_MOUSE_THREAD_EVENT	= 'fTHR',

	// No op
	F_NO_EVENT				= 'fNOP',

	// Mouse
	F_PRIMARY_MOUSE_DOWN	= 'fMPD',
	F_SECONDARY_MOUSE_DOWN	= 'fMSD',
	F_TERTIARY_MOUSE_DOWN	= 'fMTD',

	F_PRIMARY_MOUSE_UP		= 'fMPU',
	F_SECONDARY_MOUSE_UP	= 'fMSU',
	F_TERTIARY_MOUSE_UP		= 'fMTU',

	F_MOUSE_MOVED			= 'fMMV',
	F_MOUSE_ENTERED			= 'fMEN',
	F_MOUSE_WITHIN			= 'fMIN',
	F_MOUSE_EXITED			= 'fMEX',

	// Keyboard

	F_KEY_DOWN				= 'fKDN',
	F_KEY_UP				= 'fKUP',
	
	F_GOT_FOCUS				= 'fKGF',
	F_LOST_FOCUS			= 'fKLF',

	F_CUT					= 'fCUT',
	F_COPY					= 'fCPY',
	F_PASTE					= 'fPST',

	// Window
	F_SHOW_WINDOW			= 'fSWN',
	F_HIDE_WINDOW			= 'fHWN',

	// Objects
	// Button
	F_BUTTON_CLICKED		= 'fBUT',

	// Checkbox
	F_CHECKBOX_CHECKED		= 'fCBC',
	F_CHECKBOX_TOGGLE		= 'fCBT',
	F_CHECKBOX_UNCHECKED	= 'fCBU',

	// Radiobutton
	F_RADIOBUTTON_ACTIVATED		= 'fRBA',
	F_RADIOBUTTON_DEACTIVATED	= 'fRBD',

	// Scrollbar
	F_SCROLLBAR_VALUE_CHANGED	= 'fSVC',

	F_SCROLLBAR_SMALL_INCREASE	= 'fSSI',
	F_SCROLLBAR_SMALL_DECREASE	= 'fSSD',
	F_SCROLLBAR_BIG_INCREASE	= 'fSBI',
	F_SCROLLBAR_BIG_DECREASE	= 'fSBD',

	// TextInput
	F_TEXTINPUT_VALUE_CHANGED	= 'fTVC',

	F_TEXTINPUT_CURSOR_PULSE	= 'fTIC',
	F_TEXTINPUT_MOUSE_PULSE		= 'fTIM',

	// Alarm
	F_ALARM					= 'fALM',

	// Menu
	F_MENUITEM_SELECTED		= 'fSMI',

	// Misc/General
		// set/get value
	F_SET_VALUE				= 'fVST',
	F_GET_VALUE				= 'fVGT',

		// Enable/Disable
	F_ENABLE_OBJECT			= 'fENB',
	F_DISABLE_OBJECT		= 'fDSB',

		// Active/Inactive
	F_ACTIVATE_ITEM			= 'fACT',
	F_DEACTIVATE_ITEM		= 'fDAC',

		// Focus
	F_REQUEST_GET_FOCUS		= 'fRGF',
	F_REQUEST_LOSE_FOCUS	= 'fRLF',

		// more Misc
	F_NOTIFY				= 'fNTF'
};

#endif