// fDeleteNameFilter.h

#ifndef fDeleteNameFilter_h
#define fDeleteNameFilter_h

#include "fMessageFilter.h"

#pragma export on

class fDeleteNameFilter : public fMessageFilter
{
	private:

		fDeleteNameFilter( const fDeleteNameFilter &CopyObject);
		fDeleteNameFilter &operator=( const fDeleteNameFilter &CopyObject);

		ClassDeclaration( fDeleteNameFilter);

	protected:
	
		char *fName;

		DoMethodDeclaration;

	public:
	
		fDeleteNameFilter( void);
		fDeleteNameFilter( const char *Name);
		virtual ~fDeleteNameFilter( void);

		void setName( const char *Name);

		virtual bool filterMessage( BMessage *Message);
};

#pragma export off

#endif