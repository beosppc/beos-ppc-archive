// fDeleteNameFilter.cpp

#include "fDeleteNameFilter.h"
#include "fFactory.h"

ClassDefinition( fDeleteNameFilter, fMessageFilter, "");

fDeleteNameFilter::fDeleteNameFilter( void)
{
	fName = NULL;
}

fDeleteNameFilter::fDeleteNameFilter( const char *Name)
{
	fName = NULL;
	setName( Name);
}

fDeleteNameFilter::~fDeleteNameFilter( void)
{
	delete [] fName;
}

DoMethodBegin( fDeleteNameFilter)
	DoMethodDefinitionBegin( "Name", setName, 1)
		DoMethodVariable( char *, Name)
		DoMethodVoidCall( setName)( Name)
	DoMethodDefinitionEnd
DoMethodEnd( fMessageFilter)

void fDeleteNameFilter::setName( const char *Name)
{
	delete [] Name;

	if( Name)
	{
		fName = new char[ strlen( Name) + 1];
		strcpy( fName, Name);
	}
	else
		fName = NULL;
}

bool fDeleteNameFilter::filterMessage( BMessage *Message)
{
	if( Message == NULL)
		return( false);

	if( fName == NULL)
		return( false);

	if( Message->RemoveName( fName) < B_OK)
		return( false);
	
	return( true);
}
