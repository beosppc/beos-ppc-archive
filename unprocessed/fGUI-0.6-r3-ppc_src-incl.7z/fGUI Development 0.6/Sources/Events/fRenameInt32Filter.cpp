// fRenameInt32Filter.cpp

#include "fRenameInt32Filter.h"
#include "fFactory.h"

ClassDefinition( fRenameInt32Filter, fRenameFilter, "");

fRenameInt32Filter::fRenameInt32Filter( void)
{
}

fRenameInt32Filter::fRenameInt32Filter( const char *From, const char *To)
					: fRenameFilter( From, To)
{
}

fRenameInt32Filter::~fRenameInt32Filter( void)
{
}

bool fRenameInt32Filter::filterMessage( BMessage *Message)
{
	if( Message == NULL)
		return( false);

	if( fToName == NULL)
		return( false);

	if( fToName == NULL)
		return( false);

	int32 value;
	
	if( Message->FindInt32( fToName, &value) < B_OK)
		return( false);

	if( Message->AddInt32( fToName, value) < B_OK)
		return( false);

	Message->RemoveData( fToName);
	
	return( true);
}
