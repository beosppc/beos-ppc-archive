// fRenameFilter.cpp

#include "fRenameFilter.h"

VirtualClassDefinition( fRenameFilter, fMessageFilter);

fRenameFilter::fRenameFilter( void)
{
	fFromName	= NULL;
	fToName	= NULL;
}

fRenameFilter::fRenameFilter( const char *FromName, const char *ToName)
{
	fFromName	= NULL;
	setFromName( FromName);

	fToName	= NULL;
	setToName( ToName);
}

fRenameFilter::~fRenameFilter( void)
{
	delete [] fFromName;
	delete [] fToName;
}

DoMethodBegin( fRenameFilter)
	DoMethodDefinitionBegin( "From", setFromName, 1)
		DoMethodVariable( char *, FromName)
		DoMethodVoidCall( setFromName)( FromName)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "To", setToName, 1)
		DoMethodVariable( char *, ToName)
		DoMethodVoidCall( setToName)( ToName)
	DoMethodDefinitionEnd
DoMethodEnd( fMessageFilter)

void fRenameFilter::setFromName( const char *FromName)
{
	delete [] fFromName;

	if( FromName)
	{
		fFromName = new char[ strlen( FromName) + 1];
		strcpy( fFromName, FromName);
	}
	else
		fFromName = NULL;
}

void fRenameFilter::setToName( const char *ToName)
{
	delete [] fToName;

	if( ToName)
	{
		fToName = new char[ strlen( ToName) + 1];
		strcpy( fToName, ToName);
	}
	else
		fToName = NULL;
}

