// fRenameInt64Filter.cpp

#include "fRenameInt64Filter.h"
#include "fFactory.h"

ClassDefinition( fRenameInt64Filter, fRenameFilter, "");

fRenameInt64Filter::fRenameInt64Filter( void)
{
}

fRenameInt64Filter::fRenameInt64Filter( const char *From, const char *To)
					: fRenameFilter( From, To)
{
}

fRenameInt64Filter::~fRenameInt64Filter( void)
{
}

bool fRenameInt64Filter::filterMessage( BMessage *Message)
{
	if( Message == NULL)
		return( false);

	if( fFromName == NULL)
		return( false);

	if( fToName == NULL)
		return( false);

	int64 value;
	
	if( Message->FindInt64( fFromName, &value) < B_OK)
		return( false);

	if( Message->AddInt64( fToName, value) < B_OK)
		return( false);

	Message->RemoveData( fFromName);
	
	return( true);
}
