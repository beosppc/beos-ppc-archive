// fRenameFilter.h

#ifndef fRenameFilter_h
#define fRenameFilter_h

#include "fMessageFilter.h"

#pragma export on

class fRenameFilter : public fMessageFilter
{
	private:

		fRenameFilter( const fRenameFilter &CopyObject);
		fRenameFilter &operator=( const fRenameFilter &CopyObject);

		VirtualClassDeclaration( fRenameFilter);

	protected:
	
		char *fFromName;
		char *fToName;

		DoMethodDeclaration;

	public:
	
		fRenameFilter( void);
		fRenameFilter( const char *From, const char *To);
		virtual ~fRenameFilter( void);

		void setFromName( const char *FromName);
		void setToName( const char *ToName);

		virtual bool filterMessage( BMessage *Message) = 0;
};

#pragma export off

#endif