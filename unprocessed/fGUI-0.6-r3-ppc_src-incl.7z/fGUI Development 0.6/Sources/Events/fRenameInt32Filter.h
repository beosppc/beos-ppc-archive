// fRenameInt32Filter.h

#ifndef fRenameInt32Filter_h
#define fRenameInt32Filter_h

#include "fRenameFilter.h"

#pragma export on

class fRenameInt32Filter : public fRenameFilter
{
	private:

		fRenameInt32Filter( const fRenameInt32Filter &CopyObject);
		fRenameInt32Filter &operator=( const fRenameInt32Filter &CopyObject);

		ClassDeclaration( fRenameInt32Filter);

	public:
	
		fRenameInt32Filter( void);
		fRenameInt32Filter( const char *From, const char *To);
		virtual ~fRenameInt32Filter( void);

		virtual bool filterMessage( BMessage *Message);
};

#pragma export off

#endif