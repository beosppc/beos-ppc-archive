// fMessageFilter.cpp

#include "fMessageFilter.h"

#include "fFactory.h"

VirtualClassDefinition( fMessageFilter, fClassInfo);

fMessageFilter::fMessageFilter( void)
{
}

fMessageFilter::~fMessageFilter( void)
{
}