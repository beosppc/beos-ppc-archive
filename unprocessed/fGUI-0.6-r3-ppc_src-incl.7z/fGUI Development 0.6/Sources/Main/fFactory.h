// fFactory.h

#ifndef fFactory_h
#define fFactory_h

#include <List.h>

#pragma export on

class fFactory
{
	private:
	
		fFactory( const fFactory &CopyObject);
		fFactory &operator=( const fFactory &CopyObject);

		fFactory( void);
		virtual ~fFactory( void);

		static fFactory	*Factory;

		class fClassInfo *createInstance_Builder( const char *ClassName) const;
		friend class fBuilderObject;

	protected:

		char					*fDefaultStyle;
		BList					 fStyleFactories;

		class fStyleFactory		*fDefaultFactory;
		class fBuilder			*fGUIBuilder;

	public:

		static fFactory * const getFactory( void);

		void setDefaultStyle( const char *DefaultStyle);

		virtual void registerClass( class fClassInfo *Class, const char *StyleName = "");
		
		virtual class fClassInfo *createInstance( const char *ClassName) const;
		virtual bool importGUIDescription( const char *GUIDescriptionFile);
};

#pragma export off

#endif