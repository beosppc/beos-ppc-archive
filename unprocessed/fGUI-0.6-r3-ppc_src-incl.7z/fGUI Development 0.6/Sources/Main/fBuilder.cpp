// fBuilder.cpp

#include "fBuilder.h"
#include "fFactory.h"
#include "fClassInfo.h"

#include <ctype.h>


#ifdef DEBUG
#define DEBUG_FBUILDER
#endif

//#define DEBUG_FBUILDER

class fBuilderArgument
{
	private:
		// The string this object is a wrapper for.

		char *argumentName;

	public:
		fBuilderArgument( char *Name);
		virtual ~fBuilderArgument( void);

		// Debug printout.

		virtual void printToStream( fBuilder *Builder) const;

		// Create an instance of this fBuilderArgument. If argumentName
		// is the name of a define, the matching fBuilderArgument is fetched
		// and the call is passed on to that object.
 
		virtual fArgument *createInstance( fBuilder *Builder) const;

		// Returns the name of this fBuilderArgument

		const char *getName( void) const;
};

class fBuilderObject : public fBuilderArgument
{
	private:
		// The list of methodcalls that have to be done after instantiation
		// of the object that is described by this fBuilderObject. In this
		// list you will always find a string with the name of the method
		// followed by a pointer to a BList with the fBuilderArguments (or
		// fBuilderObjects) that are the arguments of this method call.

		BList methodCalls;

	public:
		fBuilderObject( char *Name);
		virtual ~fBuilderObject( void);

		// Debug printout.

		virtual void printToStream( fBuilder *Builder) const;



		virtual fArgument *createInstance( fBuilder *Builder) const;

		// Add a method call to this fBuilderObject.

		void addMethodCall( char *Name, BList *Arguments);
};


fBuilderArgument::fBuilderArgument( char *Name)
{
	argumentName = Name;
}

fBuilderArgument::~fBuilderArgument( void)
{
	#ifdef DEBUG_FBUILDER
	fprintf( stderr, "fBuilderArgument::~fBuilderArgument()\n");
	#endif

	delete [] argumentName;
}

void fBuilderArgument::printToStream( fBuilder *Builder) const
{
	// Is this just a label for a define?

	fBuilderArgument *RealArgument;

	if(( RealArgument = ( fBuilderArgument *) Builder->findArgument( argumentName)))
	{
		RealArgument->printToStream( Builder);
	}
	else
	{
		fprintf( stderr, argumentName);
	}
}

fArgument *fBuilderArgument::createInstance( fBuilder *Builder) const
{
	#ifdef DEBUG_FBUILDER
	fprintf( stderr, "fBuilderArgument::createInstance() \"%s\"\n", getName());
	#endif

	// Is this just a label for a define?

	fBuilderArgument *RealArgument;

	if(( RealArgument = ( fBuilderArgument *) Builder->findArgument( argumentName)))
	{
		#ifdef DEBUG_FBUILDER
		fprintf( stderr, "fBuilderArgument::createInstance() \"%s\" end, resolved\n", getName());
		#endif

		return( RealArgument->createInstance( Builder));
	}
	else
	{
		#ifdef DEBUG_FBUILDER
		fprintf( stderr, "fBuilderArgument::createInstance() \"%s\" end\n", getName());
		#endif

		return( new fArgument( argumentName));
	}
}

const char *fBuilderArgument::getName( void) const
{
	return( argumentName);
}


fBuilderObject::fBuilderObject( char *Name)
              : fBuilderArgument( Name)
{
}

fBuilderObject::~fBuilderObject( void)
{
	// Clear list.

	char *DeadName;
	BList *DeadArguments;

	while(( DeadName		= ( char *)		methodCalls.RemoveItem(( int32) 0)) &&
	      ( DeadArguments	= ( BList *)	methodCalls.RemoveItem(( int32) 0))    )
	{
		delete [] DeadName;

		fBuilderArgument *DeadArgument;

		while(( DeadArgument = ( fBuilderArgument *) DeadArguments->RemoveItem(( int32) 0)))
		{
			delete DeadArgument;
		}

		delete DeadArguments;
	}
}

void fBuilderObject::printToStream( fBuilder *Builder) const
{
	fprintf( stderr, getName());

	fprintf( stderr, "( ");

	char *ArgumentName;
	BList *Arguments;

	int32 Count = 0;

	while(( ArgumentName	= ( char *)		methodCalls.ItemAt( Count++)) &&
	      ( Arguments		= ( BList *)	methodCalls.ItemAt( Count++))    )
	{
		if( Count >= 3)	fprintf( stderr, ", ");

		fprintf( stderr, ArgumentName);

		int32 Count = 0;

		fBuilderArgument *Argument;

		while(( Argument = ( fBuilderArgument *) Arguments->ItemAt( Count++)))
		{
			fprintf( stderr, " ");

			Argument->printToStream( Builder);
		}
	}

	fprintf( stderr, ")");
}

fArgument *fBuilderObject::createInstance( fBuilder *Builder) const
{
	#ifdef DEBUG_FBUILDER
	fprintf( stderr, "fBuilderObject::createInstance() \"%s\"\n", getName());
	#endif

	fClassInfo *NewObject;

	if(( NewObject = fFactory::getFactory()->createInstance_Builder( getName())))
	{
		char *MethodName;
		BList *Arguments;

		int32 Count = 0;

		while(( MethodName	= ( char *)		methodCalls.ItemAt( Count++)) &&
		      ( Arguments	= ( BList *)	methodCalls.ItemAt( Count++))    )
		{
			BList fArguments;

			int32 Count = 0;

			fBuilderArgument *Argument;

			while(( Argument = ( fBuilderArgument *) Arguments->ItemAt( Count++)))
			{
				fArgument *NewfArgument;

				if(( NewfArgument = Argument->createInstance( Builder)))
				{
					fArguments.AddItem( NewfArgument);
				}
			}

			if( !NewObject->doMethod( MethodName, fArguments).getValid())
			{
				#ifdef DEBUG_FBUILDER
				fprintf( stderr, "fBuilderObject::createInstance() doMethod( \"%s\") failed\n", MethodName);
				#endif

				// Clear list

				fArgument *OldfArgument;

				while(( OldfArgument = ( fArgument *) fArguments.RemoveItem(( int32) 0)))
				{
					// It works. Trust me.

					delete static_cast< fClassInfo *>( *OldfArgument);
					delete OldfArgument;
				}
			}
			else
			{
				// Clear list

				fArgument *OldfArgument;

				while(( OldfArgument = static_cast< fArgument *>( fArguments.RemoveItem(( int32) 0))))
					delete OldfArgument;
			}
		}

		#ifdef DEBUG_FBUILDER
		fprintf( stderr, "fBuilderObject::createInstance() \"%s\" end\n", getName());
		#endif

		return( new fArgument( NewObject));
	}

	#ifdef DEBUG_FBUILDER
	fprintf( stderr, "fBuilderObject::createInstance() \"%s\" end, failed\n", getName());
	#endif

	return( NULL);
}

void fBuilderObject::addMethodCall( char *Name, BList *Arguments)
{
	methodCalls.AddItem( Name);
	methodCalls.AddItem( Arguments);
}



fBuilder::fBuilder()
{
}

fBuilder::~fBuilder()
{
	// Clear list.

	char *DeadName;
	fBuilderArgument *DeadArgument;

	while(( DeadName		= ( char *)				definedObjects.RemoveItem(( int32) 0)) &&
	      ( DeadArgument	= ( fBuilderArgument *)	definedObjects.RemoveItem(( int32) 0))    )
	{
		delete [] DeadName;
		delete DeadArgument;
	}
}

fClassInfo *fBuilder::createInstance( const char *ObjectName)
{
	#ifdef DEBUG_FBUILDER
	fprintf( stderr, "fBuilder::createInstance( %s)\n", ObjectName);
	#endif

	fBuilderArgument *definedObject;

	if(( definedObject = findArgument( ObjectName)))
	{
		if( is_instance_of( definedObject, fBuilderObject))
		{
			return( createInstance(( fBuilderObject *) definedObject));
		}
	}

	return( NULL);
}

fClassInfo *fBuilder::createInstance( fBuilderObject *DefinedObject)
{
	#ifdef DEBUG_FBUILDER
	DefinedObject->printToStream( this);
	#endif

	fArgument *NewArgument;

	if(( NewArgument = DefinedObject->createInstance( this)))
	{
		fClassInfo *NewfClassInfo;

		if(( NewfClassInfo = *NewArgument))
		{
			delete NewArgument;

			return( NewfClassInfo);
		}
	}

	return( NULL);
}

class fBuilderArgument *fBuilder::findArgument( const char *ObjectName)
{
	uint32 Count = 0;

	char *definedObjectName;

	while(( definedObjectName = ( char *) definedObjects.ItemAt( Count)))
	{
		if( !strcmp( definedObjectName, ObjectName))
		{
			fBuilderObject *definedObject;

			if(( definedObject = ( fBuilderObject *) definedObjects.ItemAt( Count + 1)))
			{
				return( definedObject);
			}
		}

		Count += 2;
	}

	return( NULL);
}

bool fBuilder::importGUIDescription( const char *GUIDescriptionName)
{
	#ifdef DEBUG_FBUILDER
	fprintf( stderr, "fBuilder::importGUIDescription(%s)\n", GUIDescriptionName);
	#endif

	tokenBufferPosition	= 0;
	tokenBuffer[ 0 ]	= 0x00;

	BFile *GUIDescriptionFile = new BFile( GUIDescriptionName, B_READ_ONLY);

	if( GUIDescriptionFile->InitCheck() == B_NO_ERROR)
	{
		// First we expect an object and an opening bracket, so we fetch for them.

		char *Token;

		while(( Token = getToken( GUIDescriptionFile)))
		{
			if( !strcasecmp( Token, "#define"))
			{
				delete [] Token;

				char *DefineName;

				if(( DefineName = getToken( GUIDescriptionFile)))
				{
					char *ObjectName;

					if(( ObjectName = getToken( GUIDescriptionFile)))
					{
						char *Token;

						if(( Token = getToken( GUIDescriptionFile)))
						{
							if( !strcmp( Token, "(") ||
							    !strcmp( Token, "{")    )
							{
								#ifdef DEBUG_FBUILDER
								fprintf( stderr, "fBuilder::importGUIDescription() createObject( %s, %s)\n", DefineName, ObjectName);
								#endif

								fBuilderObject *NewObject = new fBuilderObject( strcpy( new char [ strlen( ObjectName) + 1 ], ObjectName));

								definedObjects.AddItem( strcpy( new char [ strlen( DefineName) + 1 ], DefineName));
								definedObjects.AddItem( NewObject);

								if( !doMethods( GUIDescriptionFile, NewObject))
								{
									delete [] DefineName;
									delete [] ObjectName;
									delete [] Token;

									delete GUIDescriptionFile;

									#ifdef DEBUG_FBUILDER
									fprintf( stderr, "fBuilder::importGUIDescription() doMethods() failed, end\n");
									#endif

									return( false);
								}
							}
							else
							{
								#ifdef DEBUG_FBUILDER
								fprintf( stderr, "fBuilder::importGUIDescription() syntax error near %s, end\n", ObjectName);
								#endif

								delete [] DefineName;
								delete [] ObjectName;
								delete [] Token;

								delete GUIDescriptionFile;

								return( false);
							}

							delete [] Token;
						}
						else
						{
							#ifdef DEBUG_FBUILDER
							fprintf( stderr, "fBuilder::importGUIDescription() unexpected end of file near %s\n", ObjectName);
							#endif
						}

						delete [] ObjectName;
					}

					delete [] DefineName;
				}
			}
			else delete [] Token;
		}			

		delete GUIDescriptionFile;
	}
	else
	{
		#ifdef DEBUG_FBUILDER
		fprintf( stderr, "fBuilder::importGUIDescription() unable to open file, end\n");
		#endif

		return( false);
	}

	#ifdef DEBUG_FBUILDER
	fprintf( stderr, "fBuilder::importGUIDescription() end\n");
	#endif

	return( true);
}

bool fBuilder::doMethods( BFile *GUIDescriptionFile, fBuilderObject *CurrentObject)
{
	#ifdef DEBUG_FBUILDER
	fprintf( stderr, "fBuilder::doMethods()\n");
	#endif

	// We expect a comma separated list of methods with arguments,
	// end by a ).

	bool ExpectingMethod = true;

	char *Token;
	char *MethodName = NULL;

	BList *ArgumentList = new BList();

	while(( Token = getToken( GUIDescriptionFile)))
	{
		if( !strcmp( Token, ")") ||
		    !strcmp( Token, "}")    )
		{
			// End of Object definition.

			delete [] Token;

			// Execute method.

			if( MethodName)
			{
				#ifdef DEBUG_FBUILDER
				fprintf( stderr, "fBuilder::doMethods() fClassInfo->doMethod( %s, ArgumentList)\n", MethodName);
				#endif

				CurrentObject->addMethodCall( MethodName, ArgumentList);
			}

			#ifdef DEBUG_FBUILDER
			fprintf( stderr, "fBuilder::doMethods() end\n");
			#endif

			return( true);
		}
		else if( !strcmp( Token, ","))
		{
			// End of method.

			delete [] Token;

			// If ExpectingMethod was set, this is a syntax error. But we just skip.

			if( !ExpectingMethod)
			{
				// Execute method.

				#ifdef DEBUG_FBUILDER
				fprintf( stderr, "fBuilder::doMethods() fClassInfo->doMethod( %s, ArgumentList)\n", MethodName);
				#endif

				CurrentObject->addMethodCall( MethodName, ArgumentList);

				ArgumentList = new BList();
				MethodName = NULL;

				ExpectingMethod = true;
			}
		}
		else if( ExpectingMethod)
		{
			// This must be the method name.

			MethodName = Token;

			ExpectingMethod = false;
		}
		else if( !strcmp( Token, "(") || 
		         !strcmp( Token, "{")    )
		{
			// This is somewhat difficult. This is an error if we are still searching
			// for the method name. If we have one, there must be must be minimum one
			// token in the ArgumentList, that is the name of this class.

			delete [] Token;

			uint32 LastItem;

			if( ExpectingMethod ||
				!( LastItem = ArgumentList->CountItems()))
			{
				// Syntax error!

				break;
			}
			else
			{
				// Remove the last item and interpret it as object.

				fBuilderArgument *ClassName = ( fBuilderArgument *) ArgumentList->RemoveItem( LastItem - 1);

				if( is_instance_of( ClassName, fBuilderArgument))
				{
					#ifdef DEBUG_FBUILDER
					fprintf( stderr, "fBuilder::doMethods() createObject( %s)\n", ClassName->getName());
					#endif

					fBuilderObject *NewObject = new fBuilderObject( strcpy( new char [ strlen( ClassName->getName()) + 1 ], ClassName->getName()));

					ArgumentList->AddItem( NewObject);

					delete ClassName;

					if( !doMethods( GUIDescriptionFile, NewObject))
					{
						#ifdef DEBUG_FBUILDER
						fprintf( stderr, "fBuilder::doMethods() doMethods() failed, break\n");
						#endif

						break;
					}
				}
				else
				{
					delete ClassName;

					#ifdef DEBUG_FBUILDER
					fprintf( stderr, "fBuilder::doMethods() ClassName is no argument, break\n");
					#endif

					break;				
				}
			}
		}
		else
		{
			ArgumentList->AddItem( new fBuilderArgument( Token));
		}
	}

	// If we exit this way, we had an unexpected eof.

	#ifdef DEBUG_FBUILDER
	fprintf( stderr, "fBuilder::doMethods() unexpected end of file, end\n");
	#endif

	if( !ExpectingMethod && MethodName) delete [] MethodName;

	// Clear list.

	fBuilderArgument *DeadArgument;

	while( DeadArgument	= ( fBuilderArgument *) ArgumentList->RemoveItem(( int32) 0))
	{
		delete DeadArgument;
	}

	delete ArgumentList;

	return( false);
}

char *fBuilder::getToken( BFile *GUIDescriptionFile)
{
	#ifdef DEBUG_FBUILDER
	fprintf( stderr, "fBuilder::getToken()\n");
	#endif

	if( !tokenBuffer[ tokenBufferPosition])
	{
		// Refetch data!

		uint32 ReadSize = GUIDescriptionFile->Read( tokenBuffer, sizeof( tokenBuffer) - 1);

		// If there was no data available, return NULL.

		if( ReadSize <= 0)
		{
			#ifdef DEBUG_FBUILDER
			fprintf( stderr, "fBuilder::getToken() read failed, end\n");
			#endif

			return( NULL);
		}

		// Reset tokenBufferPosition and terminate Buffer.

		tokenBuffer[ ReadSize ] = 0x00;

		tokenBufferPosition = 0x00;
	}

	// Skip all whitespace and find next token.

	while( tokenBuffer[ tokenBufferPosition ] &&
	       isspace( tokenBuffer[ tokenBufferPosition ]))
	{
		tokenBufferPosition++;
	}

	// If we run into the end of the array here, we just recall ourself, this
	// will refetch some more data and retry the operation.

	if( !tokenBuffer[ tokenBufferPosition ])
	{
		char *ResultToken = getToken( GUIDescriptionFile);

		#ifdef DEBUG_FBUILDER
		fprintf( stderr, "fBuilder::getToken() refetched, end\n");
		#endif

		return( ResultToken);
	}

	// Now we check wether the first char is an EOT. These are single char token
	// and need to be detected here: ( {

	switch( tokenBuffer[ tokenBufferPosition ])
	{
		case ',':
		case '(':
		case ')':
		case '{':
		case '}':
		{
			char *ResultToken = new char [ 2 ];

			ResultToken[ 0 ] = tokenBuffer[ tokenBufferPosition ];
			ResultToken[ 1 ] = 0x00;

			tokenBufferPosition++;

			#ifdef DEBUG_FBUILDER
			fprintf( stderr, "fBuilder::getToken() ResultToken = %s, end\n", ResultToken);
			#endif

			return( ResultToken);
		}
		break;
	}

	// If we find a //, we have to skip everything until we reach the end of the line.

	if( tokenBuffer[ tokenBufferPosition ] == '/')
	{
		tokenBufferPosition++;

		// If we reach the end of the buffer we fetch for more.

		if( !tokenBuffer[ tokenBufferPosition ])
		{
			// Refetch data!

			uint32 ReadSize = GUIDescriptionFile->Read( tokenBuffer + 1, sizeof( tokenBuffer) - 2);

			// If there was no data available, everything ends here.

			if( ReadSize <= 0)
			{
				return( NULL);
			}

			// Reset tokenBufferPosition and terminate Buffer. Keep the already
			// detected /.

			tokenBuffer[ ReadSize + 1 ] = 0x00;
			tokenBuffer[ 0 ] = '/';

			tokenBufferPosition = 0x01;
		}

		if( tokenBuffer[ tokenBufferPosition ] == '/')
		{
			do
			{
				// If we reach the end of the buffer we fetch for more.

				if( !tokenBuffer[ tokenBufferPosition ])
				{
					// Refetch data!

					uint32 ReadSize = GUIDescriptionFile->Read( tokenBuffer, sizeof( tokenBuffer) - 1);

					// If there was no data available, everything ends here.

					if( ReadSize <= 0)
					{
						return( NULL);
					}

					// Reset tokenBufferPosition and terminate Buffer.

					tokenBuffer[ ReadSize ] = 0x00;

					tokenBufferPosition = 0x00;
				}
				else
				{
					tokenBufferPosition++;
				}
			}
			while(( tokenBuffer[ tokenBufferPosition ] != '\r') &&
			      ( tokenBuffer[ tokenBufferPosition ] != '\n')   );

			// After we are done with the comment, we expect a new token, so we refetch.

			#ifdef DEBUG_FBUILDER
			fprintf( stderr, "fBuilder::getToken() skipping comment, end\n");
			#endif

			char *ResultToken = getToken( GUIDescriptionFile);

			return( ResultToken);
		}

		tokenBufferPosition--;
	}


	// If we find a quotation, we will start skipping everything until we
	// find the matching quotation. The quotation itself is skipped.

	if( tokenBuffer[ tokenBufferPosition ] == '"')
	{
		char *SavedToken = new char [ 1 ];
		SavedToken[ 0 ] = 0x00;

		uint32 TokenStart = ++tokenBufferPosition;

		// If this is true, we found an \ and the next char is escaped.
		bool EscapeDetected = false;

		do
		{
			// If we reach the end of the buffer, we copy everything into the
			// SavedToken and fetch for more.
		
			if( !tokenBuffer[ tokenBufferPosition ])
			{
				#ifdef DEBUG_FBUILDER
				fprintf( stderr, "fBuilder::getToken() saving; SavedToken = %s, end\n", SavedToken);
				#endif

				if( EscapeDetected)
				{
					tokenBufferPosition--;
				}

				// We will safe what we have read so far and fetch for more data.

				uint32 SavedTokenSize		= strlen( SavedToken);
				uint32 NewSavedTokenSize	= tokenBufferPosition - TokenStart;

				char *NewSavedToken = new char [ SavedTokenSize + NewSavedTokenSize + 1 ];

				memcpy( NewSavedToken, SavedToken, SavedTokenSize);
				memcpy( NewSavedToken + SavedTokenSize, &tokenBuffer[ TokenStart ], NewSavedTokenSize);

				NewSavedToken[ SavedTokenSize + NewSavedTokenSize ] = 0x00;

				delete [] SavedToken;

				SavedToken = NewSavedToken;

				#ifdef DEBUG_FBUILDER
				fprintf( stderr, "fBuilder::getToken() refetching; SavedToken = %s, end\n", SavedToken);
				#endif

				// Refetch data!

				uint32 ReadSize = GUIDescriptionFile->Read( tokenBuffer, sizeof( tokenBuffer) - 1);

				// If there was no data available, the token ends here.

				if( ReadSize <= 0)
				{
					#ifdef DEBUG_FBUILDER
					fprintf( stderr, "fBuilder::getToken() reload failed; Token = %s, end\n", SavedToken);
					#endif

					return( SavedToken);
				}

				// Reset tokenBufferPosition and terminate Buffer.

				tokenBuffer[ ReadSize ] = 0x00;

				tokenBufferPosition = 0;
				TokenStart = 0x00;
			}
			else if( tokenBuffer[ tokenBufferPosition ] == '\\')
			{
				EscapeDetected = true;

				tokenBufferPosition++;
			}
			else if( EscapeDetected)
			{
				// We're in escaped mode and take the next char as it is.
				// If this is the first char, the escape char was already skipped.

				if( tokenBufferPosition)
				{
					// Skip this quotation and remove the escape char.

					memmove( &tokenBuffer[ TokenStart + 1 ], &tokenBuffer[ TokenStart ], tokenBufferPosition - TokenStart - 1);

					TokenStart++;
					tokenBufferPosition += 2;
				}
				else
				{
					tokenBufferPosition++;
				}

				EscapeDetected = false;
			}
			else
			{
				tokenBufferPosition++;
			}
		}
		while(( tokenBuffer[ tokenBufferPosition ] != '"') ||
		      EscapeDetected                                  );


		// Attach SavedToken and what we've scanned and return it.

		uint32 SavedTokenSize		= strlen( SavedToken);
		uint32 ResultPartTokenSize	= tokenBufferPosition - TokenStart;

		char *ResultToken = new char [ SavedTokenSize + ResultPartTokenSize + 1 ];

		memcpy( ResultToken, SavedToken, SavedTokenSize);
		memcpy( ResultToken + SavedTokenSize, &tokenBuffer[ TokenStart ], ResultPartTokenSize);

		ResultToken[ SavedTokenSize + ResultPartTokenSize ] = 0x00;

		delete [] SavedToken;

		#ifdef DEBUG_FBUILDER
		fprintf( stderr, "fBuilder::getToken() ResultToken = %s, end\n", ResultToken);
		#endif

		// Skip quotation mark.

		tokenBufferPosition++;

		return( ResultToken);
	}


	uint32 TokenStart = tokenBufferPosition++;

	// Now proceed to the end of the token.
	// EOT's are 0x00, !space and ( {

	while( tokenBuffer[ tokenBufferPosition ]				&&
	       !isspace( tokenBuffer[ tokenBufferPosition ])	&&
	       ( tokenBuffer[ tokenBufferPosition ] != ',')		&&
	       ( tokenBuffer[ tokenBufferPosition ] != '(')		&&
	       ( tokenBuffer[ tokenBufferPosition ] != ')')		&&
	       ( tokenBuffer[ tokenBufferPosition ] != '{')		&&
	       ( tokenBuffer[ tokenBufferPosition ] != '}')		   )
	{
		tokenBufferPosition++;
	}

	// If we run into the end of the buffer here, we are in trouble!

	if( !tokenBuffer[ tokenBufferPosition ])
	{
		// We will safe what we have read so far and fetch for more data. Then
		// we check the first char to find out wether our token continous. If
		// it does, we recall ourself and then reattach the two parts.

		uint32 SavedTokenSize = tokenBufferPosition - TokenStart;

		char *SavedToken = new char [ SavedTokenSize + 1 ];

		memcpy( SavedToken, &tokenBuffer[ TokenStart ], SavedTokenSize);

		SavedToken[ SavedTokenSize ] = 0x00;


		// Refetch data!

		uint32 ReadSize = GUIDescriptionFile->Read( tokenBuffer, sizeof( tokenBuffer) - 1);

		// If there was no data available, the token ends here.

		if( ReadSize <= 0)
		{
			#ifdef DEBUG_FBUILDER
			fprintf( stderr, "fBuilder::getToken() reload failed; Token = %s, end\n", SavedToken);
			#endif

			return( SavedToken);
		}

		// Reset tokenBufferPosition and terminate Buffer.

		tokenBuffer[ ReadSize ] = 0x00;

		tokenBufferPosition = 0x00;


		// Now check wether our token ends here by looking ahead to the next char.
		// EOT's are 0x00, !space or ( {

		if( !tokenBuffer[ 0 ]			||
	        isspace( tokenBuffer[ 0 ])	||
	        ( tokenBuffer[ 0 ] == ',')	||
	        ( tokenBuffer[ 0 ] == '(')	||
	        ( tokenBuffer[ 0 ] == ')')	||
	        ( tokenBuffer[ 0 ] == '{')	||
	        ( tokenBuffer[ 0 ] == '}')	   )
		{
			// Return just what we have.

			#ifdef DEBUG_FBUILDER
			fprintf( stderr, "fBuilder::getToken() reload useless; Token = %s, end\n", SavedToken);
			#endif

			return( SavedToken);
		}


		// Call the refetch.

		char *RefetchToken = getToken( GUIDescriptionFile);

		if( !RefetchToken)
		{
			#ifdef DEBUG_FBUILDER
			fprintf( stderr, "fBuilder::getToken() refetch failed; Token = %s, end\n", SavedToken);
			#endif

			return( SavedToken);
		}

		// Reattach the parts.

		uint32 RefetchTokenSize = strlen( RefetchToken);

		char *ResultToken = new char [ SavedTokenSize + RefetchTokenSize + 1 ];

		memcpy( ResultToken, SavedToken, SavedTokenSize);
		memcpy( ResultToken + SavedTokenSize, RefetchToken, RefetchTokenSize);

		ResultToken[ SavedTokenSize + RefetchTokenSize ] = 0x00;

		delete [] SavedToken;
		delete [] RefetchToken;

		#ifdef DEBUG_FBUILDER
		fprintf( stderr, "fBuilder::getToken() refetched; Token = %s, end\n", ResultToken);
		#endif

		return( ResultToken);
	}


	uint32 TokenSize = tokenBufferPosition - TokenStart;

	char *ResultToken = new char [ TokenSize + 1 ];

	memcpy( ResultToken, &tokenBuffer[ TokenStart ], TokenSize);

	ResultToken[ TokenSize ] = 0x00;

	#ifdef DEBUG_FBUILDER
	fprintf( stderr, "fBuilder::getToken() ResultToken = %s, end\n", ResultToken);
	#endif

	return( ResultToken);
}