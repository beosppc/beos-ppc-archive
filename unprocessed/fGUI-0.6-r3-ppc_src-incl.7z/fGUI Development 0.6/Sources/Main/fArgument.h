// fArgument.h

#ifndef fArgument_h
#define fArgument_h

#pragma export on

class fArgument
{
	private:

		fArgument( const fArgument &Argument);
		fArgument &operator =( const fArgument &Argument);

	protected:

		union
		{
			char				*fCharPointer;
			class fClassInfo	*fClassInfoPointer;
		} fValue;

		enum fArgumentType
		{
			fArgumentCharType,
			fArgumentClassInfoType
		};
		
		fArgumentType fType;
		bool fValid;

	public:

		fArgument( void);

		fArgument( char *Value);
		fArgument( class fClassInfo *Value);

		fArgument &operator =( char *Value);
		fArgument &operator =( class fClassInfo *Value);

		bool isValid( void) const;

		operator bool( void);
		operator int32( void);
		operator uint32( void);
		operator float( void);
		operator double( void);
		operator char *( void);
		operator class fClassInfo *( void);
};

#pragma export off

#endif
