// fDoMethod.h

#ifndef fDoMethod_h
#define fDoMethod_h

#include "fArgument.h"
#include "fReturnValue.h"

#define DoMethodDeclaration\
	public:\
		virtual fReturnValue doMethod( const char *MethodName, const BList &Arguments)

#define DoMethodBegin( Class)\
fReturnValue Class::doMethod( const char *MethodName, const BList &Arguments)\
{\
	fReturnValue ReturnValue;\
\
	if( MethodName == NULL)\
		return( ReturnValue);

#define DoMethodEnd( BaseClass) \
	return( BaseClass::doMethod( MethodName, Arguments));\
}

#define DoMethodDefinitionBegin( Name, Method, ArgumentCount) \
\
if(( Arguments.CountItems() == ArgumentCount) && ( strcmp( Name, MethodName) == 0))\
{\
	int32 DoMethodItem = 0;\
	fArgument *Argument;

#define DoMethodVariable( Type, Name) \
	Argument = reinterpret_cast<fArgument *>( Arguments.ItemAt( DoMethodItem++));\
\
	Type Name = *Argument;\
\
	if( Argument->isValid() == false)\
		return( ReturnValue);

#define DoMethodVariableCast( Type1, Type2, Name) \
	Argument = reinterpret_cast<fArgument *>( Arguments.ItemAt( DoMethodItem++));\
	Type1 Name = ( Type1)(( Type2) *Argument);\
\
	if( Argument->isValid() == false)\
		return( ReturnValue);\

	
#define DoMethodCall( Method) ReturnValue = Method
#define DoMethodVoidCall( Method) ReturnValue.setValid( true); Method

#define DoMethodDefinitionEnd ;\
	return( ReturnValue);\
}

#endif