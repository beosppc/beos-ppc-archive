// fClassInfo.h

#ifndef fClassInfo_h
#define fClassInfo_h

// The included files are used by all classes and therefore are included here.
#include "fDefines.h"
#include "fDoMethod.h"

#pragma export on

class fClassInfo
{
	private:

		// Private copy constructor and the assignment operator to prevent accidental
		// copying of classes.	
		fClassInfo( const fClassInfo &CopyObject);
		fClassInfo &operator=( const fClassInfo &CopyObject);

	protected:

		// Nested classes used to create the global instances of every concrete class.
		// Every concrete class has a constructor that takes a fClassInfoDummy1 object
		// (see fDefines.h). This constructor registeres the class with the factory
		// and passes a fClassInfoDummy2 object to the constructor of the base class.
		// Constructors that take a fClassInfoDummy2 object do nothing, except passing
		// an object of that type on to the base class.
		class fClassInfoDummy1{};
		class fClassInfoDummy2{};

		fClassInfo( fClassInfoDummy2);

	public:

		fClassInfo( void);
		virtual ~fClassInfo( void);

		// all the methods below are covered by the defines in fDefines.h
		// You normally don't implement or define them yourself but rather use the
		// (Virtual)ClassDefinition and (Virtual)ClassDeclaration macros.

		// In concrete derived classes return an instance of that class, i.e. return( new Class))
		virtual fClassInfo *createInstance( void) const = 0;

		// Return a pointer to the classes name or the name of its base class, respectively.
		virtual const char * const getClassName( void) const;
		virtual const char * const getBaseClassName( void) const;

		// Returns true if the class on which the method is called is of that class (in
		// isOfClass) or if ClassName is one of its base classes (in isOfType).
		virtual bool isOfClass( const char *ClassName) const;
		virtual bool isOfType( const char *ClassName) const;

		// This is just a dummy method that does nothing useful except being there. This is because
		// calls to doMethod() are passed to the base class, that is calls to doMethod() behave like
		// virtual method calls. The code you see here is just for testing purposes, ignore it.
		// For those who really want to know: It makes it possible to ask for the name of a class
		// this is not really useful but I needed it for testing... it will vanish in later versions.
		virtual fReturnValue doMethod( const char *MethodName, const BList &Arguments);
};

#pragma export off

#endif
