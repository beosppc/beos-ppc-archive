// fBuilder.h

#ifndef FBUILDER_H
#define FBUILDER_H

#pragma export on

class fBuilder
{
	private:
		char tokenBuffer[ 1024 ];
		uint32 tokenBufferPosition;

		// Fetches the next token from the input data. The token has
		// to be deleted after use. Returns NULL on error.

		char *getToken( BFile *GUIDescriptionFile);

		// This one fetches for all method calls and performs them.

		bool doMethods( BFile *GUIDescriptionFile, class fBuilderObject *CurrentObject);

		// In this list we store the defined objects.

		BList definedObjects;

		// Instanciate the given fBuilderObject

		class fClassInfo *createInstance( class fBuilderObject *DefinedObject);


		// Search for an fBuilderArgument with this name in the list of the
		// defined objects. This may return and fBuilderObject.

		class fBuilderArgument *findArgument( const char *ObjectName);

		friend class fBuilderArgument;
		friend class fBuilderObject;

	public:
		fBuilder( void);
		virtual ~fBuilder( void);

		// Read in the GUI description from the given file.

		bool importGUIDescription( const char *GUIDescriptionFile);

		// Instantiate the object with that name.

		class fClassInfo *createInstance( const char *ObjectName);
};

#pragma export off

#endif