// fReturnValue.cpp

#include "fReturnValue.h"

#define Constructor( Type)\
fReturnValue::fReturnValue( Type Value)\
{\
	Type *Pointer = reinterpret_cast<Type *>( &fValue);\
	*Pointer = Value;\
\
	fValid = true;\
}

#define AssignmentOperator( Type)\
fReturnValue &fReturnValue::operator =( Type Value)\
{\
	Type *Pointer = reinterpret_cast<Type *>( &fValue);\
	*Pointer = Value;\
\
	fValid = true;\
	return( *this);\
}

#define CastOperator( Type)\
fReturnValue::operator Type( void) const\
{\
	const Type *Pointer = const_cast<Type *>( reinterpret_cast<const Type *>( &fValue));\
	return( *Pointer);\
}

fReturnValue::fReturnValue( void)
{
//	fprintf( stderr, "fReturnValue::fReturnValue( void)\n");
	memset( &fValue, 0, sizeof( fValue));

	fValid = false;
}

void fReturnValue::setValid( bool Valid)
{
	fValid = Valid;
}

bool fReturnValue::getValid( void) const
{
	return( fValid);
}

Constructor( bool);
Constructor( int);
Constructor( unsigned int);
Constructor( int8);
Constructor( uint8);
Constructor( int16);
Constructor( uint16);
Constructor( int32);
Constructor( uint32);
Constructor( int64);
Constructor( uint64);
Constructor( float);
Constructor( double);
Constructor( char *);

AssignmentOperator( bool);
AssignmentOperator( int);
AssignmentOperator( unsigned int);
AssignmentOperator( int8);
AssignmentOperator( uint8);
AssignmentOperator( int16);
AssignmentOperator( uint16);
AssignmentOperator( int32);
AssignmentOperator( uint32);
AssignmentOperator( int64);
AssignmentOperator( uint64);
AssignmentOperator( float);
AssignmentOperator( double);
AssignmentOperator( char *);

CastOperator( bool);
CastOperator( int);
CastOperator( unsigned int);
CastOperator( int8);
CastOperator( uint8);
CastOperator( int16);
CastOperator( uint16);
CastOperator( int32);
CastOperator( uint32);
CastOperator( int64);
CastOperator( uint64);
CastOperator( float);
CastOperator( double);
//CastOperator( char *);
fReturnValue::operator char *( void) const
{
	char * const *Pointer = const_cast<char * const *>( reinterpret_cast<const char * const *>( &fValue));
	return( *Pointer);
}

