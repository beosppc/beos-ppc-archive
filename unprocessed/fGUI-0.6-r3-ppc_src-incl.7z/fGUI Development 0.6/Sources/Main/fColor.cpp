// fColor.cpp

#include "fColor.h"

//#include "fFactory.h"

//ClassDefinition( fColor, fClassInfo);

fColor::fColor( uint8 Red, uint8 Green, uint8 Blue, uint8 Alpha)
			: fRed( Red), fGreen( Green), fBlue( Blue), fAlpha( Alpha)
{
}

fColor::fColor( const fColor &Color)
			: fRed( Color.fRed), fGreen( Color.fGreen), fBlue( Color.fBlue), fAlpha( Color.fAlpha)
{
}

fColor::fColor( const rgb_color &Color)
			: fRed( Color.red), fGreen( Color.green), fBlue( Color.blue), fAlpha( Color.alpha)
{
}

fColor &fColor::operator =( const fColor &Color)
{
	fRed	= Color.fRed;
	fGreen	= Color.fGreen;
	fBlue	= Color.fBlue;
	fAlpha	= Color.fAlpha;

	return( *this);
}

fColor &fColor::operator =( const rgb_color &Color)
{
	fRed	= Color.red;
	fGreen	= Color.green;
	fBlue	= Color.blue;
	fAlpha	= Color.alpha;

	return( *this);
}

bool fColor::operator ==( const fColor &Color) const
{
	if(( fRed == Color.fRed) && ( fGreen == Color.fGreen)
			&& ( fBlue == Color.fBlue) && ( fAlpha == Color.fAlpha))
		return( true);	

	return( false);
}

bool fColor::operator ==( const rgb_color &Color) const
{
	if(( fRed == Color.red) && ( fGreen == Color.green)
			&& ( fBlue == Color.blue) && ( fAlpha == Color.alpha))
		return( true);	

	return( false);
}

bool fColor::operator !=( const fColor &Color) const
{
	if(( fRed != Color.fRed) || ( fGreen != Color.fGreen)
			|| ( fBlue != Color.fBlue) || ( fAlpha != Color.fAlpha))
		return( true);	

	return( false);
}

bool fColor::operator !=( const rgb_color &Color) const
{
	if(( fRed != Color.red) || ( fGreen != Color.green)
			|| ( fBlue != Color.blue) || ( fAlpha != Color.alpha))
		return( true);	

	return( false);
}

fColor::operator rgb_color( void) const
{
	rgb_color color = { fRed, fGreen, fBlue, fAlpha};
	
	return( color);
}

void fColor::printToStream( const char *Text) const
{
	if( Text)
		fprintf( stderr, "%s", Text);

	fprintf( stderr, "fColor: Red: %d, Green: %d, Blue: %d, Alpha: %d\n",
					fRed, fGreen, fBlue, fAlpha);
}
