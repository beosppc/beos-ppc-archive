// fAlarm.cpp

#include "fAlarm.h"

//#include "fFactory.h"

#include "fEventRoute.h"

//ClassDefinition( fAlarm, fClassInfo);

fAlarm::fAlarm( void)
{
	fRunning		= false;

	fAlarmRoute		= NULL;
	fAlarmInterval	= 1000000;	// default: 1 sec
	fFirstAlarm		= 0;		// no first alarm by default
	fRepeatAlarm	= false;
}

fAlarm::~fAlarm( void)
{
	// stop mouse thread
	stopAlarm();

	delete fAlarmRoute;
}

int32 fAlarm::startAlarmThread( void *Data)
{
	fAlarm *Alarm = static_cast<fAlarm *>( Data);

	Alarm->fRunning = true;
	int32 ret = Alarm->alarmThread();
	Alarm->fRunning = false;
	
	return( ret);
}
		
int32 fAlarm::alarmThread( void)
{
	if( fFirstAlarm)
		snooze( fFirstAlarm);

	do
	{
		snooze( fAlarmInterval);
		
		fAlarmRoute->sendMessage();
	} while( fRepeatAlarm);

	return( 0);
}

bool fAlarm::setAlarm( class fEventRoute *AlarmRoute, int64 AlarmInterval, bool RepeatAlarm, int64 FirstAlarm)
{
	if( fRunning)
		return( false);

	if( AlarmRoute == NULL)
		return( false);

	fAlarmRoute = AlarmRoute;

	fAlarmInterval = AlarmInterval;

	// no alarm times smaller than 1/100 of a second...
	if( fAlarmInterval < 10000)
		fAlarmInterval = 10000;

	fRepeatAlarm	= RepeatAlarm;
	fFirstAlarm		= FirstAlarm;

	return( true);
}

fEventRoute *fAlarm::getAlarmRoute( void) const
{
	return( fAlarmRoute);
}

bool fAlarm::startAlarm( void)
{
	if( fRunning)
		return( false);

	if(( fThread = spawn_thread( startAlarmThread, "fAlarmThread", B_DISPLAY_PRIORITY, this)) < B_OK)
		return( false);

	resume_thread( fThread);
	return( true);
}

bool fAlarm::stopAlarm( void)
{
	if( fRunning == false)
		return( false);
	
	fRunning = false;

	if( kill_thread( fThread) < B_OK)
		return( false);

	return( true);
}

bool fAlarm::getRunning( void) const
{
	return( fRunning);
}
