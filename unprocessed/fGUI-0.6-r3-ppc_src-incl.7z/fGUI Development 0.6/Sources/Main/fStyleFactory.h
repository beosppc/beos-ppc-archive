// fStyleFactory.h

#ifndef fStyleFactory_h
#define fStyleFactory_h

#include <List.h>

#pragma export on

class fStyleFactory
{
	private:
	
		fStyleFactory( const fStyleFactory &CopyObject);
		fStyleFactory &operator=( const fStyleFactory &CopyObject);

		static fStyleFactory	*Factory;

	protected:

		char	*fStyleName;
		BList	 fRegisteredClasses;

	public:

		fStyleFactory( const char *StyleName);
		virtual ~fStyleFactory( void);

		const char *getStyleName( void) const;

		virtual void registerClass( class fClassInfo *Class);
		virtual class fClassInfo *createInstance( const char *ClassName) const;
};

#pragma export off

#endif