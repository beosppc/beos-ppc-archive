// fAlarm.h

#ifndef fAlarm_h
#define fAlarm_h

//#include "fClassInfo.h"

#pragma export on

class fAlarm// : public fClassInfo
{
	private:

		fAlarm( const fAlarm &CopyObject);
		fAlarm &operator=( const fAlarm &CopyObject);

//		ClassDeclaration( fAlarm);

		static int32 startAlarmThread( void *Data);
		
		int32 alarmThread( void);

		thread_id fThread;
		bool fRunning;

	protected:

		class fEventRoute	*fAlarmRoute;

		int64				 fAlarmInterval;
		int64				 fFirstAlarm;

		bool				 fRepeatAlarm;

	public:

		fAlarm( void);
		~fAlarm( void);

		bool setAlarm( class fEventRoute *AlarmRoute, int64 AlarmInterval,
									bool RepeatAlarm, int64 FirstAlarm = 0);
		class fEventRoute *getAlarmRoute( void) const;

		bool startAlarm( void);
		bool stopAlarm( void);

		bool getRunning( void) const;
};

#pragma export off

#endif