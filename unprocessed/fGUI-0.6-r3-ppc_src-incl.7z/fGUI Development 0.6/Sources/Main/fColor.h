// fColor.h

#ifndef fColor_h
#define fColor_h

#pragma export on

class fColor
{
	public:

		uint8	fRed; 
		uint8	fGreen; 
		uint8	fBlue; 
		uint8	fAlpha;	

	public:

		fColor( uint8 Red = 255, uint8 Green = 255, uint8 Blue = 255, uint8 Alpha = 255);
		fColor( const fColor &Color);
		fColor( const rgb_color &Color);
	
		fColor &operator =( const fColor &Color);
		fColor &operator =( const rgb_color &Color);

		bool operator ==( const fColor &Color) const;
		bool operator ==( const rgb_color &Color) const;

		bool operator !=( const fColor &Color) const;
		bool operator !=( const rgb_color &Color) const;

		operator rgb_color( void) const;

		void printToStream( const char *Text = NULL) const;
};

#pragma export off

#endif