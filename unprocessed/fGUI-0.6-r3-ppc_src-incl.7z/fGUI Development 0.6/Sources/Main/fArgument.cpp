// fArgument.cpp

#include "fArgument.h"

//#include "fClassInfo.h"
#include <string.h>
#include <stdlib.h>

fArgument::fArgument( void)
{
	memset( &fValue, 0, sizeof( fValue));
	fValid = false;
}

fArgument::fArgument( char *Value)
{
	fValue.fCharPointer	= Value;
	fType				= fArgumentCharType;
	fValid				= false;
}

fArgument::fArgument( class fClassInfo *Value)
{
	fValue.fClassInfoPointer	= Value;
	fType						= fArgumentClassInfoType;
	fValid						= false;
}

fArgument &fArgument::operator =( char *Value)
{
	fValue.fCharPointer	= Value;
	fType				= fArgumentCharType;
	fValid				= false;

	return( *this);
}

fArgument &fArgument::operator =( class fClassInfo *Value)
{
	fValue.fClassInfoPointer	= Value;
	fType						= fArgumentClassInfoType;
	fValid						= false;

	return( *this);
}

bool fArgument::isValid( void) const
{
	return( fValid);
}

//CastOperators
fArgument::operator bool( void)
{
//	fprintf( stderr, "fArgument::operator bool\n");

	fValid = false;

	if(( fType != fArgumentCharType) || ( fValue.fCharPointer == NULL))
		return( false);

	if( strcasecmp( fValue.fCharPointer, "true") == 0)
	{
		fValid = true;
		return( true);
	}
	else if( strcasecmp( fValue.fCharPointer, "false") == 0)
	{
		fValid = true;
		return( false);
	}
	else
		return( false);
}

fArgument::operator int32( void)
{
//	fprintf( stderr, "fArgument::operator int32\n");

	fValid = false;

	if(( fType != fArgumentCharType) || ( fValue.fCharPointer == NULL))
		return( 0);
	
	char *Temp;
	int32 result;
	result = strtol( fValue.fCharPointer, &Temp, 10);
	
	if(( result == 0) && ( *Temp != 0x0))
		return( 0);

	fValid = true;
	return( result);
}

fArgument::operator uint32( void)
{
//	fprintf( stderr, "fArgument::operator uint32\n");

	fValid = false;

	if(( fType != fArgumentCharType) || ( fValue.fCharPointer == NULL))
		return( 0);
	
	char *Temp;
	int32 result;
	result = strtol( fValue.fCharPointer, &Temp, 10);
	
	if(( result == 0) && ( *Temp != 0x0))
		return( 0);

	fValid = true;
	return( result);
}

fArgument::operator float( void)
{
//	fprintf( stderr, "fArgument::operator float\n");

	fValid = false;

	if(( fType != fArgumentCharType) || ( fValue.fCharPointer == NULL))
		return( 0.0);
	
	char *Temp;
	double result;
	result = strtod( fValue.fCharPointer, &Temp);
	
	if(( result == 0.0) && ( *Temp != 0x0))
		return( 0.0);

	fValid = true;
	return( result);
}

fArgument::operator double( void)
{
//	fprintf( stderr, "fArgument::operator double\n");

	fValid = false;

	if(( fType != fArgumentCharType) || ( fValue.fCharPointer == NULL))
		return( 0.0);
	
	char *Temp;
	double result;
	result = strtod( fValue.fCharPointer, &Temp);
	
	if(( result == 0.0) && ( *Temp != 0x0))
		return( 0.0);

	fValid = true;
	return( result);
}

fArgument::operator char *( void)
{
//	fprintf( stderr, "fArgument::operator char *\n");

	if( fType == fArgumentCharType)
	{
		fValid = true;
		return( fValue.fCharPointer);
	}
	else
	{
		fValid = false;
		return( NULL);
	}
}

fArgument::operator class fClassInfo *( void)
{
//	fprintf( stderr, "fArgument::operator class fClassInfo *\n");

	if( fType == fArgumentClassInfoType)
	{
		fValid = true;
		return( fValue.fClassInfoPointer);
	}
	else
	{
		fValid = false;
		return( NULL);
	}
}