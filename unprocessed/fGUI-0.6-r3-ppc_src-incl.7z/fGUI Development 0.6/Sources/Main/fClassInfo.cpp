// fClassInfo.cpp

#include "fClassInfo.h"
#include "fFactory.h"

fClassInfo::fClassInfo( fClassInfoDummy2)
{
}

fClassInfo::fClassInfo( void)
{
}

fClassInfo::~fClassInfo( void)
{
}

fReturnValue fClassInfo::doMethod( const char *MethodName, const BList &Arguments)
{
	fReturnValue ReturnValue;

	if( MethodName == NULL)
		return( ReturnValue);

	if(( Arguments.CountItems() == 0) && ( strcmp( "getClassName", MethodName) == 0))
	{
		int32 DoMethodItem = 0;
		fArgument *Argument;

		ReturnValue = getClassName();

		return( ReturnValue);
	}
	
	fprintf( stderr, "fClassInfo::doMethod() Invalid method name: '%s'\n", MethodName);

	return( ReturnValue);
}

const char * const fClassInfo::getClassName( void) const
{
	return( "fClassInfo");
}

const char * const fClassInfo::getBaseClassName( void) const
{
	return( NULL);
}

bool fClassInfo::isOfClass( const char *ClassName) const
{
	if( strcmp( fClassInfo::getClassName(), ClassName) == 0)
		return( true);

	return( false);
}

bool fClassInfo::isOfType( const char *ClassName) const
{
	return( fClassInfo::isOfClass( ClassName));
}