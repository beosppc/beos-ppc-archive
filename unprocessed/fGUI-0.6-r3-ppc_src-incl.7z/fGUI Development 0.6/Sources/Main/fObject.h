// fObject.h

#ifndef fObject_h
#define fObject_h

#include <List.h>
#include <Rect.h>
#include <View.h>
#include <Font.h>
#include <Bitmap.h>

#include <Message.h>

#include "fColor.h"
#include "fPoint.h"

#include "fClassInfo.h"

#define DEBUG 0

#pragma export on

class fObject : public fClassInfo
{
	public:

		// use this if a class has no limit in its maximum size
		#define F_NO_SIZE_LIMIT 4000.0

		// Alignment constants
		enum HorizontalAlignment
		{	F_HALIGN_LEFT = 0,
			F_HALIGN_CENTER,
			F_HALIGN_RIGHT };

		enum VerticalAlignment
		{	F_VALIGN_TOP = 0,
			F_VALIGN_CENTER,
			F_VALIGN_BOTTOM };

		// constants for mouse buttons
		// Note that not every mnouse buttons has its own bit, so tests using
		// a mask will NOT work ! This also means that every event only can
		// be caused by one button. Plus it allows for mice with an arbitrary
		// amount of buttons (well, 2 billion).		
		enum MouseButton
		{
			F_NO_MOUSE_BUTTON,
			F_PRIMARY_MOUSE_BUTTON,
			F_SECONDARY_MOUSE_BUTTON,
			F_TERTIARY_MOUSE_BUTTON };

	private:

		// Private copy constructor and the assignment operator to prevent accidental
		// copying of classes.	
		fObject( const fObject &CopyObject);
		fObject &operator=( const fObject &CopyObject);

		// use of the macro from fDefines.h. see fClassInfo.h for more details.
		VirtualClassDeclaration( fObject);

	protected:

		// initializes the object to reasobale fedault values.
		void initializeObject( void);

		char				*fObjectName;

		fObject				*fParent;
		const class fWindow	*fParentWindow;
		bool 				 fWindowActivated;
		
		class BView			*fDrawView;
		class BRegion		*fClippingRegion;

		float				 fHorizontalWeight;
		float				 fVerticalWeight;

		HorizontalAlignment	 fHorizontalAlignment;
		VerticalAlignment	 fVerticalAlignment;

		float				 fHorizontalBorder;
		float				 fVerticalBorder;

		bool				 fEnabled;
		fColor				 fFontColor;
		fColor				 fBackgroundColor;
		BBitmap				*fBackgroundBitmap;

		fPoint				 fMinimumSize;
		fPoint				 fPreferredSize;
		fPoint 				 fMaximumSize;

		fPoint				 fCurrentSize;
		fPoint				 fCurrentPosition;

		bool				 fFocused;

		BList				 fEventRoutes;
		const BMessage		*fCurrentMessage;

		// Set the size limits. These are used internally to set the size
		// limits. Don't set them directly ! These methods add the correct
		// border values !
		virtual void setMinimumSize( const fPoint &Size);		
		virtual void setMaximumSize( const fPoint &Size);
		virtual void setPreferredSize( const fPoint &Size);

		// Hook methods. These three or the next one have to be obverridden by derived
		// classes to recalculate the size limits.
		virtual void calculateMinimumSize( void);
		virtual void calculatePreferredSize( void);
		virtual void calculateMaximumSize( void);

		// Override this method if all sizes are calculated on a similar fashion. If not use
		// three methods above. This methods calls all three of them, so DON'T call
		// fObject::recalculateSizeLimits(0 at the end of your overriding method !
		virtual void recalculateSizeLimits( void);

		// Method to remove EventRoutes. Used rarely.
		void removeEventRoutes( int32 fEvent);

		// This method calls draw outside the "normal" drawObject calls that are triggered
		// when the system thinks the object has to be drawn. The object can call this method
		// whenever it thinks a refresh is necessary. Don't call drawObject() !
		void redraw( BRect RedrawRectangle) const;

		// Declaration for doMethod(). See fClassInfo.h.
		DoMethodDeclaration;

	public:

		fObject( void);
		fObject( const char *ObjectName);
		virtual ~fObject( void);

// layout related methods
		// Set both weights of the object to weight.
		// The weights determine how much space each object gets while layouting.
		// A weight of 0.0 is special, it means an object won't be resized at all, but
		// will get its preferred weight.
		virtual void setWeights( float Weight);

		// Set or get the horizontal weight of the object.
		virtual void setHorizontalWeight( float Weight);
		float getHorizontalWeight( void) const;
		
		// Set or get the vertical weight of the object.
		virtual void setVerticalWeight( float Weight);
		float getVerticalWeight( void) const;

	// Size
		// Get the size limits of the object. These methods are used by the parent
		// object during layout.
		void getMinimumSize( fPoint &Size) const;
		fPoint getMinimumSize( void) const;
		
		void getMaximumSize( fPoint &Size) const;
		fPoint getMaximumSize( void) const;
		
		void getPreferredSize( fPoint &Size) const;
		fPoint getPreferredSize( void) const;
		
		// Set current size. Called during the layouting by the parent to resize
		// the object to size NewSize. Should be overridden by container classes to
		// layout all children.
		// Note: setSize() never checks NewSize ! Is relies on the parent calculating
		// correct sizes !
		virtual void setSize( const fPoint &NewSize);

		// Return the current size.
		virtual void getSize( fPoint &Size) const;
		fPoint getSize( void) const;
		
		// Return a rectangle that contains all of the object. Used for example in
		// containsPoint() and in calls to redraw(): redraw( getRectangle); for a
		// full update.
		void getObjectFrame( BRect &Position) const;
		BRect getObjectFrame( void) const;

	// Position
		// Set current position in the parent BView. Called during the layouting by the
		// parent to position the object. Should be overridden by container classes to
		// reposition all children. (see fBaseClass.cpp)
		virtual void setPosition( const fPoint &NewPosition);

		// Return the current position.		
		void getPosition( fPoint &Position) const;
		fPoint getPosition( void) const;
		
	// Border
		// Set both borders to NewBorder
		// The border is the amount of pixels that the objects frame has to be inset before
		// it draws. This make sure that the objects are not to close together.
		virtual void setBorders( float NewBorder);
	
		// Set the horizontal border to NewHorizontalBorder.
		virtual void setHorizontalBorder( float NewHorizontalBorder);
		float getHorizontalBorder( void) const;

		// Set the vertical border to NewVerticalBorder.
		virtual void setVerticalBorder( float NewVerticalBorder);
		float getVerticalBorder( void) const;

	// Alignment
		// set and return the horisontal and vertical alignment of the object,
		// respectively.
		// The alignment can be used by the containing object to align the object
		// within the group or it can be used by the object itself to align the
		// contents of the object.
		virtual void setHorizontalAlignment( HorizontalAlignment NewAlignment);
		HorizontalAlignment getHorizontalAlignment( void) const;
		virtual void setVerticalAlignment( VerticalAlignment NewAlignment);
		VerticalAlignment getVerticalAlignment( void) const;
				
// methods that change the appearance
	// State
		// enables the object when Enabled is true or disables it when it is false.
		// disabled objects don't react to user input.
		virtual void setEnabled( bool Enabled);
		bool getEnabled( void) const;

	// Font
		// Set the font to Font. This method is empty in fObject and has to be implemented
		// by derived classes when they need a font. In all cases the Font has to be copied.
		// Note: this will probably change in the future, fGUI will offer a range of predefined
		// fonts for most purposes that the user has chosen.
		virtual void setFont( const BFont *Font);

		// Set and get the color of the font. Again, these methods will probably change when the
		// user has the ability to set fonts and their properties.
		virtual void setFontColor( const fColor &FontColor);
		virtual void setFontColor( uint8 Red, uint8 Green, uint8 Blue, uint8 Alpha = 255);
		fColor getFontColor( void) const;

	// Background
		// Set and get the color of the objects background. Again, these methods will probably
		// change when the user has the ability to set the GUIs properties.
		virtual void setBackgroundColor( const fColor &BackgroundColor);
		virtual void setBackgroundColor( uint8 Red, uint8 Green, uint8 Blue, uint8 Alpha = 255);
		fColor getBackgroundColor( void) const;

		// This methos is currently empty, later releases will allow the use of background
		// bitmap according to the users wishes.
		virtual void setBackgroundBitmap( BBitmap *BackgroundBitmap);
											
// event model methods (and related)
	// Localisation
		// called by the contaning class to check if a point is within the object.
		// Should be overridden by container classes to call the containsPoint
		// method of all contained objects. Normal objects should leave this alone.
		virtual const fObject *containsPoint( const fPoint &Point) const;

	// Mouse
		// Called whenever the corresponding event occurs (see fEvent.h).
		// All these methods are only called in ONE object, except mouseMoved()
		virtual void mouseDown( MouseButton Button, const fPoint &Point, int32 Clicks);
		virtual void mouseUp( MouseButton Button, const fPoint &Point, int32 Clicks);

		virtual void mouseEntered( const fPoint &Point);
		virtual void mouseWithin( const fPoint &Point);
		virtual void mouseExited( const fPoint &Point);

		// This is the only method in the events section that is called on EVERY
		// object when the mouse moves. This will perhaps change if this imposes too
		// much overhead. In the meantime only do very fast things in here !
		// Note: This method is called even when the mouse is outside the object, in
		// contrast to mouseWithin.
		virtual void mouseMoved( const fPoint &Point);

	// Keyboard
		// setFocus() is called whenever F_GOT_FOCUS or F_LOST_FOCUS events are received.
		// The fObject's versionof this method returns true if the status of the object
		// has changed and false otherwise.
		virtual bool setFocus( bool Focus);
		bool getFocus( void) const;

		// If the object has the focus (or if it is the default button) the users input
		// is reported to this method.
		virtual void keyDown( const char *Input, int32 Length);
		virtual void keyUp( const char *Input, int32 Length);

	// Events and Messages
		// This method adds EventRoute to the objects list of event routes. See fEventRoute.h
		// and the HTML-documentation for more details on events.
		virtual void addEventRoute( class fEventRoute *EventRoute);

		// These three methods correspond to the three stages in processing an event:
		// 1. The event is delivered to processEvent. There all corresponding event routes
		//    are fired.
		// 2. When all events are delivered dispatchMessage is called. It checks for known
		//    events and calls the corresponding virtual methods.
		// 3. If it is none of the known event the event is finally passed to messageReceived.
		// Note: The Message Argument may be NULL !
		virtual void processEvent( int32 Event, BMessage *Message = NULL);
		virtual void dispatchMessage( int32 Event, BMessage *Message);
		virtual void messageReceived( int32 Event, BMessage *Message);

		// During the dispatching of the event the message that triggered the event (if any)
		// is returned by this method. 
		const BMessage *getCurrentMessage( void) const;

// hierarchy related methods
	// Name
		// Set and return the name of the object. This name can be used in events as
		// the target name.
		virtual void setName( const char *Name);
		const char *getName( void) const;

	// View
		// Called by parent classes when the object is added to a group object. Should
		// be overridden in container classes to pass it to all children.
		virtual void setView( BView *NewView);
		BView *getView( void) const;
		
	// Parent
		// Called by parent classes when the object is added to a group object. Should
		// be overridden in container classes to set themself as the aprent (usually,
		// see fTabItem.h for an exception from that rule).
		virtual void setParent( fObject *Parent);
		fObject *getParent( void) const;

	// Window
		// Called by the parent class when the objects parent has been attached to the window.
		// Should be overridden by derived classes to pass it to all children.
		// For detachedFromWindow: dito.
		virtual void attachedToWindow( const class fWindow *ParentWindow);
		virtual void detachedFromWindow( void);

		// Returns a pointer to the objects window (as passed in attachedToWindow())
		// used for example to address the windoe (using getWindow()->getWindowName())
		// in an event route.
		const class fWindow *getWindow( void) const;

		// Called by the parent class when the window the objects is attached to is
		// disabled or enabled.
		// Should be overridden by derived classes to pass it to all children.
		// The fObject's version of the method returns true if the status of the window has
		// really chaged and false if not.
		virtual bool setWindowActivated( bool Activated);
		bool getWindowActivated( void) const;

		// This method should be called by derived classes whenever the objects feels that a
		// re-layout is needed. The method calls recalculateSizeLimits() and then updateIfNeeded()
		// for the parent. This is for example used by fBaseGroup when a new object is added.
		virtual void updateIfNeeded( void);

	// Find
		// Use for delivering events: This method look for the given object either by name of by
		// a pointer. All container classes should override this method, everyone else should
		// leave it alone.
		virtual bool findObject( const fObject *ObjectPointer) const;
		virtual const fObject *findObject( const char *ObjectName) const;

// Drawing
		// Used by parent classes for setting the clipping region of the object. This is
		// only set in a full update (before the call to drawObject()). Every other drawing
		// has to respect this clipping region. Used for example in redraw()
		void setClippingRegion( const BRegion &ClippingRegion);
		
		// Called by the parent group when a full update is neccessary. A certain behaviour
		// is expected from an object in redrawObject() have a look at the implementations
		// in other classes.
		// This is the only true virtual method in fObject, thus it has to be overridden
		// in derived classes.
		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const = 0;
};

#pragma export off

#endif
