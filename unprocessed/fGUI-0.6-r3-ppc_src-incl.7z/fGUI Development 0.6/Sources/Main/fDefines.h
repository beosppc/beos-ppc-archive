// fDefines.h

#ifndef fDefine_h
#define fDefine_h

// templates
template <class T>
inline float min( T a, T b)
{
	return( a < b ? a : b);
}

template <class T>
inline float max( T a, T b)
{
	return( a > b ? a : b);
}

template <class T>
inline float abs( T a)
{
	return( a < 0 ? -a : a);
}

// Layout
#define ShowObjectLayout\
	BRect ShowLayoutFrame = getRectangle();\
	if( getView())\
	{\
		getView()->SetHighColor( 0xff, 0x0, 0x0);\
		getView()->StrokeRect( ShowLayoutFrame);\
	}

#define ShowGroupLayout\
	BRect ShowLayoutFrame = getRectangle();\
	if( getView())\
	{\
		getView()->SetHighColor( 0xff, 0xff, 0x0);\
		getView()->StrokeRect( ShowLayoutFrame);\
	}

// ClassDeclaration
#define ClassDeclaration( CLASSNAME) \
	public:\
		CLASSNAME( fClassInfoDummy1);\
		CLASSNAME( fClassInfoDummy2);\
\
	public:\
		virtual fClassInfo *createInstance( void) const;\
\
		virtual const char * const getClassName( void) const;\
		virtual const char * const getBaseClassName( void) const;\
\
		virtual bool isOfClass( const char *ClassName) const;\
		virtual bool isOfType( const char *ClassName) const

// ClassDefinition
#define ClassDefinition( CLASSNAME, BASECLASSNAME, STYLE) \
\
CLASSNAME Global##CLASSNAME( fClassInfo::fClassInfoDummy1());\
\
CLASSNAME::CLASSNAME( fClassInfoDummy1)\
			: BASECLASSNAME( fClassInfoDummy2())\
{\
	fFactory *Factory = fFactory::getFactory();\
\
	Factory->registerClass( this, STYLE);\
}\
\
CLASSNAME::CLASSNAME( fClassInfoDummy2)\
			: BASECLASSNAME( fClassInfoDummy2())\
{\
}\
\
fClassInfo *CLASSNAME::createInstance( void) const\
{\
	return( new CLASSNAME());\
}\
\
const char * const CLASSNAME::getClassName( void) const\
{\
	return( #CLASSNAME);\
}\
\
const char * const CLASSNAME::getBaseClassName( void) const\
{\
	return( BASECLASSNAME::getClassName());\
}\
\
bool CLASSNAME::isOfClass( const char *ClassName) const\
{\
	if( strcmp( CLASSNAME::getClassName(), ClassName) == 0)\
		return( true);\
\
	return( false);\
}\
\
bool CLASSNAME::isOfType( const char *ClassName) const\
{\
	if( CLASSNAME::isOfClass( ClassName))\
		return( true);\
\
	return( BASECLASSNAME::isOfType( ClassName));\
}

// VirtualClassDeclaration
#define VirtualClassDeclaration( CLASSNAME) \
	protected:\
\
		CLASSNAME( fClassInfoDummy2);\
\
	public:\
		virtual fClassInfo *createInstance( void) const = 0;\
\
		virtual const char * const getClassName( void) const;\
		virtual const char * const getBaseClassName( void) const;\
\
		virtual bool isOfClass( const char *ClassName) const;\
		virtual bool isOfType( const char *ClassName) const

// VirtualClassDefinition
#define VirtualClassDefinition( CLASSNAME, BASECLASSNAME) \
\
CLASSNAME::CLASSNAME( fClassInfoDummy2)\
			: BASECLASSNAME( fClassInfoDummy2())\
{\
}\
\
const char * const CLASSNAME::getClassName( void) const\
{\
	return( #CLASSNAME);\
}\
\
const char * const CLASSNAME::getBaseClassName( void) const\
{\
	return( BASECLASSNAME::getClassName());\
}\
\
bool CLASSNAME::isOfClass( const char *ClassName) const\
{\
	if( strcmp( CLASSNAME::getClassName(), ClassName) == 0)\
		return( true);\
\
	return( false);\
}\
\
bool CLASSNAME::isOfType( const char *ClassName) const\
{\
	if( CLASSNAME::isOfClass( ClassName))\
		return( true);\
\
	return( BASECLASSNAME::isOfType( ClassName));\
}

#endif