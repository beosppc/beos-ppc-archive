// fObject.cpp

#include <Region.h>

#include "fObject.h"

#include "fEvents.h"
#include "fEventRoute.h"

#if DEBUG > 0
#define FOBJECT_DEBUG DEBUG
#endif

//#undef FOBJECT_DEBUG

VirtualClassDefinition( fObject, fClassInfo);

fObject::fObject( void)
{
	fObjectName	= NULL;

	initializeObject();
}

fObject::fObject( const char *ObjectName)
{
	#if FOBJECT_DEBUG > 0
	fprintf( stderr, "fObject::fObject()\n");
	#endif

	if( ObjectName)
	{
		fObjectName	= new char[ strlen( ObjectName) + 1];
		strcpy( fObjectName, ObjectName);
	}
	else
		fObjectName		= NULL;

	initializeObject();

	#if FOBJECT_DEBUG > 0
	fprintf( stderr, "fObject::fObject() end\n");
	#endif
}

void fObject::initializeObject( void)
{
	fParent					= NULL;
	fParentWindow			= NULL;
	fWindowActivated		= false;

	fDrawView				= NULL;
	fClippingRegion			= NULL;

	fHorizontalWeight		= 100.0;
	fVerticalWeight			= 100.0;

	fHorizontalAlignment	= F_HALIGN_LEFT;
	fVerticalAlignment		= F_VALIGN_TOP;

	fHorizontalBorder		= 1.0;
	fVerticalBorder			= 1.0;

	fEnabled				= true;
	fFontColor				= fColor( 0x0, 0x0, 0x0);
	fBackgroundColor		= fColor( 0xd0, 0xd0, 0xd0);
	fBackgroundBitmap		= NULL;

	recalculateSizeLimits();

	fCurrentSize			= getPreferredSize();

	fFocused				= false;

	fCurrentMessage			= NULL;
}

fObject::~fObject( void)
{
	#if FOBJECT_DEBUG > 0
	fprintf( stderr, "fObject::~fObject()\n");
	#endif
	
	delete [] fObjectName;
	delete fBackgroundBitmap;
	delete fClippingRegion;

	#if FOBJECT_DEBUG > 0
	fprintf( stderr, "fObject::~fObject() end\n");
	#endif
}

// Protected
DoMethodBegin( fObject)
	DoMethodDefinitionBegin( "Weights", setWeights, 1)
		DoMethodVariable( float, Weight)
		DoMethodVoidCall( setWeights)( Weight)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "HorizontalWeight", setHorizontalWeight, 1)
		DoMethodVariable( float, Weight)
		DoMethodVoidCall( setHorizontalWeight)( Weight)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "VerticalWeight", setVerticalWeight, 1)
		DoMethodVariable( float, Weight)
		DoMethodVoidCall( setVerticalWeight)( Weight)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Borders", setBorders, 1)
		DoMethodVariable( float, NewBorder)
		DoMethodVoidCall( setBorders)( NewBorder)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "HorizontalBorder", setHorizontalBorder, 1)
		DoMethodVariable( float, NewBorder)
		DoMethodVoidCall( setHorizontalBorder)( NewBorder)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "VerticalBorder", setVerticalBorder, 1)
		DoMethodVariable( float, NewBorder)
		DoMethodVoidCall( setVerticalBorder)( NewBorder)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "HorizontalAlignment", setHorizontalAlignment, 1)
		DoMethodVariableCast( HorizontalAlignment, int32, NewAlignment)
		DoMethodVoidCall( setHorizontalAlignment)( NewAlignment)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "VerticalAlignment", setVerticalAlignment, 1)
		DoMethodVariableCast( VerticalAlignment, int32, NewAlignment)
		DoMethodVoidCall( setVerticalAlignment)( NewAlignment)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Enabled", setEnabled, 1)
		DoMethodVariable( bool, Enabled)
		DoMethodVoidCall( setEnabled)( Enabled)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "FontColor", setFontColor, 4)
		DoMethodVariableCast( uint8, uint32, Red)
		DoMethodVariableCast( uint8, uint32, Green)
		DoMethodVariableCast( uint8, uint32, Blue)
		DoMethodVariableCast( uint8, uint32, Alpha)
		DoMethodVoidCall( setFontColor)( Red, Green, Blue, Alpha)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "BackgroundColor", setBackgroundColor, 4)
		DoMethodVariableCast( uint8, uint32, Red)
		DoMethodVariableCast( uint8, uint32, Green)
		DoMethodVariableCast( uint8, uint32, Blue)
		DoMethodVariableCast( uint8, uint32, Alpha)
		DoMethodVoidCall( setBackgroundColor)( Red, Green, Blue, Alpha)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "EventRoute", addEventRoute, 1)
		DoMethodVariableCast( fEventRoute *, fClassInfo *, EventRoute)
		DoMethodVoidCall( addEventRoute)( EventRoute)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Name", setName, 1)
		DoMethodVariable( char *, Name)
		DoMethodVoidCall( setName)( Name)
	DoMethodDefinitionEnd
DoMethodEnd( fClassInfo)

void fObject::setMinimumSize( const fPoint &Size)
{
	// Add horizontal and vertical borders to size
	fMinimumSize = Size + fPoint( 2 * fHorizontalBorder, 2 * fVerticalBorder);

	fMinimumSize.roundToInteger();
}

void fObject::setMaximumSize( const fPoint &Size)
{
	// Add horizontal and vertical borders to size
	fMaximumSize = Size + fPoint( 2 * fHorizontalBorder, 2 * fVerticalBorder);

	fMaximumSize.roundToInteger();
}

void fObject::setPreferredSize( const fPoint &Size)
{
	// Add horizontal and vertical borders to size
	fPreferredSize = Size + fPoint( 2 * fHorizontalBorder, 2 * fVerticalBorder);

	fPreferredSize.roundToInteger();
}

void fObject::calculateMinimumSize( void)
{
	setMinimumSize( B_ORIGIN);
}

void fObject::calculateMaximumSize( void)
{
	setMaximumSize( B_ORIGIN);
}

void fObject::calculatePreferredSize( void)
{
	setPreferredSize( B_ORIGIN);
}

void fObject::recalculateSizeLimits( void)
{
	calculateMinimumSize();
	calculatePreferredSize();
	calculateMaximumSize();
}

void fObject::setClippingRegion( const BRegion &ClippingRegion)
{
	delete fClippingRegion;
	fClippingRegion = new BRegion( ClippingRegion);
}

void fObject::removeEventRoutes( int32 fEvent)
{
	int32 Item = 0;
	fEventRoute *EventRoute;

	while(( EventRoute = static_cast<fEventRoute *>( fEventRoutes.ItemAt( Item))) != NULL)
	{
		if( EventRoute->getEvent() == fEvent)
		{
			fEventRoutes.RemoveItem( Item);
			delete EventRoute;
		}
		else
			Item++;
	}
}

void fObject::redraw( BRect RedrawRectangle) const
{
	if( getView() == NULL)
		return;

	RedrawRectangle.left	= rint( RedrawRectangle.left);
	RedrawRectangle.top		= rint( RedrawRectangle.top);
	RedrawRectangle.right	= rint( RedrawRectangle.right);
	RedrawRectangle.bottom	= rint( RedrawRectangle.bottom);

	BRegion Region;
	Region.Set( RedrawRectangle);

	if( fClippingRegion)
		Region.IntersectWith( fClippingRegion);

	drawObject( Region, false);
}

// layout related methods

// Weights
void fObject::setWeights( float Weight)
{
	fHorizontalWeight	= Weight;
	fVerticalWeight		= Weight;

	updateIfNeeded();
}

void fObject::setHorizontalWeight( float Weight)
{
	fHorizontalWeight = Weight;
	updateIfNeeded();
}

float fObject::getHorizontalWeight( void) const
{
	return( fHorizontalWeight);
}

void fObject::setVerticalWeight( float Weight)
{
	fVerticalWeight = Weight;
	updateIfNeeded(); 
}

float fObject::getVerticalWeight( void) const
{
	return( fVerticalWeight);
}

// Size
	// Limits
void fObject::getMinimumSize( fPoint &Size) const
{
	Size = fMinimumSize;
}

fPoint fObject::getMinimumSize( void) const
{
	return( fMinimumSize);
}

void fObject::getMaximumSize( fPoint &Size) const
{
	Size = fMaximumSize;
}

fPoint fObject::getMaximumSize( void) const
{
	return( fMaximumSize);
}

void fObject::getPreferredSize( fPoint &Size) const
{
	Size = fPreferredSize;
}

fPoint fObject::getPreferredSize( void) const
{
	return( fPreferredSize);
}

	// Current
void fObject::setSize( const fPoint &NewSize)
{
	fCurrentSize = NewSize;
	fCurrentSize.roundToInteger();
}

void fObject::getSize( fPoint &Size) const
{
	Size = fCurrentSize;
}

fPoint fObject::getSize( void) const
{
	return( fCurrentSize);
}

void fObject::getObjectFrame( BRect &ObjectFrame) const
{
	ObjectFrame = BRect( fCurrentPosition,
					fCurrentPosition + fCurrentSize - fPoint( 1.0, 1.0));
}

BRect fObject::getObjectFrame( void) const
{
	#if FOBJECT_DEBUG > 3
	fprintf( stderr, "fObject::getObjectFrame()\n");
	#endif

	#if FOBJECT_DEBUG > 3
	fCurrentPosition.PrintToStream();
	fCurrentSize.PrintToStream();
	#endif

//	BRect ObjectFrame = BRect( fCurrentPosition,
//								fCurrentPosition + fCurrentSize - fPoint( 1.0, 1.0));
//	ObjectFrame.InsetBy( fHorizontalBorder, fVerticalBorder);

//	return( ObjectFrame);

	return( BRect( fCurrentPosition,
					fCurrentPosition + fCurrentSize - fPoint( 1.0, 1.0)));

	#if FOBJECT_DEBUG > 3
	fprintf( stderr, "fObject::getObjectFrame() end\n");
	#endif
}

// Position
void fObject::setPosition( const fPoint &NewPosition)
{
	fCurrentPosition = NewPosition;
	fCurrentPosition.roundToInteger();
}

void fObject::getPosition( fPoint &Position) const
{
	Position = fCurrentPosition;
}

fPoint fObject::getPosition( void) const
{
	return( fCurrentPosition);
}

// Border
void fObject::setBorders( float NewBorder)
{
	setHorizontalBorder( NewBorder);
	setVerticalBorder( NewBorder);
}

void fObject::setHorizontalBorder( float NewHorizontalBorder)
{
	fMinimumSize.x		= fMinimumSize.x	- 2 * fHorizontalBorder + 2 * NewHorizontalBorder;
	fMaximumSize.x		= fMaximumSize.x	- 2 * fHorizontalBorder + 2 * NewHorizontalBorder;
	fPreferredSize.x	= fPreferredSize.x	- 2 * fHorizontalBorder + 2 * NewHorizontalBorder;

	fHorizontalBorder = NewHorizontalBorder;

	// redraw or tell parent to resize
	updateIfNeeded();
}

float fObject::getHorizontalBorder( void) const
{
	return( fHorizontalBorder);
}

void fObject::setVerticalBorder( float NewVerticalBorder)
{
	fMinimumSize.y	= fMinimumSize.y	- 2 * fVerticalBorder + 2 * NewVerticalBorder;
	fMaximumSize.y	= fMaximumSize.y	- 2 * fVerticalBorder + 2 * NewVerticalBorder;
	fPreferredSize.y	= fPreferredSize.y	- 2 * fVerticalBorder + 2 * NewVerticalBorder;

	fVerticalBorder = NewVerticalBorder;

	// redraw or tell parent to resize
	updateIfNeeded();
}

float fObject::getVerticalBorder( void) const
{
	return( fVerticalBorder);
}

// Alignment
void fObject::setHorizontalAlignment( HorizontalAlignment NewAlignment)
{
	fHorizontalAlignment = NewAlignment;
}

fObject::HorizontalAlignment fObject::getHorizontalAlignment( void) const
{
	return( fHorizontalAlignment);
}

void fObject::setVerticalAlignment( VerticalAlignment NewAlignment)
{
	fVerticalAlignment = NewAlignment;
}

fObject::VerticalAlignment fObject::getVerticalAlignment( void) const
{
	return( fVerticalAlignment);
}

// methods that change the appearance
// State
void fObject::setEnabled( bool Enabled)
{
	if( fEnabled == Enabled)
		return;

	fEnabled = Enabled;

	redraw( getObjectFrame());
//	if( getView())
//		getView()->Invalidate( getObjectFrame());
}

bool fObject::getEnabled( void) const
{
	return( fEnabled);
}

// Font
void fObject::setFont( const BFont */*Font*/)
{
}

void fObject::setFontColor( const fColor &FontColor)
{
	if( fFontColor == FontColor)
		return;

	fFontColor = FontColor;

	redraw( getObjectFrame());
//	if( getView())
//		getView()->Invalidate( getObjectFrame());
}

void fObject::setFontColor( uint8 Red, uint8 Green, uint8 Blue, uint8 Alpha)
{
	setFontColor( fColor( Red, Green, Blue, Alpha));
}

fColor fObject::getFontColor( void) const
{
	fColor FontColor = fFontColor;

	return( FontColor);
}

// Background
void fObject::setBackgroundColor( const fColor &BackgroundColor)
{
	if( fBackgroundColor == BackgroundColor)
		return;

	fBackgroundColor = BackgroundColor;

	redraw( getObjectFrame());
//	if( getView())
//		getView()->Invalidate( getObjectFrame());
}

void fObject::setBackgroundColor( uint8 Red, uint8 Green, uint8 Blue, uint8 Alpha)
{
	setBackgroundColor( fColor( Red, Green, Blue, Alpha));
}

fColor fObject::getBackgroundColor( void) const
{
	return( fBackgroundColor);
}

void fObject::setBackgroundBitmap( BBitmap *BackgroundBitmap)
{
	if( fBackgroundBitmap)
		delete fBackgroundBitmap;

	fBackgroundBitmap = BackgroundBitmap;

	redraw( getObjectFrame());
//	if( getView())
//		getView()->Invalidate( getObjectFrame());
}

// event model methods (and related)

// Localisation
const fObject *fObject::containsPoint( const fPoint &Point) const
{
	BRect rect = getObjectFrame();
	
	rect.InsetBy( getHorizontalBorder(), getVerticalBorder());
	
	if( rect.Contains( Point) == false)
		return( NULL);
		   
	return( this);
}

// Mouse
void fObject::mouseDown( MouseButton /*Button*/, const fPoint &/*Point*/, int32 /*NumClicks*/)
{
	#if FOBJECT_DEBUG > 1
	fprintf( stderr, "fObject::mouseDown() clicks: %d\n", NumClicks);
	#endif

	#if FOBJECT_DEBUG > 1
	fprintf( stderr, "fObject::mouseDown() end\n");
	#endif
}

void fObject::mouseUp( MouseButton /*Button*/, const fPoint &/*Point*/, int32 /*NumClicks*/)
{
	#if FOBJECT_DEBUG > 1
	fprintf( stderr, "fObject::mouseUp() clicks: %d\n", NumClicks);
	#endif

	#if FOBJECT_DEBUG > 1
	fprintf( stderr, "fObject::mouseUp() end\n");
	#endif
}

void fObject::mouseEntered( const fPoint &/*Point*/)
{
	#if FOBJECT_DEBUG > 1
	fprintf( stderr, "fObject::mouseEntered()\n");
	#endif

	#if FOBJECT_DEBUG > 1
	fprintf( stderr, "fObject::mouseEntered() end\n");
	#endif
}

void fObject::mouseWithin( const fPoint &/*Point*/)
{
	#if FOBJECT_DEBUG > 4
	fprintf( stderr, "fObject::mouseWithin()\n");
	#endif

	#if FOBJECT_DEBUG > 4
	fprintf( stderr, "fObject::mouseWithin() end\n");
	#endif
}

void fObject::mouseExited( const fPoint &/*Point*/)
{
	#if FOBJECT_DEBUG > 1
	fprintf( stderr, "fObject::mouseExited()\n");
	#endif

	#if FOBJECT_DEBUG > 1
	fprintf( stderr, "fObject::mouseExited() end\n");
	#endif
}

void fObject::mouseMoved( const fPoint &/*Point*/)
{
	#if FOBJECT_DEBUG > 1
	fprintf( stderr, "fObject::mouseMoved()\n");
	#endif

	#if FOBJECT_DEBUG > 1
	fprintf( stderr, "fObject::mouseMoved() end\n");
	#endif
}

// Keyboard
bool fObject::setFocus( bool Focus)
{
	// Ignore if no change in focus
	if( fFocused == Focus)
		return( false);

	fFocused = Focus;

	// force redraw
	redraw( getObjectFrame());

//	if( getView())
//		getView()->Invalidate( getObjectFrame());

	return( true);
}

bool fObject::getFocus( void) const
{
	return( fFocused);
}

void fObject::keyDown( const char */*bytes*/, int32 /*numBytes*/)
{
}

void fObject::keyUp( const char */*bytes*/, int32 /*numBytes*/)
{
}

// Events and Messages
void fObject::addEventRoute( fEventRoute *EventRoute)
{
	fEventRoutes.AddItem( EventRoute);
}

void fObject::processEvent( int32 Event, BMessage *Message)
{
	// remember message for "getCurrentMessage"
	fCurrentMessage = Message;

	int32 Item = 0;
	fEventRoute *EventRoute;
	
	while(( EventRoute = static_cast<fEventRoute *>( fEventRoutes.ItemAt( Item++))) != NULL)
	{
		if( EventRoute->getEvent() == Event)
			EventRoute->sendMessage( Message, fParentWindow);
	}

	// dispatch the message
	dispatchMessage( Event, Message);

	// forget message
	fCurrentMessage = NULL;
}

void fObject::dispatchMessage( int32 Event, BMessage *Message)
{
	#if FOBJECT_DEBUG > 3
	fprintf( stderr, "fObject::dispatchMessage()\n");
	#endif

	// check for keyboard event (starts with 'fK')
	if(( Event & 'fK\0\0') == 'fK\0\0')
	{
		#if FOBJECT_DEBUG > 3
		fprintf( stderr, "fObject::dispatchMessage() Keyboard event\n");
		#endif

		switch( Event)
		{
			case F_GOT_FOCUS:
				setFocus( true);
				break;
				
			case F_LOST_FOCUS:
				setFocus( false);
				break;

			case F_KEY_DOWN:
			{
				const char *Bytes;
				
				if( Message->FindString( "bytes", &Bytes) < B_OK)
					return;

				int32 Modifiers;

				if( Message->FindInt32( "modifiers", &Modifiers) < B_OK)
					return;

				if(( Modifiers & B_COMMAND_KEY) == B_COMMAND_KEY)
				{
					switch( Bytes[ 0])
					{
						case 'x':
							processEvent( F_CUT);
							break;
	
						case 'c':
							processEvent( F_COPY);
							break;
	
						case 'v':
							processEvent( F_PASTE);
							break;
	
						default:
							keyDown( Bytes, strlen( Bytes));
							break;
					}
				}
				else
					keyDown( Bytes, strlen( Bytes));
			}
			break;
				
			case F_KEY_UP:
			{
				const char *Bytes;
				
				if( Message->FindString( "bytes", &Bytes) < B_OK)
					return;

				keyUp( Bytes, strlen( Bytes));
			}
			break;

			default:
				messageReceived( Event, Message);
				break;
		}
	}
	else	
	// check for mouse event (starts with 'fM')
	if(( Event & 'fM\0\0') == 'fM\0\0')
	{
		#if FOBJECT_DEBUG > 3
		fprintf( stderr, "fObject::dispatchMessage() Mouse event\n");
		#endif

		// all mouse events need the mouse position...
		BPoint BePoint;

		if( Message->FindPoint( "fLocation", &BePoint) < B_OK)
			return;

		fPoint Point = BePoint;

		int32 Clicks;
		
		Message->FindInt32( "fClicks", &Clicks);

		switch( Event)
		{
			case F_PRIMARY_MOUSE_DOWN:
				mouseDown( F_PRIMARY_MOUSE_BUTTON, Point, Clicks);
				break;

			case F_SECONDARY_MOUSE_DOWN:
				mouseDown( F_SECONDARY_MOUSE_BUTTON, Point, Clicks);
				break;

			case F_TERTIARY_MOUSE_DOWN:
				mouseDown( F_TERTIARY_MOUSE_BUTTON, Point, Clicks);
				break;

			case F_PRIMARY_MOUSE_UP:
				mouseUp( F_PRIMARY_MOUSE_BUTTON, Point, Clicks);
				break;

			case F_SECONDARY_MOUSE_UP:
				mouseUp( F_SECONDARY_MOUSE_BUTTON, Point, Clicks);
				break;

			case F_TERTIARY_MOUSE_UP:
				mouseUp( F_TERTIARY_MOUSE_BUTTON, Point, Clicks);
				break;

			case F_MOUSE_MOVED:
			{
				int32 Transit = 0;
			
				if( Message->FindInt32( "fTransit", &Transit) == B_OK)
				{
					#if FOBJECT_DEBUG > 3
					fprintf( stderr, "Transit found!\n");
					#endif

					switch( Transit)
					{
						case F_MOUSE_ENTERED:
							mouseEntered( Point);
							break;
			
						case F_MOUSE_WITHIN:
							mouseWithin( Point);
							break;
			
						case F_MOUSE_EXITED:
							mouseExited( Point);
							break;

						default:
							break;
					}
				}
			}
			break;

			default:
				messageReceived( Event, Message);
				break;
		}
	}
	else
	// Some other event ?
	switch( Event)
	{
		case F_ENABLE_OBJECT:
			setEnabled( true);
			break;

		case F_DISABLE_OBJECT:
			setEnabled( false);
			break;

		default:
			messageReceived( Event, Message);
			break;
	}

	#if FOBJECT_DEBUG > 3
	fprintf( stderr, "fObject::dispatchMessage() end\n");
	#endif
}

void fObject::messageReceived( int32 /*Event*/, BMessage */*Message*/)
{
}

const BMessage *fObject::getCurrentMessage( void) const
{
	return( fCurrentMessage);
}

// hierarchy related methods

// Name
void fObject::setName( const char *Name)
{
	delete [] fObjectName;

	if( Name)
	{
		fObjectName	= new char[ strlen( Name) + 1];
		strcpy( fObjectName, Name);
	}
	else
		fObjectName = NULL;
}

const char *fObject::getName( void) const
{
	return( fObjectName);
}

// View
void fObject::setView( BView *NewView)
{
	fDrawView = NewView;
}

BView *fObject::getView( void) const
{
	return( fDrawView);
}

// Parent
void fObject::setParent( fObject *Parent)
{
	fParent = Parent;
}

fObject *fObject::getParent( void) const
{
	return( fParent);
}

// Window
void fObject::attachedToWindow( const class fWindow *ParentWindow)
{
	fParentWindow = ParentWindow;	
}

void fObject::detachedFromWindow( void)
{
	fParentWindow = NULL;
}

const class fWindow *fObject::getWindow( void) const
{
	return( fParentWindow);
}

bool fObject::setWindowActivated( bool Activated)
{
	if( fWindowActivated == Activated)
		return( false);

	fWindowActivated = Activated;
	return( true);
}

bool fObject::getWindowActivated( void) const
{
	return( fWindowActivated);
}

void fObject::updateIfNeeded( void)
{
//	fprintf( stderr, "fObject::updateIfNeeded() Classname: %s\n", getClassName());

	// calculate new size limits
	recalculateSizeLimits();

	// tell parent to update
	if( getParent())
		getParent()->updateIfNeeded(); 
}
	
// Find
bool fObject::findObject( const fObject *ObjectPointer) const
{
	if( ObjectPointer == this)
		return( true);

	return( false);
}

const fObject *fObject::findObject( const char *ObjectName) const
{
	if( fObjectName && ObjectName)
		if( strcmp( fObjectName, ObjectName) == 0)
			return( this);

	return( NULL);
}