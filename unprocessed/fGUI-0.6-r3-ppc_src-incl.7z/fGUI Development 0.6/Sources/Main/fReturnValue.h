// fReturnValue.h

#ifndef fReturnValue_h
#define fReturnValue_h

#pragma export on

class fReturnValue
{
	protected:

		union
		{
			int64	fValue1;
			double	fValue2;
		} fValue;

		bool fValid;

	public:

		fReturnValue( void);

		void setValid( bool Valid);
		bool getValid( void) const;

		fReturnValue( bool Value);
		fReturnValue( int Value);
		fReturnValue( unsigned int Value);
		fReturnValue( int8 Value);
		fReturnValue( uint8 Value);
		fReturnValue( int16 Value);
		fReturnValue( uint16 Value);
		fReturnValue( int32 Value);
		fReturnValue( uint32 Value);
		fReturnValue( int64 Value);
		fReturnValue( uint64 Value);
		fReturnValue( float Value);
		fReturnValue( double Value);
		fReturnValue( char *Value);

		fReturnValue &operator =( bool Value);
		fReturnValue &operator =( int Value);
		fReturnValue &operator =( unsigned int Value);
		fReturnValue &operator =( int8 Value);
		fReturnValue &operator =( uint8 Value);
		fReturnValue &operator =( int16 Value);
		fReturnValue &operator =( uint16 Value);
		fReturnValue &operator =( int32 Value);
		fReturnValue &operator =( uint32 Value);
		fReturnValue &operator =( int64 Value);
		fReturnValue &operator =( uint64 Value);
		fReturnValue &operator =( float Value);
		fReturnValue &operator =( double Value);
		fReturnValue &operator =( char *Value);

		operator bool( void) const;
		operator int( void) const;
		operator unsigned int( void) const;
		operator int8( void) const;
		operator uint8( void) const;
		operator int16( void) const;
		operator uint16( void) const;
		operator int32( void) const;
		operator uint32( void) const;
		operator int64( void) const;
		operator uint64( void) const;
		operator float( void) const;
		operator double( void) const;
		operator char *( void) const;
};

#pragma export off

#endif
