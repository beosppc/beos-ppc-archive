// fPoint.h

#ifndef fPoint_h
#define fPoint_h

//#include "fClassInfo.h"

#pragma export on

class fPoint// : public fClassInfo
{
	private:

//		ClassDeclaration( fPoint);
	
	public:
	
		double x, y;
	
		fPoint( double X = 0.0, double Y = 0.0);
		fPoint( const fPoint &Point);
		fPoint( const BPoint &Point);
	
		bool operator <( const fPoint &Point) const;
		bool operator >( const fPoint &Point) const;

		fPoint &operator =( const fPoint &Point);
		fPoint &operator =( const BPoint &Point);

		bool operator ==( const fPoint &Point) const;
		bool operator ==( const BPoint &Point) const;

		bool operator !=( const fPoint &Point) const;
		bool operator !=( const BPoint &Point) const;

		fPoint operator +( const fPoint &Point) const;
		fPoint &operator +=( const fPoint &Point);

		fPoint operator -( const fPoint &Point) const;
		fPoint &operator -=( const fPoint &Point);

		fPoint operator *( double Multiplier) const;

		operator BPoint( void) const;

		void set( double X, double Y);

		void constrainTo( const BRect &Rect);
		void rotateBy( float Angle);
		void roundToInteger( void);

		void printToStream( const char *Text = NULL) const;
};

#pragma export off

#endif