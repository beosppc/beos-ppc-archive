// fStyleFactory.cpp

#include "fStyleFactory.h"
#include "fClassInfo.h"

#if DEBUG > 0
#define FAPPLICATION_DEBUG DEBUG
#endif

//#undef FFACTORY_DEBUG
//#define FFACTORY_DEBUG 2

fStyleFactory *fStyleFactory::Factory = NULL;

fStyleFactory::fStyleFactory( const char *StyleName)
{
	if( StyleName)
	{
		fStyleName = new char[ strlen( StyleName) + 1];
		strcpy( fStyleName, StyleName);
	}
	else
		fStyleName = NULL;
}
	
fStyleFactory::~fStyleFactory( void)
{
	delete [] fStyleName;
}

const char *fStyleFactory::getStyleName( void) const
{
	return( fStyleName);
}

void fStyleFactory::registerClass( class fClassInfo *Class)
{
/*
	fprintf( stderr, "Registering class %d: %s (descendant of %s)\n",
				fRegisteredClasses.CountItems() + 1,
				Class->getClassName(), Class->getBaseClassName());
*/
	fRegisteredClasses.AddItem( Class);
}

class fClassInfo *fStyleFactory::createInstance( const char *ClassName) const
{
	char *FullClassName = new char[ 1 + strlen( fStyleName) + strlen( ClassName) + 1];
	sprintf( FullClassName, "f%s%s", fStyleName, ClassName);

	int32 Item = 0;
	fClassInfo *Class;
	fClassInfo *NewClass = NULL;
	
	while(( Class = static_cast<fClassInfo *>( fRegisteredClasses.ItemAt( Item++))) != NULL)
	{
		if( Class->isOfType( FullClassName))
		{
			NewClass = Class->createInstance();
			break;
		}
	}

	delete [] FullClassName;
	return( NewClass);
}












