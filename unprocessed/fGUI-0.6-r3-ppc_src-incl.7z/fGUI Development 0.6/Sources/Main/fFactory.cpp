// fFactory.cpp

#include "fFactory.h"
#include "fStyleFactory.h"

#include "fWindow.h"

#include "fBuilder.h"

#if DEBUG > 0
#define FAPPLICATION_DEBUG DEBUG
#endif

//#undef FFACTORY_DEBUG
//#define FFACTORY_DEBUG 2

fFactory *fFactory::Factory = NULL;

fFactory::fFactory( void)
{
	// store pointer to factory
	Factory = this;

	// set default style
	fDefaultStyle = new char[ 1];
	*fDefaultStyle = 0x0;

	// create default factory
	fDefaultFactory = new fStyleFactory( fDefaultStyle);
	fStyleFactories.AddItem( fDefaultFactory);
	
	// create fBuilder instance
	fGUIBuilder = new fBuilder();
}
	
fFactory::~fFactory( void)
{
	delete [] fDefaultStyle;
	delete fDefaultFactory;
	delete fGUIBuilder;
}
	
fFactory * const fFactory::getFactory( void)
{
	if( Factory == NULL)
		new fFactory();

	return( Factory);
}

void fFactory::setDefaultStyle( const char *DefaultStyle)
{
	if( DefaultStyle == NULL)
		return;

	delete [] fDefaultStyle;

	fDefaultStyle = new char[ strlen( DefaultStyle) + 1];
	strcpy( fDefaultStyle, DefaultStyle);
}

void fFactory::registerClass( class fClassInfo *Class, const char *StyleName)
{
	if(( Class == NULL) || ( StyleName == NULL))
		return;

//	fprintf( stderr, "fFactory::registerClass( '%s', '%s')\n", Class->getClassName(), StyleName);

	// find style factory
	int32 Item = 0;
	fStyleFactory *StyleFactory;
	
	while(( StyleFactory = static_cast<fStyleFactory *>(fStyleFactories.ItemAt( Item++))) != NULL)
	{
		if( strcmp( StyleFactory->getStyleName(), StyleName) == 0)
		{
			StyleFactory->registerClass( Class);
			return;
		}
	}
	
	// no factory found, create new one
//	fprintf( stderr, "fFactory::registerClass() creating new factory\n");
	StyleFactory = new fStyleFactory( StyleName);
	fStyleFactories.AddItem( StyleFactory);
	StyleFactory->registerClass( Class);
}

class fClassInfo *fFactory::createInstance( const char *ClassName) const
{
	fClassInfo *NewClass;
	
//	fprintf( stderr, "fFactory::createInstance() Creating an instance of '%s'\n", ClassName);

	if(( NewClass = fGUIBuilder->createInstance( ClassName)) != NULL)
		return( NewClass);

//	fprintf( stderr, "fFactory::createInstance() Can't create an instance of '%s'\n", ClassName);

	return( createInstance_Builder( ClassName));
}

class fClassInfo *fFactory::createInstance_Builder( const char *ClassName) const
{
	int32 Item = 0;
	fStyleFactory *StyleFactory;
	fClassInfo *NewClass;

//	fprintf( stderr, "fFactory::createInstance_Builder() Creating an instance of '%s'\n", ClassName);

	while(( StyleFactory = static_cast<fStyleFactory *>( fStyleFactories.ItemAt( Item++))) != NULL)
	{
		if( strcmp( StyleFactory->getStyleName(), fDefaultStyle) == 0)
		{
			NewClass = StyleFactory->createInstance( ClassName);

			if( NewClass)
				return( NewClass);
			else
			{
				NewClass = fDefaultFactory->createInstance( ClassName);
				return( NewClass);
//				if( NewClass)
//					return( NewClass);
			}
			
			break;
		}
	}

	fprintf( stderr, "fFactory::createInstance_Builder() Can't create an instance of '%s'\n", ClassName);
	return( NULL);
}

bool fFactory::importGUIDescription( const char *GUIDescriptionFile)
{
	return( fGUIBuilder->importGUIDescription( GUIDescriptionFile));
}