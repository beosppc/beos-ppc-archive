// fPoint.cpp

#include "fPoint.h"

//#include "fFactory.h"

//ClassDefinition( fPoint, fClassInfo);

fPoint::fPoint( double X, double Y)
	: x( X), y( Y)
{
}

fPoint::fPoint( const BPoint &Point)
	: x( Point.x), y( Point.y)
{
}

fPoint::fPoint( const fPoint &Point)
	: x( Point.x), y( Point.y)
{
}
	
bool fPoint::operator <( const fPoint &Point) const
{
	if( x < Point.x || y < Point.y)
		return( true);

	return( false);
}

bool fPoint::operator >( const fPoint &Point) const
{
	if( x > Point.x || y > Point.y)
		return( true);

	return( false);
}

fPoint &fPoint::operator =( const fPoint &Point)
{
	x = Point.x;
	y = Point.y;
	
	return( *this);
}

fPoint &fPoint::operator =( const BPoint &Point)
{
	x = Point.x;
	y = Point.y;
	
	return( *this);
}

bool fPoint::operator ==( const fPoint &Point) const
{
	if(( Point.x == x) && ( Point.y == y))
		return( true);

	return( false);
}

bool fPoint::operator ==( const BPoint &Point) const
{
	if(( Point.x == x) && ( Point.y == y))
		return( true);

	return( false);
}

bool fPoint::operator !=( const fPoint &Point) const
{
	if(( Point.x != x) || ( Point.y != y))
		return( true);

	return( false);
}

bool fPoint::operator !=( const BPoint &Point) const
{
	if(( Point.x != x) || ( Point.y != y))
		return( true);

	return( false);
}

fPoint fPoint::operator +( const fPoint &Point) const
{
	return( fPoint( x + Point.x, y + Point.y));
}

fPoint &fPoint::operator +=( const fPoint &Point)
{
	x += Point.x;
	y += Point.y;

	return( *this);
}

fPoint fPoint::operator -( const fPoint &Point) const
{
	return( fPoint( x - Point.x, y - Point.y));
}

fPoint &fPoint::operator -=( const fPoint &Point)
{
	x -= Point.x;
	y -= Point.y;

	return( *this);
}

fPoint fPoint::operator *( double Multiplier) const
{
	return( fPoint( x * Multiplier, y * Multiplier));
}

fPoint::operator BPoint( void) const
{
	return( BPoint( x, y));
}

void fPoint::set( double X, double Y)
{
	x = X;
	y = Y;
}

void fPoint::constrainTo( const BRect &Rect)
{
	if( x < Rect.left)
		x = Rect.left;

	if( x > Rect.right)
		x = Rect.right;

	if( y < Rect.top)
		y = Rect.top;

	if( y > Rect.bottom)
		y = Rect.bottom;
}

void fPoint::rotateBy( float Angle)
{
	double NewX, NewY;
	double rad = Angle / 180 * M_PI;

	NewX = cos( rad) * ( double) x - sin( rad) * ( double) y;
	NewY = sin( rad) * ( double) x + cos( rad) * ( double) y;

	x = NewX;
	y = NewY;
}

void fPoint::roundToInteger( void)
{
	x = static_cast<int64>( x + 0.5);
	y = static_cast<int64>( y + 0.5);

//	x = rint( x);
//	y = rint( y);
}

void fPoint::printToStream( const char *Text) const
{
	if( Text)
		fprintf( stderr, "%s", Text);

	fprintf( stderr, "fPoint( x:%.2f, y:%.2f)\n", x, y);
}

