// fTextInput.cpp

#include "fTextInput.h"
#include "fFactory.h"

#include "fEventRoute.h"

#include "fAlarm.h"

#include "fWindow.h"

#if DEBUG > 0
#define FTEXTINPUT_DEBUG DEBUG
#endif

//#undef FTEXTINPUT_DEBUG
//#define FTEXTINPUT_DEBUG 2
 
ClassDefinition( fTextInput, fObject, "");

fTextInput::fTextInput( const char *MinimumWidthText)
{
	fAcceptCharacters	= NULL;
	fRejectCharacters	= NULL;
	fMinimumWidthText	= NULL;

	fText				= new char[ 1];
	*fText				= 0x0;

	fTextChanged		= false;

	fFont				= NULL;
	setFont( be_plain_font);

	setMinimumWidthText( MinimumWidthText);

	setBackgroundColor( 0xff, 0xff, 0xff);

	fWatchMouse			= false;
	fHighlightStart		= 100.0;
	fHighlightEnd		= 120.0;

	fShowCursor			= true;
	fCursorPosition		= 0;

	fTextOffset			= 0.0;
	fBeamPosition		= 0.0;

	setVerticalWeight( 0.0);

	recalculateSizeLimits();
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

	// prepare alarms
	fCursorPulse = new fAlarm();

	fEventRoute *AlarmRoute = new fEventRoute( F_ALARM);
	AlarmRoute->setSourcePointer( this);
	AlarmRoute->setTargetPointer( this);
	AlarmRoute->setAction( F_TEXTINPUT_CURSOR_PULSE);

	fCursorPulse->setAlarm( AlarmRoute, 500000, true);

	fMouseMovedPulse = new fAlarm();

	AlarmRoute = new fEventRoute( F_ALARM);
	AlarmRoute->setSourcePointer( this);
	AlarmRoute->setTargetPointer( this);
	AlarmRoute->setAction( F_TEXTINPUT_MOUSE_PULSE);

	fMouseMovedPulse->setAlarm( AlarmRoute, 50000, true);
}

fTextInput::~fTextInput( void)
{
	delete [] fAcceptCharacters;
	delete [] fRejectCharacters;
	
	delete [] fMinimumWidthText;
	
	delete [] fText;

	delete fFont;
	
	delete fCursorPulse;
	delete fMouseMovedPulse;
}

DoMethodBegin( fTextInput)
	DoMethodDefinitionBegin( "Text", setText, 1)
		DoMethodVariable( char *, Text)
		DoMethodVoidCall( setText)( Text)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "MinimumWidthText", setMinimumWidthText, 1)
		DoMethodVariable( char *, MinimumWidthText)
		DoMethodVoidCall( setMinimumWidthText)( MinimumWidthText)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "AcceptCharacters", setAcceptCharacters, 1)
		DoMethodVariable( char *, AcceptCharacters)
		DoMethodVoidCall( setAcceptCharacters)( AcceptCharacters)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "RejectCharacters", setRejectCharacters, 1)
		DoMethodVariable( char *, RejectCharacters)
		DoMethodVoidCall( setRejectCharacters)( RejectCharacters)
	DoMethodDefinitionEnd
DoMethodEnd( fObject)

int32 fTextInput::UTF8Len( void) const
{
	int32 count = 0; 
	char *Text = fText;

	while( *Text)
		if(((*Text++ & 0xc0) != 0x80)) 
			count++; 

	return( count);
}

int32 fTextInput::nextCharacter( int32 CursorPosition, const char *Text)
{
	if( CursorPosition == -1)
		CursorPosition = fCursorPosition;

	if( Text == NULL)
		Text = fText;

	// if the cursor is already at the end, don't move
	if( Text[ CursorPosition] == 0x0)
		return( CursorPosition);

	int32 NextPosition = CursorPosition + 1;

	while( Text[ NextPosition])
		if(((Text[ NextPosition] & 0xc0) != 0x80)) 
			break;
		else
			NextPosition++;

	return( NextPosition);
}

int32 fTextInput::previousCharacter( int32 CursorPosition, const char *Text)
{
	if( CursorPosition == -1)
		CursorPosition = fCursorPosition;

	if( Text == NULL)
		Text = fText;

	// if the cursor is already at the beginning, don't move
	if( CursorPosition == 0)
		return( CursorPosition);

	int32 PreviousPosition = CursorPosition - 1;

	while( PreviousPosition >= 0)
		if(((Text[ PreviousPosition] & 0xc0) != 0x80))
			break;
		else
			PreviousPosition--;

	// shouldn't be necessary... but you never know !
	if( PreviousPosition < 0)
		return( 0);

	return( PreviousPosition);
}

bool fTextInput::acceptCharacter( const char *Input)
{
	if( fAcceptCharacters == NULL)
		return( true);

	if( strstr( fAcceptCharacters, Input))
		return( true);

	return( false);
}

bool fTextInput::rejectCharacter( const char *Input)
{
	if( fRejectCharacters == NULL)
		return( false);

	if( strstr( fRejectCharacters, Input))
		return( true);

	return( false);
}

void fTextInput::repositionCursor( bool Redraw)
{
	char Temp = fText[ fCursorPosition];
	fText[ fCursorPosition] = 0x0;
	
	float BeamPosition = fFont->StringWidth( fText);
	
	fText[ fCursorPosition] = Temp;

	float TextOffset = fTextOffset;

	if(( BeamPosition < fTextOffset) || ( BeamPosition > fTextOffset + ( fTextFrame.Width() - 1.0)))
	{
		TextOffset = fBeamPosition - ( fTextFrame.Width() + 1.0) / 2.0;
	
		if( TextOffset < 0.0)
			TextOffset = 0.0;
	}

	fShowCursor = true;

	if(( TextOffset != fTextOffset) || Redraw)
	{
		fBeamPosition = BeamPosition;	
		fTextOffset = TextOffset;

		redraw( fTextFrame);
	}
	else
	{
		drawCursor( true);
		fBeamPosition = BeamPosition;
		drawCursor();
	}
}

void fTextInput::calculateCursorAndBeamPosition( const fPoint &Point, int32 &CursorPosition,
													float &BeamPosition, float &TextOffset)
{
	int32 StrLen = UTF8Len();
	
	float *Escapements = new float[ StrLen];

	fFont->GetEscapements( fText, StrLen, Escapements);

	float ClickPosition = Point.x - fTextFrame.LeftTop().x + fTextOffset;
	ClickPosition = rint( ClickPosition);

	CursorPosition = 0;
	BeamPosition = 0.0;

	int32 Index = 0;
	
	for( ; Index < StrLen; Index++)
	{
		if(( BeamPosition + Escapements[ Index] * fFont->Size()) >= ClickPosition)
			break;

		BeamPosition += Escapements[ Index] * fFont->Size();
		CursorPosition = nextCharacter( CursorPosition);
	}

	delete [] Escapements;

	if(( BeamPosition < fTextOffset) || ( BeamPosition > fTextOffset + ( fTextFrame.Width() - 1.0)))
	{
		TextOffset = BeamPosition - ( fTextFrame.Width() + 1.0) / 2.0;

		if( TextOffset < 0.0)
			TextOffset = 0.0;
	}
	else
		TextOffset = fTextOffset;
}

void fTextInput::handleInput( const char *Input, int32 Length)
{
	if( Input == NULL)
		return;

	if( Length == 0)
		return;

	switch( *Input)
	{
		case B_BACKSPACE:
		{
			// delete character left of cursor position
			int32 NewCursorPosition = previousCharacter();

			if( fHighlightStartCursor != fHighlightEndCursor)
			{
				fCursorPosition		= fHighlightEndCursor;
				NewCursorPosition	= fHighlightStartCursor;
				fHighlightEndCursor	= fHighlightStartCursor;
			}
			else if( fCursorPosition == 0)
				return;

			char *NewText = new char[ strlen( fText) - ( fCursorPosition -  NewCursorPosition) + 1];
			strncpy( NewText, fText, NewCursorPosition);
			NewText[ NewCursorPosition] = 0x0;
			strcat( NewText, &fText[ fCursorPosition]);
			delete [] fText;

			fText = NewText;
			fCursorPosition = NewCursorPosition;

			repositionCursor( true);

			fTextChanged = true;
		}
		break;

		case B_LEFT_ARROW:
		{
			// move cursor one character to the left
			if(( fHighlightStartCursor != fHighlightEndCursor) && ( fCursorPosition != fHighlightStartCursor))
			{
				fCursorPosition = fHighlightEndCursor = fHighlightStartCursor;
				repositionCursor( true);
			}
			else
			{
				if( fCursorPosition == 0)
					return;

				fCursorPosition = previousCharacter();

				repositionCursor();
			}
		}
		break;

		case B_RETURN: // == B_ENTER
		{
			// finish entering
			if( fTextChanged == false)
				return;

			BMessage Message;
			Message.AddString( "fValue", fText);

			processEvent( F_TEXTINPUT_VALUE_CHANGED, &Message);

			fTextChanged = false;
		}
		break;

		case B_RIGHT_ARROW:
		{
			// move cursor one character to the right
			if(( fHighlightStartCursor != fHighlightEndCursor) && ( fCursorPosition != fHighlightEndCursor))
			{
				fCursorPosition = fHighlightStartCursor = fHighlightEndCursor;
				repositionCursor( true);
			}
			else
			{
				if( fText[ fCursorPosition] == 0x0)
					return;

				fCursorPosition = nextCharacter();
			
				repositionCursor();
			}
		}
		break;

		case B_DELETE:
		{
			// delete character right of cursor position
			int32 NewCursorPosition = nextCharacter();

			if( fHighlightStartCursor != fHighlightEndCursor)
			{
				NewCursorPosition	= fHighlightEndCursor;
				fCursorPosition		= fHighlightStartCursor;
				fHighlightEndCursor	= fHighlightStartCursor;
			}
			
			if( fText[ fCursorPosition] == 0x0)
				return;

			char *NewText = new char[ strlen( fText) - ( NewCursorPosition -  fCursorPosition) + 1];
			strncpy( NewText, fText, fCursorPosition);
			NewText[ fCursorPosition] = 0x0;
			strcat( &NewText[ fCursorPosition], &fText[ NewCursorPosition]);
			delete [] fText;

			fText = NewText;

			repositionCursor( true);

			fTextChanged = true;
		}
		break;

		case B_PAGE_UP:
		case B_HOME:
		case B_UP_ARROW:
		{
			// move cursor one character before the first character
			if( fCursorPosition == 0)
				return;

			fCursorPosition = 0;
			repositionCursor();
		}
		break;

		case B_PAGE_DOWN:
		case B_END:
		case B_DOWN_ARROW:
		{
			// move cursor one character after the last character
			if( fText[ fCursorPosition] == 0x0)
				return;

			fCursorPosition = strlen( fText);
			repositionCursor();
		}
		break;

		case B_INSERT:
		case B_TAB:
		case B_ESCAPE:
		case B_FUNCTION_KEY:
			// ignore input
			break;

		default:
		{
			// insert text at cursor position
			if(( acceptCharacter( Input) == false) || ( rejectCharacter( Input) == true))
				return;

			if( fHighlightStartCursor == fHighlightEndCursor)
				fHighlightEndCursor = fHighlightStartCursor = fCursorPosition;

			char *NewText = new char[ strlen( fText) - ( fHighlightEndCursor -  fHighlightStartCursor) + Length + 1];
			strncpy( NewText, fText, fHighlightStartCursor);
			NewText[ fHighlightStartCursor] = 0x0;
			strcat( NewText, Input);
			strcat( NewText, &fText[ fHighlightEndCursor]);
			delete [] fText;

			fText = NewText;
			fCursorPosition = nextCharacter( fHighlightEndCursor);

			fHighlightStartCursor = fHighlightEndCursor;

//			fprintf( stderr, "new cursor position: %d, strlen( fText): %d, fText: '%s'\n", fCursorPosition, strlen( fText), fText);
			repositionCursor( true);

			fTextChanged = true;
		}
		break;
	}
}

void fTextInput::setDefaultEvents( void)
{
	removeEventRoutes( F_PRIMARY_MOUSE_DOWN);

	if( getWindow() == NULL)
		return;

	fEventRoute *EventRoute = new fEventRoute( F_PRIMARY_MOUSE_DOWN);

	EventRoute->setAction( F_REQUEST_GET_FOCUS);

	EventRoute->setTargetName( getWindow()->getWindowTitle());

	if( getName())
		EventRoute->setSourceName( getName());
	else
		EventRoute->setSourcePointer( this);

	addEventRoute( EventRoute);
	
	#if FTEXTINPUT_DEBUG > 1
	fprintf( stderr, "fTextInput::setDefaultEvents() EventRoute:\n");
	EventRoute->printToStream();
	#endif
}

void fTextInput::recalculateSizeLimits( void)
{
	if( fFont == NULL)
	{
		setMinimumSize( fPoint( 5.0, 5.0));
		setPreferredSize( fPoint( 5.0, 5.0));
		
		return;
	}

	font_height fontheight;

	fFont->GetHeight( &fontheight);

	float FontWidth = fFont->StringWidth( fMinimumWidthText);
	float FontHeight = fontheight.ascent + fontheight.descent + fontheight.leading;

	fTextPosition = fPoint( 0.0, fontheight.ascent);

	fPoint Size( FontWidth, FontHeight);

	// Size for the inner spacing
	Size += fPoint( 2.0 * 1.0, 2.0 + 1.0);

	// outer frame, 2 pixels each
	Size += fPoint( 2 * 2.0, 2 * 2.0);

	setMinimumSize( Size);
	setPreferredSize( Size);
}

void fTextInput::attachedToWindow( const class fWindow *ParentWindow)
{
	#if FTEXTINPUT_DEBUG > 2
	fprintf( stderr, "fTextInput::attachedToWindow()\n");
	#endif

	fObject::attachedToWindow( ParentWindow);

	setDefaultEvents();

	#if FTEXTINPUT_DEBUG > 2
	fprintf( stderr, "fTextInput::attachedToWindow() end\n");
	#endif
}

void fTextInput::detachedFromWindow( void)
{
	removeEventRoutes( F_PRIMARY_MOUSE_DOWN);
}

void fTextInput::setFont( const BFont *Font)
{
	if( Font == NULL)
		return;

	delete fFont;

	fFont = new BFont( Font);

	// No rotation or shear supported in fTextInput...
	fFont->SetRotation( 0.0);
	fFont->SetShear( 90.0);

	updateIfNeeded();
}

void fTextInput::setSize( const fPoint &NewSize)
{
	fObject::setSize( NewSize);

	fTextFrame = getObjectFrame();
	fTextFrame.InsetBy( getHorizontalBorder() + 3.0, getVerticalBorder() + 3.0);

	fTextFrame.left		= rint( fTextFrame.left);
	fTextFrame.top		= rint( fTextFrame.top);
	fTextFrame.right	= rint( fTextFrame.right);
	fTextFrame.bottom	= rint( fTextFrame.bottom);
}

void fTextInput::setPosition( const fPoint &NewPosition)
{
	fObject::setPosition( NewPosition);

	fTextFrame = getObjectFrame();
	fTextFrame.InsetBy( getHorizontalBorder() + 3.0, getVerticalBorder() + 3.0);

	fTextFrame.left		= rint( fTextFrame.left);
	fTextFrame.top		= rint( fTextFrame.top);
	fTextFrame.right	= rint( fTextFrame.right);
	fTextFrame.bottom	= rint( fTextFrame.bottom);
}

bool fTextInput::setFocus( bool Focus)
{
	if( fObject::setFocus( Focus) == false)
		return( false);

	if( getFocus() && getWindowActivated() && getEnabled() && !fWatchMouse)
	{
		fCursorPulse->startAlarm();
		fShowCursor = true;
	}
	else
	{
		fCursorPulse->stopAlarm();
		fShowCursor = false;
	}

	// when losing focus, de-highlight and send message
	if( getFocus() == false)
	{
		if( fTextChanged)
		{
			BMessage Message;
			Message.AddString( "fValue", fText);
	
			processEvent( F_TEXTINPUT_VALUE_CHANGED, &Message);
	
			fTextChanged = false;
		}

		fHighlightStartCursor = fHighlightEndCursor;	
		redraw( fTextFrame);
	}

	return( true);
}

bool fTextInput::setWindowActivated( bool Activated)
{
	if( fObject::setWindowActivated( Activated) == false)
		return( false);
	
	if( getFocus() && getWindowActivated() && getEnabled() && !fWatchMouse)
	{
		fCursorPulse->startAlarm();
		fShowCursor = true;
	}
	else
	{
		fCursorPulse->stopAlarm();
		fShowCursor = false;
	}

	redraw( getObjectFrame());

	return( true);
}

void fTextInput::setEnabled( bool Active)
{
	fObject::setEnabled( Active);
	
	if( getFocus() && getWindowActivated() && getEnabled() && !fWatchMouse)
	{
		fCursorPulse->startAlarm();
		fShowCursor = true;
	}
	else
	{
		fCursorPulse->stopAlarm();
		fShowCursor = false;
	}
}

void fTextInput::messageReceived( int32 Event, BMessage *Message)
{
	switch( Event)
	{
		case F_CUT:
		case F_COPY:
		{
			if( fHighlightStartCursor != fHighlightEndCursor)
			{
				if( be_clipboard->Lock())
				{ 
					be_clipboard->Clear(); 
					BMessage *clipper = be_clipboard->Data(); 
					clipper->AddData( "text/plain", B_MIME_TYPE, &fText[ fHighlightStartCursor], fHighlightEndCursor - fHighlightStartCursor); 
					be_clipboard->Commit(); 
					be_clipboard->Unlock();				
				}
			}
		}

		if( Event == F_CUT)
		{
			char temp = B_DELETE;
			handleInput( &temp, 1);
		}
		break;

		case F_PASTE:
		{
			if( be_clipboard->Lock())
			{ 
				BMessage *clipper = be_clipboard->Data(); 

				const char *Input;
				int32 Length;
				if( clipper->FindData( "text/plain", B_MIME_TYPE, &Input, &Length) == B_OK)
				{
					int32 NewPosition = 0;
					int32 OldPosition = 0;

					char *Input2 = new char[ strlen( Input) + 1];
					strcpy( Input2, Input);

					while( NewPosition < Length)
					{
						NewPosition = nextCharacter( OldPosition, Input2);
						char temp = Input2[ NewPosition];
						Input2[ NewPosition] = 0x0;
						handleInput( &Input2[ OldPosition], NewPosition - OldPosition);
						Input2[ NewPosition] = temp;
						OldPosition = NewPosition;
					}
					
					delete [] Input2;
				}
				be_clipboard->Unlock(); 
			}
		}
		break;
		
		case F_TEXTINPUT_CURSOR_PULSE:
		{
			fShowCursor = !fShowCursor;
			drawCursor();
		}
		break;
		
		case F_TEXTINPUT_MOUSE_PULSE:
		{
			if( fMousePosition.x < fTextFrame.left)
			{
				if( fTextOffset == 0.0)
					return;

				fTextOffset -= ( fTextFrame.left - fMousePosition.x) / 2.0;

				if( fTextOffset < 0.0)
					fTextOffset = 0.0;
			}
			
			if( fMousePosition.x > fTextFrame.right)
			{
				float StringWidth = fFont->StringWidth( fText);

				if( fTextOffset == ( StringWidth - 10.0) || StringWidth <= 10.0)
					return;

				fTextOffset += ( fMousePosition.x - fTextFrame.right) / 2.0;

				if( fTextOffset > StringWidth - 10.0)
					fTextOffset = StringWidth - 10.0;
			}

			calculateHighlighting( fMousePosition);

			redraw( fTextFrame);
		}
		break;
		
		case F_TEXTINPUT_VALUE_CHANGED:
			if( Message)
			{
				const char *NewValue;
				
				if( Message->FindString( "fValue", &NewValue) == B_OK)
				{
					fprintf( stderr, "New value: '%s'\n", NewValue);
				}
			}
			break;

		default:
			break;
	}
}

void fTextInput::mouseDown( MouseButton Button, const fPoint &Point, int32 NumClicks)
{
	#if FTEXTINPUT_DEBUG > 2
	fprintf( stderr, "fTextInput::mouseDown()\n");
	#endif

	if( getEnabled() == false)
		return;

	if( Button != B_PRIMARY_MOUSE_BUTTON)
		return;

	fWatchMouse = true;
	fCursorPulse->stopAlarm();

	fShowCursor = true;
	drawCursor();

	fMousePosition = Point;

	int32 NewCursorPosition;
	float NewBeamPosition;
	float NewTextOffset;

	calculateCursorAndBeamPosition( Point, NewCursorPosition, NewBeamPosition, NewTextOffset);

	fHighlightStart			= NewBeamPosition;
	fHighlightStartCursor	= NewCursorPosition;
	fHighlightEnd			= NewBeamPosition;
	fHighlightEndCursor		= NewCursorPosition;

	fMouseDownCharacter		= NewCursorPosition;

	switch( NumClicks)
	{
		case 1:
		{
			int32 StrLen = UTF8Len();
			
			fCursorPosition = NewCursorPosition;
			fBeamPosition = NewBeamPosition;
			fTextOffset = NewTextOffset;
	/*
			if( NewTextOffset != fTextOffset)
				redraw( fTextFrame);
			else
			{
				drawCursor( true);
				fBeamPosition = NewBeamPosition;
				drawCursor();
			}
	*/	}
		break;

		case 3:
		{
			fHighlightStart			= 0.0;
			fHighlightStartCursor	= 0;
			fHighlightEnd			= fFont->StringWidth( fText);;
			fHighlightEndCursor		= UTF8Len();
		}
		break;

		default:
			break;
	}

	redraw( fTextFrame);

	#if FTEXTINPUT_DEBUG > 2
	fprintf( stderr, "fTextInput::mouseDown() end\n");
	#endif
}

void fTextInput::mouseUp( MouseButton Button, const fPoint &/*Point*/, int32 /*NumClicks*/)
{
	if( Button != B_PRIMARY_MOUSE_BUTTON)
		return;

	fWatchMouse = false;
	fMouseMovedPulse->stopAlarm();

	if( getFocus() && getWindowActivated() && getEnabled())
	{
		fCursorPulse->startAlarm();
		fShowCursor = true;
	}
}

void fTextInput::mouseMoved( const fPoint &Point)
{
	if( fWatchMouse == false)
		return;

	fMousePosition = Point;
}

void fTextInput::mouseEntered( const fPoint &Point)
{
	if( fWatchMouse == false)
		return;

	fMouseMovedPulse->stopAlarm();

	calculateHighlighting( Point);
}

void fTextInput::mouseWithin( const fPoint &Point)
{
	if( fWatchMouse == false)
		return;

	if( fTextFrame.Contains( Point) == false)
		return;

	calculateHighlighting( Point);
}

void fTextInput::mouseExited( const fPoint &Point)
{
	if( fWatchMouse == false)
		return;

	fMouseMovedPulse->startAlarm();

	calculateHighlighting( Point);
}

void fTextInput::calculateHighlighting( const fPoint &Point)
{
	int32 NewCursorPosition;
	float NewBeamPosition;
	float NewTextOffset;

	calculateCursorAndBeamPosition( Point, NewCursorPosition, NewBeamPosition, NewTextOffset);

	float HighlightStart = min( fHighlightStart, fHighlightEnd);
	float HighlightEnd = max( fHighlightStart, fHighlightEnd);

	float HighlightStartCursor = min( fHighlightStartCursor, fHighlightEndCursor);
	float HighlightEndCursor = max( fHighlightStartCursor, fHighlightEndCursor);

	if( NewCursorPosition <= fMouseDownCharacter)
	{
		HighlightStart			= NewBeamPosition;
		HighlightStartCursor	= NewCursorPosition;

		HighlightEnd			= fBeamPosition;
		HighlightEndCursor		= fMouseDownCharacter;
	}
	else
	{
		HighlightEnd			= NewBeamPosition;
		HighlightEndCursor		= NewCursorPosition;

		HighlightStart			= fBeamPosition;
		HighlightStartCursor	= fMouseDownCharacter;
	}

	bool Changed = false;

	if( fHighlightStart != HighlightStart)
	{
		fHighlightStart			= HighlightStart;
		fHighlightStartCursor	= HighlightStartCursor;
		Changed					= true;
	}

	if( fHighlightEnd != HighlightEnd)
	{
		fHighlightEnd		= HighlightEnd;
		fHighlightEndCursor	= HighlightEndCursor;
		Changed				= true;
	}

	if( Changed)
		redraw( fTextFrame);
}

void fTextInput::keyDown( const char *Input, int32 Length)
{
	#if FTEXTINPUT_DEBUG > 2
	fprintf( stderr, "fTextInput::keyDown()\n");
	#endif

	if( getEnabled() == false)
		return;

	handleInput( Input, Length);
}

void fTextInput::setText( const char *Text)
{
	delete [] fText;

	if( Text)
	{
		fText = new char[ strlen( Text) + 1];
		strcpy( fText, Text);
	}
	else
		fText = NULL;
}

const char *fTextInput::getText( void) const
{
	return( fText);
}
		
void fTextInput::setAcceptCharacters( const char *AcceptCharacters)
{
	delete [] fAcceptCharacters;

	if( AcceptCharacters)
	{
		fAcceptCharacters = new char[ strlen( AcceptCharacters) + 1];
		strcpy( fAcceptCharacters, AcceptCharacters);
	}
	else
		fAcceptCharacters = NULL;
}

const char *fTextInput::getAcceptCharacters( void) const
{
	return( fAcceptCharacters);
}
		
void fTextInput::setRejectCharacters( const char *RejectCharacters)
{
	delete [] fRejectCharacters;

	if( RejectCharacters)
	{
		fRejectCharacters = new char[ strlen( RejectCharacters) + 1];
		strcpy( fAcceptCharacters, RejectCharacters);
	}
	else
		fRejectCharacters = NULL;
}

const char *fTextInput::getRejectCharacters( void) const
{
	return( fRejectCharacters);
}

void fTextInput::setMinimumWidthText( const char *MinimumWidthText)
{
	if( MinimumWidthText == NULL)
		return;

	delete [] fMinimumWidthText;

	fMinimumWidthText = new char[ strlen( MinimumWidthText) + 1];
	strcpy( fMinimumWidthText, MinimumWidthText);
	
	updateIfNeeded();
}

void fTextInput::drawCursor( bool HideCursor) const
{
	if( getView() == NULL)
		return;

	if( fHighlightStartCursor != fHighlightEndCursor)
		return;

	BRegion Region;
	Region.Set( fTextFrame);

//	getView()->ConstrainClippingRegion( &Region);
	getView()->ConstrainClippingRegion( new BRegion( Region));

	if( fShowCursor && !HideCursor)
		getView()->SetHighColor( getFontColor());
	else
		getView()->SetHighColor( getBackgroundColor());

	fPoint CursorPosition = fTextFrame.LeftTop() + fPoint( fBeamPosition - fTextOffset, 0.0);
	
	if( fTextFrame.Contains( CursorPosition))
		getView()->StrokeLine( CursorPosition, CursorPosition + fPoint( 0.0, fTextFrame.Height()));

	getView()->ConstrainClippingRegion( NULL);
}

void fTextInput::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.left	= rint( Frame.left);
	Frame.top	= rint( Frame.top);
	Frame.right	= rint( Frame.right);
	Frame.bottom= rint( Frame.bottom);

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;
		
	#if FTEXTINPUT_DEBUG > 2
	fprintf( stderr, "fTextInput::draw() Drawing to: ");
	Frame.PrintToStream();
	fprintf( stderr, "fTextInput::draw() fTextFrame: ");
	fTextFrame.PrintToStream();
	#endif

    if( getView()->Window() == NULL)
        return;

    if( getView()->Window()->Lock() == false)
        return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
	{
		BRect FillRect = Frame;
		FillRect.InsetBy( 2.0, 2.0);
		getView()->FillRect( FillRect, B_SOLID_LOW);
	}

	// draw frame
		// outer frame
	getView()->SetHighColor( 0xff, 0xff, 0xff);
	getView()->StrokeLine( Frame.RightTop(), Frame.RightBottom());
	getView()->StrokeLine( Frame.LeftBottom());

	getView()->SetHighColor( 0xb8, 0xb8, 0xb8);
	getView()->StrokeLine( Frame.LeftTop());
	getView()->StrokeLine( Frame.RightTop());

		// inner frame
	Frame.InsetBy( 1.0, 1.0);
	
	if( getFocus() && getWindowActivated())
		getView()->SetHighColor( keyboard_navigation_color());
	else
		getView()->SetHighColor( 0x98, 0x98, 0x98);

	getView()->StrokeRect( Frame);

	// draw cursor
	if( getFocus() && getEnabled())
		drawCursor();

	// draw text
	BRegion NewRegion;
	NewRegion.Set( fTextFrame);
	NewRegion.IntersectWith( &ClippingRegion);
//	getView()->ConstrainClippingRegion( &NewRegion);
	getView()->ConstrainClippingRegion( new BRegion( NewRegion));

//	fPoint TextPosition = Frame.LeftTop() + BPoint( 1.0, 0.0);
	fPoint TextPosition = fTextFrame.LeftTop() + fPoint( 1.0, 0.0);

	TextPosition += fTextPosition;
	TextPosition.x -= fTextOffset;

	if( getEnabled())
		getView()->SetHighColor( getFontColor());
	else
		getView()->SetHighColor( 0x78, 0x78, 0x78);

	getView()->SetFont( fFont);
	getView()->DrawString( fText, TextPosition);

	getView()->ConstrainClippingRegion( NULL);

	// highlight text
	if( fHighlightStartCursor != fHighlightEndCursor)
	{
		Frame = fTextFrame;
		Frame.OffsetTo( B_ORIGIN);
	
		Frame.left = min( fHighlightStart, fHighlightEnd) - fTextOffset;
		Frame.right = max( fHighlightStart, fHighlightEnd) - fTextOffset;
		
		Frame.OffsetBy( fTextFrame.LeftTop());
		Frame = Frame & fTextFrame;

		if( Frame.IsValid())
			getView()->InvertRect( Frame);
	}
	
	// end
	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())    
		getView()->Window()->Unlock();
}