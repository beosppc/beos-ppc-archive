// fButton.h

#ifndef fButton_h
#define fButton_h

#include "fObject.h"
#include "fEventRoute.h"

#pragma export on

class fButton : public fObject
{
	private :

		fButton( const fButton &CopyObject);
		fButton &operator=( const fButton &CopyObject);
	
		VirtualClassDeclaration( fButton);

	protected:

		virtual void initializeObject( void);

		bool		 fClicked;
		bool		 fHighlighted;
		bool		 fDefaultButton;

		BFont		*fFont;
		fPoint		 fTextSize;

		char		*fButtonText;

		virtual void setDefaultEvents( void);

		DoMethodDeclaration;

	public :

		fButton( const char *ButtonText = NULL);
		virtual ~fButton( void);

		virtual void setFont( const BFont *Font);

		virtual void setDefaultButton( bool DefaultTarget);
		virtual bool getDefaultButton( void) const;

		virtual void mouseDown( MouseButton Button, const fPoint &Point, int32 NumClicks);
		virtual void mouseUp( MouseButton Button, const fPoint &Point, int32 NumClicks);

		virtual void mouseEntered( const fPoint &Point);
		virtual void mouseExited( const fPoint &Point);

		virtual void keyDown( const char *Input, int32 Length);
		virtual void keyUp( const char *Input, int32 Length);

		virtual void setText( const char *NewString);
};

#pragma export off

#endif
