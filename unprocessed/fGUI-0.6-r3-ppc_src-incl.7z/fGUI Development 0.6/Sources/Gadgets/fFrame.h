// fFrame.h

#ifndef fFrame_h
#define fFrame_h

#include "fSingleContainer.h"

#pragma export on

class fFrame : public fSingleContainer
{
	private:

		fFrame( const fFrame &CopyObject);
		fFrame &operator=( const fFrame &CopyObject);

		VirtualClassDeclaration( fFrame);

	protected:

		char	*fLabel;
		BFont	*fFont;

		float	 fLeftInset;
		float	 fTopInset;
		float	 fRightInset;
		float	 fBottomInset;

		DoMethodDeclaration;

	public:

		fFrame( const char *Label = NULL, fObject *Object = NULL);
		virtual ~fFrame( void);

		virtual void setText( const char *Label);
		virtual void setFont( const BFont *Font);
};

#pragma export off

#endif