// fRadioButton.h

#ifndef fRadioButton_h
#define fRadioButton_h

#include "fObject.h"
#include "fEventRoute.h"

#pragma export on

class fRadioButton : public fObject
{
	private :

		fRadioButton( const fRadioButton &CopyObject);
		fRadioButton &operator=( const fRadioButton &CopyObject);
	
		VirtualClassDeclaration( fRadioButton);

	protected:

		virtual void initializeObject( void);

		bool		 fClicked;
		bool		 fHighlighted;
		bool		 fActivated;

		BFont		*fFont;
		fPoint		 fTextPosition;
		fPoint	 	 fTextSize;

		char		*fRadioButtonText;

//		class fGroupDispatcher *fExclusiveGroup;
		char *fExclusiveGroup;

		virtual void setDefaultEvents( void);
		virtual void invalidateRadioButton( void);

		DoMethodDeclaration;

	public :

		fRadioButton( const char *RadioButtonText);
		virtual ~fRadioButton( void);

		virtual void setExclusiveGroup( const char *ExclusiveGroup);
//		virtual void setExclusiveGroup( class fGroupDispatcher *ExclusiveGroup);

		virtual void setFont( const BFont *Font);

		virtual void mouseDown( MouseButton Button, const fPoint &Point, int32 NumClicks);
		virtual void mouseUp( MouseButton Button, const fPoint &Point, int32 NumClicks);

		virtual void mouseEntered( const fPoint &Point);
		virtual void mouseExited( const fPoint &Point);

		virtual void keyDown( const char *Input, int32 Length);
		virtual void keyUp( const char *Input, int32 Length);

		virtual void setParent( fObject *Parent);

		virtual void setActive( bool Active);
		virtual bool getActive( void) const;

//		virtual void processEvent( int32 Event, BMessage *Message = NULL);
		virtual void messageReceived( int32 Event, BMessage *Message);

		virtual void setText( const char *NewString);
};

#pragma export off

#endif
