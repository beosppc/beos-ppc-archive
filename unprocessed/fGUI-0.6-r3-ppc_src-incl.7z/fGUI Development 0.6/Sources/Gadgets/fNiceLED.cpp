// fNiceLED.cpp

#include "fNiceLED.h"

#include "fFactory.h"

#include "LedOff.h"
#include "LedBlue.h"
#include "LedRed.h"
#include "LedGreen.h"
#include "LedYellow.h"

#if DEBUG > 0
#define FLED_DEBUG DEBUG
#endif
 
//#undef FLED_DEBUG
//#define FLED_DEBUG 2

ClassDefinition( fNiceLED, fLED, "");

fNiceLED::fNiceLED( Color InitColor)
{
	#if FLED_DEBUG > 0
	fprintf( stderr, "fNiceLED::fNiceLED()\n");
	#endif

	BRect bounds = BRect( 0.000000, 0.000000, 17.000000, 16.000000);

	fOn = new BBitmap( bounds, B_RGB_32_BIT);

	switch( InitColor)
	{
		case C_RED:
			fOn->SetBits( LedRed, 918, 0, B_RGB_32_BIT);
			break;
		
		case C_GREEN:
			fOn->SetBits( LedGreen, 918, 0, B_RGB_32_BIT);
			break;

		case C_BLUE:
			fOn->SetBits( LedBlue, 918, 0, B_RGB_32_BIT);
			break;

		case C_YELLOW:
			fOn->SetBits( LedYellow, 918, 0, B_RGB_32_BIT);
			break;
	}
	
	fOff = new BBitmap( bounds, B_RGB_32_BIT);
	fOff->SetBits( LedOff, 918, 0, B_RGB_32_BIT);

	setMinimumSize( bounds.RightBottom());
	setMaximumSize( bounds.RightBottom());
	setPreferredSize( bounds.RightBottom());

	#if FLED_DEBUG > 0
	fprintf( stderr, "fNiceLED::fNiceLED() end\n");
	#endif
}

fNiceLED::~fNiceLED()
{
	#if FLED_DEBUG > 0
	fprintf( stderr, "fNiceLED::~fNiceLED()\n");
	#endif

	delete fOn;
	delete fOff;

	#if FLED_DEBUG > 0
	fprintf( stderr, "fNiceLED::~fNiceLED() end\n");
	#endif
}

void fNiceLED::recalculateSizeLimits( void)
{
	#if FLED_DEBUG > 1
	fprintf( stderr, "fNiceLED::recalculateSizeLimits()\n");
	#endif

	#if FLED_DEBUG > 1
	fprintf( stderr, "fNiceLED::recalculateSizeLimits() end\n");
	#endif
}

void fNiceLED::setColor( Color LEDColor)
{
	fLED::setColor( LEDColor);

	BRect bounds = BRect( 0.000000, 0.000000, 17.000000, 16.000000);

	delete fOn;
	fOn = new BBitmap( bounds, B_RGB_32_BIT);

	switch( LEDColor)
	{
		case C_RED:
			fOn->SetBits( LedRed, 918, 0, B_RGB_32_BIT);
			break;
		
		case C_GREEN:
			fOn->SetBits( LedGreen, 918, 0, B_RGB_32_BIT);
			break;

		case C_BLUE:
			fOn->SetBits( LedBlue, 918, 0, B_RGB_32_BIT);
			break;

		case C_YELLOW:
			fOn->SetBits( LedYellow, 918, 0, B_RGB_32_BIT);
			break;
	}
}

void fNiceLED::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FLED_DEBUG > 1
	fprintf( stderr, "fNiceLED::draw()\n");
	#endif

	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;

	#if FLED_DEBUG > 2
	fprintf( stderr, "fNiceLED::draw() Minimum size: ");
	getMinimumSize().PrintToStream();
	fprintf( stderr, "fNiceLED::draw() Preferred size: ");
	getPreferredSize().PrintToStream();
	fprintf( stderr, "fNiceLED::draw() Maximum size: ");
	getMaximumSize().PrintToStream();
	fprintf( stderr, "fNiceLED::draw() Current size: ");
	getSize().PrintToStream();
	fprintf( stderr, "fNiceLED::draw() Drawing to: ");
	Frame.PrintToStream();
	#endif

    if( getView()->Window() == NULL)
        return;

    if( getView()->Window()->Lock() == false)
        return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	if( activated)
		getView()->DrawBitmapAsync( fOn, Frame);
	else
		getView()->DrawBitmapAsync( fOff, Frame);

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())    
        getView()->Window()->Unlock();

	#if FLED_DEBUG > 1
	fprintf( stderr, "fNiceLED::draw() end\n");
	#endif
}