// fVerticalSpace.h

#ifndef fVerticalSpace_h
#define fVerticalSpace_h

#include "fObject.h"

#pragma export on

class fVerticalSpace : public fObject
{
	private:

		fVerticalSpace( const fVerticalSpace &CopyObject);
		fVerticalSpace &operator=( const fVerticalSpace &CopyObject);

		ClassDeclaration( fVerticalSpace);

	protected:
	
		virtual void recalculateSizeLimits( void);

	public:

		fVerticalSpace( float Height = 2.0);
		virtual ~fVerticalSpace( void);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
