// fSingleContainer.h

#ifndef fSingleContainer_h
#define fSingleContainer_h

#include "fObject.h"

#pragma export on

class fSingleContainer : public fObject
{
	private:

		fSingleContainer( const fSingleContainer &CopyObject);
		fSingleContainer &operator=( const fSingleContainer &CopyObject);

		VirtualClassDeclaration( fSingleContainer);

	protected:

		fObject	*fSomeObject;

		DoMethodDeclaration;

	public:

		fSingleContainer( fObject *NewObject = NULL);
		virtual ~fSingleContainer( void);

		virtual void setObject( fObject *NewObject);
		virtual const fObject *getObject( void);

		virtual void setView( BView *NewView);

		virtual void mouseMoved( const fPoint &Point);

		virtual void setSize( const fPoint &NewSize);
		virtual void setPosition( const fPoint &NewPosition);

		virtual void attachedToWindow( const class fWindow *ParentWindow);
		virtual void detachedFromWindow( void);

		virtual void setEnabled( bool Enabled);
		virtual bool setWindowActivated( bool Activated);

		virtual const fObject *containsPoint( const fPoint &Point) const;
		virtual bool findObject( const fObject *ObjectPointer) const;
		virtual const fObject *findObject( const char *ObjectName) const;

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
