// fCycleButton.cpp

#include "fCycleButton.h"

#include "fEvents.h"

#include "fFactory.h"

#if DEBUG > 0
#define FBUTTON_DEBUG DEBUG
#endif
 
//#undef FBUTTON_DEBUG
//#define FBUTTON_DEBUG 3

VirtualClassDefinition( fCycleButton, fObject);

fCycleButton::fCycleButton( void)
{
	initializeObject();
}

void fCycleButton::initializeObject( void)
{
	fClicked		= false;
	fHighlighted	= false;
	fDefaultButton	= false;

	fChoicesCount	= 0;
	fCurrentChoice	= 0;

	fFont			= new BFont( be_plain_font);
	fTextSizes		= NULL;

	setBackgroundColor( 0xeb, 0xeb, 0xeb);
	
	setVerticalWeight( 0.0);
}

fCycleButton::~fCycleButton()
{
	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fCycleButton::~fCycleButton()\n");
	#endif  

	char *OldText;
	
	while(( OldText = static_cast<char*>( Texts.RemoveItem(( int32) 0))) != NULL)
		delete [] OldText;

	delete [] fTextSizes;

	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fCycleButton::~fCycleButton() end\n");
	#endif  
}

DoMethodBegin( fCycleButton)
	DoMethodDefinitionBegin( "Text", addText, 1)
		DoMethodVariable( char *, Text)
		DoMethodVoidCall( addText)( Text)
	DoMethodDefinitionEnd
DoMethodEnd( fObject)

void fCycleButton::addText( const char *Text)
{
	if( Text == NULL)
		return;

	char *NewText = new char[ strlen( Text) + 1];
	strcpy( NewText, Text);

	Texts.AddItem( NewText);

	fChoicesCount =  Texts.CountItems();

	delete [] fTextSizes;
	fTextSizes = new float[ fChoicesCount];

	recalculateSizeLimits();

	updateIfNeeded();
}

void fCycleButton::setFont( const BFont *Font)
{
	if( Font == NULL)
		return;

	delete fFont;

	fFont = new BFont( Font);

	// no support for sheared or rotated fonts here
	fFont->SetRotation( 0.0);
	fFont->SetShear( 90.0);

	updateIfNeeded();
}

void fCycleButton::mouseDown( MouseButton Button, const fPoint &/*Point*/, int32 /*NumClicks*/)
{
	if( getEnabled() == false)
		return;

	if( Button == F_PRIMARY_MOUSE_BUTTON)
	{
		fClicked = true;
		fHighlighted = true;

		// force redraw
		redraw( getObjectFrame());
	}
}

void fCycleButton::mouseUp( MouseButton Button, const fPoint &Point, int32 /*NumClicks*/)
{
	if( fClicked == false)
		return;

	if( Button != F_PRIMARY_MOUSE_BUTTON)
		return;

	fClicked = false;

	// trigger action !
	if( containsPoint( Point) == this)
	{
		fCurrentChoice = ( fCurrentChoice + 1) % fChoicesCount;
		processEvent( F_BUTTON_CLICKED);		
	}

	// force redraw
	if( fHighlighted)
	{
		fHighlighted = false;
		redraw( getObjectFrame());
	}
}

void fCycleButton::mouseEntered( const fPoint &/*Point*/)
{
	if( fClicked)
	{
		fHighlighted = true;

		// force redraw
		redraw( getObjectFrame());
	}
}

void fCycleButton::mouseExited( const fPoint &/*Point*/)
{
	if( fClicked)
	{
		fHighlighted = false;

		// force redraw
		redraw( getObjectFrame());
	}
}

void fCycleButton::keyDown( const char *Input, int32 Length)
{
	if( getEnabled() == false)
		return;

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
		if( fHighlighted == false)
			redraw( getObjectFrame());
}

void fCycleButton::keyUp( const char *Input, int32 Length)
{
	if( getEnabled() == false)
		return;

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
	{
		fHighlighted = false;

		fCurrentChoice = ( fCurrentChoice + 1) % fChoicesCount;
		processEvent( F_BUTTON_CLICKED);
		redraw( getObjectFrame());
	}
}