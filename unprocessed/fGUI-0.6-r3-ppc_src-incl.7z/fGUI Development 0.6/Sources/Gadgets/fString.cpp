// fString.cpp

#include "fString.h"
#include "fFactory.h"

#include "fEvents.h"

#if DEBUG > 0
#define FSTRING_DEBUG DEBUG
#endif

//#undef FSTRING_DEBUG
#define FSTRING_DEBUG -1
 
ClassDefinition( fString, fObject, "");

fString::fString( const char *InitString)
{
	#if FSTRING_DEBUG > 0
	fprintf( stderr, "fString::fString( const char *InitString)\n");
	#endif

	if( InitString)
	{
		string = new char[ strlen( InitString) + 1];
		strcpy( string, InitString);
	}
	else
	{
		string = new char[ 1];
		*string = 0x0;
	}

	initializeObject();
}

fString::fString( int32 InitValue)
{
	#if FSTRING_DEBUG > 0
	fprintf( stderr, "fString::fString( int32 InitValue)\n");
	#endif

	string = new char[ 30];
	sprintf( string, "%ld", InitValue);

	initializeObject();

	#if FSTRING_DEBUG > 0
	fprintf( stderr, "fString::fString( int32 InitValue) end\n");
	#endif
}

void fString::initializeObject( void)
{
	fFont = new BFont( be_plain_font);

	recalculateSizeLimits();

	#if FSTRING_DEBUG > 0
	fprintf( stderr, "fString::fString( const char *InitString) end\n");
	#endif
}

fString::~fString()
{
	#if FSTRING_DEBUG > 0
	fprintf( stderr, "fString::~fString()\n");
	#endif

	delete [] string;

	delete fFont;

	#if FSTRING_DEBUG > 0
	fprintf( stderr, "fString::~fString() end\n");
	#endif
}

DoMethodBegin( fString)
	DoMethodDefinitionBegin( "Text", setText, 1)
		DoMethodVariable( char *, NewString)
		DoMethodVoidCall( setText)( NewString)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Value", setValue, 1)
		DoMethodVariable( int32, NewValue)
		DoMethodVoidCall( setValue)( NewValue)
	DoMethodDefinitionEnd
DoMethodEnd( fObject)

void fString::recalculateSizeLimits( void)
{
	#if FSTRING_DEBUG > 1
	fprintf( stderr, "fString::recalculateSizeLimits()\n");
	#endif

	if( fFont == NULL)
	{
		setMinimumSize( fPoint( 5.0, 5.0));
		setPreferredSize( fPoint( 5.0, 5.0));
		
		return;
	}

	font_height fontheight;
	fFont->GetHeight( &fontheight);

	float FontWidth = fFont->StringWidth( string);

	float Rotation = fFont->Rotation();

	fPoint LeftBottom, LeftTop, RightTop, RightBottom;
	
	LeftBottom.x	= 0;
	LeftBottom.y	= - ( fontheight.descent + fontheight.leading);

	// Rotation
	LeftBottom.rotateBy( Rotation);

	LeftTop.x		= 0;
	LeftTop.y		= fontheight.ascent;
	
	// Shear
	LeftTop.rotateBy( 90.0 - fFont->Shear());
	LeftTop.y		= fontheight.ascent;

	// Rotation
	LeftTop.rotateBy( Rotation);

	RightTop.x	= 0;
	RightTop.y	= fontheight.ascent;
	
	// Shear
	RightTop.rotateBy( 90.0 - fFont->Shear());
	RightTop.x	+= FontWidth;
	RightTop.y	= fontheight.ascent;

	// Rotation
	RightTop.rotateBy( Rotation);

	RightBottom.x	= FontWidth;
	RightBottom.y	= - ( fontheight.descent + fontheight.leading);
	
	// Rotation
	RightBottom.rotateBy( Rotation);

	float TempOne, TempTwo;

	// LeftMost
	TempOne = min( LeftBottom.x, LeftTop.x);
	TempTwo = min( RightTop.x, RightBottom.x);
	
	float LeftMost = min( TempOne, TempTwo);

	// RightMost
	TempOne = max( LeftBottom.x, LeftTop.x);
	TempTwo = max( RightTop.x, RightBottom.x);

	float RightMost = max( TempOne, TempTwo);
	
	// BottomMost
	TempOne = min( LeftBottom.y, LeftTop.y);
	TempTwo = min( RightTop.y, RightBottom.y);

	float BottomMost = min( TempOne, TempTwo);
	
	// TopMost
	TempOne = max( LeftBottom.y, LeftTop.y);
	TempTwo = max( RightTop.y, RightBottom.y);
	
	float TopMost = max( TempOne, TempTwo);

	float BoxWidth 	= abs( RightMost - LeftMost) + 1.0;
	float BoxHeight	= abs( TopMost - BottomMost) + 1.0;

	fPoint BoxSize = fPoint( BoxWidth, BoxHeight);

	fPoint TextPosition = fPoint( -LeftMost, TopMost);

	// Remember font size
	fTextSize = BoxSize;

	// Remember font Position
	fTextPosition = TextPosition;

	setMinimumSize( BoxSize);
	setPreferredSize( BoxSize);
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

	#if FSTRING_DEBUG > 1
	fprintf( stderr, "fString::recalculateSizeLimits() end\n");
	#endif
}

void fString::setFont( const BFont *Font)
{
	#if FSTRING_DEBUG > 1
	fprintf( stderr, "fString::setFont()\n");
	#endif

	if( Font == NULL)
		return;

	delete fFont;

	fFont = new BFont( Font);

	updateIfNeeded();

	#if FSTRING_DEBUG > 1
	fprintf( stderr, "fString::setFont() end\n");
	#endif
}

void fString::setText( const char *NewString)
{
	#if FSTRING_DEBUG > 1
	fprintf( stderr, "fString::setText( %s)\n", NewString);
	#endif

	if( NewString == NULL)
		return;

	delete [] string;

	string = new char[ strlen( NewString) + 1];
	strcpy( string, NewString);

	updateIfNeeded();

	#if FSTRING_DEBUG > 1
	fprintf( stderr, "fString::setText() end\n");
	#endif
}

void fString::setValue( int32 NewValue)
{
	#if FSTRING_DEBUG > 1
	fprintf( stderr, "fString::setValue( int32)\n");
	#endif

	delete [] string;

	string = new char[ 30 ];
	sprintf( string, "%ld", NewValue);

	redraw( getObjectFrame());
//	if( getView())
//		getView()->Invalidate( getObjectFrame());

//	updateIfNeeded();

	#if FSTRING_DEBUG > 1
	fprintf( stderr, "fString::setValue( int32) end\n");
	#endif
}

void fString::dispatchMessage( int32 Event, BMessage *Message)
{
	switch( Event)
	{
		case F_SET_VALUE:
			if( Message != NULL)
			{
				float NewValue;
				
				if( Message->FindFloat( "fValue", &NewValue) == B_OK)
					setValue(( int32) NewValue);
			}
			break;

		default:
			fObject::dispatchMessage( Event, Message);
			break;
	}
}

void fString::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FSTRING_DEBUG > 1
	fprintf( stderr, "fString::draw()\n");
	#endif

	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;
		
	#if FSTRING_DEBUG > 2
	fprintf( stderr, "fString::draw() Drawing to: ");
	Frame.PrintToStream();
	#endif

    if( getView()->Window() == NULL)
        return;

    if( getView()->Window()->Lock() == false)
        return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	#if FSTRING_DEBUG >= 0
	ShowObjectLayout;
	#endif

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
//	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRect( Frame, B_SOLID_LOW);

	fPoint TextPosition = getPosition();

	TextPosition += fTextPosition;

	switch( getHorizontalAlignment())
	{
		case F_HALIGN_LEFT:
			#if FSTRING_DEBUG > 1
			fprintf( stderr, "fString::draw() F_HALIGN_LEFT\n");
			#endif
			break;

		case F_HALIGN_CENTER:
			#if FSTRING_DEBUG > 1
			fprintf( stderr, "fString::draw() F_HALIGN_CENTER\n");
			#endif
			TextPosition.x += ( getSize().x - fTextSize.x) / 2.0;
			break;

		case F_HALIGN_RIGHT:
			#if FSTRING_DEBUG > 1
			fprintf( stderr, "fString::draw() F_HALIGN_RIGHT\n");
			#endif
			TextPosition.x += getSize().x - fTextSize.x;
			break;
	}

	switch( getVerticalAlignment())
	{
		case F_VALIGN_TOP:
			#if FSTRING_DEBUG > 1
			fprintf( stderr, "fString::draw() F_VALIGN_TOP\n");
			#endif
			break;

		case F_VALIGN_CENTER:
			#if FSTRING_DEBUG > 1
			fprintf( stderr, "fString::draw() F_VALIGN_CENTER\n");
			#endif
			TextPosition.y += ( getSize().y - fTextSize.y) / 2.0;
			break;

		case F_VALIGN_BOTTOM:
			#if FSTRING_DEBUG > 1
			fprintf( stderr, "fString::draw() F_VALIGN_BOTTOM\n");
			#endif
			TextPosition.y += getSize().y - fTextSize.y;
			break;
	}

	if( getEnabled())
		getView()->SetHighColor( getFontColor());
	else
		getView()->SetHighColor( 0x78, 0x78, 0x78);
	
	getView()->SetFont( fFont);
	getView()->DrawString( string, TextPosition);

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())    
		getView()->Window()->Unlock();

	#if FSTRING_DEBUG > 1
	fprintf( stderr, "fString::draw() end\n");
	#endif
}