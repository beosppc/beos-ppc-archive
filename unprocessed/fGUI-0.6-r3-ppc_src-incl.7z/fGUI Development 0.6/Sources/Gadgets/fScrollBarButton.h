// fScrollBarButton.h

#ifndef fScrollBarButton_h
#define fScrollBarButton_h

#include "fBitmapButton.h"

#pragma export on

class fScrollBarButton : public fBitmapButton
{
	private:

		fScrollBarButton( const fScrollBarButton &CopyObject);
		fScrollBarButton &operator=( const fScrollBarButton &CopyObject);

		ClassDeclaration( fScrollBarButton);

	protected:

		class fAlarm *fMouseDownPulse;

	public:

		fScrollBarButton( void);
		fScrollBarButton( int32 Action, const fObject *Target,
							const BBitmap *PassiveBitmap, const BBitmap *ActiveBitmap, const BBitmap *DisabledBitmap);
		virtual ~fScrollBarButton( void);

		virtual void dispatchMessage( int32 Event, BMessage *Message);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif