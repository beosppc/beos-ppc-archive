// fHorizontalScrollBar.cpp

#include "fHorizontalScrollBar.h"

#include "fEvents.h"

#include "fFactory.h"

#include "fAlarm.h"
#include "fEventRoute.h"

#if DEBUG > 0
#define FSCROLLBAR_DEBUG DEBUG
#endif
 
//#undef FSCROLLBAR_DEBUG
//#define FSCROLLBAR_DEBUG 2

VirtualClassDefinition( fHorizontalScrollBar, fScrollBar);

fHorizontalScrollBar::fHorizontalScrollBar( void)
{
	// set size limits
	setMinimumSize( fPoint( 0.0, B_H_SCROLL_BAR_HEIGHT + 1.0));
	setPreferredSize( fPoint( 0.0, B_H_SCROLL_BAR_HEIGHT + 1.0));
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, B_H_SCROLL_BAR_HEIGHT + 1.0));

	setVerticalWeight( 0.0);
}

fHorizontalScrollBar::~fHorizontalScrollBar( void)
{
}

void fHorizontalScrollBar::mouseDown( MouseButton Button, const fPoint &Point, int32 /*NumClicks*/)
{
	if( getEnabled() == false)
		return;

	if( Button != F_PRIMARY_MOUSE_BUTTON)
		return;

	BRect KnobFrame = fKnobFrame;
	KnobFrame.OffsetBy( getPosition());

	// Inset because the left and right border really belongs to the knob
	// the 0.5 are for rounding puposes.
	KnobFrame.InsetBy( -1.5, 0.0);
	
	fLastPosition = Point;

	if( KnobFrame.Contains( Point))
		fDragged = true;
	else
	{
		BRect ScrollBarFrame = fScrollBarFrame;
		ScrollBarFrame.OffsetBy( getPosition());

		if( ScrollBarFrame.Contains( Point))
		{
			if( Point.x < KnobFrame.left)
			{
				fMouseDownPulse->getAlarmRoute()->setAction( F_SCROLLBAR_BIG_DECREASE);
				fMouseDownPulse->startAlarm();
				processEvent( F_SCROLLBAR_BIG_DECREASE);
			}
			else 
			{
				fMouseDownPulse->getAlarmRoute()->setAction( F_SCROLLBAR_BIG_INCREASE);
				fMouseDownPulse->startAlarm();
				processEvent( F_SCROLLBAR_BIG_INCREASE);
			}
		}
	}
}

void fHorizontalScrollBar::mouseUp( MouseButton Button, const fPoint &/*Point*/, int32 /*NumClicks*/)
{
	if( Button != F_PRIMARY_MOUSE_BUTTON)
		return;

	fDragged = false;

	fMouseDownPulse->stopAlarm();
}

void fHorizontalScrollBar::mouseMoved( const fPoint &Point)
{
	if( fDragged == false)
	{
		fLastPosition = Point;
		return;
	}

	double Difference = ( Point - fLastPosition).x;

	double LeftMost = fScrollBarFrame.left;
	double RightMost = fScrollBarFrame.right - fKnobFrame.Width();

	double NewPosition = fKnobFrame.left + Difference;
	
	if( NewPosition < LeftMost)
		NewPosition = LeftMost;

	if( NewPosition > RightMost)
		NewPosition = RightMost;

	double OldPosition = fKnobFrame.left;

//	fprintf( stderr, "fHorizontalScrollBar::mouseWithin() Old position: %f\n", OldPosition);
//	fprintf( stderr, "fHorizontalScrollBar::mouseWithin() New position: %f\n", NewPosition);

	if( OldPosition == NewPosition)
		return;

	BRect UpdateFrame = fKnobFrame;
	
	fKnobFrame.OffsetBy( fPoint( NewPosition - OldPosition, 0.0));

	double Total = fMaximum - fMinimum;

	// calculate new position (logical)
	// current position * ( fTotal - fVisible) / ( Width - KnobWidth)
	double NewKnobPosition = 0.0;
	
	if( Total != fDirection * fVisible)
		NewKnobPosition = fMinimum + ( NewPosition - LeftMost) * ( Total - ( fDirection * fVisible)) / ( fScrollBarFrame.Width() + 1.0 - ( fKnobFrame.Width() + 1.0));

//	fprintf( stderr, "Showing %f to %f\n", NewKnobPosition, NewKnobPosition + ( fDirection * fVisible));

	setKnobPosition( NewKnobPosition);

	UpdateFrame = UpdateFrame | fKnobFrame;
	UpdateFrame.OffsetBy( getPosition());

	redraw( UpdateFrame);

//	if( getView())
//		getView()->Invalidate( UpdateFrame);

	fLastPosition = Point;
}