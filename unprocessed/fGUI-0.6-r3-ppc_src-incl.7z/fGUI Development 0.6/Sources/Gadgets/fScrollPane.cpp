// fScrollPane.cpp

#include "fScrollPane.h"
#include "fFactory.h"
#include "fEventRoute.h"

ClassDefinition( fScrollPane, fSingleContainer, "");

fScrollPane::fScrollPane( fObject *Object)
			: fSingleContainer( Object)
{
	fHScrollBar = ( fScrollBar *) fFactory::getFactory()->createInstance( "HorizontalScrollBar");
	fVScrollBar = ( fScrollBar *) fFactory::getFactory()->createInstance( "VerticalScrollBar");

	if( fHScrollBar)
	{
		fHScrollBar->setBorders( 0.0);

		fEventRoute *route = ( fEventRoute *) fFactory::getFactory()->createInstance( "EventRoute");
		route->setEvent( F_SCROLLBAR_VALUE_CHANGED);
		route->setAction( HScrollBar);
		route->setTargetPointer( this);
		fHScrollBar->addEventRoute(route);
		
		fHScrollBar->setSmallJump( 10.0);
	}

	if( fVScrollBar)
	{
		fVScrollBar->setBorders( 0.0);

		fEventRoute *route = ( fEventRoute *) fFactory::getFactory()->createInstance( "EventRoute");
		route->setEvent( F_SCROLLBAR_VALUE_CHANGED);
		route->setAction( VScrollBar);
		route->setTargetPointer( this);
		fVScrollBar->addEventRoute(route);
		
		fVScrollBar->setSmallJump( 10.0);
	}

	recalculateSizeLimits();
}

fScrollPane::~fScrollPane( void)
{
	delete fHScrollBar;
	delete fVScrollBar;
}

void fScrollPane::recalculateSizeLimits( void)
{
//	fprintf( stderr, "fScrollPane::recalculateSizeLimits()\n");

	fPoint MinimumSize;
	fPoint PreferredSize;
	fPoint MaximumSize;

	if( fHScrollBar)
	{
		MinimumSize.x	= fHScrollBar->getMinimumSize().x;
		PreferredSize.x	= fHScrollBar->getPreferredSize().x;
		MaximumSize.x	= fHScrollBar->getMaximumSize().x;

		fInset.y			= fHScrollBar->getMinimumSize().y;
	}

	if( fVScrollBar)
	{
		MinimumSize.y	= fVScrollBar->getMinimumSize().y;
		PreferredSize.y	= fVScrollBar->getPreferredSize().y;
		MaximumSize.y	= fVScrollBar->getMaximumSize().y;

		fInset.x			= fVScrollBar->getMinimumSize().x;
	}

	MinimumSize		-= fInset;
	PreferredSize	-= fInset;
	MaximumSize		-= fInset;

	if( fSomeObject)
	{
		fPoint ObjectMinimumSize;
		fPoint ObjectPreferredSize	= fSomeObject->getPreferredSize();
		fPoint ObjectMaximumSize;
	
		if( fSomeObject->getVerticalWeight() == 0.0)
		{
			ObjectMinimumSize.y = fSomeObject->getPreferredSize().y;
			ObjectMaximumSize.y = fSomeObject->getPreferredSize().y;
		}
		else
		{
			ObjectMinimumSize.y = fSomeObject->getMinimumSize().y;
			ObjectMaximumSize.y = fSomeObject->getMaximumSize().y;
		}

		if( fSomeObject->getHorizontalWeight() == 0.0)
		{
			ObjectMinimumSize.x = fSomeObject->getPreferredSize().x;
			ObjectMaximumSize.x = fSomeObject->getPreferredSize().x;
		}
		else
		{
			ObjectMinimumSize.x = fSomeObject->getMinimumSize().x;
			ObjectMaximumSize.x = fSomeObject->getMaximumSize().x;
		}
/*
		if( ObjectMinimumSize.x > MinimumSize.x)
			MinimumSize.x = ObjectMinimumSize.x;

		if( ObjectMinimumSize.y > MinimumSize.y)
			MinimumSize.y = ObjectMinimumSize.y;

		if( ObjectPreferredSize.x > PreferredSize.x)
			PreferredSize.x = ObjectPreferredSize.x;

		if( ObjectPreferredSize.y > PreferredSize.y)
			PreferredSize.y = ObjectPreferredSize.y;

		if( ObjectMaximumSize.x > MaximumSize.x)
			MaximumSize.x = ObjectMaximumSize.x;

		if( ObjectMaximumSize.y > MaximumSize.y)
			MaximumSize.y = ObjectMaximumSize.y;
*/
	}

//	MinimumSize.printToStream( "MinimumSize: ");
//	PreferredSize.printToStream( "PreferredSize: ");
//	MaximumSize.printToStream( "MaximumSize: ");

//	fInset.printToStream( "Inset: ");

	setMinimumSize( MinimumSize + fInset);
	setPreferredSize( PreferredSize + fInset);
	setMaximumSize( MaximumSize + fInset);

//	fprintf( stderr, "fScrollPane::recalculateSizeLimits() end\n");
}

void fScrollPane::setView( BView *NewView)
{
	fObject::setView( NewView);

	if( fHScrollBar)
		fHScrollBar->setView( NewView);

	if( fVScrollBar)
		fVScrollBar->setView( NewView);

	if( fSomeObject)
		fSomeObject->setView( NewView);
}

void fScrollPane::messageReceived( int32 Event, BMessage *Message)
{
	if( Message == NULL)
		return;

//	fprintf( stderr, "fScrollPane::messageReceived()\n");

	float Value;

	switch( Event)
	{
		case HScrollBar:
		{
			if( Message->FindFloat( "fValue", &Value) != B_OK)
				return;

			fObjectPosition = fPoint( Value, fObjectPosition.y);
			fPoint Borders( getHorizontalBorder(), getVerticalBorder());

			if( fSomeObject)
			{
				fSomeObject->setPosition( getPosition() + Borders - fObjectPosition);

				BRect frame = getObjectFrame();
				frame.InsetBy( 1.0, 1.0);
	
				// don't refresh scrollbars
				frame.right -= fInset.x;
				frame.bottom -= fInset.y;
				redraw( frame);
			}
		}
		break;

		case VScrollBar:
		{
			if( Message->FindFloat( "fValue", &Value) != B_OK)
				return;

			fObjectPosition = fPoint( fObjectPosition.x, Value);
			fPoint Borders( getHorizontalBorder(), getVerticalBorder());

			if( fSomeObject)
			{
				fSomeObject->setPosition( getPosition() + Borders - fObjectPosition);

				BRect frame = getObjectFrame();
				frame.InsetBy( 1.0, 1.0);
	
				// don't refresh scrollbars
				frame.right -= fInset.x;
				frame.bottom -= fInset.y;
				redraw( frame);
			}
		}
		break;
	}
}

void fScrollPane::mouseMoved( const fPoint &Point)
{
	fObject::mouseMoved( Point);

	if( fHScrollBar)
		fHScrollBar->mouseMoved( Point);

	if( fVScrollBar)
		fVScrollBar->mouseMoved( Point);

	if( fSomeObject)
		fSomeObject->mouseMoved( Point);
}

void fScrollPane::setSize( const fPoint &Size)
{
	fObject::setSize( Size);

	fPoint Borders( getHorizontalBorder(), getVerticalBorder());

	fPoint NewSize = Size;

	NewSize -= Borders;
	NewSize -= Borders;

//	NewSize.printToStream( "***********\nNew size: ");
//	getPosition().printToStream( "Position: ");

	// set horizontal scrollbar
	if( fHScrollBar)
	{
		fHScrollBar->setSize( fPoint( NewSize.x - fInset.x, fInset.y));
		fHScrollBar->setPosition( getPosition() + Borders + fPoint( 0.0, NewSize.y - fInset.y));

		if( fSomeObject)
			fHScrollBar->setMaximum( fSomeObject->getPreferredSize().x);
	}

	// set vertical scrollbar
	if( fVScrollBar)
	{
		fVScrollBar->setSize( fPoint( fInset.x, NewSize.y - fInset.y));
		fVScrollBar->setPosition( getPosition() + Borders + fPoint( NewSize.x - fInset.x, 0.0));

		if( fSomeObject)
			fVScrollBar->setMaximum( fSomeObject->getPreferredSize().y);
	}

	NewSize -= fInset + fPoint( 1.0, 1.0);

	if( fSomeObject)
	{
		if( fHScrollBar)
		{
			fHScrollBar->setVisible( NewSize.x);
			fHScrollBar->setBigJump( NewSize.x);
		}
		
		if( fVScrollBar)
		{
			fVScrollBar->setVisible( NewSize.y);
			fVScrollBar->setBigJump( NewSize.y);
		}

//		fObjectPosition.printToStream( "fObjectposition: ");
		fSomeObject->setSize( fSomeObject->getPreferredSize());
		fSomeObject->setPosition( getPosition() + Borders - fObjectPosition);
	}	
}

void fScrollPane::setPosition( const fPoint &NewPosition)
{
	fPoint delta = NewPosition - getPosition();

	fObject::setPosition( NewPosition);

	if( fHScrollBar)
		fHScrollBar->setPosition( fHScrollBar->getPosition() + delta);

	if( fVScrollBar)
		fVScrollBar->setPosition( fVScrollBar->getPosition() + delta);

	if( fSomeObject)
		fSomeObject->setPosition( fSomeObject->getPosition() + delta);
}

void fScrollPane::attachedToWindow( const class fWindow *ParentWindow)
{
	fObject::attachedToWindow( ParentWindow);

	if( fHScrollBar)
		fHScrollBar->attachedToWindow( ParentWindow);

	if( fVScrollBar)
		fVScrollBar->attachedToWindow( ParentWindow);

	if( fSomeObject)
		fSomeObject->attachedToWindow( ParentWindow);
}

void fScrollPane::detachedFromWindow( void)
{
	fObject::detachedFromWindow();

	if( fHScrollBar)
		fHScrollBar->detachedFromWindow();

	if( fVScrollBar)
		fVScrollBar->detachedFromWindow();

	if( fSomeObject)
		fSomeObject->detachedFromWindow();
}

void fScrollPane::setEnabled( bool Enabled)
{
	fObject::setEnabled( Enabled);

	if( fHScrollBar)
		fHScrollBar->setEnabled( Enabled);

	if( fVScrollBar)
		fVScrollBar->setEnabled( Enabled);

	if( fSomeObject)
		fSomeObject->setEnabled( Enabled);
}

bool fScrollPane::setWindowActivated( bool Activated)
{
	if( fObject::setWindowActivated( Activated) == false)
		return( false);

	if( fHScrollBar)
		fHScrollBar->setWindowActivated( Activated);

	if( fVScrollBar)
		fVScrollBar->setWindowActivated( Activated);

	if( fSomeObject)
		fSomeObject->setWindowActivated( Activated);

	return( true);
}

const fObject *fScrollPane::containsPoint( const fPoint &Point) const
{
	if( fObject::containsPoint( Point) == false)
		return( false);

	const fObject *TempObject;

	if( fHScrollBar)
	{
		TempObject = fHScrollBar->containsPoint( Point);

		if( TempObject)
			return( TempObject);
	}	

	if( fVScrollBar)
	{
		TempObject = fVScrollBar->containsPoint( Point);

		if( TempObject)
			return( TempObject);
	}	

	if( fSomeObject)
	{
		BRect frame = getObjectFrame();
		frame.InsetBy( 1.0, 1.0);

		// don't refresh scrollbars
		frame.right -= fInset.x;
		frame.bottom -= fInset.y + 1.0;

		if( frame.Contains( Point))
		{
			const fObject *TempObject = fSomeObject->containsPoint( Point);
	
			if( TempObject)
				return( TempObject);
		}
	}	

	return( fObject::containsPoint( Point));
}

bool fScrollPane::findObject( const fObject *ObjectPointer) const
{
	if( fObject::findObject( ObjectPointer))
		return( true);

	if( fHScrollBar)
		if( fHScrollBar->findObject( ObjectPointer))
			return( true);

	if( fVScrollBar)
		if( fVScrollBar->findObject( ObjectPointer))
			return( true);

	if( fSomeObject)
		if( fSomeObject->findObject( ObjectPointer))
			return( true);

	return( false);
}

const fObject *fScrollPane::findObject( const char *ObjectName) const
{
	const fObject *TempObject = fObject::findObject( ObjectName);

	if( TempObject)
		return( TempObject);

	if( fHScrollBar)
	{
		TempObject = fHScrollBar->findObject( ObjectName);

		if( TempObject)
			return( TempObject);
	}	
	if( fVScrollBar)
	{
		TempObject = fVScrollBar->findObject( ObjectName);

		if( TempObject)
			return( TempObject);
	}	
	if( fSomeObject)
	{
		TempObject = fSomeObject->findObject( ObjectName);

		if( TempObject)
			return( TempObject);
	}

	return( NULL);
}

void fScrollPane::drawObject( const BRegion &ClippingRegion, bool FullUpdate) const
{
	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;

    if( getView()->Window() == NULL)
        return;

    if( getView()->Window()->Lock() == false)
        return;

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
	{
		BRect FillRect = Frame;
		FillRect.InsetBy( 2.0, 2.0);
		getView()->FillRect( FillRect, B_SOLID_LOW);
	}

	if( fHScrollBar && ClippingRegion.Intersects( fHScrollBar->getObjectFrame()))
	{
		if( FullUpdate)
			fHScrollBar->setClippingRegion( ClippingRegion);
		fHScrollBar->drawObject( ClippingRegion, FullUpdate);
	}

	if( fVScrollBar && ClippingRegion.Intersects( fVScrollBar->getObjectFrame()))
	{
		if( FullUpdate)
			fVScrollBar->setClippingRegion( ClippingRegion);
		fVScrollBar->drawObject( ClippingRegion, FullUpdate);
	}

	Frame.right		-= fInset.x;
	Frame.bottom	-= fInset.y;

	getView()->FillRect( Frame, B_SOLID_LOW);

	Frame.InsetBy( 1.0, 1.0);
	
	BRegion Region;
	Region.Set( Frame);

	if( fSomeObject && ClippingRegion.Intersects( fSomeObject->getObjectFrame()))
	{
		getView()->ConstrainClippingRegion( new BRegion( Region));
		fSomeObject->setClippingRegion( Region);
		fSomeObject->drawObject( Region, true);
		getView()->ConstrainClippingRegion( NULL);	
	}

	if( getView()->Window())    
		getView()->Window()->Unlock();
}