// fHorizontalSpace.h

#ifndef fHorizontalSpace_h
#define fHorizontalSpace_h

#include "fObject.h"

#pragma export on

class fHorizontalSpace : public fObject
{
	private:

		fHorizontalSpace( const fHorizontalSpace &CopyObject);
		fHorizontalSpace &operator=( const fHorizontalSpace &CopyObject);

		ClassDeclaration( fHorizontalSpace);

	protected:
	
		virtual void recalculateSizeLimits( void);

	public:

		fHorizontalSpace( float Width = 2.0);
		virtual ~fHorizontalSpace( void);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
