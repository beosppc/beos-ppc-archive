// fLED.cpp

#include "fLED.h"

#include "fFactory.h"

#if DEBUG > 0
#define FLED_DEBUG DEBUG
#endif
 
//#undef FLED_DEBUG
//#define FLED_DEBUG 2

VirtualClassDefinition( fLED, fObject);

fLED::fLED( Color InitColor)
{
	#if FLED_DEBUG > 0
	fprintf( stderr, "fLED::fLED()\n");
	#endif

	color		= InitColor;
	activated		= 0;

	setMinimumSize( fPoint( 4.0, 4.0));
	setPreferredSize( fPoint( 12.0, 12.0));
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

	#if FLED_DEBUG > 0
	fprintf( stderr, "fLED::fLED() end\n");
	#endif
}

fLED::~fLED()
{
	#if FLED_DEBUG > 0
	fprintf( stderr, "fLED::~fLED()\n");
	#endif

	#if FLED_DEBUG > 0
	fprintf( stderr, "fLED::~fLED() end\n");
	#endif
}

DoMethodBegin( fLED)
	DoMethodDefinitionBegin( "Color", setColor, 1)
		DoMethodVariableCast( Color, int32, LEDColor)
		DoMethodVoidCall( setColor)( LEDColor)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "Activate", activate, 0)
		DoMethodVoidCall( activate)()
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "Deactivate", deActivate, 0)
		DoMethodVoidCall( deActivate)()
	DoMethodDefinitionEnd
DoMethodEnd( fObject)

void fLED::setColor( Color LEDColor)
{
	color = LEDColor;
}

void fLED::activate( void)
{
	#if FLED_DEBUG > 1
	fprintf( stderr, "fLED::activate()\n");
	#endif

	activated++;

//	if( getView())
//		getView()->Invalidate( getObjectFrame());
	redraw( getObjectFrame());

	#if FLED_DEBUG > 1
	fprintf( stderr, "fLED::activate() end\n");
	#endif
}

void fLED::deActivate( void)
{
	#if FLED_DEBUG > 1
	fprintf( stderr, "fLED::deactivate()\n");
	#endif

	if( activated) activated--;

//	if( getView())
//		getView()->Invalidate( getObjectFrame());
	redraw( getObjectFrame());

	#if FLED_DEBUG > 1
	fprintf( stderr, "fLED::deactivate() end\n");
	#endif
}
