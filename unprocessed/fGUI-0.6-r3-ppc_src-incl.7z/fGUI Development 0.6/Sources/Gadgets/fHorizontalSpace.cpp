// fHorizontalSpace.cpp

#include "fHorizontalSpace.h"
#include "fFactory.h"

#include "fFactory.h"

#if DEBUG > 0
#define FHORIZONTALSPACE_DEBUG DEBUG
#endif

//#undef FHORIZONTALSPACE_DEBUG
#define FHORIZONTALSPACE_DEBUG -1

ClassDefinition( fHorizontalSpace, fObject, "");

fHorizontalSpace::fHorizontalSpace( float Width)
{
	#if FHORIZONTALSPACE_DEBUG > 0
	fprintf( stderr, "fHorizontalSpace::fHorizontalSpace()\n");
	#endif

	setHorizontalWeight( 0.0);

	setHorizontalBorder( 0.0);
	setVerticalBorder( 0.0);

	setMinimumSize( fPoint( Width, 0.0));
	setPreferredSize( fPoint( Width, 0.0));
	setMaximumSize( fPoint( Width, F_NO_SIZE_LIMIT));

	#if FHORIZONTALSPACE_DEBUG > 0
	fprintf( stderr, "fHorizontalSpace::fHorizontalSpace() end\n");
	#endif
}

fHorizontalSpace::~fHorizontalSpace( void)
{
}

void fHorizontalSpace::recalculateSizeLimits( void)
{
}

void fHorizontalSpace::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FHORIZONTALSPACE_DEBUG > 1
	fprintf( stderr, "fHorizontalSpace::draw()\n");
	#endif

	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	if( Frame.IsValid() == false)
	{
		#if FHORIZONTALSPACE_DEBUG > 2
		fprintf( stderr, "fHorizontalSpace::draw() Drawing to: ");
		Frame.PrintToStream();
		#endif

		return;
	}

	if( getView()->Window() == NULL)
		return;
		
	if( getView()->Window()->Lock() == false)
		return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	#if FHORIZONTALSPACE_DEBUG >= 0
	ShowObjectLayout;
	#endif

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRect( Frame, B_SOLID_LOW);

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FHORIZONTALSPACE_DEBUG > 1
	fprintf( stderr, "fHorizontalSpace::draw() end\n");
	#endif
}
