// fCheckBox.h

#ifndef fCheckBox_h
#define fCheckBox_h

#include "fObject.h"
#include "fEventRoute.h"

#pragma export on

class fCheckBox : public fObject
{
	private :

		fCheckBox( const fCheckBox &CopyObject);
		fCheckBox &operator=( const fCheckBox &CopyObject);
	
		VirtualClassDeclaration( fCheckBox);

	protected:

		virtual void initializeObject( void);

		bool		 fClicked;
		bool		 fHighlighted;
		bool		 fActivated;

		BFont	*fFont;
		fPoint	 fTextPosition;
		fPoint	 fTextSize;

		char		*fCheckBoxText;

		virtual void setDefaultEvents( void);
		virtual void invalidateCheckBox( void);

		DoMethodDeclaration;

	public:

		fCheckBox( const char *CheckBoxText);
		virtual ~fCheckBox( void);

		virtual void setFont( const BFont *Font);

		virtual void mouseDown( MouseButton Button, const fPoint &Point, int32 NumClicks);
		virtual void mouseUp( MouseButton Button, const fPoint &Point, int32 NumClicks);

		virtual void mouseEntered( const fPoint &Point);
		virtual void mouseExited( const fPoint &Point);

		virtual void keyDown( const char *Input, int32 Length);
		virtual void keyUp( const char *Input, int32 Length);

		virtual void attachedToWindow( const class fWindow *ParentWindow);
		virtual void detachedFromWindow( void);

		virtual void setActive( bool Active);
		virtual bool getActive( void) const;

		virtual void messageReceived( int32 Event, BMessage *Message);

		virtual void setText( const char *NewString);
};

#pragma export off

#endif
