// fTextInput.h

#ifndef fTextInput_h
#define fTextInput_h

#include "fObject.h"

#pragma export on

class fTextInput : public fObject
{
	private :

		fTextInput( const fTextInput &CopyObject);
		fTextInput &operator=( const fTextInput &CopyObject);

		ClassDeclaration( fTextInput);

	protected:

		char			*fAcceptCharacters;
		char			*fRejectCharacters;

		char			*fMinimumWidthText;


		BFont			*fFont;

		char			*fText;
		fPoint			 fTextPosition;
		BRect			 fTextFrame;
		bool			 fTextChanged;

		bool			 fWatchMouse;
		fPoint			 fMousePosition;

		float			 fHighlightStart;
		int32			 fHighlightStartCursor;
		float			 fHighlightEnd;
		int32			 fHighlightEndCursor;
		
		int32			 fMouseDownCharacter;

		bool			 fShowCursor;
		int32			 fCursorPosition;

		float			 fTextOffset;
		float			 fBeamPosition;

		class fAlarm	*fCursorPulse;
		class fAlarm	*fMouseMovedPulse;

		int32 UTF8Len( void) const;

		int32 nextCharacter( int32 CursorPosition = -1, const char *Text = NULL);
		int32 previousCharacter( int32 CursorPosition = -1, const char *Text = NULL);

		bool acceptCharacter( const char *Input);
		bool rejectCharacter( const char *Input);

		void repositionCursor( bool Redraw = false);
		void calculateCursorAndBeamPosition( const fPoint &Point, int32 &CursorPosition,
												float &BeamPosition, float &TextOffset);

		void handleInput( const char *Input, int32 Length);

		void calculateHighlighting( const fPoint &Point);

		virtual void setDefaultEvents( void);
		virtual void recalculateSizeLimits( void);

		virtual void drawCursor( bool HideCursor = false) const;

		DoMethodDeclaration;

	public :

		fTextInput( const char *MinimumWidthText = "Langer Text");
		virtual ~fTextInput( void);

		virtual void attachedToWindow( const class fWindow *ParentWindow);
		virtual void detachedFromWindow( void);

		virtual void setFont( const BFont *Font);

		virtual void setSize( const fPoint &NewSize);
		virtual void setPosition( const fPoint &NewPosition);

		virtual bool setFocus( bool Focus);
		virtual bool setWindowActivated( bool Active);

		virtual void setEnabled( bool Active);

		virtual void messageReceived( int32 Event, BMessage *Message);

		virtual void mouseDown( MouseButton Button, const fPoint &Point, int32 NumClicks);
		virtual void mouseUp( MouseButton Button, const fPoint &Point, int32 NumClicks);
		virtual void mouseMoved( const fPoint &Point);

		virtual void mouseEntered( const fPoint &Point);
		virtual void mouseWithin( const fPoint &Point);
		virtual void mouseExited( const fPoint &Point);

		virtual void keyDown( const char *Input, int32 Length);

		virtual void setText( const char *Text);
		virtual const char *getText( void) const;
		
		virtual void setAcceptCharacters( const char *AcceptCharacters);
		virtual const char *getAcceptCharacters( void) const;
		
		virtual void setRejectCharacters( const char *RejectCharacters);
		virtual const char *getRejectCharacters( void) const;

		virtual void setMinimumWidthText( const char *MinimumWidthText);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
