// fScrollPane.h

#ifndef fScrollPane_h
#define fScrollPane_h

#include "fSingleContainer.h"

#include "fHorizontalScrollBar.h"
#include "fVerticalScrollBar.h"

#pragma export on

class fScrollPane : public fSingleContainer
{
	private:

		fScrollPane( const fScrollPane &CopyObject);
		fScrollPane &operator=( const fScrollPane &CopyObject);

		ClassDeclaration( fScrollPane);

		enum ScrollBar
		{
			HScrollBar,
			VScrollBar
		};

	protected:

		fPoint		 fInset;
		fPoint		 fObjectPosition;

		fScrollBar	*fHScrollBar;
		fScrollBar	*fVScrollBar;

		virtual void recalculateSizeLimits( void);

	public:

		fScrollPane( fObject *Object = NULL);
		virtual ~fScrollPane( void);

		virtual void setView( BView *NewView);

		virtual void messageReceived( int32 Event, BMessage *Message);

		virtual void mouseMoved( const fPoint &Point);

		virtual void setSize( const fPoint &NewSize);
		virtual void setPosition( const fPoint &NewPosition);

		virtual void attachedToWindow( const class fWindow *ParentWindow);
		virtual void detachedFromWindow( void);

		virtual void setEnabled( bool Enabled);
		virtual bool setWindowActivated( bool Activated);

		virtual const fObject *containsPoint( const fPoint &Point) const;
		virtual bool findObject( const fObject *ObjectPointer) const;
		virtual const fObject *findObject( const char *ObjectName) const;

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif