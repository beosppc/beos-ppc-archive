// fLED.h

#ifndef fLED_h
#define fLED_h

#include "fObject.h"

#pragma export on

class fLED : public fObject
{
	public :
		enum Color
		{
			C_RED,
			C_GREEN,
			C_BLUE,
			C_YELLOW
		};
	
	private :

		fLED( const fLED &CopyObject);
		fLED &operator=( const fLED &CopyObject);

		VirtualClassDeclaration( fLED);

	protected:

		Color color;

		int32 activated;

		DoMethodDeclaration;

	public :

		fLED( Color InitColor = C_RED);
		virtual ~fLED( void);

		virtual void setColor( Color LEDColor);

		virtual void activate( void);
		virtual void deActivate( void);
};

#pragma export off

#endif
