// fGauge.h

#ifndef fGauge_h
#define fGauge_h

#include "fObject.h"

#pragma export on

class fGauge : public fObject
{
	private :

		fGauge( const fGauge &CopyObject);
		fGauge &operator=( const fGauge &CopyObject);

		ClassDeclaration( fGauge);

	protected:

		fColor fGaugeColor;

		int32 totalValue;
		int32 currentValue;

		virtual void recalculateSizeLimits( void);

		DoMethodDeclaration;

	public :

		fGauge( int32 TotalValue = 0);
		fGauge( fColor InitColor, int32 TotalValue = 0);
		virtual ~fGauge( void);

		virtual void setBarHeight( float BarHeight);

		virtual void setValues( int32 CurrentValue, int32 TotalValue);
		virtual void setCurrentValue( int32 CurrentValue);
		virtual void setTotalValue( int32 TotalValue);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif

