// fString.h

#ifndef fString_h
#define fString_h

#include "fObject.h"

#pragma export on

class fString : public fObject
{
	private:

		fString( const fString &CopyObject);
		fString &operator=( const fString &CopyObject);

		ClassDeclaration( fString);

	protected:
	
		virtual void initializeObject( void);

		BFont 	*fFont;
		fPoint	 fTextPosition;
		fPoint	 fTextSize;
	
		char		*string;

		virtual void recalculateSizeLimits( void);

		DoMethodDeclaration;

	public:

		fString( const char *InitString = NULL);
		fString( int32 InitValue);
		virtual ~fString( void);

		virtual void setFont( const BFont *Font);
		
		virtual void setText( const char *NewString);
		virtual void setValue( int32 NewValue);

		virtual void dispatchMessage( int32 Event, BMessage *Message);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
