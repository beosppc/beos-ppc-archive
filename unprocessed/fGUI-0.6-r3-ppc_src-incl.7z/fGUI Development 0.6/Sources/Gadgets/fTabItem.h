// fTabItem.h

#ifndef fTabItem_h
#define fTabItem_h

#include "fButton.h"

#pragma export on

class fTabItem : public fButton
{
	private:

		fTabItem( const fTabItem &CopyObject);
		fTabItem &operator=( const fTabItem &CopyObject);

		VirtualClassDeclaration( fTabItem);

	protected:

		virtual void initializeObject( void);

		fObject	*fSomeObject;

		bool		 fActive;		

		float	 fInset;

		virtual void setDefaultEvents( void);

		DoMethodDeclaration;

	public:

		fTabItem( const char *Label = NULL);
		virtual ~fTabItem( void);

		virtual void setObject( fObject *NewObject);
		virtual fObject *getObject( void);

		virtual void setActive( bool Active);
		virtual bool getActive( void) const;

		virtual void messageReceived( int32 Event, BMessage *Message);

		virtual void setInset( float NewInset);
		virtual void setParent( fObject *Parent);
		virtual void setView( BView *NewView);

		virtual void mouseMoved( const fPoint &Point);

		virtual void attachedToWindow( const class fWindow *ParentWindow);
		virtual void detachedFromWindow( void);
		virtual void setEnabled( bool Enabled);
		virtual bool setWindowActivated( bool Activated);

		virtual const fObject *containsPoint( const fPoint &Point) const;
		virtual bool findObject( const fObject *ObjectPointer) const;
		virtual const fObject *findObject( const char *ObjectName) const;
};

#pragma export off

#endif
