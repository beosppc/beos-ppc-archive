// fCheckBox.cpp

#include "fCheckBox.h"

#include "fEvents.h"

#include "fFactory.h"

#if DEBUG > 0
#define FCHECKBOX_DEBUG DEBUG
#endif
 
//#undef FCHECKBOX_DEBUG
//#define FCHECKBOX_DEBUG 3

VirtualClassDefinition( fCheckBox, fObject);

fCheckBox::fCheckBox( const char *CheckBoxText)
{
	#if FCHECKBOX_DEBUG > 0
	fprintf( stderr, "fCheckBox::fCheckBox()\n");
	#endif

	if( CheckBoxText)
	{
		fCheckBoxText = new char[ strlen( CheckBoxText) + 1];
		strcpy( fCheckBoxText, CheckBoxText);
	}
	else
	{
		fCheckBoxText = new char[ 1];
		*fCheckBoxText = 0x0;
	}
	
	initializeObject();

	#if FCHECKBOX_DEBUG > 0
	fprintf( stderr, "fCheckBox::fCheckBox() end\n");
	#endif
}

void fCheckBox::initializeObject( void)
{
	fClicked		= false;
	fHighlighted	= false;
	fActivated		= false;

	fFont			= new BFont( be_plain_font);

	setVerticalWeight( 0.0);
}

fCheckBox::~fCheckBox()
{
	#if FCHECKBOX_DEBUG > 0
	fprintf( stderr, "fCheckBox::~fCheckBox()\n");
	#endif  

	delete [] fCheckBoxText;

	delete fFont;

	#if FCHECKBOX_DEBUG > 0
	fprintf( stderr, "fCheckBox::~fCheckBox() end\n");
	#endif  
}

DoMethodBegin( fCheckBox)
	DoMethodDefinitionBegin( "Text", setText, 1)
		DoMethodVariable( char *, NewString)
		DoMethodVoidCall( setText)( NewString)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "Active", setActive, 1)
		DoMethodVariable( bool, Active)
		DoMethodVoidCall( setActive)( Active)
	DoMethodDefinitionEnd
DoMethodEnd( fObject)

void fCheckBox::setDefaultEvents( void)
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::setDefaultEvents()\n");
	#endif
/*
	removeEventRoutes( F_CHECKBOX_CHECKED);

	fEventRoute *EventRoute = new fEventRoute( F_CHECKBOX_CHECKED);
	EventRoute->setAction( F_NOTIFY);

	EventRoute->setTargetName( getView()->Window()->Title());

	if( getName())
		EventRoute->setSourceName( getName());
	else
		EventRoute->setSourcePointer( this);

	addEventRoute( EventRoute);
	
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::setDefaultEvents() EventRoute:\n");
	EventRoute->printToStream();
	#endif

	removeEventRoutes( F_CHECKBOX_UNCHECKED);

	EventRoute = new fEventRoute( F_CHECKBOX_UNCHECKED);
	EventRoute->setAction( F_NOTIFY);

	EventRoute->setTargetName( getView()->Window()->Title());

	if( getName())
		EventRoute->setSourceName( getName());
	else
		EventRoute->setSourcePointer( this);

	addEventRoute( EventRoute);
*/
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::setDefaultEvents() EventRoute:\n");
	EventRoute->printToStream();
	#endif

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::setDefaultEvents() end\n");
	#endif
}

void fCheckBox::invalidateCheckBox( void)
{
	// force redraw
//	if( getView())
//		getView()->Invalidate( getObjectFrame());
	redraw( getObjectFrame());
}

void fCheckBox::setFont( const BFont *Font)
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::setFont()\n");
	#endif

	if( Font == NULL)
		return;

	delete fFont;

	fFont = new BFont( Font);

	// no support for sheared or rotated fonts here
	fFont->SetRotation( 0.0);
	fFont->SetShear( 90.0);

	updateIfNeeded();

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::setFont() end\n");
	#endif
}

void fCheckBox::mouseDown( MouseButton Button, const fPoint &/*Point*/, int32 /*NumClicks*/)
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::mouseDown()\n");
	#endif

	if( getEnabled() == false)
		return;

	if( Button == F_PRIMARY_MOUSE_BUTTON)
	{
		fClicked = true;
		fHighlighted = true;

		invalidateCheckBox();
	}

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::mouseDown() end\n");
	#endif
}

void fCheckBox::mouseUp( MouseButton Button, const fPoint &Point, int32 /*NumClicks*/)
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::mouseUp()\n");
	#endif  

	if( fClicked == false)
		return;

	if( Button != F_PRIMARY_MOUSE_BUTTON)
		return;

	fClicked = false;
	fHighlighted = false;

	// trigger action !
	if( containsPoint( Point) == this)
	{
		#if FCHECKBOX_DEBUG > 1
		fprintf( stderr, "fCheckBox::mouseUp() ACTION !\n");
		#endif

		setActive( !fActivated);
	}
	else
		invalidateCheckBox();

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::mouseUp() end\n");
	#endif  
}

void fCheckBox::mouseEntered( const fPoint &/*Point*/)
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::mouseEntered()\n");
	#endif

	if( fClicked)
	{
		fHighlighted = true;
		invalidateCheckBox();
	}

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::mouseEntered() end\n");
	#endif
}

void fCheckBox::mouseExited( const fPoint &/*Point*/)
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::mouseExited()\n");
	#endif

	if( fClicked)
	{
		fHighlighted = false;
		invalidateCheckBox();
	}

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::mouseExited() end\n");
	#endif
}

void fCheckBox::keyDown( const char *Input, int32 Length)
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::keyDown()\n");
	#endif

	if( getEnabled() == false)
		return;

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
	{
		if( fHighlighted == false)
		{
			fHighlighted = true;
			invalidateCheckBox();
		}
	}

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::keyDown()\n");
	#endif
}

void fCheckBox::keyUp( const char *Input, int32 Length)
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::keyUp()\n");
	#endif

	if( getEnabled() == false)
		return;

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
	{
		fHighlighted = false;
		setActive( !fActivated);
	}

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::keyUp()\n");
	#endif
}

void fCheckBox::attachedToWindow( const class fWindow *ParentWindow)
{
	#if FCHECKBOX_DEBUG > 2
	fprintf( stderr, "fCheckBox::attachedToWindow()\n");
	#endif

	fObject::attachedToWindow( ParentWindow);

	setDefaultEvents();

	#if FCHECKBOX_DEBUG > 2
	fprintf( stderr, "fCheckBox::attachedToWindow() end\n");
	#endif
}

void fCheckBox::detachedFromWindow( void)
{
//	removeEventRoutes( F_CHECKBOX_CHECKED);
//	removeEventRoutes( F_CHECKBOX_UNCHECKED);
}

void fCheckBox::setActive( bool Active)
{
	if( fActivated == Active)
		return;

	fActivated = Active;

	invalidateCheckBox();
	
	if( fActivated)
		processEvent( F_CHECKBOX_CHECKED);
	else
		processEvent( F_CHECKBOX_UNCHECKED);
}

bool fCheckBox::getActive( void) const
{
	return( fActivated);
}

void fCheckBox::messageReceived( int32 Event, BMessage *Message)
{
	switch( Event)
	{
		case F_CHECKBOX_CHECKED:
		{
			setActive( true);
		}
		break;

		case F_CHECKBOX_TOGGLE:
		{
			setActive( !getActive());
		}
		break;

		case F_CHECKBOX_UNCHECKED:
		{
			setActive( false);
		}
		break;
		
		default:
			break;
	}
}

void fCheckBox::setText( const char *NewString)
{
	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::setText()\n");
	#endif

	if( NewString == NULL)
		return;

	delete [] fCheckBoxText;

	fCheckBoxText = new char[ strlen( NewString) + 1];
	strcpy( fCheckBoxText, NewString);

	updateIfNeeded();

	#if FCHECKBOX_DEBUG > 1
	fprintf( stderr, "fCheckBox::setText() end\n");
	#endif
}
