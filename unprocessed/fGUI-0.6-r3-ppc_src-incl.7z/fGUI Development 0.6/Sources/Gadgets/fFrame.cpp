// fFrame.cpp

#include "fFrame.h"
#include "fFactory.h"

VirtualClassDefinition( fFrame, fSingleContainer);

fFrame::fFrame( const char *Label, fObject *Object)
		: fSingleContainer( Object)
{
	fFont = NULL;

	fLabel = NULL;
	setText( Label);
}

fFrame::~fFrame( void)
{
	delete [] fLabel;
	delete fFont;
}

DoMethodBegin( fFrame)
	DoMethodDefinitionBegin( "Text", setText, 1)
		DoMethodVariable( char *, Label)
		DoMethodVoidCall( setText)( Label)
	DoMethodDefinitionEnd
DoMethodEnd( fSingleContainer)

void fFrame::setText( const char *Label)
{
	delete [] fLabel;

	if( Label)
	{
		fLabel = new char[ strlen( Label) + 1];
		strcpy( fLabel, Label);
	}
	else
		fLabel = NULL;
}

void fFrame::setFont( const BFont *Font)
{
	delete fFont;
	
	fFont = new BFont( Font);
	
	fFont->SetRotation( 0.0);
	fFont->SetShear( 90.0);
}


