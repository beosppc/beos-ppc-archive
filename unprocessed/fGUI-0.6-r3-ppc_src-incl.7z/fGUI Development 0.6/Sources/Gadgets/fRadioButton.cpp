// fRadioButton.cpp

#include "fRadioButton.h"

#include "fEvents.h"

#include "fFactory.h"
#include "fGroup.h"

#include "fGroupDispatcher.h"

#if DEBUG > 0
#define FRADIOBUTTON_DEBUG DEBUG
#endif
 
//#undef FRADIOBUTTON_DEBUG
//#define FRADIOBUTTON_DEBUG 3

VirtualClassDefinition( fRadioButton, fObject);

fRadioButton::fRadioButton( const char *RadioButtonText)
{
	#if FRADIOBUTTON_DEBUG > 0
	fprintf( stderr, "fRadioButton::fRadioButton()\n");
	#endif

	if( RadioButtonText)
	{
		fRadioButtonText = new char[ strlen( RadioButtonText) + 1];
		strcpy( fRadioButtonText, RadioButtonText);
	}
	else
	{
		fRadioButtonText = new char[ 1];
		*fRadioButtonText = 0x0;
	}
	
	initializeObject();

	#if FRADIOBUTTON_DEBUG > 0
	fprintf( stderr, "fRadioButton::fRadioButton() end\n");
	#endif
}

void fRadioButton::initializeObject( void)
{
	fClicked		= false;
	fHighlighted	= false;
	fActivated		= false;

	fFont			= new BFont( be_plain_font);

	fExclusiveGroup	= NULL;

	setVerticalWeight( 0.0);
}

fRadioButton::~fRadioButton()
{
	#if FRADIOBUTTON_DEBUG > 0
	fprintf( stderr, "fRadioButton::~fRadioButton()\n");
	#endif  

	delete [] fRadioButtonText;

	delete fFont;

	delete [] fExclusiveGroup;

	#if FRADIOBUTTON_DEBUG > 0
	fprintf( stderr, "fRadioButton::~fRadioButton() end\n");
	#endif  
}

DoMethodBegin( fRadioButton)
	DoMethodDefinitionBegin( "Text", setText, 1)
		DoMethodVariable( char *, NewString)
		DoMethodVoidCall( setText)( NewString)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "Active", setActive, 1)
		DoMethodVariable( bool, Active)
		DoMethodVoidCall( setActive)( Active)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "ExclusiveGroup", setExclusiveGroup, 1)
		DoMethodVariable( char *, ExclusiveGroup)
		DoMethodVoidCall( setExclusiveGroup)( ExclusiveGroup)
	DoMethodDefinitionEnd
DoMethodEnd( fObject)

void fRadioButton::setDefaultEvents( void)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::setDefaultEvents()\n");
	#endif

	removeEventRoutes( F_RADIOBUTTON_ACTIVATED);
	
	if( fExclusiveGroup)
	{
		fEventRoute *EventRoute = new fEventRoute( F_RADIOBUTTON_ACTIVATED);
		EventRoute->setAction( F_ACTIVATE_ITEM);

		EventRoute->setTargetName( fExclusiveGroup);

		if( getName())
			EventRoute->setSourceName( getName());

		EventRoute->setSourcePointer( this);
		addEventRoute( EventRoute);
		
		#if FRADIOBUTTON_DEBUG > 1
		fprintf( stderr, "fRadioButton::setDefaultEvents() EventRoute:\n");
		EventRoute->printToStream();
		#endif
	}
	else if( getParent())
	{
		fEventRoute *EventRoute = new fEventRoute( F_RADIOBUTTON_ACTIVATED);
		EventRoute->setAction( F_ACTIVATE_ITEM);

		if( getParent()->getName())
			EventRoute->setTargetName( getParent()->getName());
		else
			EventRoute->setTargetPointer( getParent());

		if( getName())
			EventRoute->setSourceName( getName());

		EventRoute->setSourcePointer( this);
		addEventRoute( EventRoute);
	}	


	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::setDefaultEvents() end\n");
	#endif
}

void fRadioButton::invalidateRadioButton( void)
{
	// force redraw
//	if( getView())
//		getView()->Invalidate( getObjectFrame());
	redraw( getObjectFrame());
}

void fRadioButton::setExclusiveGroup( const char *ExclusiveGroup)
{
	delete [] fExclusiveGroup;

	fExclusiveGroup = new char[ strlen( ExclusiveGroup) + 1];
	strcpy( fExclusiveGroup, ExclusiveGroup);

	setDefaultEvents();
}
/*
void fRadioButton::setExclusiveGroup( class fGroupDispatcher *ExclusiveGroup)
{
	if( fExclusiveGroup)
		fExclusiveGroup->removeFromGroup( this);

	fExclusiveGroup = ExclusiveGroup;

	if( fExclusiveGroup)
		fExclusiveGroup->addToGroup( this);
}
*/
void fRadioButton::setFont( const BFont *Font)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::setFont()\n");
	#endif

	if( Font == NULL)
		return;

	delete fFont;

	fFont = new BFont( Font);

	// no support for sheared or rotated fonts here
	fFont->SetRotation( 0.0);
	fFont->SetShear( 90.0);

	updateIfNeeded();

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::setFont() end\n");
	#endif
}

void fRadioButton::mouseDown( MouseButton Button, const fPoint &/*Point*/, int32 /*NumClicks*/)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::mouseDown()\n");
	#endif

	if( getEnabled() == false)
		return;

	if( Button == F_PRIMARY_MOUSE_BUTTON)
	{
		fClicked = true;
		fHighlighted = true;

		invalidateRadioButton();
	}

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::mouseDown() end\n");
	#endif
}

void fRadioButton::mouseUp( MouseButton Button, const fPoint &Point, int32 /*NumClicks*/)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::mouseUp()\n");
	#endif  

	if( fClicked == false)
		return;

	if( Button != F_PRIMARY_MOUSE_BUTTON)
		return;

	fClicked = false;
	fHighlighted = false;

	// trigger action !
	if( containsPoint( Point) == this)
	{
		#if FRADIOBUTTON_DEBUG > 1
		fprintf( stderr, "fRadioButton::mouseUp() ACTION !\n");
		#endif

		if( fActivated == false)
			processEvent( F_RADIOBUTTON_ACTIVATED);
		else
			invalidateRadioButton();
	}
	else
		invalidateRadioButton();

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::mouseUp() end\n");
	#endif  
}

void fRadioButton::mouseEntered( const fPoint &/*Point*/)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::mouseEntered()\n");
	#endif

	if( fClicked)
	{
		fHighlighted = true;

		invalidateRadioButton();
	}

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::mouseEntered() end\n");
	#endif
}

void fRadioButton::mouseExited( const fPoint &/*Point*/)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::mouseExited()\n");
	#endif

	if( fClicked)
	{
		fHighlighted = false;

		invalidateRadioButton();
	}

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::mouseExited() end\n");
	#endif
}

void fRadioButton::keyDown( const char *Input, int32 Length)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::keyDown()\n");
	#endif

	if( getEnabled() == false)
		return;

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
	{
		if( fHighlighted == false)
		{
			fHighlighted = true;
			invalidateRadioButton();
		}
	}

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::keyDown()\n");
	#endif
}

void fRadioButton::keyUp( const char *Input, int32 Length)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::keyUp()\n");
	#endif

	if( getEnabled() == false)
		return;

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
	{
		fHighlighted = false;
		invalidateRadioButton();

		processEvent( F_RADIOBUTTON_ACTIVATED);
	}

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::keyUp()\n");
	#endif
}

void fRadioButton::setParent( fObject *Parent)
{
	fObject::setParent( Parent);

	setDefaultEvents();
}

void fRadioButton::setActive( bool Active)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::setActive()\n");
	#endif

	if( fActivated == Active)
		return;

	fActivated = Active;

	invalidateRadioButton();
	
	if( fActivated)
		processEvent( F_RADIOBUTTON_ACTIVATED);
	else
		processEvent( F_RADIOBUTTON_DEACTIVATED);

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::setActive() end\n");
	#endif
}

bool fRadioButton::getActive( void) const
{
	return( fActivated);
}
/*
void fRadioButton::processEvent( int32 Event, BMessage *Message)
{
	if( Event == F_RADIOBUTTON_ACTIVATED)
		if( fExclusiveGroup)
			fExclusiveGroup->sendMessage( F_RADIOBUTTON_ACTIVATED, F_DEACTIVATE_ITEM, Message, this);

	fObject::processEvent( Event, Message);
}
*/
void fRadioButton::messageReceived( int32 Event, BMessage *Message)
{
	switch( Event)
	{
		case F_ACTIVATE_ITEM:
			if( fActivated == false)
			{
				fActivated = true;
				invalidateRadioButton();
			}
			break;

		case F_DEACTIVATE_ITEM:
			if( fActivated)
			{
				fActivated = false;
				invalidateRadioButton();

				processEvent( F_RADIOBUTTON_DEACTIVATED);
			}
			break;
/*
		case F_RADIOBUTTON_ACTIVATED:
			int32 Item = 0;
			fRadioButton *TempObject;
		
			while(( TempObject = ( fRadioButton *) fSiblings.ItemAt( Item++)) != NULL)
				TempObject->setActive( false);
			break;
*/
		default:
			fObject::messageReceived( Event, Message);
	}
}
/*
void fRadioButton::addSiblingGroup( fGroup *SiblingGroup)
{
	if( SiblingGroup == NULL)
		return;

	fEventRoute *EventRoute = new fEventRoute( F_RADIOBUTTON_ACTIVATED);
	EventRoute->setAction( F_ACTIVATE_ITEM);

	if( SiblingGroup->getName())
		EventRoute->setTargetName( SiblingGroup->getName());
	else
		EventRoute->setTargetPointer( SiblingGroup);

	if( getName())
		EventRoute->setSourceName( getName());
	else
		EventRoute->setSourcePointer( this);

	addEventRoute( EventRoute);
}

void fRadioButton::addSibling( fRadioButton *Sibling)
{
	if( Sibling && Sibling->isOfType( "fRadioButton"))
		fSiblings.AddItem( Sibling);
}
*/
void fRadioButton::setText( const char *NewString)
{
	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::setText()\n");
	#endif

	if( NewString == NULL)
		return;

	delete [] fRadioButtonText;

	fRadioButtonText = new char[ strlen( NewString) + 1];
	strcpy( fRadioButtonText, NewString);

	updateIfNeeded();

	#if FRADIOBUTTON_DEBUG > 1
	fprintf( stderr, "fRadioButton::setText() end\n");
	#endif
}
