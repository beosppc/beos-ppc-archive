// fCycleButton.h

#ifndef fCycleButton_h
#define fCycleButton_h

#include "fObject.h"
#include "fEventRoute.h"

#pragma export on

class fCycleButton : public fObject
{
	private :

		fCycleButton( const fCycleButton &CopyObject);
		fCycleButton &operator=( const fCycleButton &CopyObject);
	
		VirtualClassDeclaration( fCycleButton);

	protected:

		virtual void initializeObject( void);

		bool		 fClicked;
		bool		 fHighlighted;
		bool		 fDefaultButton;

		BFont		*fFont;
		float		*fTextSizes;

		BList		 Texts;
		int32		 fChoicesCount;

		int32		 fCurrentChoice;

		DoMethodDeclaration;

	public :

		fCycleButton( void);
		virtual ~fCycleButton( void);

		virtual void addText( const char *Text);

		virtual void setFont( const BFont *Font);

		virtual void mouseDown( MouseButton Button, const fPoint &Point, int32 NumClicks);
		virtual void mouseUp( MouseButton Button, const fPoint &Point, int32 NumClicks);

		virtual void mouseEntered( const fPoint &Point);
		virtual void mouseExited( const fPoint &Point);

		virtual void keyDown( const char *Input, int32 Length);
		virtual void keyUp( const char *Input, int32 Length);
};

#pragma export off

#endif
