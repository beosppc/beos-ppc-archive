// fScrollBarButton.cpp

#include "fScrollBarButton.h"

#include "fFactory.h"

#include "fAlarm.h"
#include "fEventRoute.h"

ClassDefinition( fScrollBarButton, fBitmapButton, "");

fScrollBarButton::fScrollBarButton( void)
{
	fMouseDownPulse = NULL;
}

fScrollBarButton::fScrollBarButton( int32 Action, const fObject *Target,
						const BBitmap *PassiveBitmap, const BBitmap *ActiveBitmap, const BBitmap *DisabledBitmap)
					: fBitmapButton( PassiveBitmap, ActiveBitmap, DisabledBitmap)
{
	// prepare alarm
	fMouseDownPulse = new fAlarm();

	fEventRoute *AlarmRoute = new fEventRoute( 'fALM');
	AlarmRoute->setSourcePointer( this);
	AlarmRoute->setTargetPointer( Target);
	AlarmRoute->setAction( Action);

	fMouseDownPulse->setAlarm( AlarmRoute, 50000, true, 200000);
}

fScrollBarButton::~fScrollBarButton( void)
{
	delete fMouseDownPulse;
}

void fScrollBarButton::dispatchMessage( int32 Event, BMessage *Message)
{
	switch( Event)
	{
		case F_PRIMARY_MOUSE_DOWN:
			fMouseDownPulse->startAlarm();
			break;

		case F_PRIMARY_MOUSE_UP:
			fMouseDownPulse->stopAlarm();
			break;
	}
	
	fBitmapButton::dispatchMessage( Event, Message);
}

void fScrollBarButton::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FBITMAPBUTTON_DEBUG > 1
	fprintf( stderr, "fScrollBarButton::draw()\n");
	#endif

	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;
		
	#if FBITMAPBUTTON_DEBUG > 2
	fprintf( stderr, "fButton::fScrollBarButton() Drawing to: ");
	Frame.PrintToStream();
	#endif

	if( getView()->Window() == NULL)
		return;

	if( getView()->Window()->Lock() == false)
		return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRect( Frame, B_SOLID_LOW);

	getView()->MovePenTo( getPosition());

	if(( getEnabled() == false) || ( getWindowActivated() == false))
	{
		if( fDisabledBitmap)
			getView()->DrawBitmapAsync( fDisabledBitmap);
	}
	else
	{
		if( fHighlighted)
		{
			if( fActiveBitmap)
				getView()->DrawBitmapAsync( fActiveBitmap);
		}
		else
		{
			if( fPassiveBitmap)
				getView()->DrawBitmapAsync( fPassiveBitmap);
		}
	}

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FBITMAPBUTTON_DEBUG > 1
	fprintf( stderr, "fScrollBarButton::draw() end\n");
	#endif
}
