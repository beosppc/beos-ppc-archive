// fNiceLED.h

#ifndef fNiceLED_h
#define fNiceLED_h

#include "fLED.h"

#pragma export on

class fNiceLED : public fLED
{
	private :

		fNiceLED( const fNiceLED &CopyObject);
		fNiceLED &operator=( const fNiceLED &CopyObject);

		ClassDeclaration( fNiceLED);

	protected:

		BBitmap *fOn;
		BBitmap *fOff;

		virtual void recalculateSizeLimits( void);

	public :

		fNiceLED( Color InitColor = C_RED);
		virtual ~fNiceLED( void);

		virtual void setColor( Color LEDColor);
		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
