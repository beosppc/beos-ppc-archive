// fBitmapButton.cpp

#include "fBitmapButton.h"

#include "fFactory.h"

#if DEBUG > 0
#define FBITMAPBUTTON_DEBUG DEBUG
#endif
 
//#undef FBITMAPBUTTON_DEBUG
//#define FBITMAPBUTTON_DEBUG 3

ClassDefinition( fBitmapButton, fButton, "");

fBitmapButton::fBitmapButton( void)
{
	fPassiveBitmap		= NULL;
	fActiveBitmap		= NULL;
	fDisabledBitmap		= NULL;

	setWeights( 0.0);
	setBorders( 0.0);
}

fBitmapButton::fBitmapButton( const BBitmap *PassiveBitmap, const BBitmap *ActiveBitmap, const BBitmap *DisabledBitmap)
{
	fPassiveBitmap		= NULL;
	fActiveBitmap		= NULL;
	fDisabledBitmap		= NULL;

	setPassiveBitmap( PassiveBitmap);
	setActiveBitmap( ActiveBitmap);
	setDisabledBitmap( DisabledBitmap);
	
	setWeights( 0.0);
	setBorders( 0.0);
}

fBitmapButton::~fBitmapButton( void)
{
	delete fPassiveBitmap;
	delete fActiveBitmap;
}

void fBitmapButton::recalculateSizeLimits( void)
{
}

void fBitmapButton::setPassiveBitmap( const BBitmap *PassiveBitmap)
{
	delete fPassiveBitmap;
	fPassiveBitmap = PassiveBitmap;

	BRect Rectangle( 0.0, 0.0, 0.0, 0.0);

	if( fActiveBitmap)
		Rectangle = Rectangle | fActiveBitmap->Bounds();
	
	if( fPassiveBitmap)
		Rectangle = Rectangle | fPassiveBitmap->Bounds();
		
	if( fDisabledBitmap)
		Rectangle = Rectangle | fDisabledBitmap->Bounds();
		
	fPoint Size = Rectangle.RightBottom() + fPoint( 1.0, 1.0);

	setMinimumSize( Size);
	setPreferredSize( Size);
	setMaximumSize( Size);
	
	updateIfNeeded();
}

const BBitmap *fBitmapButton::getPassiveBitmap( void) const
{
	return( fPassiveBitmap);
}

void fBitmapButton::setActiveBitmap( const BBitmap *ActiveBitmap)
{
	delete fActiveBitmap;
	fActiveBitmap = ActiveBitmap;
	
	BRect Rectangle( 0.0, 0.0, 0.0, 0.0);

	if( fActiveBitmap)
		Rectangle = Rectangle | fActiveBitmap->Bounds();
	
	if( fPassiveBitmap)
		Rectangle = Rectangle | fPassiveBitmap->Bounds();
		
	if( fDisabledBitmap)
		Rectangle = Rectangle | fDisabledBitmap->Bounds();
		
	fPoint Size = Rectangle.RightBottom() + fPoint( 1.0, 1.0);

	#if FBITMAPBUTTON_DEBUG > 2
	fprintf( stderr, "fButton::setActiveBitmap() Setting size to: ");
	Size.PrintToStream();
	#endif

	setMinimumSize( Size);
	setPreferredSize( Size);
	setMaximumSize( Size);
	
	updateIfNeeded();
}

const BBitmap *fBitmapButton::getActiveBitmap( void) const
{
	return( fActiveBitmap);
}

void fBitmapButton::setDisabledBitmap( const BBitmap *DisabledBitmap)
{
	delete fDisabledBitmap;
	fDisabledBitmap = DisabledBitmap;
	
	BRect Rectangle( 0.0, 0.0, 0.0, 0.0);

	if( fActiveBitmap)
		Rectangle = Rectangle | fActiveBitmap->Bounds();
	
	if( fPassiveBitmap)
		Rectangle = Rectangle | fPassiveBitmap->Bounds();
		
	if( fDisabledBitmap)
		Rectangle = Rectangle | fDisabledBitmap->Bounds();
		
	fPoint Size = Rectangle.RightBottom() + fPoint( 1.0, 1.0);

	#if FBITMAPBUTTON_DEBUG > 2
	fprintf( stderr, "fButton::setDisabledBitmap() Setting size to: ");
	Size.PrintToStream();
	#endif

	setMinimumSize( Size);
	setPreferredSize( Size);
	setMaximumSize( Size);
	
	updateIfNeeded();
}

const BBitmap *fBitmapButton::getDisabledBitmap( void) const
{
	return( fDisabledBitmap);
}

void fBitmapButton::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FBITMAPBUTTON_DEBUG > 1
	fprintf( stderr, "fBitmapButton::draw()\n");
	#endif

	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;
		
	#if FBITMAPBUTTON_DEBUG > 2
	fprintf( stderr, "fButton::fBitmapButton() Drawing to: ");
	Frame.PrintToStream();
	#endif

	if( getView()->Window() == NULL)
		return;

	if( getView()->Window()->Lock() == false)
		return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRect( Frame, B_SOLID_LOW);

	getView()->MovePenTo( getPosition());

	if( getEnabled() == false)
	{
		if( fDisabledBitmap)
			getView()->DrawBitmapAsync( fDisabledBitmap);
	}
	else
	{
		if( fHighlighted)
		{
			if( fActiveBitmap)
				getView()->DrawBitmapAsync( fActiveBitmap);
		}
		else
		{
			if( fPassiveBitmap)
				getView()->DrawBitmapAsync( fPassiveBitmap);
		}
	}

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FBITMAPBUTTON_DEBUG > 1
	fprintf( stderr, "fBitmapButton::draw() end\n");
	#endif
}
