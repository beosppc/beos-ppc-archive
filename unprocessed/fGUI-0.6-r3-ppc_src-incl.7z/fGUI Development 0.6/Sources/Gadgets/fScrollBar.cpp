// fScrollBar.cpp

#include "fScrollBar.h"
#include "fFactory.h"
#include "fEvents.h"

#include "fScrollBarButton.h"

#include "fAlarm.h"
#include "fEventRoute.h"

#if DEBUG > 0
#define FSCROLLBAR_DEBUG DEBUG
#endif
 
//#undef FSCROLLBAR_DEBUG
//#define FSCROLLBAR_DEBUG 2

template <class T>
inline double min( T a, T b)
{
	return( a < b ? a : b);
}

template <class T>
inline double max( T a, T b)
{
	return( a > b ? a : b);
}

VirtualClassDefinition( fScrollBar, fObject);

fScrollBar::fScrollBar( void)
{
	fMinimum				= 0.0;
	fMaximum				= 100.0;
	fDirection				= 1.0;
	fVisible				= 10.0;
	fKnobPosition			= 0.0;

	fSmallJump				= 1.0;
	fBigJump				= 10.0;

	fDragged				= false;

	fMinimumKnobSize		= 15.0;
	fDoubleArrows			= true;
	fUseMinimumKnobSize		= false;

	setBackgroundColor( 0xd9, 0xd9, 0xd9);

	for( int32 Item = 0; Item < 4; Item++)
		fArrows[ Item] = NULL;

	// prepare alarm
	fMouseDownPulse = new fAlarm();

	fEventRoute *AlarmRoute = new fEventRoute( F_ALARM);
	AlarmRoute->setSourcePointer( this);
	AlarmRoute->setTargetPointer( this);

	fMouseDownPulse->setAlarm( AlarmRoute, 50000, true, 250000);
}

fScrollBar::~fScrollBar( void)
{
	delete fMouseDownPulse;

	for( int32 Item = 0; Item < 4; Item++)
		delete fArrows[ Item];
}

void fScrollBar::recalculateSizeLimits( void)
{
}

const fObject *fScrollBar::containsPoint( const fPoint &Point) const
{
	if( fObject::containsPoint( Point) == NULL)
		return( NULL);

	const fObject *TempObject;

	for( int32 Item = 0; Item < 4; Item++)
	{
		if( fArrows[ Item])
		{
			TempObject = fArrows[ Item]->containsPoint( Point);

			if( TempObject)
				return( TempObject);
		}
	}

	return( this);
}

bool fScrollBar::findObject( const fObject *ObjectPointer) const
{
	#if FSCROLLBAR_DEBUG > 3
	fprintf( stderr, "fScrollBar::findObject( const fObject *ObjectPointer)\n");
	#endif

	if( fObject::findObject( ObjectPointer))
		return( true);

	for( int32 Item = 0; Item < 4; Item++)
		if( fArrows[ Item])
			if( fArrows[ Item]->findObject( ObjectPointer))
				return( true);

	return( false);

	#if FSCROLLBAR_DEBUG > 3
	fprintf( stderr, "fScrollBar::findObject( const fObject *ObjectPointer) end\n");
	#endif
}

const fObject *fScrollBar::findObject( const char *ObjectName) const
{
	#if FSCROLLBAR_DEBUG > 3
	fprintf( stderr, "fScrollBar::findObject( const char *ObjectName)\n");
	#endif

	const fObject *TempObject = fObject::findObject( ObjectName);

	if( TempObject)
		return( TempObject);

	for( int32 Item = 0; Item < 4; Item++)
	{
		if( fArrows[ Item])
		{
			TempObject = fArrows[ Item]->findObject( ObjectName);

			if( TempObject)
				return( TempObject);
		}
	}

	return( NULL);

	#if FSCROLLBAR_DEBUG > 3
	fprintf( stderr, "fScrollBar::findObject( const char *ObjectName) end\n");
	#endif
}

void fScrollBar::setView( BView *NewView)
{
	fObject::setView( NewView);

	for( int32 Item = 0; Item < 4; Item++)
		if( fArrows[ Item])
			fArrows[ Item]->setView( NewView);
}

void fScrollBar::setEnabled( bool Enabled)
{
	if( Enabled == getEnabled())
		return;

	fObject::setEnabled( Enabled);

	for( int32 Item = 0; Item < 4; Item++)
		if( fArrows[ Item])
			fArrows[ Item]->setEnabled( Enabled);

	redraw( getObjectFrame());
}

void fScrollBar::attachedToWindow( const class fWindow *ParentWindow)
{
	fObject::attachedToWindow( ParentWindow);

	for( int32 Item = 0; Item < 4; Item++)
		if( fArrows[ Item])
			fArrows[ Item]->attachedToWindow( fParentWindow);
}

void fScrollBar::detachedFromWindow( void)
{
	fObject::detachedFromWindow();

	for( int32 Item = 0; Item < 4; Item++)
		if( fArrows[ Item])
			fArrows[ Item]->detachedFromWindow();
}

bool fScrollBar::setWindowActivated( bool Activated)
{
	if( fObject::setWindowActivated( Activated) == false)
		return( false);

	for( int32 Item = 0; Item < 4; Item++)
		if( fArrows[ Item])
			fArrows[ Item]->setWindowActivated( Activated);

	redraw( getObjectFrame());

	return( true);
}

void fScrollBar::setPosition( const fPoint &NewPosition)
{
	fPoint delta = NewPosition - getPosition();

	fObject::setPosition( NewPosition);
	
	for( int32 Item = 0; Item < 4; Item++)
		if( fArrows[ Item])
			fArrows[ Item]->setPosition( fArrows[ Item]->getPosition() + delta);
}

void fScrollBar::messageReceived( int32 Event, BMessage *Message)
{
	switch( Event)
	{
		case F_SCROLLBAR_SMALL_INCREASE:
			setKnobPosition( fKnobPosition + fDirection * fSmallJump);
			break;

		case F_SCROLLBAR_SMALL_DECREASE:
			setKnobPosition( fKnobPosition - fDirection * fSmallJump);
			break;

		case F_SCROLLBAR_BIG_INCREASE:
		{
			if( fMouseDownPulse->getRunning() && fKnobFrame.Contains( fLastPosition - getPosition()))
				fMouseDownPulse->stopAlarm();
			else
				setKnobPosition( fKnobPosition + fDirection * fBigJump);
		}
		break;

		case F_SCROLLBAR_BIG_DECREASE:
		{
			if( fMouseDownPulse->getRunning() && fKnobFrame.Contains( fLastPosition - getPosition()))
				fMouseDownPulse->stopAlarm();
			else
				setKnobPosition( fKnobPosition - fDirection * fBigJump);
		}
		break;

		case F_SCROLLBAR_VALUE_CHANGED:
			if( Message)
			{
				float NewValue;
				
				if( Message->FindFloat( "fValue", &NewValue) == B_OK)
					valueChanged( NewValue);
			}
			break;
	}
}

void fScrollBar::setMinimum( double Minimum)
{
//	fprintf( stderr, "fScrollBar::setMinimum( %f) fVisible: %f, fMinimum: %f, fKnobPosition: %f\n", Minimum, fVisible, fMinimum, fKnobPosition);

	// do nothing if the value doesn't change
	if( fMinimum == Minimum)
		return;
	
	fMinimum = Minimum;

	double Total = fMaximum - fMinimum;

	if( Total < 0.0)
		fDirection = -1.0;
	else
		fDirection = 1.0;

	if( fVisible >= abs( Total))
	{
		fVisible = abs( Total);
		setEnabled( false);
	}
	else
		setEnabled( true);

	if( fDirection < 0.0)
	{
		if( fKnobPosition > fMinimum)
			fKnobPosition = fMinimum;
	}
	else
	{
		if( fKnobPosition < fMinimum)
			fKnobPosition = fMinimum;
	}

	BRect UpdateFrame = fKnobFrame;

	recalculateKnobFrame();

	UpdateFrame = UpdateFrame | fKnobFrame;
	UpdateFrame.OffsetBy( getPosition());

	redraw( UpdateFrame);
}

double fScrollBar::getMinimum( void) const
{
	return( fMinimum);
}

void fScrollBar::setMaximum( double Maximum)
{
//	fprintf( stderr, "fScrollBar::setMaximum( %f) fVisible: %f, fMaximum: %f, fKnobPosition: %f\n", Maximum, fVisible, fMaximum, fKnobPosition);

	// do nothing if the value doesn't change
	if( fMaximum == Maximum)
		return;
	
	fMaximum = Maximum;

	double Total = fMaximum - fMinimum;

	if( Total < 0.0)
		fDirection = -1.0;
	else
		fDirection = 1.0;

	if( fVisible >= abs( Total))
	{
		fVisible = abs( Total);
		setEnabled( false);
	}
	else
		setEnabled( true);

	if( fDirection < 0.0)
	{
		if( fKnobPosition < ( fMaximum + fVisible))
			fKnobPosition = fMaximum + fVisible;
	}
	else
	{
		if( fKnobPosition > ( fMaximum - fVisible))
			fKnobPosition = fMaximum - fVisible;
	}

	BRect UpdateFrame = fKnobFrame;

	recalculateKnobFrame();

	UpdateFrame = UpdateFrame | fKnobFrame;
	UpdateFrame.OffsetBy( getPosition());

	redraw( UpdateFrame);
}

double fScrollBar::getMaximum( void) const
{
	return( fMaximum);
}

void fScrollBar::setVisible( double Visible)
{
//	fprintf( stderr, "fScrollBar::setVisible( %f) fVisible: %f, fTotal: %f, fKnobPosition: %f\n", Visible, fVisible, fMaximum - fMinimum, fKnobPosition);

	if( Visible <= 0.0)
		return;

	double Total = fMaximum - fMinimum;

	if( Visible >= abs( Total))
	{
		Visible = abs( Total);
		setEnabled( false);
	}
	else
		setEnabled( true);

	if( fVisible == Visible)
		return;

	fVisible = Visible;

	if( fDirection < 0.0)
	{
		if( fKnobPosition < ( fMaximum + fVisible))
//			fKnobPosition = fMaximum + fVisible;
			setKnobPosition( fMaximum + fVisible);
	}
	else
	{
		if( fKnobPosition > ( fMaximum - fVisible))
//			fKnobPosition = fMaximum - fVisible;
			setKnobPosition( fMaximum - fVisible);
	}

	BRect UpdateFrame = fKnobFrame;

	recalculateKnobFrame();

	UpdateFrame = UpdateFrame | fKnobFrame;
	UpdateFrame.OffsetBy( getPosition());

	redraw( UpdateFrame);
}

double fScrollBar::getVisible( void) const
{
	return( fVisible);
}

void fScrollBar::setKnobPosition( double KnobPosition)
{
//	fprintf( stderr, "fScrollBar::setKnobPosition( %f) fKnobPosition: %f\n", KnobPosition, fKnobPosition);

	if( fDirection < 0.0)
	{
		if( KnobPosition > fMinimum)
			KnobPosition = fMinimum;
	
		if( KnobPosition < ( fMaximum + fVisible))
			KnobPosition = fMaximum + fVisible;
	}
	else
	{
		if( KnobPosition < fMinimum)
			KnobPosition = fMinimum;
	
		if( KnobPosition > ( fMaximum - fVisible))
			KnobPosition = fMaximum - fVisible;
	}

	if( fKnobPosition == KnobPosition)
	{
//		fprintf( stderr, "fScrollBar::setKnobPosition() fKnobPosition unchanged !\n");
		return;
	}

	fKnobPosition = KnobPosition;

	BRect UpdateFrame = fKnobFrame;

	recalculateKnobFrame();

	UpdateFrame = UpdateFrame | fKnobFrame;
	UpdateFrame.OffsetBy( getPosition());

	redraw( UpdateFrame);

	BMessage Message;
	Message.AddFloat( "fValue", fKnobPosition);

	processEvent( F_SCROLLBAR_VALUE_CHANGED, &Message);
}

double fScrollBar::getKnobPosition( void) const
{
	return( fKnobPosition);
}

void fScrollBar::setSmallJump( double SmallJump)
{
	fSmallJump = SmallJump;
}

double fScrollBar::getSmallJump( void) const
{
	return( fSmallJump);
}

void fScrollBar::setBigJump( double BigJump)
{
	fBigJump = BigJump;
}

double fScrollBar::getBigJump( void) const
{
	return( fBigJump);
}

void fScrollBar::valueChanged( double /*NewValue*/)
{
//	fprintf( stderr, "fScrollBar::valueChanged() New value: %f\n", NewValue);
}
