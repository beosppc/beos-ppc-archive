// fVerticalSpace.cpp

#include "fVerticalSpace.h"
#include "fFactory.h"

#if DEBUG > 0
#define FVERTICALSPACE_DEBUG DEBUG
#endif

//#undef FVERTICALSPACE_DEBUG
#define FVERTICALSPACE_DEBUG -1

ClassDefinition( fVerticalSpace, fObject, "");

fVerticalSpace::fVerticalSpace( float Height)
{
	#if FVERTICALSPACE_DEBUG > 0
	fprintf( stderr, "fVerticalSpace::fVerticalSpace()\n");
	#endif

	setVerticalWeight( 0.0);

	setHorizontalBorder( 0.0);
	setVerticalBorder( 0.0);

	setMinimumSize( fPoint( 0.0, Height));
	setPreferredSize( fPoint( 0.0, Height));
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, Height));

	#if FVERTICALSPACE_DEBUG > 0
	fprintf( stderr, "fVerticalSpace::fVerticalSpace() end\n");
	#endif
}

fVerticalSpace::~fVerticalSpace( void)
{
}

void fVerticalSpace::recalculateSizeLimits( void)
{
}

void fVerticalSpace::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FVERTICALSPACE_DEBUG > 1
	fprintf( stderr, "fVerticalSpace::draw()\n");
	#endif

	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	if( Frame.IsValid() == false)
	{
		#if FVERTICALSPACE_DEBUG > 2
		fprintf( stderr, "fVerticalSpace::draw() Drawing to: ");
		Frame.PrintToStream();
		#endif
		
		return;
	}

	if( getView()->Window() == NULL)
		return;
		
	if( getView()->Window()->Lock() == false)
		return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	#if FVERTICALSPACE_DEBUG >= 0
	ShowObjectLayout;
	#endif

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRect( Frame, B_SOLID_LOW);

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FVERTICALSPACE_DEBUG > 1
	fprintf( stderr, "fVerticalSpace::draw() end\n");
	#endif
}
