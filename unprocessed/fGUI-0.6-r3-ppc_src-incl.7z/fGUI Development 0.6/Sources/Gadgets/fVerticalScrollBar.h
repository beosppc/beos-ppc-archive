// fVerticalScrollBar.h

#ifndef fVerticalScrollBar_h
#define fVerticalScrollBar_h

#include "fScrollBar.h"

#pragma export on

class fVerticalScrollBar : public fScrollBar
{
	private:

		fVerticalScrollBar( const fVerticalScrollBar &CopyObject);
		fVerticalScrollBar &operator=( const fVerticalScrollBar &CopyObject);
	
		VirtualClassDeclaration( fVerticalScrollBar);

		enum { F_SINGLE_ARROW_UP,
				F_SINGLE_ARROW_DOWN,
				F_DOUBLE_ARROW_UP,
				F_DOUBLE_ARROW_DOWN };

	protected:

	public:

		fVerticalScrollBar( void);
		virtual ~fVerticalScrollBar( void);
		
		virtual void mouseDown( MouseButton Button, const fPoint &Point, int32 NumClicks);
		virtual void mouseUp( MouseButton Button, const fPoint &Point, int32 NumClicks);

		virtual void mouseMoved( const fPoint &Point);
};

#pragma export off

#endif