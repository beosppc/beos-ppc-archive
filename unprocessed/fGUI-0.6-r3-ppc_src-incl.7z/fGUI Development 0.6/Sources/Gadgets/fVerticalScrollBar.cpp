// fVerticalScrollBar.cpp

#include "fVerticalScrollBar.h"

#include "fEvents.h"

#include "fFactory.h"

#include "fAlarm.h"
#include "fEventRoute.h"

#if DEBUG > 0
#define FSCROLLBAR_DEBUG DEBUG
#endif
 
//#undef FSCROLLBAR_DEBUG
//#define FSCROLLBAR_DEBUG 2

VirtualClassDefinition( fVerticalScrollBar, fScrollBar);

fVerticalScrollBar::fVerticalScrollBar( void)
{
	// set size limits
	setMinimumSize( fPoint( B_V_SCROLL_BAR_WIDTH + 1.0, 0.0));
	setPreferredSize( fPoint( B_V_SCROLL_BAR_WIDTH + 1.0, 0.0));
	setMaximumSize( fPoint( B_V_SCROLL_BAR_WIDTH + 1.0, F_NO_SIZE_LIMIT));

	setHorizontalWeight( 0.0);
}

fVerticalScrollBar::~fVerticalScrollBar( void)
{
}

void fVerticalScrollBar::mouseDown( MouseButton Button, const fPoint &Point, int32 /*NumClicks*/)
{
	if( getEnabled() == false)
		return;

	if( Button != F_PRIMARY_MOUSE_BUTTON)
		return;

	BRect KnobFrame = fKnobFrame;
	KnobFrame.OffsetBy( getPosition());

	// Inset because the top an bottom border really belongs to the knob
	KnobFrame.InsetBy( 0.0, -1.0);
	
	fLastPosition = Point;

	if( KnobFrame.Contains( Point))
		fDragged = true;
	else
	{
		BRect ScrollBarFrame = fScrollBarFrame;
		ScrollBarFrame.OffsetBy( getPosition());

		if( ScrollBarFrame.Contains( Point))
		{
			if( Point.y < KnobFrame.top)
			{
				fMouseDownPulse->getAlarmRoute()->setAction( F_SCROLLBAR_BIG_DECREASE);
				fMouseDownPulse->startAlarm();
				processEvent( F_SCROLLBAR_BIG_DECREASE);
			}
			else 
			{
				fMouseDownPulse->getAlarmRoute()->setAction( F_SCROLLBAR_BIG_INCREASE);
				fMouseDownPulse->startAlarm();
				processEvent( F_SCROLLBAR_BIG_INCREASE);
			}
		}
	}
}

void fVerticalScrollBar::mouseUp( MouseButton Button, const fPoint &/*Point*/, int32 /*NumClicks*/)
{
	if( Button != F_PRIMARY_MOUSE_BUTTON)
		return;

	fDragged = false;

	fMouseDownPulse->stopAlarm();
}

void fVerticalScrollBar::mouseMoved( const fPoint &Point)
{
	if( fDragged == false)
	{
		fLastPosition = Point;
		return;
	}

	double Difference = ( Point - fLastPosition).y;

	double TopMost = fScrollBarFrame.top;
	double BottomMost = fScrollBarFrame.bottom - fKnobFrame.Height();

	double NewPosition = fKnobFrame.top + Difference;
	
	if( NewPosition < TopMost)
		NewPosition = TopMost;

	if( NewPosition > BottomMost)
		NewPosition = BottomMost;

	double OldPosition = fKnobFrame.top;

//	fprintf( stderr, "fVerticalScrollBar::mouseWithin() Old position: %f\n", OldPosition);
//	fprintf( stderr, "fVerticalScrollBar::mouseWithin() New position: %f\n", NewPosition);

	if( OldPosition == NewPosition)
		return;

	BRect UpdateFrame = fKnobFrame;
	
	fKnobFrame.OffsetBy( fPoint( 0.0, NewPosition - OldPosition));

	double Total = fMaximum - fMinimum;

	// calculate new position (logical)
	// current position * ( fTotal - fVisible) / ( Height - KnobHeight)
	double NewKnobPosition = 0.0;
	
	if( Total != ( fDirection * fVisible))
		NewKnobPosition = fMinimum + ( NewPosition - TopMost) * ( Total - ( fDirection * fVisible)) / ( fScrollBarFrame.Height() + 1.0 - ( fKnobFrame.Height() + 1.0));

//	fprintf( stderr, "Showing %f to %f\n", NewKnobPosition, NewKnobPosition + ( fDirection * fVisible));

//	fKnobPosition = NewKnobPosition;
	setKnobPosition( NewKnobPosition);
/*
	if( Difference < 0.0)
		UpdateFrame.left += Difference;
	else
		UpdateFrame.right += Difference;

	UpdateFrame.InsetBy( -1.0, 0.0);
*/
	UpdateFrame = UpdateFrame | fKnobFrame;
	UpdateFrame.OffsetBy( getPosition());

	redraw( UpdateFrame);

//	if( getView())
//		getView()->Invalidate( UpdateFrame);


	fLastPosition = Point;
}