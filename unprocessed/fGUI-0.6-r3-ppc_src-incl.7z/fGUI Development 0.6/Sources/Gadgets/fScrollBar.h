// fScrollBar.h

#ifndef fScrollBar_h
#define fScrollBar_h

#include "fObject.h"

#pragma export on

class fScrollBar : public fObject
{
	private:
	
		fScrollBar( const fScrollBar &CopyObject);
		fScrollBar &operator=( const fScrollBar &CopyObject);
	
		VirtualClassDeclaration( fScrollBar);

	protected:

		class fAlarm *fMouseDownPulse;

		BRect				 fKnobFrame;
		BRect				 fScrollBarFrame;

		double 				 fMinimum;
		double 				 fMaximum;
		double 				 fDirection;
		double 				 fVisible;
		double 				 fKnobPosition;

		double 				 fSmallJump;
		double 				 fBigJump;

		bool				 fDragged;
		fPoint				 fLastPosition;

		double				 fMinimumKnobSize;
		bool				 fDoubleArrows;
		bool				 fUseMinimumKnobSize;

		class fScrollBarButton	*fArrows[ 4];


		virtual void recalculateKnobFrame( void) = 0;

		virtual void recalculateSizeLimits( void);

	public:

		fScrollBar( void);
		virtual ~fScrollBar( void);
		
		virtual const fObject *containsPoint( const fPoint &Point) const;

		virtual  bool findObject( const fObject *ObjectPointer) const;
		virtual const fObject *findObject( const char *ObjectName) const;
				
		virtual void setView( BView *NewView);
		virtual void setEnabled( bool Enabled);

		virtual void attachedToWindow( const class fWindow *ParentWindow);
		virtual void detachedFromWindow( void);

		virtual bool setWindowActivated( bool Activated);

		virtual void setPosition( const fPoint &NewPosition);

		virtual void messageReceived( int32 Event, BMessage *Message);

		virtual void setMinimum( double Minimum);
		virtual double getMinimum( void) const;

		virtual void setMaximum( double Maximum);
		virtual double getMaximum( void) const;

		virtual void setVisible( double Visible);
		virtual double getVisible( void) const;
		
		virtual void setKnobPosition( double KnobPosition);
		virtual double getKnobPosition( void) const;

		virtual void setSmallJump( double SmallJump);
		virtual double getSmallJump( void) const;

		virtual void setBigJump( double BigJump);
		virtual double getBigJump( void) const;

		virtual void valueChanged( double NewValue);
};

#pragma export off

#endif