// fButton.cpp

#include "fButton.h"

#include "fEvents.h"

#include "fFactory.h"

#if DEBUG > 0
#define FBUTTON_DEBUG DEBUG
#endif
 
//#undef FBUTTON_DEBUG
//#define FBUTTON_DEBUG 2

VirtualClassDefinition( fButton, fObject);

fButton::fButton( const char *ButtonText)
{
	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fButton::fButton()\n");
	#endif

	if( ButtonText)
	{
		fButtonText = new char[ strlen( ButtonText) + 1];
		strcpy( fButtonText, ButtonText);
	}
	else
	{
		fButtonText = new char[ 1];
		*fButtonText = 0x0;
	}
	
	initializeObject();

	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fButton::fButton() end\n");
	#endif
}

void fButton::initializeObject( void)
{
	fClicked		= false;
	fHighlighted	= false;
	fDefaultButton	= false;

	fFont			= new BFont( be_plain_font);
}

DoMethodBegin( fButton)
	DoMethodDefinitionBegin( "Text", setText, 1)
		DoMethodVariable( char *, NewString)
		DoMethodVoidCall( setText)( NewString)
	DoMethodDefinitionEnd
DoMethodEnd( fObject)

fButton::~fButton()
{
	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fButton::~fButton()\n");
	#endif  

	delete [] fButtonText;

	delete fFont;

	#if FBUTTON_DEBUG > 0
	fprintf( stderr, "fButton::~fButton() end\n");
	#endif  
}

void fButton::setDefaultEvents( void)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::setDefaultEvents()\n");
	#endif

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::setDefaultEvents() end\n");
	#endif
}

void fButton::setFont( const BFont *Font)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::setFont()\n");
	#endif

	if( Font == NULL)
		return;

	delete fFont;

	fFont = new BFont( Font);

	// no support for sheared or rotated fonts here
	fFont->SetRotation( 0.0);
	fFont->SetShear( 90.0);

	updateIfNeeded();

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::setFont() end\n");
	#endif
}

void fButton::mouseDown( MouseButton Button, const fPoint &/*Point*/, int32 /*NumClicks*/)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::mouseDown()\n");
	#endif

	if( getEnabled() == false)
		return;

	if( Button == F_PRIMARY_MOUSE_BUTTON)
	{
		fClicked = true;
		fHighlighted = true;

		// force redraw
		redraw( getObjectFrame());
	}

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::mouseDown() end\n");
	#endif
}

void fButton::mouseUp( MouseButton Button, const fPoint &Point, int32 /*NumClicks*/)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::mouseUp()\n");
	#endif  

	if( fClicked == false)
		return;

	if( Button != F_PRIMARY_MOUSE_BUTTON)
		return;

	fClicked = false;

	// trigger action !
	if( containsPoint( Point) == this)
	{
		#if FBUTTON_DEBUG > 1
		fprintf( stderr, "fButton::mouseUp() ACTION !\n");
		#endif

		processEvent( F_BUTTON_CLICKED);		
	}

	// force redraw
	if( fHighlighted)
	{
		fHighlighted = false;
		redraw( getObjectFrame());
	}

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::mouseUp() end\n");
	#endif  
}

void fButton::mouseEntered( const fPoint &/*Point*/)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::mouseEntered()\n");
	#endif

	if( fClicked)
	{
		fHighlighted = true;

		// force redraw
		redraw( getObjectFrame());
	}

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::mouseEntered() end\n");
	#endif
}

void fButton::mouseExited( const fPoint &/*Point*/)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::mouseExited()\n");
	#endif

	if( fClicked)
	{
		fHighlighted = false;

		// force redraw
		redraw( getObjectFrame());
	}

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::mouseExited() end\n");
	#endif
}

void fButton::setDefaultButton( bool DefaultButton)
{
	fDefaultButton = DefaultButton;
	
	updateIfNeeded();
}

bool fButton::getDefaultButton( void) const
{
	return( fDefaultButton);
}

void fButton::keyDown( const char *Input, int32 Length)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::keyDown()\n");
	#endif

	if( getEnabled() == false)
		return;

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
		if( fHighlighted == false)
			redraw( getObjectFrame());

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::keyDown() end\n");
	#endif
}

void fButton::keyUp( const char *Input, int32 Length)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::keyUp()\n");
	#endif

	if( getEnabled() == false)
		return;

	if(( Length == 1) && (( *Input == B_ENTER) || ( *Input == B_SPACE)))
	{
		fHighlighted = false;
		redraw( getObjectFrame());

		processEvent( F_BUTTON_CLICKED);
	}

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::keyUp() end\n");
	#endif
}

void fButton::setText( const char *NewString)
{
	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::setText()\n");
	#endif

	if( NewString == NULL)
		return;

	delete [] fButtonText;

	fButtonText = new char[ strlen( NewString) + 1];
	strcpy( fButtonText, NewString);

	updateIfNeeded();

	#if FBUTTON_DEBUG > 1
	fprintf( stderr, "fButton::setText() end\n");
	#endif
}
