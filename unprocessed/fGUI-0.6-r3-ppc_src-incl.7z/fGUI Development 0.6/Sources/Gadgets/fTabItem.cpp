// fTabItem.cpp

#include "fTabItem.h"
#include "fFactory.h"

#include "fEvents.h"

#if DEBUG > 0
#define FTABITEM_DEBUG DEBUG
#endif

//#undef FTABITEM_DEBUG
//#define FTABITEM_DEBUG 2

VirtualClassDefinition( fTabItem, fButton);

fTabItem::fTabItem( const char *Label)
		: fButton( Label)
{
	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fTabItem::fTabItem()\n");
	#endif

	initializeObject();

	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fTabItem::fTabItem() end\n");
	#endif
}

void fTabItem::initializeObject( void)
{
	setHorizontalBorder( 0.0);
	setVerticalBorder( 0.0);

	setVerticalWeight( 0.0);

	fSomeObject = NULL;

	fActive = false;

	fInset  = 3.0;

	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));
}

fTabItem::~fTabItem( void)
{
	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fTabItem::~fTabItem()\n");
	#endif

	delete fSomeObject;

	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fTabItem::~fTabItem() end\n");
	#endif
}

DoMethodBegin( fTabItem)
	DoMethodDefinitionBegin( "Child", setObject, 1)
		DoMethodVariableCast( fObject *, fClassInfo *, NewObject)
		DoMethodVoidCall( setObject)( NewObject)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "Active", setActive, 1)
		DoMethodVariable( bool, Active)
		DoMethodVoidCall( setActive)( Active)
	DoMethodDefinitionEnd
DoMethodEnd( fButton)

void fTabItem::setDefaultEvents( void)
{
	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fTabItem::setDefaultEvents()\n");
	#endif

	removeEventRoutes( F_BUTTON_CLICKED);
	
	if( getParent())
	{
		fEventRoute *EventRoute = new fEventRoute( F_BUTTON_CLICKED);

		EventRoute->setAction( F_ACTIVATE_ITEM);

		if( getParent()->getName())
			EventRoute->setTargetName( getParent()->getName());
		else
			EventRoute->setTargetPointer( getParent());

		if( getName())
			EventRoute->setSourceName( getName());
		else
			EventRoute->setSourcePointer( this);

		addEventRoute( EventRoute);
		
		#if FTABITEM_DEBUG > 1
		fprintf( stderr, "fTabItem::setDefaultEvents() EventRoute:\n");
		EventRoute->printToStream();
		#endif
	}

	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fTabItem::setDefaultEvents() end\n");
	#endif
}

void fTabItem::setObject( fObject *NewObject)
{
	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fTabItem::addObject()\n");
	#endif

	if( fSomeObject)
		if( fParentWindow)
			fSomeObject->detachedFromWindow();

	delete fSomeObject;
	fSomeObject = NewObject;
	
	if( fSomeObject)
	{
		fSomeObject->setParent( getParent());
		if( getEnabled() == false)
			fSomeObject->setEnabled( false);
	}

	// if the object is attached to a window, tell the new child object
	if( fParentWindow)
		NewObject->attachedToWindow( fParentWindow);

	updateIfNeeded();

	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fTabItem::addObject() end\n");
	#endif
}

fObject *fTabItem::getObject( void)
{
	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fTabItem::getObject()\n");
	#endif

	return( fSomeObject);

	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fTabItem::getObject() end\n");
	#endif
}

void fTabItem::setActive( bool Active)
{
	// if status is unchanged, do nothing
	if( fActive == Active)
		return;

	// else...
	fActive = Active;

	if( fActive)
	{
		if( fSomeObject)
			fSomeObject->setView( getView());
	
//		updateIfNeeded();
	}
	else
	{
		if( fSomeObject)
			fSomeObject->setView( NULL);
	}
}

bool fTabItem::getActive( void) const
{
	return( fActive);
}

void fTabItem::messageReceived( int32 Event, BMessage *Message)
{
	switch( Event)
	{
		case F_ACTIVATE_ITEM:
			setActive( true);
			break;

		case F_DEACTIVATE_ITEM:
			setActive( false);
			break;

		default:
			fObject::messageReceived( Event, Message);
	}
}

void fTabItem::setInset( float NewInset)
{
	if( NewInset <= ( getMinimumSize().y / 2.0))
		fInset = NewInset;

	recalculateSizeLimits();

	updateIfNeeded();
}

void fTabItem::setParent( fObject *Parent)
{
	fObject::setParent( Parent);

	if( fSomeObject)
		fSomeObject->setParent( Parent);

	setDefaultEvents();
}

void fTabItem::setView( BView *NewView)
{
	fObject::setView( NewView);

	if( getActive())
	{
		if( fSomeObject)
			fSomeObject->setView( NewView);
	}
/*
	else
	{
		if( fSomeObject)
			fSomeObject->setView( NULL);
	}
*/
}

void fTabItem::mouseMoved( const fPoint &Point)
{
	fObject::mouseMoved( Point);

	if( fSomeObject)
		fSomeObject->mouseMoved( Point);
}

void fTabItem::attachedToWindow( const class fWindow *ParentWindow)
{
	fObject::attachedToWindow( ParentWindow);

	if( fSomeObject)
		fSomeObject->attachedToWindow( ParentWindow);
}

void fTabItem::detachedFromWindow( void)
{
	fObject::detachedFromWindow();

	if( fSomeObject)
		fSomeObject->detachedFromWindow();
}

void fTabItem::setEnabled( bool Enabled)
{
	fObject::setEnabled( Enabled);

	if( fSomeObject)
		fSomeObject->setEnabled( Enabled);
}

bool fTabItem::setWindowActivated( bool Activated)
{
	if( fObject::setWindowActivated( Activated) == false)
		return( false);

	if( fSomeObject)
		fSomeObject->setWindowActivated( Activated);

	return( true);
}

const fObject *fTabItem::containsPoint( const fPoint &Point) const
{
	#if FTABITEM_DEBUG > 3
	fprintf( stderr, "fTabItem::containsPoint()\n");
	#endif

	if( getActive())
		if( fSomeObject)
		{
			const fObject *TempObject = fSomeObject->containsPoint( Point);
	
			if( TempObject)
				return( TempObject);
		}	

	return( fObject::containsPoint( Point));

	#if FTABITEM_DEBUG > 3
	fprintf( stderr, "fTabItem::containsPoint() end\n");
	#endif

}

bool fTabItem::findObject( const fObject *ObjectPointer) const
{
	#if FTABITEM_DEBUG > 3
	fprintf( stderr, "fTabItem::findObject( const fObject *ObjectPointer)\n");
	#endif

	if( fObject::findObject( ObjectPointer))
		return( true);

	if( getActive())
		if( fSomeObject)
		{
			if( fSomeObject->findObject( ObjectPointer))
				return( true);
		}	

	return( false);

	#if FTABITEM_DEBUG > 3
	fprintf( stderr, "fTabItem::findObject( const fObject *ObjectPointer) end\n");
	#endif
}

const fObject *fTabItem::findObject( const char *ObjectName) const
{
	#if FTABITEM_DEBUG > 3
	fprintf( stderr, "fTabItem::findObject( const char *ObjectName)\n");
	#endif

	if( fSomeObject)
	{
		const fObject *TempObject = fSomeObject->findObject( ObjectName);

		if( TempObject)
			return( TempObject);
	}	

	return( fObject::findObject( ObjectName));

	#if FTABITEM_DEBUG > 3
	fprintf( stderr, "fTabItem::findObject( const char *ObjectName) end\n");
	#endif
}