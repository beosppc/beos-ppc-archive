// fBitmapButton.h

#ifndef fBitmapButton_h
#define fBitmapButton_h

#include "fButton.h"

#pragma export on

class fBitmapButton : public fButton
{
	private:
	
		fBitmapButton( const fBitmapButton &CopyObject);
		fBitmapButton &operator=( const fBitmapButton &CopyObject);
	
		ClassDeclaration( fBitmapButton);

	protected:

		const BBitmap *fPassiveBitmap;
		const BBitmap *fActiveBitmap;
		const BBitmap *fDisabledBitmap;

		virtual void recalculateSizeLimits( void);

	public:
	
		fBitmapButton( void);
		fBitmapButton( const BBitmap *PassiveBitmap, const BBitmap *ActiveBitmap, const BBitmap *DisabledBitmap = NULL);
		virtual ~fBitmapButton( void);

		virtual void setPassiveBitmap( const BBitmap *PassiveBitmap);
		virtual const BBitmap *getPassiveBitmap( void) const;

		virtual void setActiveBitmap( const BBitmap *ActiveBitmap);
		virtual const BBitmap *getActiveBitmap( void) const;

		virtual void setDisabledBitmap( const BBitmap *DisabledBitmap);
		virtual const BBitmap *getDisabledBitmap( void) const;

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif