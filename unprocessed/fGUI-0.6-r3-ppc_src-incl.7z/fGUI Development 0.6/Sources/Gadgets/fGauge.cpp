// fGauge.cpp

#include "fGauge.h"

#include "fFactory.h"

#include <stdio.h>
#include <Window.h>

#if DEBUG > 0
#define FGAUGE_DEBUG DEBUG
#endif
  
//#undef FGAUGE_DEBUG
#define FGAUGE_DEBUG -1

ClassDefinition( fGauge, fObject, "");

fGauge::fGauge( int32 TotalValue)
{
	#if FGAUGE_DEBUG > 0
	fprintf( stderr, "fGauge::fGauge( int32 TotalValue)\n");
	#endif

//	fGaugeColor = fColor( 0x33, 0x98, 0xff);
	fGaugeColor = fColor( 0x0, 0x0, 0xa0);

	totalValue	= TotalValue;
	currentValue	= 0;

	setVerticalWeight( 0.0);

	setMinimumSize( fPoint( 4.0, 4.0));
	setPreferredSize( fPoint( 100.0, 6.0));
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

	#if FGAUGE_DEBUG >  0
	fprintf( stderr, "fGauge::fGauge( int32 TotalValue) end\n");
	#endif
}

fGauge::fGauge( fColor InitColor, int32 TotalValue)
{
	#if FGAUGE_DEBUG > 0
	fprintf( stderr, "fGauge::fGauge( fColor InitColor, int32 TotalValue)\n");
	#endif

	fGaugeColor	= InitColor;

	totalValue	= TotalValue;
	currentValue	= 0;

	setVerticalWeight( 0.0);

	setMinimumSize( fPoint( 4.0, 4.0));
	setPreferredSize( fPoint( 100.0, 6.0));
	setMaximumSize( fPoint( F_NO_SIZE_LIMIT, F_NO_SIZE_LIMIT));

	#if FGAUGE_DEBUG > 0
	fprintf( stderr, "fGauge::fGauge( fColor InitColor, int32 TotalValue) end\n");
	#endif
}

fGauge::~fGauge( void)
{
	#if FGAUGE_DEBUG > 0
	fprintf( stderr, "fGauge::~fGauge()\n");
	#endif

	#if FGAUGE_DEBUG > 0
	fprintf( stderr, "fGauge::~fGauge() end\n");
	#endif
}

DoMethodBegin( fGauge)
	DoMethodDefinitionBegin( "BarHeight", setBarHeight, 1)
		DoMethodVariable( float, BarHeight)
		DoMethodVoidCall( setBarHeight)( BarHeight)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Values", setValues, 2)
		DoMethodVariable( float, CurrentValue)
		DoMethodVariable( float, TotalValue)
		DoMethodVoidCall( setValues)( CurrentValue, TotalValue)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "CurrentValue", setCurrentValue, 1)
		DoMethodVariable( float, CurrentValue)
		DoMethodVoidCall( setCurrentValue)( CurrentValue)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "TotalValue", setTotalValue, 1)
		DoMethodVariable( float, TotalValue)
		DoMethodVoidCall( setTotalValue)( TotalValue)
	DoMethodDefinitionEnd
DoMethodEnd( fObject)

void fGauge::recalculateSizeLimits( void)
{
	#if FGAUGE_DEBUG > 1
	fprintf( stderr, "fGauge::recalculateSizeLimits()\n");
	#endif

	#if FGAUGE_DEBUG > 1
	fprintf( stderr, "fGauge::recalculateSizeLimits() end\n");
	#endif
}

void fGauge::setBarHeight( float BarHeight)
{
	if( BarHeight < 0)
		return;

	setPreferredSize( fPoint( getPreferredSize().x, BarHeight + 2.0));

	updateIfNeeded();
}

void fGauge::setValues( int32 CurrentValue, int32 TotalValue)
{
	currentValue	= CurrentValue;
	totalValue	= TotalValue;
	
//	if( getView())
//		getView()->Invalidate( getObjectFrame());
	redraw( getObjectFrame());
}

void fGauge::setCurrentValue( int32 CurrentValue)
{
	currentValue = CurrentValue;

//	if( getView())
//		getView()->Invalidate( getObjectFrame());
	redraw( getObjectFrame());
}

void fGauge::setTotalValue( int32 TotalValue)
{
	totalValue = TotalValue;

//	if( getView())
//		getView()->Invalidate( getObjectFrame());
	redraw( getObjectFrame());
}

void fGauge::drawObject( const BRegion &ClippingRegion, bool /*FullUpdate*/) const
{
	#if FGAUGE_DEBUG > 1
	fprintf( stderr, "fGauge::Draw()\n");
	#endif

	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;

	#if FGAUGE_DEBUG > 2
	fprintf( stderr, "fGauge::draw() Minimum size: ");
	getMinimumSize().PrintToStream();
	fprintf( stderr, "fGauge::draw() Preferred size: ");
	getPreferredSize().PrintToStream();
	fprintf( stderr, "fGauge::draw() Maximum size: ");
	getMaximumSize().PrintToStream();
	fprintf( stderr, "fGauge::draw() Current size: ");
	getSize().PrintToStream();
	fprintf( stderr, "fGauge::draw() Drawing to: ");
	Frame.PrintToStream();
	#endif

    if( getView()->Window() == NULL)
        return;

    if( getView()->Window()->Lock() == false)
        return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	#if FGAUGE_DEBUG >= 0
	ShowObjectLayout;
	#endif

	getView()->SetHighColor( 0x00, 0x00, 0x00);

	getView()->StrokeLine( Frame.LeftBottom(),
						Frame.LeftTop());
	getView()->StrokeLine( Frame.RightTop());

	getView()->SetHighColor( 0xff, 0xff, 0xff);

	getView()->StrokeLine( Frame.RightBottom());
	getView()->StrokeLine( Frame.LeftBottom());

	// Fill gauge.

	int32 Percent;
	
	if( totalValue == 0)	Percent = 100;
	else					Percent = ( currentValue * 100 / totalValue);

	getView()->SetHighColor( 0xc0, 0xc0, 0xc0);
	getView()->FillRect( BRect( Frame.left  + 1, Frame.top	+ 1,
								   Frame.right - 1, Frame.bottom - 1));

	getView()->SetHighColor( fGaugeColor);
	getView()->FillRect( BRect( Frame.left + 1, Frame.top + 1,
							   Frame.left + ( Percent *  Frame.Width() / 100) - 1, Frame.bottom - 1));

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())    
		getView()->Window()->Unlock();

	#if FGAUGE_DEBUG > 1
	fprintf( stderr, "fGauge::Draw() end\n");
	#endif
}