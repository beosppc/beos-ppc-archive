// fSingleContainer.cpp

#include "fSingleContainer.h"
#include "fFactory.h"

#include "fEvents.h"

#if DEBUG > 0
#define FTABITEM_DEBUG DEBUG
#endif

//#undef FTABITEM_DEBUG
//#define FTABITEM_DEBUG 2

VirtualClassDefinition( fSingleContainer, fObject);

fSingleContainer::fSingleContainer( fObject *NewObject)
{
	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fSingleContainer::fSingleContainer()\n");
	#endif

	fSomeObject = NULL;
	setObject( NewObject);

	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fSingleContainer::fSingleContainer() end\n");
	#endif
}

fSingleContainer::~fSingleContainer( void)
{
	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fSingleContainer::~fSingleContainer()\n");
	#endif

	delete fSomeObject;

	#if FTABITEM_DEBUG > 0
	fprintf( stderr, "fSingleContainer::~fSingleContainer() end\n");
	#endif
}

DoMethodBegin( fSingleContainer)
	DoMethodDefinitionBegin( "Child", setObject, 1)
		DoMethodVariableCast( fObject *, fClassInfo *, NewObject)
		DoMethodVoidCall( setObject)( NewObject)
	DoMethodDefinitionEnd
DoMethodEnd( fClassInfo)

void fSingleContainer::setObject( fObject *NewObject)
{
	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fSingleContainer::addObject()\n");
	#endif

	if( fSomeObject)
		if( fParentWindow)
			fSomeObject->detachedFromWindow();

	delete fSomeObject;
	fSomeObject = NewObject;
	
	if( fSomeObject)
	{
		fSomeObject->setParent( this);
		fSomeObject->setEnabled( getEnabled());
		fSomeObject->setView( getView());

		// if the object is attached to a window, tell the new child object
		if( fParentWindow)
			NewObject->attachedToWindow( fParentWindow);
	}

	updateIfNeeded();

	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fSingleContainer::addObject() end\n");
	#endif
}

const fObject *fSingleContainer::getObject( void)
{
	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fSingleContainer::getObject()\n");
	#endif

	return( fSomeObject);

	#if FTABITEM_DEBUG > 1
	fprintf( stderr, "fSingleContainer::getObject() end\n");
	#endif
}

void fSingleContainer::setView( BView *NewView)
{
	fObject::setView( NewView);

	if( fSomeObject)
		fSomeObject->setView( NewView);
}

void fSingleContainer::mouseMoved( const fPoint &Point)
{
	fObject::mouseMoved( Point);

	if( fSomeObject)
		fSomeObject->mouseMoved( Point);
}

void fSingleContainer::setSize( const fPoint &NewSize)
{
	fObject::setSize( NewSize);

	fPoint Borders( getHorizontalBorder(), getVerticalBorder());

	fPoint Size = NewSize;

	Size -= Borders;
	Size -= Borders;

	if( fSomeObject)
	{
		fSomeObject->setSize( Size);
		fSomeObject->setPosition( getPosition() + Borders);
	}
}

void fSingleContainer::setPosition( const fPoint &NewPosition)
{
	fPoint delta = NewPosition - getPosition();

	fObject::setPosition( NewPosition);

	if( fSomeObject)
		fSomeObject->setPosition( fSomeObject->getPosition() + delta);
}

void fSingleContainer::attachedToWindow( const class fWindow *ParentWindow)
{
	fObject::attachedToWindow( ParentWindow);

	if( fSomeObject)
		fSomeObject->attachedToWindow( ParentWindow);
}

void fSingleContainer::detachedFromWindow( void)
{
	fObject::detachedFromWindow();

	if( fSomeObject)
		fSomeObject->detachedFromWindow();
}

void fSingleContainer::setEnabled( bool Enabled)
{
	fObject::setEnabled( Enabled);

	if( fSomeObject)
		fSomeObject->setEnabled( Enabled);
}

bool fSingleContainer::setWindowActivated( bool Activated)
{
	if( fObject::setWindowActivated( Activated) == false)
		return( false);

	if( fSomeObject)
		fSomeObject->setWindowActivated( Activated);

	return( true);
}

const fObject *fSingleContainer::containsPoint( const fPoint &Point) const
{
	if( fSomeObject)
	{
		const fObject *TempObject = fSomeObject->containsPoint( Point);
	
		if( TempObject)
			return( TempObject);
	}	

	return( fObject::containsPoint( Point));
}

bool fSingleContainer::findObject( const fObject *ObjectPointer) const
{
	if( fObject::findObject( ObjectPointer))
		return( true);

	if( fSomeObject)
		if( fSomeObject->findObject( ObjectPointer))
			return( true);

	return( false);
}

const fObject *fSingleContainer::findObject( const char *ObjectName) const
{
	const fObject *TempObject = fObject::findObject( ObjectName);

	if( TempObject)
		return( TempObject);

	if( fSomeObject)
	{
		TempObject = fSomeObject->findObject( ObjectName);

		if( TempObject)
			return( TempObject);
	}

	return( NULL);
}

void fSingleContainer::drawObject( const BRegion &ClippingRegion, bool FullUpdate) const
{
	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
		return;

    if( getView()->Window() == NULL)
        return;

    if( getView()->Window()->Lock() == false)
        return;

	BRegion FillRegion;
	FillRegion.Set( Frame);
	
	FillRegion.IntersectWith( &ClippingRegion);

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRegion( &FillRegion, B_SOLID_LOW);

	// draw object
	if( fSomeObject)
		if( ClippingRegion.Intersects( fSomeObject->getObjectFrame()))
		{
			if( FullUpdate)
				fSomeObject->setClippingRegion( ClippingRegion);
			fSomeObject->drawObject( ClippingRegion, FullUpdate);
		}

	if( getView()->Window())    
		getView()->Window()->Unlock();

	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::draw() end\n");
	#endif
}
