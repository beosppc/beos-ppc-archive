// fHorizontalScrollBar.h

#ifndef fHorizontalScrollBar_h
#define fHorizontalScrollBar_h

#include "fScrollBar.h"

#pragma export on

class fHorizontalScrollBar : public fScrollBar
{
	private:

		fHorizontalScrollBar( const fHorizontalScrollBar &CopyObject);
		fHorizontalScrollBar &operator=( const fHorizontalScrollBar &CopyObject);
	
		VirtualClassDeclaration( fHorizontalScrollBar);

		enum { F_SINGLE_ARROW_LEFT,
				F_SINGLE_ARROW_RIGHT,
				F_DOUBLE_ARROW_LEFT,
				F_DOUBLE_ARROW_RIGHT };

	protected:

	public:

		fHorizontalScrollBar( void);
		virtual ~fHorizontalScrollBar( void);
		
		virtual void mouseDown( MouseButton Button, const fPoint &Point, int32 NumClicks);
		virtual void mouseUp( MouseButton Button, const fPoint &Point, int32 NumClicks);

		virtual void mouseMoved( const fPoint &Point);
};

#pragma export off

#endif