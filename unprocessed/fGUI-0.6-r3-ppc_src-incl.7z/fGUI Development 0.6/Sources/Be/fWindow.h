// fWindow.h

#ifndef fWindow_h
#define fWindow_h

#include <Window.h>
#include <View.h>
#include <MessageFilter.h>

#include "fClassInfo.h"
#include "fEvents.h"

//#include "fHorizontalGroup.h"
#include "fSingleContainer.h"

#pragma export on

class fWindow : public BMessageFilter, public fClassInfo
{
	private :

		fWindow( const fWindow &CopyObject);
		fWindow &operator=( const fWindow &CopyObject);

		ClassDeclaration( fWindow);

	protected: // fView class
		class fView : public BView, public fSingleContainer
		{
			private:
		
				fView( const fView &CopyObject);
				fView &operator=( const fView &CopyObject);
		
			protected:

				virtual void AttachedToWindow( void);
				virtual void Draw( BRect updateRect);
		
				virtual void updateIfNeeded( void);

				fPoint fPreviousSize;

			public :
		
				fView( fObject *Object = NULL);
				virtual ~fView( void);
				
//				void setObject( fObject *Object);

				virtual void recalculateSizeLimits( void);

				virtual fClassInfo *createInstance( void) const;

				virtual const char * const getClassName( void) const;
				virtual const char * const getBaseClassName( void) const;

				virtual bool isOfClass( const char *ClassName) const;
				virtual bool isOfType( const char *ClassName) const;

				virtual void FrameResized( float width, float height);
		};

		virtual void initializeObject( void);

		bigtime_t	 fMouseClickInterval;

		fObject		*fPrimaryDownObject;
		bigtime_t	 fPrimaryDownTime;
		int32		 fPrimaryDownCount;
		bool		 fPrimaryDown;

		fObject		*fSecondaryDownObject;
		bigtime_t	 fSecondaryDownTime;
		int32		 fSecondaryDownCount;
		bool		 fSecondaryDown;

		fObject		*fTertiaryDownObject;
		bigtime_t	 fTertiaryDownTime;
		int32		 fTertiaryDownCount;
		bool		 fTertiaryDown;

		fObject		*fMouseOverObject;

		fObject		*fFocusObject;

		fView		*View;
		BWindow		*Window;

		char		*fWindowTitle;
		window_type	 fWindowType;
		window_look	 fWindowLook;
		window_feel	 fWindowFeel;
		int32		 fWindowFlags;

		char		*fWindowName;

		class fButton	*fDefaultButton;

		virtual filter_result Filter( BMessage *Message, BHandler **Handler);

		virtual void setView( fWindow::fView *View);
		virtual void handleMouseEvents( BMessage *Message);
		virtual void mouseMoved( const fPoint &Point);

		virtual bool handleWindowMessages( int32 Action, BMessage *Message);

		BWindow *getWindow( void) const;

		friend class fApplication;
		friend class fEventRoute;

		DoMethodDeclaration;

	public :

		fWindow( void);
		fWindow( fObject *Object, const char *Title = "Unnamed",
					window_type Type = B_TITLED_WINDOW, uint32 Flags = 0);
		fWindow( fObject *Object, const char *Title,
					window_look WindowLook, window_feel WindowFeel, uint32 Flags);
		fWindow( const char *Title, window_type Type = B_TITLED_WINDOW, uint32 Flags = 0);
		fWindow( const char *Title, window_look WindowLook, window_feel WindowFeel, uint32 Flags);
		virtual ~fWindow( void);

		virtual bool Quit(void);
		virtual bool QuitRequested(void);

  		virtual filter_result MessageReceived( BMessage *Message);

		virtual void setWindowTitle( const char *WindowTitle);
		const char *getWindowTitle( void) const;
		
		virtual void setWindowType( window_type WindowType);
		window_type getWindowType( void) const;
		
		virtual void setWindowLook( window_look WindowLook);
		window_look getWindowLook( void) const;
		
		virtual void setWindowFeel( window_feel WindowFeel);
		window_feel getWindowFeel( void) const;
		
		virtual void setWindowFlags( int32 WindowFlags);
		int32 getWindowFlags( void) const;
		
		virtual void setWindowName( const char *WindowName);
		const char *getWindowName( void) const;
		
		virtual void setObject( fObject *Object);
		virtual void removeObject( void);

		virtual void setDefaultButton( fButton *Button);
		fButton *getDefaultButton( void) const;

		virtual void showWindow( void);
		virtual void hideWindow( void);
		
		void moveWindowTo( fPoint Location);
		void moveWindowBy( fPoint Offset);

		const fObject *findObject( const fObject *ObjectPointer) const;
		const fObject *findObject( const char *ObjectName) const;
};

#pragma export off

#endif
