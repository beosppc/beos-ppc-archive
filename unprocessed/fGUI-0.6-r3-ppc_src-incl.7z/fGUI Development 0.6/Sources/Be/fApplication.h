// fApplication.h

#ifndef fApplication_h
#define fApplication_h

#include <Application.h>
#include <List.h>

#include "fObject.h"

#pragma export on

class fApplication : public BApplication
{
	private:
	
		fApplication( const fApplication &CopyObject);
		fApplication &operator=( const fApplication &CopyObject);

		static int32 startMouseThread( void *Data);
		
		int32 mouseThread( void);

		bool 		 fRunning;

		// helper method for loading add-ons
		void loadAddOn( const BPath &AddOnPath) const;

	protected:

		BList	 	 fWindows;

	public:
	
		fApplication( const char *Signature);
		virtual ~fApplication( void);

		static fApplication * const getApplication( void);

		virtual void addWindow( const class fWindow *Window);
		virtual bool removeWindow( class fWindow *Window);

 		virtual const BLooper *locateObject( const fObject *ObjectPointer) const;
		virtual const BLooper *locateObject( const char *ObjectName) const;

		virtual void MessageReceived( BMessage *Message);
};

#pragma export off

#endif