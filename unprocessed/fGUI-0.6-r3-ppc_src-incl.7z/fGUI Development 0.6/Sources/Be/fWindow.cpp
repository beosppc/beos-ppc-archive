// fWindow.cpp

#include "fWindow.h"
#include "fFactory.h"

#include "fButton.h"

#if DEBUG > 0
#define FWINDOW_DEBUG DEBUG
#endif

//#undef FWINDOW_DEBUG
//#define FWINDOW_DEBUG 3

fWindow GlobalfWindow( fClassInfo::fClassInfoDummy1());

fWindow::fWindow( fClassInfoDummy1)
		: BMessageFilter( B_ANY_DELIVERY, B_ANY_SOURCE),
			fClassInfo( fClassInfoDummy2())
{
	fFactory *Factory = fFactory::getFactory();

	Factory->registerClass( this, "");
}

fWindow::fWindow( fClassInfoDummy2)
		: BMessageFilter( B_ANY_DELIVERY, B_ANY_SOURCE),
			fClassInfo( fClassInfoDummy2())
{
}

fWindow::fWindow( void)
		: BMessageFilter( B_ANY_DELIVERY, B_ANY_SOURCE)
{
	initializeObject();

	setView( new fView());
}

fWindow::fWindow( fObject *Object, const char *WindowTitle, window_type WindowType, uint32 WindowFlags)
		: BMessageFilter( B_ANY_DELIVERY, B_ANY_SOURCE)
{
	initializeObject();

	setWindowTitle( WindowTitle);
	fWindowType		= WindowType;
	fWindowFlags	= WindowFlags;

	setView( new fView( Object));
}

fWindow::fWindow( fObject *Object, const char *WindowTitle, window_look WindowLook,
					window_feel WindowFeel, uint32 WindowFlags)
		: BMessageFilter( B_ANY_DELIVERY, B_ANY_SOURCE)
{
	initializeObject();

	setWindowTitle( WindowTitle);
	fWindowType		= static_cast<window_type>( -1);
	fWindowLook		= WindowLook;
	fWindowFeel		= WindowFeel;
	fWindowFlags	= WindowFlags;

	setView( new fView( Object));
}

fWindow::fWindow( const char *WindowTitle, window_type WindowType, uint32 WindowFlags)
		: BMessageFilter( B_ANY_DELIVERY, B_ANY_SOURCE)
{
	initializeObject();

	setWindowTitle( WindowTitle);
	fWindowType		= WindowType;
	fWindowFlags	= WindowFlags;

	setView( new fView());
}

fWindow::fWindow( const char *WindowTitle, window_look WindowLook, window_feel WindowFeel, uint32 WindowFlags)
		: BMessageFilter( B_ANY_DELIVERY, B_ANY_SOURCE)
{
	initializeObject();

	setWindowTitle( WindowTitle);
	fWindowType		= static_cast<window_type>( -1);
	fWindowLook		= WindowLook;
	fWindowFeel		= WindowFeel;
	fWindowFlags	= WindowFlags;

	setView( new fView());
}

void fWindow::initializeObject( void)
{
	fApplication::getApplication()->addWindow( this);

	if( get_click_speed( &fMouseClickInterval) < B_OK)
		fMouseClickInterval = 300000;

	fPrimaryDownObject		= NULL;
	fPrimaryDownTime		= 0;
	fPrimaryDownCount		= 0;
	fPrimaryDown			= false;
		
	fSecondaryDownObject	= NULL;
	fSecondaryDownTime		= 0;
	fSecondaryDownCount		= 0;
	fSecondaryDown			= false;
	
	fTertiaryDownObject		= NULL;
	fTertiaryDownTime		= 0;
	fTertiaryDownCount		= 0;
	fTertiaryDown			= false;

	fMouseOverObject		= NULL;

	fFocusObject			= NULL;

	View					= NULL;
	Window					= NULL;

	fWindowTitle			= NULL;
	fWindowType				= B_TITLED_WINDOW;
	fWindowFlags			= 0;

	fWindowName				= NULL;

	fDefaultButton			= NULL;
}

fWindow::~fWindow( void)
{
	#if FWINDOW_DEBUG > 1
	fprintf( stderr, "fWindow::~fWindow()\n");
	#endif

	if( fApplication::getApplication())
		fApplication::getApplication()->removeWindow( this);

	#if FWINDOW_DEBUG > 1
	fprintf( stderr, "fWindow::~fWindow() end\n");
	#endif
}

DoMethodBegin( fWindow)
	DoMethodDefinitionBegin( "Title", setWindowTitle, 1)
		DoMethodVariable( char *, WindowTitle)
		DoMethodVoidCall( setWindowTitle)( WindowTitle)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Type", setWindowType, 1)
		DoMethodVariableCast( window_type, int32, WindowType)
		DoMethodVoidCall( setWindowType)( WindowType)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Look", setWindowLook, 1)
		DoMethodVariableCast( window_look, int32, WindowLook)
		DoMethodVoidCall( setWindowLook)( WindowLook)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Feel", setWindowFeel, 1)
		DoMethodVariableCast( window_feel, int32, WindowFeel)
		DoMethodVoidCall( setWindowFeel)( WindowFeel)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Flags", setWindowFlags, 1)
		DoMethodVariable( int32, WindowFlags)
		DoMethodVoidCall( setWindowFlags)( WindowFlags)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Name", setWindowName, 1)
		DoMethodVariable( char *, WindowName)
		DoMethodVoidCall( setWindowName)( WindowName)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "Object", setObject, 1)
		DoMethodVariableCast( fObject *, fClassInfo *, Object)
		DoMethodVoidCall( setObject)( Object)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "Show", showWindow, 0)
		DoMethodVoidCall( showWindow)()
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "Hide", hideWindow, 0)
		DoMethodVoidCall( hideWindow)()
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "MoveTo", moveWindowTo, 2)
		DoMethodVariable( double, x)
		DoMethodVariable( double, y)
		DoMethodVoidCall( moveWindowTo)( fPoint( x, y))
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "MoveBy", moveWindowBy, 2)
		DoMethodVariable( double, x)
		DoMethodVariable( double, y)
		DoMethodVoidCall( moveWindowBy)( fPoint( x, y))
	DoMethodDefinitionEnd
DoMethodEnd( fClassInfo)

bool fWindow::Quit( void)
{
	if( Window)
	{
		// Workaround
		View = NULL;

		if( Window->PostMessage( B_QUIT_REQUESTED) == B_OK)
			return( true);
	}

	return( false);	
}

bool fWindow::QuitRequested( void)
{
	return( true);
}

filter_result fWindow::MessageReceived( BMessage */*Message*/)
{
	return( B_DISPATCH_MESSAGE);
}

BWindow *fWindow::getWindow( void) const
{
	return( Window);
}

void fWindow::setWindowTitle( const char *WindowTitle)
{
	delete [] fWindowTitle;
	
	if( WindowTitle)
	{
		fWindowTitle = new char[ strlen( WindowTitle) + 1];
		strcpy( fWindowTitle, WindowTitle);
	
		if( Window)
			Window->SetTitle( WindowTitle);
	}
	else
		fWindowTitle = NULL;
}

const char *fWindow::getWindowTitle( void) const
{
	return( fWindowTitle);
}

void fWindow::setWindowType( window_type WindowType)
{
	if( Window)
		Window->SetType( WindowType);

	fWindowType = WindowType;
}

window_type fWindow::getWindowType( void) const
{
	return( fWindowType);
}

void fWindow::setWindowLook( window_look WindowLook)
{
	fWindowType = static_cast<window_type>( -1);

	if( Window)
		Window->SetLook( WindowLook);

	fWindowLook = WindowLook;
}

window_look fWindow::getWindowLook( void) const
{
	return( fWindowLook);
}

void fWindow::setWindowFeel( window_feel WindowFeel)
{
	fWindowType = static_cast<window_type>( -1);

	if( Window)
		Window->SetFeel( WindowFeel);

	fWindowFeel = WindowFeel;
}

window_feel fWindow::getWindowFeel( void) const
{
	return( fWindowFeel);
}

void fWindow::setWindowFlags( int32 WindowFlags)
{
	if( Window)
		Window->SetFlags( WindowFlags);

	fWindowFlags = WindowFlags;
}
		
int32 fWindow::getWindowFlags( void) const
{
	return( fWindowFlags);
}

void fWindow::setWindowName( const char *WindowName)
{
	delete [] fWindowName;
	
	if( fWindowName)
	{
		fWindowTitle = new char[ strlen( WindowName) + 1];
		strcpy( fWindowName, WindowName);
	}
	else
		fWindowName = NULL;
}

const char *fWindow::getWindowName( void) const
{
	if( fWindowName)
		return( fWindowName);
	else
		return( fWindowTitle);
}

void fWindow::setObject( fObject *Object)
{
	if( View == NULL)
		setView( new fView( Object));
	else
		View->setObject( Object);
}

void fWindow::removeObject( void)
{
	if( View != NULL)
		View->setObject( NULL);	
}

filter_result fWindow::Filter( BMessage *Message, BHandler **/*Handler*/)
{
	#if FWINDOW_DEBUG > 6
	fprintf( stderr, "fWindow::Filter()\n");
	#endif

	switch( Message->what)
	{
		case F_MOUSE_THREAD_EVENT:
			handleMouseEvents( Message);
			return( B_SKIP_MESSAGE);
			break;

		case B_WINDOW_ACTIVATED:
			bool WindowActive = Message->FindBool( "active");
			View->setWindowActivated( WindowActive);
			break;

		case B_QUIT_REQUESTED:
			if( QuitRequested() == false)
				return( B_SKIP_MESSAGE);

			#if FWINDOW_DEBUG > 1
			fprintf( stderr, "fWindow::Filter() B_QUIT_REQUESTED\n");
			#endif

			break;

		case B_WINDOW_RESIZED:
//			Message->PrintToStream();
			int32 width = Message->FindInt32( "width");
			int32 height = Message->FindInt32( "height");
			
			if( View)
				View->FrameResized( width, height);
			return( B_SKIP_MESSAGE);
			break;

		case B_KEY_DOWN:
			#if FWINDOW_DEBUG > 3
			fprintf( stderr, "fWindow::Filter() B_KEY_DOWN\n");
			Message->PrintToStream();
			#endif
			
			if( View->IsFocus())
			{
				const char *bytes;
				
				if( Message->FindString( "bytes", &bytes) < B_OK)
					return( B_SKIP_MESSAGE);

				// default button handling goes here...
				if(( bytes[ 0] == B_ENTER) && fDefaultButton)
					fDefaultButton->processEvent( F_KEY_DOWN, Message);
				else if( fFocusObject)
					{
//						fprintf( stderr, "fWindow::Filter() calling processEvent\n");
						fFocusObject->processEvent( F_KEY_DOWN, Message);
					}
//				return( B_SKIP_MESSAGE);
			}
			break;

		case B_KEY_UP:
			if( View->IsFocus())
			{
				const char *bytes;
				
				if( Message->FindString( "bytes", &bytes) < B_OK)
					return( B_SKIP_MESSAGE);

				// default button handling goes here...
				if(( bytes[ 0] == B_ENTER) && fDefaultButton)
					fDefaultButton->processEvent( F_KEY_UP, Message);
				else if( fFocusObject)
						fFocusObject->processEvent( F_KEY_UP, Message);
			
				return( B_SKIP_MESSAGE);
			}
			break;

		case FGUI_EVENT:
		{
			#if FWINDOW_DEBUG > 2
			fprintf( stderr, "fWindow::Filter() Got FGUI_EVENT:\n");
			Message->PrintToStream();
			#endif

			int32 fAction	= 0;
			
			if( Message->FindInt32( "fAction", &fAction) < B_OK)
			{
				#if FVIEW_DEBUG > 3
				fprintf( stderr, "fWindow::Filter() Error getting fAction !\n");
				#endif
				
				return( B_DISPATCH_MESSAGE);
			}

			const char *TargetName = Message->FindString( "fTargetName");
			
			if( TargetName != NULL)
			{
				fObject *TargetPointer = const_cast<fObject *>( findObject( TargetName));

				if( TargetPointer)
				{
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::Filter() Found target, delivering message.\n");
					#endif

					TargetPointer->processEvent( fAction, Message);
					return( B_SKIP_MESSAGE);
				}
				
				if( strcmp( TargetName, getWindowTitle()) == 0)
				{
					if( handleWindowMessages( fAction, Message))
						return( B_SKIP_MESSAGE);
				}
			}
			else
			{
				fObject *TargetPointer;
				
				if( Message->FindPointer( "fTargetPointer", &TargetPointer) == B_OK)
				{
					TargetPointer->processEvent( fAction, Message);
					return( B_SKIP_MESSAGE);
				}
			}
			
			#if FWINDOW_DEBUG > 2
			fprintf( stderr, "fWindow::Filter() Couldn't find object, calling MessageReceived()\n");
			#endif

			return( MessageReceived( Message));
		}
		break;

		default:
			// only non-system messages go to MessageReceived...
			if( Message->IsSystem() == false)
				return( MessageReceived( Message));
			break;
	}

	// default is to dispatch the message to the window
	return( B_DISPATCH_MESSAGE);

	#if FWINDOW_DEBUG > 6
	fprintf( stderr, "fWindow::Filter()\n");
	#endif
}

bool fWindow::handleWindowMessages( int32 Action, BMessage *Message)
{
//	fprintf( stderr, "fWindow::handleWindowMessages() Message for the Window...\n");
	
	switch( Action)
	{
		case F_REQUEST_GET_FOCUS:
		{
			const char *SourceName = Message->FindString( "fSourceName");
			
			fObject *SourcePointer = NULL;
	
			if( SourceName)
				SourcePointer = const_cast<fObject *>( findObject( SourceName));
			else
				Message->FindPointer( "fSourcePointer", &SourcePointer);
	
				BMessage NewMessage;
				NewMessage.AddPointer( "fSourcePointer", SourcePointer);
				NewMessage.AddPointer( "fTargetPointer", SourcePointer);
				NewMessage.AddInt64( "fTimeStamp", system_time());
				NewMessage.AddInt32( "fEvent", F_REQUEST_GET_FOCUS);

			if( fFocusObject != SourcePointer)
			{
				if( fFocusObject)
				{
					BMessage Copy( NewMessage);
					Copy.AddInt32( "fAction", F_LOST_FOCUS);
					fFocusObject->processEvent( F_LOST_FOCUS, &Copy);
				}
	
				fFocusObject = SourcePointer;
	
				if( fFocusObject)
				{
//					fprintf( stderr, "fWindow::handleWindowMessages() Giving focus to object (%s).\n", fFocusObject->getClassName());
					NewMessage.AddInt32( "fAction", F_GOT_FOCUS);
					fFocusObject->processEvent( F_GOT_FOCUS, &NewMessage);
				}
			}
			
			return( true);
		}
		break;
		
		case F_REQUEST_LOSE_FOCUS:
		{
			if( fFocusObject)
				fFocusObject->processEvent( F_LOST_FOCUS, Message);
			
			fFocusObject = NULL;
			
			return( true);
		}
		break;

		case F_SHOW_WINDOW:
			if( Window && Window->IsHidden())
				Window->Show();
			break;

		case F_HIDE_WINDOW:
			if( Window && !Window->IsHidden())
				Window->Hide();
			break;
	}
	
	return( false);
}

void fWindow::setView( fWindow::fView *NewView)
{
	#if FWINDOW_DEBUG > 2
	fprintf( stderr, "fWindow::setView()\n");
	#endif

	if( NewView == NULL)
		return;

	View = NewView;

	if( fWindowType != static_cast<window_type>( -1))
		Window = new BWindow( BRect( 0.0, 0.0, 1.0, 1.0), fWindowTitle, fWindowType, fWindowFlags);
	else
		Window = new BWindow( BRect( 0.0, 0.0, 1.0, 1.0), fWindowTitle, fWindowLook, fWindowFeel, fWindowFlags | B_OUTLINE_RESIZE);
	
	Window->AddCommonFilter( this);

	BPoint minSize	= View->getMinimumSize();
	BPoint prefSize	= View->getPreferredSize();
	BPoint maxSize	= View->getMaximumSize();

	Window->SetSizeLimits((float) ((int32) minSize.x), (float) ((int32) maxSize.x),
						(float) ((int32) minSize.y), (float) ((int32) maxSize.y));

	Window->AddChild( View);
	View->attachedToWindow( this);

	Window->ResizeTo( prefSize.x, prefSize.y);

	#if FWINDOW_DEBUG > 2
	fprintf( stderr, "fWindow::setView() Resizing window to: ");
	prefSize.PrintToStream();
	#endif

	#if FWINDOW_DEBUG > 2
	fprintf( stderr, "fWindow::setView() end\n");
	#endif
}

void fWindow::showWindow( void)
{
	Window->Show();
}

void fWindow::hideWindow( void)
{
	Window->Hide();
}

void fWindow::moveWindowTo( fPoint Location)
{
	Window->MoveTo( Location);
}

void fWindow::moveWindowBy( fPoint Offset)
{
	Window->MoveBy( Offset.x, Offset.y);
}

const fObject *fWindow::findObject( const fObject *ObjectPointer) const
{
	#if FWINDOW_DEBUG > 2
	fprintf( stderr, "fWindow::findObject( const fObject *ObjectPointer)\n");
	#endif

	bool result = false;
	
	if( View)
	{
		Window->Lock();
		result = View->findObject( ObjectPointer);
		Window->Unlock();
	}

	if( result)
		return( ObjectPointer);

	return( NULL);

	#if FWINDOW_DEBUG > 2
	fprintf( stderr, "fWindow::findObject( const fObject *ObjectPointer) end\n");
	#endif
}

const fObject *fWindow::findObject( const char *ObjectName) const
{
	#if FWINDOW_DEBUG > 2
	fprintf( stderr, "fWindow::findObject( const char *ObjectName)\n");
	#endif

	const fObject *result = NULL;

	if( View)
	{
		Window->Lock();
		result = View->findObject( ObjectName);
		Window->Unlock();
	}
	
	#if FWINDOW_DEBUG > 2
	fprintf( stderr, "fWindow::findObject( const char *ObjectName) end\n");
	#endif

	return( result);
}

void fWindow::setDefaultButton( fButton *Button)
{
	if( fDefaultButton)
		fDefaultButton->setDefaultButton( false);

	fDefaultButton = Button;

	if( fDefaultButton)
		fDefaultButton->setDefaultButton( true);
}

fButton *fWindow::getDefaultButton( void) const
{
	return( fDefaultButton);
}
/*
void fWindow::pulse( void)
{
	#if FWINDOW_DEBUG > 6
	fprintf( stderr, "fWindow::pulse()\n");
	#endif

	// Workaround...
	if( View == NULL)
		return;

	BPoint Point;
	uint32 buttons;
		
	View->GetMouse( &Point, &buttons, false);

	// Check if mouse has moved.
	if( Point != fLastMousePosition)
	{
		fLastMousePosition = Point;
		mouseMoved( Point);
	}

	if( Window->IsActive())
	{
		// Check if mouse buttons went up.
		checkMouseUp( Point, buttons);

		// Check if mouse buttons went down.
		checkMouseDown( Point, buttons);
	}

	#if FWINDOW_DEBUG > 6
	fprintf( stderr, "fWindow::pulse() end\n");
	#endif
}
*/
void fWindow::handleMouseEvents( BMessage *Message)
{
	int32 Item = 0;
	int32 Event;

	BPoint Point;
	int32 Workspace = -1;
	int64 systemtime;

	bool SameWorkspace = false;

	if( Message->FindInt64( "fTimeStamp", &systemtime) < B_OK)
		return;

	if( Message->FindPoint( "fLocation", &Point) < B_OK)
		return;

	Window->ConvertFromScreen( &Point);

	fObject *MouseObject = const_cast<fObject *>( View->containsPoint( Point));

	// is window in the same workspace as the mouse ?
	// this is important for the mouse handling:
	// a mouse down/moved is ignored, a mouse up is handled
	// but it is made sure that the point is not within the window
	if( Message->FindInt32( "fWorkspace", &Workspace) < B_OK)
		return;

	if(( 1 << Workspace) & Window->Workspaces())
		SameWorkspace = true;
	else
		Point = fPoint( -1.0, -1.0);

	Message->ReplacePoint( "fLocation", Point);

	while(( Event = Message->FindInt32( "fEvent", Item++)) != 0)
	{
		switch( Event)
		{
			case F_PRIMARY_MOUSE_DOWN:
			{
				if( SameWorkspace == false)
					break;

				if( MouseObject == NULL)
					break;

				if( Window->IsActive() == false)
					break;

				// is the time in the interval for a multiclick or in another object ?
				if(( systemtime - fPrimaryDownTime > fMouseClickInterval) || ( fPrimaryDownObject != MouseObject))
				{
					// no, set clickcount to 1
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Last click too far away, resetting counter to 1 !\n");
					#endif
		
					fPrimaryDownCount = 1;
				}
				else
				{
					// yes, increase clickcount
					fPrimaryDownCount++;
		
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Primary multiclick: %d!\n", fPrimaryDownCount);
					#endif
				}

				// remember time
				fPrimaryDownTime = systemtime;

				#if FWINDOW_DEBUG > 2
				fprintf( stderr, "fWindow::checkMouseDown() Primary mouse click, calling processEvent()\n");
				#endif
			
				fPrimaryDownObject = MouseObject;
	
				BMessage Copy( Message);
				Copy.AddInt32( "fAction", F_PRIMARY_MOUSE_DOWN);
				Copy.AddInt32( "fClicks", fPrimaryDownCount);

				fPrimaryDownObject->processEvent( F_PRIMARY_MOUSE_DOWN, &Copy);
			}
			break;

			case F_SECONDARY_MOUSE_DOWN:
			{
				if( SameWorkspace == false)
					break;

				if( MouseObject == NULL)
					break;

				if( Window->IsActive() == false)
					break;

				// is the time in the interval for a multiclick or in another object ?
				if(( systemtime - fSecondaryDownTime > fMouseClickInterval) || ( fSecondaryDownObject != MouseObject))
				{
					// no, set clickcount to 1
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Last click too far away, resetting counter to 1 !\n");
					#endif
		
					fSecondaryDownCount = 1;
				}
				else
				{
					// yes, increase clickcount
					fSecondaryDownCount++;
		
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Secondary multiclick: %d!\n", fSecondaryDownCount);
					#endif
				}
		
				// remember time
				fSecondaryDownTime = systemtime;
		
				fSecondaryDownObject = MouseObject;
		
				BMessage Copy( Message);
				Copy.AddInt32( "fAction", F_SECONDARY_MOUSE_DOWN);
				Copy.AddInt32( "fClicks", fSecondaryDownCount);
		
				fSecondaryDownObject->processEvent( F_SECONDARY_MOUSE_DOWN, &Copy);
			}
			break;

			case F_TERTIARY_MOUSE_DOWN:
			{
				if( SameWorkspace == false)
					break;

				if( MouseObject == NULL)
					break;

				if( Window->IsActive() == false)
					break;

				// is the time in the interval for a multiclick or in another object ?
				if(( systemtime - fTertiaryDownTime > fMouseClickInterval) || ( fTertiaryDownObject != MouseObject))
				{
					// no, set clickcount to 1
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Last click too far away, resetting counter to 1 !\n");
					#endif
		
					fTertiaryDownCount = 1;
				}
				else
				{
					// yes, increase clickcount
					fTertiaryDownCount++;
		
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Tertiary multiclick: %d!\n", fTertiaryDownCount);
					#endif
				}
		
				// remember time
				fTertiaryDownTime = systemtime;
		
				fTertiaryDownObject = MouseObject;
		
				BMessage Copy( Message);
				Copy.AddInt32( "fAction", F_TERTIARY_MOUSE_DOWN);
				Copy.AddInt32( "fClicks", fTertiaryDownCount);
		
				fTertiaryDownObject->processEvent( F_TERTIARY_MOUSE_DOWN, &Copy);
			}

			case F_PRIMARY_MOUSE_UP:
			{
				// tell object in which button was pressed that the button was released.
				if( fPrimaryDownObject)
				{
					BMessage Copy( Message);
					Copy.AddInt32( "fAction", F_PRIMARY_MOUSE_UP);
					Copy.AddInt32( "fClicks", fPrimaryDownCount);
	
					fPrimaryDownObject->processEvent( F_PRIMARY_MOUSE_UP, &Copy);
				}
	
				// tell object in which button was released that the button was released.
				// (only if != object in which it was pressed [see above]).
				if( MouseObject && ( MouseObject != fPrimaryDownObject))
				{
					BMessage Copy( Message);
					Copy.AddInt32( "fAction", F_PRIMARY_MOUSE_UP);
					Copy.AddInt32( "fClicks", fPrimaryDownCount);
	
					MouseObject->processEvent( F_PRIMARY_MOUSE_UP, &Copy);
				}
			}
			break;

			case F_SECONDARY_MOUSE_UP:
			{
				// tell object in which button was pressed that the button was released.
				if( fSecondaryDownObject)
				{
					BMessage Copy( Message);
					Copy.AddInt32( "fAction", F_SECONDARY_MOUSE_UP);
					Copy.AddInt32( "fClicks", fSecondaryDownCount);
	
					fSecondaryDownObject->processEvent( F_SECONDARY_MOUSE_UP, &Copy);
				}
	
				// tell object in which button was released that the button was released.
				// (only if != object in which it was pressed [see above]).
				if( MouseObject && ( MouseObject != fSecondaryDownObject))
				{
					BMessage Copy( Message);
					Copy.AddInt32( "fAction", F_SECONDARY_MOUSE_UP);
					Copy.AddInt32( "fClicks", fSecondaryDownCount);
	
					MouseObject->processEvent( F_SECONDARY_MOUSE_UP, &Copy);
				}
			}
			break;
			
			case F_TERTIARY_MOUSE_UP:
			{
				// tell object in which button was pressed that the button was released.
				if( fTertiaryDownObject)
				{
					BMessage Copy( Message);
					Copy.AddInt32( "fAction", F_TERTIARY_MOUSE_UP);
					Copy.AddInt32( "fClicks", fTertiaryDownCount);
	
					fTertiaryDownObject->processEvent( F_TERTIARY_MOUSE_UP, &Copy);
				}
	
				// tell object in which button was released that the button was released.
				// (only if != object in which it was pressed [see above]).
				if( MouseObject && ( MouseObject != fTertiaryDownObject))
				{
					BMessage Copy( Message);
					Copy.AddInt32( "fAction", F_TERTIARY_MOUSE_UP);
					Copy.AddInt32( "fClicks", fTertiaryDownCount);
	
					MouseObject->processEvent( F_TERTIARY_MOUSE_UP, &Copy);
				}
			}
			break;

			case F_MOUSE_MOVED:
				if( SameWorkspace == false)
					break;
//				fprintf( stderr, "fWindow::handleMouseEvents() F_MOUSE_MOVED\n");
				mouseMoved( Point);
				break;

			default:
				break;
		}
	}

}
/*
void fWindow::checkMouseDown( const fPoint &Point, int32 Buttons)
{
	#if FWINDOW_DEBUG > 3
	fprintf( stderr, "fWindow::checkMouseDown()\n");
	#endif

	bigtime_t systemtime = system_time();

	BMessage Message( FGUI_EVENT);

	Message.AddInt64( "fTimeStamp", systemtime);
	Message.AddPoint( "fLocation", Point);

	fObject *MouseDownObject = ( fObject *) View->containsPoint( Point);

	#if FWINDOW_DEBUG > 3
	if( MouseDownObject == NULL)
		fprintf( stderr, "fWindow::checkMouseDown() Mouseclick NOT within window\n");
	#endif

	// Check if primary mouse button was pressed
	if( Buttons & B_PRIMARY_MOUSE_BUTTON)
	{
		if( fPrimaryDown == false)
		{
			#if FWINDOW_DEBUG > 2
			fprintf( stderr, "fWindow::checkMouseDown() Primary down !\n");
			#endif

			fPrimaryDown = true;
	
			if( MouseDownObject == NULL)
			{
				fPrimaryDownCount = 0;

				#if FWINDOW_DEBUG > 3
				fprintf( stderr, "fWindow::checkMouseDown() Primary mouse click NOT within window\n");
				#endif
			}
			else
			{
				// is the time in the interval for a multiclick or in another object ?
				if(( systemtime - fPrimaryDownTime > mouseClickInterval) || ( fPrimaryDownObject != MouseDownObject))
				{
					// no, set clickcount to 1
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Last click too far away, resetting counter to 1 !\n");
					#endif
		
					fPrimaryDownCount = 1;
				}
				else
				{
					// yes, increase clickcount
					fPrimaryDownCount++;
		
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Primary multiclick: %d!\n", fPrimaryDownCount);
					#endif
				}

				// remember time
				fPrimaryDownTime = systemtime;

				#if FWINDOW_DEBUG > 2
				fprintf( stderr, "fWindow::checkMouseDown() Primary mouse click, calling processEvent()\n");
				#endif
			
				fPrimaryDownObject = MouseDownObject;
	
				BMessage Copy( Message);
				Copy.AddInt32( "fAction", F_PRIMARY_MOUSE_DOWN);
	
				fPrimaryDownObject->processEvent( F_PRIMARY_MOUSE_DOWN, &Copy);
			}
		}
	}
	
	// Check if secondary mouse button was pressed
	if( Buttons & B_SECONDARY_MOUSE_BUTTON)
	{
		if( fSecondaryDown == false)
		{
			#if FWINDOW_DEBUG > 2
			fprintf( stderr, "fWindow::checkMouseDown() Secondary down !\n");
			#endif

			fSecondaryDown = true;
	
			if( MouseDownObject == NULL)
			{
				fSecondaryDownCount = 0;

				#if FWINDOW_DEBUG > 3
				fprintf( stderr, "fWindow::checkMouseDown() Secondary mouse click NOT within window\n");
				#endif
			}
			else
			{
				// is the time in the interval for a multiclick or in another object ?
				if(( systemtime - fSecondaryDownTime > mouseClickInterval) || ( fSecondaryDownObject != MouseDownObject))
				{
					// no, set clickcount to 1
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Last click too far away, resetting counter to 1 !\n");
					#endif
		
					fSecondaryDownCount = 1;
				}
				else
				{
					// yes, increase clickcount
					fSecondaryDownCount++;
		
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Secondary multiclick: %d!\n", fSecondaryDownCount);
					#endif
				}
		
				// remember time
				fSecondaryDownTime = systemtime;
		
				fSecondaryDownObject = MouseDownObject;
		
				BMessage Copy( Message);
				Copy.AddInt32( "fAction", F_SECONDARY_MOUSE_DOWN);
		
				fSecondaryDownObject->processEvent( F_SECONDARY_MOUSE_DOWN, &Copy);
			}
		}
	}

	// Check if tertiary mouse button was pressed
	if( Buttons & B_TERTIARY_MOUSE_BUTTON)
	{
		if( fTertiaryDown == false)
		{
			#if FWINDOW_DEBUG > 2
			fprintf( stderr, "fWindow::checkMouseDown() Tertiary down !\n");
			#endif

			fTertiaryDown = true;
	
			if( MouseDownObject == NULL)
			{
				fTertiaryDownCount = 0;

				#if FWINDOW_DEBUG > 3
				fprintf( stderr, "fWindow::checkMouseDown() Tertiary mouse click NOT within window\n");
				#endif
			}
			else
			{
				// is the time in the interval for a multiclick or in another object ?
				if(( systemtime - fTertiaryDownTime > mouseClickInterval) || ( fTertiaryDownObject != MouseDownObject))
				{
					// no, set clickcount to 1
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Last click too far away, resetting counter to 1 !\n");
					#endif
		
					fTertiaryDownCount = 1;
				}
				else
				{
					// yes, increase clickcount
					fTertiaryDownCount++;
		
					#if FWINDOW_DEBUG > 2
					fprintf( stderr, "fWindow::checkMouseDown() Tertiary multiclick: %d!\n", fTertiaryDownCount);
					#endif
				}
		
				// remember time
				fTertiaryDownTime = systemtime;
		
				fTertiaryDownObject = MouseDownObject;
		
				Message.AddInt32( "fAction", F_TERTIARY_MOUSE_DOWN);
		
				fTertiaryDownObject->processEvent( F_TERTIARY_MOUSE_DOWN, &Message);
			}
		}
	}

	#if FWINDOW_DEBUG > 3
	fprintf( stderr, "fWindow::checkMouseDown() end\n");
	#endif
}

void fWindow::checkMouseUp( const fPoint &Point, int32 Buttons)
{
	#if FWINDOW_DEBUG > 5
	fprintf( stderr, "fWindow::checkMouseUp()\n");
	#endif

	fObject *MouseUpObject = ( fObject *) View->containsPoint( Point);

	BMessage Message( FGUI_EVENT);

	Message.AddInt64( "fTimeStamp", system_time());
	Message.AddPoint( "fLocation", Point);

	// was primary button down ?	
	if( fPrimaryDown)
	{
		// Is it pressed at the moment ?
		if(( Buttons & B_PRIMARY_MOUSE_BUTTON) == 0)
		{
			// no -> gone up.
			fPrimaryDown = false;
			
			// tell object in which button was pressed that the button was released.
			if( fPrimaryDownObject)
			{
				BMessage Copy( Message);
				Copy.AddInt32( "fAction", F_PRIMARY_MOUSE_UP);
				Copy.AddInt32( "fClicks", fPrimaryDownCount);

				fPrimaryDownObject->processEvent( F_PRIMARY_MOUSE_UP, &Copy);
			}

			// tell object in which button was released that the button was released.
			// (only if != object in which it was pressed [see above]).
			if( MouseUpObject && ( MouseUpObject != fPrimaryDownObject))
			{
				BMessage Copy( Message);
				Copy.AddInt32( "fAction", F_PRIMARY_MOUSE_UP);
				Copy.AddInt32( "fClicks", fPrimaryDownCount);

				MouseUpObject->processEvent( F_PRIMARY_MOUSE_UP, &Copy);
			}
		}
	}
	
	// was secondary button down ?	
	if( fSecondaryDown)
	{
		// Is it pressed at the moment ?
		if(( Buttons & B_SECONDARY_MOUSE_BUTTON) == 0)
		{
			// no -> gone up.
			fSecondaryDown = false;
			
			// tell object in which button was pressed that the button was released.
			if( fSecondaryDownObject)
			{
				BMessage Copy( Message);
				Copy.AddInt32( "fAction", F_SECONDARY_MOUSE_UP);
				Copy.AddInt32( "fClicks", fSecondaryDownCount);

				fSecondaryDownObject->processEvent( F_SECONDARY_MOUSE_UP, &Copy);
			}

			// tell object in which button was released that the button was released.
			// (only if != object in which it was pressed [see above]).
			if( MouseUpObject && ( MouseUpObject != fSecondaryDownObject))
			{
				BMessage Copy( Message);
				Copy.AddInt32( "fAction", F_SECONDARY_MOUSE_UP);
				Copy.AddInt32( "fClicks", fSecondaryDownCount);

				MouseUpObject->processEvent( F_SECONDARY_MOUSE_UP, &Copy);
			}
		}
	}
	
	// was tertiary button down ?	
	if( fTertiaryDown)
	{
		// Is it pressed at the moment ?
		if(( Buttons & B_TERTIARY_MOUSE_BUTTON) == 0)
		{
			// no -> gone up.
			fTertiaryDown = false;

			// tell object in which button was pressed that the button was released.
			if( fTertiaryDownObject)
			{
				BMessage Copy( Message);
				Copy.AddInt32( "fAction", F_TERTIARY_MOUSE_UP);
				Copy.AddInt32( "fClicks", fTertiaryDownCount);

				fTertiaryDownObject->processEvent( F_TERTIARY_MOUSE_UP, &Copy);
			}

			// tell object in which button was released that the button was released.
			// (only if != object in which it was pressed [see above]).
			if( MouseUpObject && ( MouseUpObject != fTertiaryDownObject))
			{
				BMessage Copy( Message);
				Copy.AddInt32( "fAction", F_TERTIARY_MOUSE_UP);
				Copy.AddInt32( "fClicks", fTertiaryDownCount);

				MouseUpObject->processEvent( F_TERTIARY_MOUSE_UP, &Copy);
			}
		}
	}

	#if FWINDOW_DEBUG > 5
	fprintf( stderr, "fWindow::checkMouseUp() end\n");
	#endif
}
*/
void fWindow::mouseMoved( const fPoint &Point)
{
	#if FWINDOW_DEBUG > 5
	fprintf( stderr, "fWindow::mouseMoved()\n");
	#endif

	BMessage Message( FGUI_EVENT);

	Message.AddInt32( "fAction", F_MOUSE_MOVED);
	Message.AddInt64( "fTimeStamp", system_time());
	Message.AddPoint( "fLocation", Point);

	fObject *NewMouseOver = NULL;

	// mouse moved broadcast
	View->mouseMoved( Point);

	// Was the mouse within the view ? (i.e. was the mouse in an object ?)
	if( fMouseOverObject)
	{
		// Is the mouse still within the same object ?
		NewMouseOver = const_cast<fObject *>( fMouseOverObject->containsPoint( Point));
	
		if( fMouseOverObject == NewMouseOver)
		{
			#if FWINDOW_DEBUG > 4
			fprintf( stderr, "fWindow::mouseMoved() F_MOUSE_WITHIN\n");
			#endif

			// Yes !
			Message.AddInt32( "fTransit", F_MOUSE_WITHIN);

			fMouseOverObject->processEvent( F_MOUSE_MOVED, &Message);
			return;
		}

		// No, the mouse is somewhere else...
		#if FWINDOW_DEBUG > 4
		fprintf( stderr, "fWindow::mouseMoved() F_MOUSE_EXITED\n");
		#endif

		BMessage Copy( Message);
		Copy.AddInt32( "fTransit", F_MOUSE_EXITED);

		fMouseOverObject->processEvent( F_MOUSE_MOVED, &Copy);
	}

	// get the object the mouse is over now (if necessary)
	if( NewMouseOver)
		fMouseOverObject = NewMouseOver;
	else
		fMouseOverObject = const_cast<fObject *>( View->containsPoint( Point));

	// and tell it the mouse entered (if it is within the view)
	if( fMouseOverObject)
	{
		#if FWINDOW_DEBUG > 4
		fprintf( stderr, "fWindow::mouseMoved() F_MOUSE_ENTERED\n");
		#endif

		Message.AddInt32( "fTransit", F_MOUSE_ENTERED);
		fMouseOverObject->processEvent( F_MOUSE_MOVED, &Message);
	}

	#if FWINDOW_DEBUG > 5
	fprintf( stderr, "fWindow::mouseMoved() end\n");
	#endif
}

fClassInfo *fWindow::createInstance( void) const
{
	return( new fWindow());
}

const char * const fWindow::getClassName( void) const
{
	return( "fWindow");
}

const char * const fWindow::getBaseClassName( void) const
{
	return( fClassInfo::getClassName());
}

bool fWindow::isOfClass( const char *ClassName) const
{
	if( strcmp( fWindow::getClassName(), ClassName) == 0)
		return( true);

	return( false);
}

bool fWindow::isOfType( const char *ClassName) const
{
	if( fWindow::isOfClass( ClassName))
		return( true);

	return( fClassInfo::isOfType( ClassName));
}