// fApplication.cpp

#include "fApplication.h"
#include "fFactory.h"

#include "fWindow.h"

#include <string.h>

#if DEBUG > 0
#define FAPPLICATION_DEBUG DEBUG
#endif

//#undef FAPPLICATION_DEBUG
//#define FAPPLICATION_DEBUG 2

fApplication::fApplication( const char *Signature)
			: BApplication( Signature)
{
	#if FAPPLICATION_DEBUG > 0
	fprintf( stderr, "fApplication::fApplication()\n");
	#endif

	// start mouse thread
	thread_id tid;
	fRunning = false;

	if(( tid = spawn_thread( startMouseThread, "fMouseThread", B_DISPLAY_PRIORITY, this)) >= B_OK)
		resume_thread( tid);

	// load addons
	BPath AddOnPath1;
	
	if( find_directory( B_BEOS_ADDONS_DIRECTORY, &AddOnPath1) == B_OK)
		loadAddOn( AddOnPath1);

	BPath AddOnPath2;
	if( find_directory( B_COMMON_ADDONS_DIRECTORY, &AddOnPath2) == B_OK)
		if( AddOnPath1 != AddOnPath2)
			loadAddOn( AddOnPath2);

	BPath AddOnPath3;
	if( find_directory( B_USER_ADDONS_DIRECTORY, &AddOnPath3) == B_OK)
		if(( AddOnPath1 != AddOnPath2) && ( AddOnPath2 != AddOnPath3))
			loadAddOn( AddOnPath3);

	fFactory::getFactory()->setDefaultStyle( "Be");

	#if FAPPLICATION_DEBUG > 0
	fprintf( stderr, "fApplication::fApplication() end\n");
	#endif
}
	
fApplication::~fApplication( void)
{
	#if FAPPLICATION_DEBUG > 0
	fprintf( stderr, "fApplication::~fApplication()\n");
	#endif

	// stop mouse thread
	if( fRunning)
	{
		fRunning = false;
		
		snooze( 20000);
	}
	
	#if FAPPLICATION_DEBUG > 0
	fprintf( stderr, "fApplication::~fApplication() end\n");
	#endif
}

void fApplication::loadAddOn( const BPath &AddOnDirPath) const
{
	BDirectory AddOnDirectory( AddOnDirPath.Path());

	fprintf( stderr, "Looking for addons in: '%s'\n", AddOnDirPath.Path());

	if( AddOnDirectory.InitCheck() == B_OK)
	{
		BEntry fGUIAddOnEntry;
	
		if( AddOnDirectory.FindEntry( "fGUI", &fGUIAddOnEntry) == B_OK)
		{
			BDirectory fGUIAddOnDirectory( &fGUIAddOnEntry);
	
			if( fGUIAddOnDirectory.InitCheck() == B_OK)
			{
				fGUIAddOnDirectory.Rewind();
	
				while( fGUIAddOnDirectory.GetNextEntry( &fGUIAddOnEntry) == B_OK)
				{
					char AddOnName[ B_FILE_NAME_LENGTH]; 
					BPath AddOnPath;
					
					if( fGUIAddOnEntry.GetName( AddOnName) == B_OK && fGUIAddOnEntry.GetPath( &AddOnPath) == B_OK)
					{
						fprintf( stderr, "Loading add on '%s'.\n", AddOnName);
	
						image_id addon = load_add_on( AddOnPath.Path());
	
						if( addon == B_ERROR)
							fprintf( stderr, "Error loading add on\n");
						else
						{
							void (*fred)( void); 
							if( get_image_symbol( addon, "Fred", B_SYMBOL_TYPE_TEXT, &fred) != B_OK)
								unload_add_on( addon);
						}
					}
				}				
			}
//			else
//				fprintf( stderr, "fGUIAddOnDirectory.InitCheck failed\n");
		}
//		else
//			fprintf( stderr, "FindEntry failed\n");
	}		
//	else
//		fprintf( stderr, "AddOnDirectory.InitCheck failed\n");
}
	
int32 fApplication::startMouseThread( void *Data)
{
	fApplication *Application = static_cast<fApplication *>( Data);

	Application->fRunning = true;
	int32 ret = Application->mouseThread();
	Application->fRunning = false;
	
	return( ret);
}
		
int32 fApplication::mouseThread( void)
{
	BPoint Point;
	uint32 Buttons;

	bool MouseStateChanged = false;

	bool PrimaryDown = false;
	bool SecondaryDown = false;
	bool TertiaryDown = false;

	BWindow *Window = new BWindow( BRect( 0.0, 0.0, 1.0, 1.0),
								"fMouseThreadWindow",
								B_BORDERED_WINDOW, 0);

	BView *View;
	Window->AddChild( View = new BView( Window->Bounds(), NULL, 0, 0));
	Window->MoveTo( B_ORIGIN);

	// initialize mouse button states and mouse position
	View->GetMouse( &Point, &Buttons);
	View->ConvertToScreen( &Point);

	if( Buttons & B_PRIMARY_MOUSE_BUTTON)
		PrimaryDown = true;

	if( Buttons & B_SECONDARY_MOUSE_BUTTON)
		SecondaryDown = true;

	if( Buttons & B_TERTIARY_MOUSE_BUTTON)
		TertiaryDown = true;

	// and unlock window
	Window->Unlock();

	int32 i = 0;

	// main loop
	while( fRunning)
	{
		// prepare message
		BMessage Message( F_MOUSE_THREAD_EVENT);

		i++;

		// wait 1/25 seconds
		snooze( 40000);
	
		// presume no changes in mouse state
		MouseStateChanged = false;

		// check mouse state
		if( Window->Lock() == false)
			break;

		BPoint NewPoint;

		View->GetMouse( &NewPoint, &Buttons);
		View->ConvertToScreen( &NewPoint);
		Window->Unlock();

		// check mouse buttons
		
		if( Buttons & B_PRIMARY_MOUSE_BUTTON)
		{
			if( PrimaryDown == false)
			{
				// primary down
				PrimaryDown = true;

				Message.AddInt32( "fEvent", F_PRIMARY_MOUSE_DOWN);
				MouseStateChanged = true;
			}
		}
		else
		{
			if( PrimaryDown == true)
			{
				// primary up
				PrimaryDown = false;

				Message.AddInt32( "fEvent", F_PRIMARY_MOUSE_UP);
				MouseStateChanged = true;
			}
		}

		if( Buttons & B_SECONDARY_MOUSE_BUTTON)
		{
			if( SecondaryDown == false)
			{
				// primary down
				SecondaryDown = true;

				Message.AddInt32( "fEvent", F_SECONDARY_MOUSE_DOWN);
				MouseStateChanged = true;
			}
		}
		else
		{
			if( SecondaryDown == true)
			{
				// primary up
				SecondaryDown = false;

				Message.AddInt32( "fEvent", F_SECONDARY_MOUSE_UP);
				MouseStateChanged = true;
			}
		}

		if( Buttons & B_TERTIARY_MOUSE_BUTTON)
		{
			if( TertiaryDown == false)
			{
				// primary down
				TertiaryDown = true;

				Message.AddInt32( "fEvent", F_TERTIARY_MOUSE_DOWN);
				MouseStateChanged = true;
			}
		}
		else
		{
			if( TertiaryDown == true)
			{
				// primary up
				TertiaryDown = false;

				Message.AddInt32( "fEvent", F_TERTIARY_MOUSE_UP);
				MouseStateChanged = true;
			}
		}
/*
		// check mouse position only every 1/10 of a second
		if( i % 5)
		{
			if( Point != NewPoint)
			{
				Point = NewPoint;

				Message.AddInt32( "fEvent", F_MOUSE_MOVED);
				MouseStateChanged = true;
			}
		}
*/
		// check mouse position only every 1/5 of a second
		if( MouseStateChanged || ( i % 3) == 0)
		{
			Message.AddInt64( "fTimeStamp", system_time());
			Message.AddInt32( "fWorkspace", current_workspace());

			if( Point != NewPoint)
			{
				// if the mouse has been moved, remember new position
				// and add event
				Point = NewPoint;
				Message.AddInt32( "fEvent", F_MOUSE_MOVED);

				i = 0;
			}

			Message.AddPoint( "fLocation", NewPoint);

			PostMessage( &Message);
		}
/*
		else
		{
			// check mouse position only every 1/10 of a second
			if( i % 5)
			{
				Message.AddInt64( "fTimeStamp", system_time());
				Message.AddInt32( "fWorkspace", current_workspace());

				if( Point != NewPoint)
				{
					Point = NewPoint;
	
					Message.AddInt32( "fEvent", F_MOUSE_MOVED);
					Message.AddPoint( "fLocation", Point);
				}
			}
		}
*/
	}

	if( Window->Lock())
		Window->Quit();

	return( 0);
}

fApplication * const fApplication::getApplication( void)
{
	return( static_cast<fApplication *>( be_app));
}

void fApplication::addWindow( const fWindow *Window)
{
//	fprintf( stderr, "fApplication::addWindow()\n");
	fWindows.AddItem( static_cast<void *>( const_cast<fWindow *>( Window)));
}

bool fApplication::removeWindow( fWindow *Window)
{
	bool result = fWindows.RemoveItem( Window);

	// exit application when last window is closed
	if( fWindows.CountItems() == 0)
		PostMessage( B_QUIT_REQUESTED);

	return( result);
}

const BLooper *fApplication::locateObject( const fObject *ObjectPointer) const
{
	#if FAPPLICATION_DEBUG > 1
	fprintf( stderr, "fApplication::locateObject()\n");
	#endif

	int32 Item = 0;
	fWindow *SomeWindow;
	
	while(( SomeWindow = static_cast<fWindow *>( fWindows.ItemAt( Item++))) != NULL)
	{
		if( SomeWindow->findObject( ObjectPointer))
		{
			#if FAPPLICATION_DEBUG > 1
			fprintf( stderr, "fApplication::locateObject() Found object.\n");
			#endif
		
			return( SomeWindow->getWindow());
		}
	}

	Item = 0;
	
	while(( SomeWindow = static_cast<fWindow *>( fWindows.ItemAt( Item++))) != NULL)
	{
		// if the objectpointer is a window return that window
		if( static_cast<void *>( SomeWindow) == static_cast<void *>( const_cast<fObject *>(ObjectPointer)))
		{
			#if FAPPLICATION_DEBUG > 1
			fprintf( stderr, "fApplication::locateObject() Found window.\n");
			#endif
		
			return( SomeWindow->getWindow());
		}
	}

	// if the objectpointer is the the app return the app
	if( static_cast<void *>( be_app) == static_cast<void *>( const_cast<fObject *>(ObjectPointer)))
	{
		#if FAPPLICATION_DEBUG > 1
		fprintf( stderr, "fApplication::locateObject() Found application.\n");
		#endif
		
		return( this);
	}

	#if FAPPLICATION_DEBUG > 1
	fprintf( stderr, "fApplication::locateObject() end (unsuccessful)\n");
	#endif

	return( NULL);
}

const BLooper *fApplication::locateObject( const char *ObjectName) const
{
	#if FAPPLICATION_DEBUG > 1
	fprintf( stderr, "fApplication::locateObject()\n");
	#endif

	int32 Item = 0;
	fWindow *SomeWindow;
	
	while(( SomeWindow = static_cast<fWindow *>( fWindows.ItemAt( Item++))) != NULL)
	{
		if( SomeWindow->findObject( ObjectName))
		{
			#if FAPPLICATION_DEBUG > 1
			fprintf( stderr, "fApplication::locateObject() Found object.\n");
			#endif
		
			return( SomeWindow->getWindow());
		}
	}

	Item = 0;
	
	while(( SomeWindow = static_cast<fWindow *>( fWindows.ItemAt( Item++))) != NULL)
	{
		// if the objectname is a window title return that window
		if( strcmp( SomeWindow->getWindowName(), ObjectName) == 0)
		{
			#if FAPPLICATION_DEBUG > 1
			fprintf( stderr, "fApplication::locateObject() Found window.\n");
			#endif
		
			return( SomeWindow->getWindow());
		}
	}

	app_info appinfo;

	// get application info
	if( GetAppInfo( &appinfo) != B_OK)
		return( NULL);

	// if the objectname is the signature of the app return the app
	if( strcmp( appinfo.signature, ObjectName) == 0)
	{
		#if FAPPLICATION_DEBUG > 1
		fprintf( stderr, "fApplication::locateObject() Found application.\n");
		#endif
		
		return( this);
	}

	#if FAPPLICATION_DEBUG > 1
	fprintf( stderr, "fApplication::locateObject() end (unsuccessful)\n");
	#endif

	return( NULL);
}

void fApplication::MessageReceived( BMessage *Message)
{
	BLooper *Target = NULL;

	const fObject *TargetPointer = NULL;

	if( Message->what == F_MOUSE_THREAD_EVENT)
	{
		fWindow *Window; 
		int32 Item = 0; 
		
		while(( Window = static_cast<fWindow *>( fWindows.ItemAt( Item++))) != NULL)
		{
			BWindow *BeWindow = Window->getWindow();

			// only send messages to windows on screen
			if( BeWindow)
			{
				if( BeWindow->Lock())
				{
					if( BeWindow->IsHidden() == false)
						BeWindow->PostMessage( Message);

					BeWindow->Unlock(); 
				} 
			}
		}
		
		return;
	}   
   
   	// is pointer to target given ?
	if( Message->FindPointer( "fTargetPointer", const_cast<void**>( reinterpret_cast<const void **>( &TargetPointer))) == B_OK)
		Target = const_cast<BLooper *>( locateObject( TargetPointer));
	else
	{
		// if not, is name of target there ?
		const char *TargetName = Message->FindString( "fTargetName");
	
		if( TargetName != NULL)
			Target = const_cast<BLooper *>( locateObject( TargetName));
	}

	// if we have located the target send the message to its window
	if( Target)
	{
		#if FAPPLICATION_DEBUG > 1
		fprintf( stderr, "fApplication::MessageReceived() end (successful)\n");
		#endif
	
		Target->PostMessage( Message);
	}
	else
	{
		#if FAPPLICATION_DEBUG > 1
		fprintf( stderr, "fApplication::MessageReceived() end (unsuccessful)\n");
		#endif
	
		BApplication::MessageReceived( Message);
	}
}