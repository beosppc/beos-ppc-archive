// fView.cpp

#include <View.h>
#include <Region.h>

#include "fWindow.h"

#include "fEvents.h"

#if DEBUG > 0
#define FVIEW_DEBUG DEBUG
#endif

//#undef FVIEW_DEBUG
//#define FVIEW_DEBUG 3

fWindow::fView::fView( fObject *Object)
//		: BView( BRect( 0.0, 0.0, 1.0, 1.0), "fView", B_FOLLOW_ALL_SIDES, B_SUBPIXEL_PRECISE | B_WILL_DRAW | B_FRAME_EVENTS)
		: BView( BRect( 0.0, 0.0, 1.0, 1.0), "fView", B_FOLLOW_ALL_SIDES, B_WILL_DRAW | B_FRAME_EVENTS)
{
	#if FVIEW_DEBUG > 0
	fprintf( stderr, "fView::fView()\n");
	#endif

	setBorders( 0.0);

//	SetHighColor( 0xff, 0xff, 0xff);
//	SetLowColor( 0x00, 0x00, 0x00);
//	SetViewColor( 0xc0, 0xc0, 0xc0);
	SetViewColor( B_TRANSPARENT_32_BIT);
	
	setView( this);

	if( Object)
		setObject( Object);
	
	#if FVIEW_DEBUG > 0
	fprintf( stderr, "fView::fView() end\n");
	#endif
}

fWindow::fView::~fView( void)
{
	#if FVIEW_DEBUG > 0
	fprintf( stderr, "fView::~fView()\n");
	#endif

	#if FVIEW_DEBUG > 0
	fprintf( stderr, "fView::~fView() end\n");
	#endif
}

void fWindow::fView::updateIfNeeded( void)
{
	#if FVIEW_DEBUG > 1
	fprintf( stderr, "fView::updateIfNeeded()\n");
	fprintf( stderr, "fView::updateIfNeeded() Old size: ");
	getSize().PrintToStream();
	#endif

	recalculateSizeLimits();
	
	fPoint minSize = getMinimumSize();
	fPoint maxSize = getMaximumSize();

	if( fSomeObject)
	{
		if( getVerticalWeight() == 0.0 || fSomeObject->getVerticalWeight() == 0.0)
		{
			minSize.y = getPreferredSize().y;
			maxSize.y = getPreferredSize().y;
		}

		if( getHorizontalWeight() == 0.0 || fSomeObject->getHorizontalWeight() == 0.0)
		{
			minSize.x = getPreferredSize().x;
			maxSize.x = getPreferredSize().x;
		}
	}

	#if FVIEW_DEBUG > 2
	fprintf( stderr, "fView::updateIfNeeded() New minimum size: ");
	minSize.PrintToStream();
	fprintf( stderr, "fView::updateIfNeeded() New maximum size: ");
	maxSize.PrintToStream();
	#endif

	fPoint curSize = getSize();

	if( curSize < minSize)
	{
		if( curSize.x < minSize.x)
			curSize.x = minSize.x;

		if( curSize.y < minSize.y)
			curSize.y = minSize.y;
	}
	
	if( curSize > maxSize)
	{
		if( curSize.x > maxSize.x)
			curSize.x = maxSize.x;

		if( curSize.y > maxSize.y)
			curSize.y = maxSize.y;
	}
	
	setSize( curSize);
	
	if( Window())
	{
/*
		// Make up for Be's lack in providing resizing in B_BORDERED_WINDOW windows
		if( Window()->WindowType() == B_BORDERED_WINDOW)
		{
//			ResizeTo( curSize.x - 1.0, curSize.y - 1.0);
			#if FVIEW_DEBUG > 1
			fprintf( stderr, "fView::updateIfNeeded() Resizing view to: ");
			(curSize - BPoint( 1.0, 1.0)).PrintToStream();
			#endif
			ResizeTo( curSize.x, curSize.y);
		}
		else
*/	
		Window()->SetSizeLimits( minSize.x - 1.0, maxSize.x - 1.0, minSize.y - 1.0, maxSize.y - 1.0);
		Window()->SetZoomLimits( maxSize.x - 1.0, maxSize.y - 1.0);
		Window()->ResizeTo( curSize.x - 1.0, curSize.y - 1.0);

		Invalidate( Bounds());
	}

	#if FVIEW_DEBUG > 1
	fprintf( stderr, "fView::updateIfNeeded() New size: ");
	getSize().printToStream();
	fprintf( stderr, "fView::updateIfNeeded() end\n");
	#endif
}

void fWindow::fView::AttachedToWindow( void)
{
	#if FVIEW_DEBUG > 1
	fprintf( stderr, "fView::AttachedToWindow()\n");
	#endif

	updateIfNeeded();
	MakeFocus( true);
	
	#if FVIEW_DEBUG > 1
	fprintf( stderr, "fView::AttachedToWindow() end\n");
	#endif
}

void fWindow::fView::Draw( BRect updateRect)
{
	#if FVIEW_DEBUG > 1
	fprintf( stderr, "fView::Draw()\n");
	fprintf( stderr, "fView::Draw() Drawing to: ");
	updateRect.PrintToStream();
	fprintf( stderr, "fView::Draw() ObjectFrame: ");
	getObjectFrame().PrintToStream();
	#endif

//	ConstrainClippingRegion( NULL);

	BRegion ClippingRegion;

//	fprintf( stderr, "fView::Draw() ClippingRegion: ");
//	GetClippingRegion( &ClippingRegion);
//	ClippingRegion.PrintToStream();

	ClippingRegion.Set( updateRect);
//	ConstrainClippingRegion( NULL);

//	SetLowColor( getBackgroundColor());
//	SetHighColor( B_TRANSPARENT_32_BIT);

	// Clear background
//	FillRect( updateRect, B_SOLID_LOW);

/*
	if( Window()->WindowType() == B_DOCUMENT_WINDOW)
	{
		BRect bounds = Bounds();

		bounds.OffsetTo( bounds.RightBottom() - BPoint( B_V_SCROLL_BAR_WIDTH, B_H_SCROLL_BAR_HEIGHT));
		ClippingRegion.Exclude( bounds);
//		ConstrainClippingRegion( &ClippingRegion);
	}
*/

//	SetHighColor( 0x00, 0x00, 0x00);
//	SetLowColor( 0xc0, 0xc0, 0xc0);

	if( updateRect == getObjectFrame())
		drawObject( ClippingRegion, true);
	else
		drawObject( ClippingRegion, false);

	ConstrainClippingRegion( NULL);

	Sync();

	#if FVIEW_DEBUG > 1
	fprintf( stderr, "fView::Draw() end\n");
	#endif
}

void fWindow::fView::FrameResized( float /*width*/, float /*height*/)
{
	fPoint NewSize = Bounds().RightBottom() + fPoint( 1.0, 1.0);

	#if FVIEW_DEBUG > 1
	fprintf( stderr, "fView::FrameResized()\n");
	fprintf( stderr, "fView::FrameResized() New Size: ");
	NewSize.PrintToStream();
	fprintf( stderr, "fView::FrameResized() getSize(): ");
	getSize().PrintToStream();
	fprintf( stderr, "fView::FrameResized() Frame: ");
	Frame().PrintToStream();
	fprintf( stderr, "fView::FrameResized() Bounds: ");
	Bounds().PrintToStream();
	#endif

	if( NewSize == getSize())
		return;

	setSize( NewSize);

	Invalidate( Bounds());

	#if FVIEW_DEBUG > 1
	fprintf( stderr, "fView::FrameResized() end\n");
	#endif
}

void fWindow::fView::recalculateSizeLimits( void)
{
	fPoint MinimumSize;
	fPoint PreferredSize;
	fPoint MaximumSize;

	if( fSomeObject)
	{
		PreferredSize = fSomeObject->getPreferredSize();

		if( fSomeObject->getVerticalWeight() == 0.0)
		{
			MinimumSize.y = fSomeObject->getPreferredSize().y;
			MaximumSize.y = fSomeObject->getPreferredSize().y;
		}
		else
		{
			MinimumSize.y = fSomeObject->getMinimumSize().y;
			MaximumSize.y = fSomeObject->getMaximumSize().y;
		}

		if( fSomeObject->getHorizontalWeight() == 0.0)
		{
			MinimumSize.x = fSomeObject->getPreferredSize().x;
			MaximumSize.x = fSomeObject->getPreferredSize().x;
		}
		else
		{
			MinimumSize.x = fSomeObject->getMinimumSize().x;
			MaximumSize.x = fSomeObject->getMaximumSize().x;
		}
	}

	setMinimumSize( MinimumSize);
	setPreferredSize( PreferredSize);
	setMaximumSize( MaximumSize);
}

fClassInfo *fWindow::fView::createInstance( void) const
{
	return( new fView());
}

const char * const fWindow::fView::getClassName( void) const
{
	return( "fView");
}

const char * const fWindow::fView::getBaseClassName( void) const
{
	return( fSingleContainer::getClassName());
}

bool fWindow::fView::isOfClass( const char *ClassName) const
{
	if( strcmp( fView::getClassName(), ClassName) == 0)
		return( true);

	return( false);
}

bool fWindow::fView::isOfType( const char *ClassName) const
{
	if( fView::isOfClass( ClassName))
		return( true);

	return( fSingleContainer::isOfType( ClassName));
}
