// fEqualHorizontalGroup.cpp

#include "fEqualHorizontalGroup.h"
#include "fFactory.h"

#if DEBUG > 0
#define FEQUALHGROUP_DEBUG DEBUG
#endif
 
//#undef FEQUALHGROUP_DEBUG
//#define FEQUALHGROUP_DEBUG 2

ClassDefinition( fEqualHorizontalGroup, fHorizontalGroup, "");

fEqualHorizontalGroup::fEqualHorizontalGroup( void)
{
	#if FEQUALHGROUP_DEBUG > 0
	fprintf( stderr, "fEqualHorizontalGroup::fEqualHorizontalGroup()\n");
	#endif

	#if FEQUALHGROUP_DEBUG > 0
	fprintf( stderr, "fEqualHorizontalGroup::fEqualHorizontalGroup() end\n");
	#endif
}

fEqualHorizontalGroup::~fEqualHorizontalGroup( void)
{
	#if FEQUALHGROUP_DEBUG > 0
	fprintf( stderr, "fEqualHorizontalGroup::~fEqualHorizontalGroup()\n");
	#endif

	#if FEQUALHGROUP_DEBUG > 0
	fprintf( stderr, "fEqualHorizontalGroup::~fEqualHorizontalGroup end()\n");
	#endif
}

void fEqualHorizontalGroup::calculateMinimumSize( void)
{
	#if FEQUALHGROUP_DEBUG > 1
	fprintf( stderr, "fEqualHorizontalGroup::calculateMinimumSize()\n");
	#endif
	
	fPoint Size;

	int32 Item = 0;
	const fObject *TempObject;
	
	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		fPoint minSize = TempObject->getMinimumSize();
		fPoint prefSize = TempObject->getPreferredSize();

		float temp;

		// get width of the object
		if( TempObject->getHorizontalWeight() == 0)
			temp = prefSize.x;
		else
			temp = minSize.x;

		// if wider than previous width, take the new width
		if( temp > Size.x)
			Size.x = temp;

		// get height of the object
		if( TempObject->getVerticalWeight() == 0)
			temp = prefSize.y;
		else
			temp = minSize.y;

		// if higher than previous height, take the new height
		if( temp > Size.y)
			Size.y = temp;
	}

	// Set horizontal size
	Size.x *= ( Item - 1);

	// Add spacing for objects	
	if( --Item)
		Size.x += ( fSpacing + 1) * ( Item - 1);

	setMinimumSize( Size);

	#if FEQUALHGROUP_DEBUG > 1
	fprintf( stderr, "fEqualHorizontalGroup::calculateMinimumSize() end\n");
	#endif
}

void fEqualHorizontalGroup::calculatePreferredSize( void)
{
	fPoint Size;

	int32 Item = 0;
	const fObject *TempObject;
	
	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		fPoint prefSize = TempObject->getPreferredSize();

		// if wider than previous width, take the new width
		if( prefSize.x > Size.x)
			Size.x = prefSize.x;

		// if higher than previous height, take the new height
		if( prefSize.y > Size.y)
			Size.y = prefSize.y;
	}

	// Set horizontal size
	Size.x *= ( Item - 1);

	// Add spacing for objects	
	if( --Item)
		Size.x += ( fSpacing + 1) * ( Item - 1);

	setPreferredSize( Size);
}

void fEqualHorizontalGroup::calculateMaximumSize( void)
{
	fPoint Size;

	int32 Item = 0;
	const fObject *TempObject;
	
	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		fPoint prefSize = TempObject->getPreferredSize();
		fPoint maxSize = TempObject->getMaximumSize();

		float temp;

		// get width of the object
		if( TempObject->getHorizontalWeight() == 0)
			temp = prefSize.x;
		else
			temp = maxSize.x;

		// if wider than previous width, take the new width
		if( temp > Size.x)
			Size.x = temp;

		// get height of the object
		if( TempObject->getVerticalWeight() == 0)
			temp = prefSize.y;
		else
			temp = maxSize.y;

		// if higher than previous height, take the new height
		if( temp > Size.y)
			Size.y = temp;
	}

	// Set horizontal size
	Size.x *= ( Item - 1);

	// Add spacing for objects	
	if( --Item)
		Size.x += ( fSpacing + 1) * ( Item - 1);

	setMaximumSize( Size);
}