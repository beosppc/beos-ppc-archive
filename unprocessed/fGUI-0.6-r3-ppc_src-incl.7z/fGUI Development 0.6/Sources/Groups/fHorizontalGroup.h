// fHorizontalGroup.h

#ifndef fHorizontalGroup_h
#define fHorizontalGroup_h

#include "fBaseGroup.h"

#pragma export on

class fHorizontalGroup : public fBaseGroup
{
	private:

		fHorizontalGroup( const fHorizontalGroup &CopyObject);
		fHorizontalGroup &operator=( const fHorizontalGroup &CopyObject);

		ClassDeclaration( fHorizontalGroup);

	protected:

		virtual void calculateMinimumSize( void);
		virtual void calculatePreferredSize( void);
		virtual void calculateMaximumSize( void);

	public:

		fHorizontalGroup( void);
		virtual ~fHorizontalGroup( void);
		
		virtual void setSize( const fPoint &NewSize);
};

#pragma export off

#endif
