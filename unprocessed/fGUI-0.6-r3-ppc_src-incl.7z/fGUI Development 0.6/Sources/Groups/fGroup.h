// fGroup.h

#ifndef fGroup_h
#define fGroup_h

#include "fObject.h"

#pragma export on

class fGroup : public fObject
{
	private:

		fGroup( const fGroup &CopyObject);
		fGroup &operator=( const fGroup &CopyObject);

		VirtualClassDeclaration( fGroup);

	protected:

		DoMethodDeclaration;

	public:
		
		fGroup( void);
		virtual ~fGroup( void);
		
		virtual void addObject( fObject *NewObject) = 0;
		virtual void insertObject( fObject *NewObject, int32 Position = 0) = 0;
		virtual void insertObjectAfter( fObject *NewObject, fObject *OtherObject) = 0;
		virtual void insertObjectBefore( fObject *NewObject, fObject *OtherObject) = 0;
		virtual void removeObject( fObject *OldObject) = 0;

		virtual void recursiveDelivery( fObject *Source, const char *Type, int32 Action) = 0;

		virtual void setSpacing( float NewSpacing) = 0;
};

#pragma export off

#endif
