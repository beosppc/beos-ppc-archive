// fBaseGroup.h

#ifndef fBaseGroup_h
#define fBaseGroup_h

#include "fGroup.h"
#include "fPoint.h"

#pragma export on

class fBaseGroup : public fGroup
{
	private:

		fBaseGroup( const fBaseGroup &CopyObject);
		fBaseGroup &operator=( const fBaseGroup &CopyObject);

		VirtualClassDeclaration( fBaseGroup);

	protected:

		BList	 fObjects;
		float	 fSpacing;

		virtual void recalculateSizeLimits( void);

	public:

		fBaseGroup( void);
		virtual ~fBaseGroup( void);
		
		virtual void addObject( fObject *NewObject);
		virtual void insertObject( fObject *NewObject, int32 Position = 0);
		virtual void insertObjectAfter( fObject *NewObject, fObject *OtherObject);
		virtual void insertObjectBefore( fObject *NewObject, fObject *OtherObject);
		virtual void removeObject( fObject *OldObject);
		
		virtual void recursiveDelivery( fObject *Source, const char *Type, int32 Action);

		virtual void setSpacing( float NewSpacing);
		
		virtual void setBorders( float NewBorder);
		virtual void setHorizontalBorder( float NewHorizontalBorder);
		virtual void setVerticalBorder( float NewVerticalBorder);

		virtual void setView( BView *NewView);
		
		virtual const fObject *containsPoint( const fPoint &Point) const;
		virtual void mouseMoved( const fPoint &Point);

		virtual bool findObject( const fObject *ObjectPointer) const;
		virtual const fObject *findObject( const char *ObjectName) const;
				
		virtual void setPosition( const fPoint &NewPosition);

		virtual void messageReceived( int32 Event, BMessage *Message);

		virtual void attachedToWindow( const class fWindow *ParentWindow);
		virtual void detachedFromWindow( void);

		virtual bool setWindowActivated( bool Activated);

		virtual void setEnabled( bool Enabled);

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
