// fEqualHorizontalGroup.h

#ifndef fEqualHorizontalGroup_h
#define fEqualHorizontalGroup_h

#include "fHorizontalGroup.h"

#pragma export on

class fEqualHorizontalGroup : public fHorizontalGroup
{
	private:

		fEqualHorizontalGroup( const fEqualHorizontalGroup &CopyObject);
		fEqualHorizontalGroup &operator=( const fEqualHorizontalGroup &CopyObject);

		ClassDeclaration( fEqualHorizontalGroup);

	protected:

		virtual void calculateMinimumSize( void);
		virtual void calculatePreferredSize( void);
		virtual void calculateMaximumSize( void);

	public:

		fEqualHorizontalGroup( void);
		virtual ~fEqualHorizontalGroup( void);
};

#pragma export off

#endif
