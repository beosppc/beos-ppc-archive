// fBaseGroup.cpp

#include "fBaseGroup.h"
#include "fEvents.h"

#if DEBUG > 0
#define FBASEGROUP_DEBUG DEBUG
#endif
 
//#undef FBASEGROUP_DEBUG
#define FBASEGROUP_DEBUG -1

VirtualClassDefinition( fBaseGroup, fGroup);

fBaseGroup::fBaseGroup( void)
{
	#if FBASEGROUP_DEBUG > 0
	fprintf( stderr, "fBaseGroup::fBaseGroup()\n");
	#endif

	fSpacing	= 2.0;

//	fGroupFrame = NULL;

	#if FBASEGROUP_DEBUG > 0
	fprintf( stderr, "fBaseGroup::fBaseGroup() end\n");
	#endif
}

fBaseGroup::~fBaseGroup( void)
{
	#if FBASEGROUP_DEBUG > 0
	fprintf( stderr, "fBaseGroup::~BaseGroup()\n");
	#endif

	const fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.RemoveItem(( int32) 0))) != NULL)
		delete TempObject;

//	delete fGroupFrame;

	#if FBASEGROUP_DEBUG > 0
	fprintf( stderr, "fBaseGroup::~BaseGroup end()\n");
	#endif
}

void fBaseGroup::recalculateSizeLimits( void)
{	
	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::recalculateSizeLimits()\n");
	#endif

	fObject::recalculateSizeLimits();

	#if FBASEGROUP_DEBUG > 2
	fprintf( stderr, "fBaseGroup::recalculateSizeLimits() New Minimum Size: ");
	getMinimumSize().PrintToStream();
	fprintf( stderr, "fBaseGroup::recalculateSizeLimits() New Maximum Size: ");
	getMaximumSize().PrintToStream();
	fprintf( stderr, "fBaseGroup::recalculateSizeLimits() New Preferred Size: ");
	getPreferredSize().PrintToStream();
	fprintf( stderr, "fBaseGroup::recalculateSizeLimits() Current Size: ");
	getSize().PrintToStream();
	#endif

	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::recalculateSizeLimits() end\n");
	#endif
}

void fBaseGroup::addObject( fObject *NewObject)
{
	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::addObject()\n");
	#endif

	if( NewObject == NULL)
		return;

	NewObject->setView( getView());
	NewObject->setParent( this);
	if( getEnabled() == false)
		NewObject->setEnabled( false);

	fObjects.AddItem( NewObject);

	// if the object is attached to a window, tell the new child object
	if( fParentWindow)
		NewObject->attachedToWindow( fParentWindow);

	updateIfNeeded();

	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::addObject() end\n");
	#endif
}

void fBaseGroup::insertObject( fObject *NewObject, int32 Position)
{
	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::insertObject()\n");
	#endif

	if( NewObject == NULL)
		return;

	NewObject->setView( getView());
	NewObject->setParent( this);
	if( getEnabled() == false)
		NewObject->setEnabled( false);

	fObjects.AddItem( NewObject, Position);

	// if the object is attached to a window, tell the new child object
	if( fParentWindow)
		NewObject->attachedToWindow( fParentWindow);

	updateIfNeeded();

	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::insertObject() end\n");
	#endif
}

void fBaseGroup::insertObjectAfter( fObject *NewObject, fObject *OtherObject)
{
	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::insertObjectAfter( fObject *NewObject, fObject *OtherObject)\n");
	#endif

	if( NewObject == NULL)
		return;

	// If no other object is given behave like addObject()
	if( OtherObject == NULL)
	{
		addObject( NewObject);
		return;
	}

	int32 index = fObjects.IndexOf( OtherObject);
	
	// if the other object is not in the list behave like addObject()
	if( index < 0)
	{
		addObject( NewObject);
		return;
	}
	
	NewObject->setView( getView());
	NewObject->setParent( this);
	if( getEnabled() == false)
		NewObject->setEnabled( false);

	fObjects.AddItem( NewObject, index + 1);

	// if the object is attached to a window, tell the new child object
	if( fParentWindow)
		NewObject->attachedToWindow( fParentWindow);

	updateIfNeeded();

	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::insertObjectAfter( fObject *NewObject, fObject *OtherObject) end\n");
	#endif
}

void fBaseGroup::insertObjectBefore( fObject *NewObject, fObject *OtherObject)
{
	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::insertObjectBefore( fObject *NewObject, fObject *OtherObject)\n");
	#endif

	if( NewObject == NULL)
		return;

	// If no other object is given behave like addObject()
	if( OtherObject == NULL)
	{
		addObject( NewObject);
		return;
	}

	int32 index = fObjects.IndexOf( OtherObject);
	
	// if the other object is not in the list behave like addObject()
	if( index < 0)
	{
		addObject( NewObject);
		return;
	}
	
	NewObject->setView( getView());
	NewObject->setParent( this);
	if( getEnabled() == false)
		NewObject->setEnabled( false);

	fObjects.AddItem( NewObject, index);

	// if the object is attached to a window, tell the new child object
	if( fParentWindow)
		NewObject->attachedToWindow( fParentWindow);

	updateIfNeeded();

	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::insertObjectBefore( fObject *NewObject, fObject *OtherObject) end\n");
	#endif
}

void fBaseGroup::removeObject( fObject *OldObject)
{
	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::removeObject()\n");
	#endif

	fObjects.RemoveItem( OldObject);
	
	OldObject->setParent( NULL);
	OldObject->setView( NULL);

	// if the object is attached to a window, tell the new child object
	// that is has been removed
	if( fParentWindow)
		OldObject->detachedFromWindow();

	updateIfNeeded();

	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::removeObject() end\n");
	#endif
}
		
void fBaseGroup::setSpacing( float NewSpacing)
{
	fSpacing = NewSpacing;
	
	updateIfNeeded();
}

void fBaseGroup::setBorders( float NewBorder)
{
	fObject::setBorders( NewBorder);

	int32 Item = 0;
	fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->setBorders( NewBorder);

	updateIfNeeded();
}

void fBaseGroup::setHorizontalBorder( float NewHorizontalBorder)
{
	fObject::setHorizontalBorder( NewHorizontalBorder);

	int32 Item = 0;
	fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->setHorizontalBorder( NewHorizontalBorder);

	updateIfNeeded();
}

void fBaseGroup::setVerticalBorder( float NewVerticalBorder)
{
	fObject::setVerticalBorder( NewVerticalBorder);

	int32 Item = 0;
	fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->setVerticalBorder( NewVerticalBorder);

	updateIfNeeded();
}

void fBaseGroup::setView( BView *NewView)
{
	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::setView()\n");
	#endif

	fObject::setView( NewView);

	int32 Item = 0;
	fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->setView( NewView);

	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::setView() end\n");
	#endif
}

const fObject *fBaseGroup::containsPoint( const fPoint &Point) const
{
	#if FBASEGROUP_DEBUG > 5
	fprintf( stderr, "fBaseGroup::containsPoint()\n");
	#endif

	if( fObject::containsPoint( Point) == NULL)
		return( NULL);

	int32 Item = 0;
	const fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		TempObject = TempObject->containsPoint( Point);

		if( TempObject)
			return( TempObject);
	}
	
	return( this);

	#if FBASEGROUP_DEBUG > 5
	fprintf( stderr, "fBaseGroup::containsPoint() end\n");
	#endif
}

void fBaseGroup::mouseMoved( const fPoint &Point)
{
	#if FBASEGROUP_DEBUG > 5
	fprintf( stderr, "fBaseGroup::mouseMoved()\n");
	#endif

	int32 Item = 0;
	fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->mouseMoved( Point);
	
	#if FBASEGROUP_DEBUG > 5
	fprintf( stderr, "fBaseGroup::mouseMoved() end\n");
	#endif
}

bool fBaseGroup::findObject( const fObject *ObjectPointer) const
{
	#if FBASEGROUP_DEBUG > 3
	fprintf( stderr, "fBaseGroup::findObject( const fObject *ObjectPointer)\n");
	#endif

	if( fObject::findObject( ObjectPointer))
		return( true);

	int32 Item = 0;
	const fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		if( TempObject->findObject( ObjectPointer))
			return( true);
	}

	return( false);

	#if FBASEGROUP_DEBUG > 3
	fprintf( stderr, "fBaseGroup::findObject( const fObject *ObjectPointer) end\n");
	#endif
}

const fObject *fBaseGroup::findObject( const char *ObjectName) const
{
	#if FBASEGROUP_DEBUG > 3
	fprintf( stderr, "fBaseGroup::findObject( const char *ObjectName)\n");
	#endif

	const fObject *TempObject = fObject::findObject( ObjectName);

	if( TempObject)
		return( TempObject);

	int32 Item = 0;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		TempObject = TempObject->findObject( ObjectName);

		if( TempObject)
			return( TempObject);
	}

	return( NULL);

	#if FBASEGROUP_DEBUG > 3
	fprintf( stderr, "fBaseGroup::findObject( const char *ObjectName) end\n");
	#endif
}

void fBaseGroup::setPosition( const fPoint &NewPosition)
{
	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::setPosition() New position:");
	NewPosition.PrintToStream();
	#endif

	fPoint delta = NewPosition - getPosition();

	fObject::setPosition( NewPosition);
	
	int32 Item = 0;
	fObject *SomeObject;
	
	while(( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		#if FBASEGROUP_DEBUG > 2
		fprintf( stderr, "fBaseGroup::setPosition() Setting object %d to position ", Item - 1);
		(SomeObject->getPosition() + delta).PrintToStream();
		#endif

		SomeObject->setPosition( SomeObject->getPosition() + delta);
	}

	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::setPosition() end\n");
	#endif
}

void fBaseGroup::messageReceived( int32 Event, BMessage *Message)
{
	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::messageReceived() Event: ");
	char *temp = ( char *) &Event;
	fprintf( stderr, "'%c%c%c%c'\n", temp[ 0], temp[ 1], temp[ 2], temp[ 3]);
	#endif

	switch( Event)
	{
		case F_ACTIVATE_ITEM:
		{
			fObject *SourcePointer = NULL;
			
			if( Message->FindPointer( "fSourcePointer", reinterpret_cast<void **>( &SourcePointer)) < B_OK)
			{
				#if FTABGROUP_DEBUG > 3
				fprintf( stderr, "fBaseGroup::messageReceived() Error getting fSourcePointer!\n");
				#endif
			
				const char *SourceName = Message->FindString( "fSourceName");

				if( SourceName == NULL)
				{
					#if FTABGROUP_DEBUG > 3
					fprintf( stderr, "fBaseGroup::messageReceived() Error getting fSourceName!\n");
					#endif
			
					return;
				}
				
				SourcePointer = const_cast<fObject *>( findObject( SourceName));
			}

			if( SourcePointer)
			{
				const char *ObjectType = SourcePointer->getClassName();

				recursiveDelivery( SourcePointer, ObjectType, F_DEACTIVATE_ITEM);

/*			
				int32 Item = 0;
				fObject *TempObject;
				
				while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
				{
//					fprintf( stderr, "fBaseGroup::messageReceived() Objecttype: %s\n", TempObject->getClassName());

					if( TempObject->isOfType( ObjectType))
						if( TempObject != SourcePointer)
							TempObject->messageReceived( F_DEACTIVATE_ITEM, NULL);
				}
*/
				SourcePointer->messageReceived( F_ACTIVATE_ITEM, NULL);
			}
		}
		break;

		default:
		{
			fGroup::messageReceived( Event, Message);
		}
		break;
	}

	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::messageReceived() end\n");
	#endif
}

void fBaseGroup::recursiveDelivery( fObject *Source, const char *Type, int32 Action)
{
	int32 Item = 0;
	fObject *TempObject;
	
//	fprintf( stderr, "fBaseGroup::recursiveDelivery()\n");

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		if( TempObject->isOfType( Type))
			if( TempObject != Source)
				TempObject->messageReceived( Action, NULL);

		fGroup *SubGroup = dynamic_cast<fGroup *>( TempObject);

		if( SubGroup) // It's a group
		{
//			fprintf( stderr, "fBaseGroup::recursiveDelivery() SubGroup found\n");
			SubGroup->recursiveDelivery( Source, Type, Action);
		}
	}

//	fprintf( stderr, "fBaseGroup::recursiveDelivery() end\n");
}	

void fBaseGroup::attachedToWindow( const class fWindow *ParentWindow)
{
	fGroup::attachedToWindow( ParentWindow);

	int32 Item = 0;
	fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->attachedToWindow( fParentWindow);
}

void fBaseGroup::detachedFromWindow( void)
{
	fGroup::detachedFromWindow();

	int32 Item = 0;
	fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->detachedFromWindow();
}

bool fBaseGroup::setWindowActivated( bool Activated)
{
	if( fGroup::setWindowActivated( Activated) == false)
		return( false);

	int32 Item = 0;
	fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->setWindowActivated( Activated);

	return( true);
}

void fBaseGroup::setEnabled( bool Enabled)
{
	fGroup::setEnabled( Enabled);

	int32 Item = 0;
	fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->setEnabled( Enabled);
}
/*
void fBaseGroup::setFrame( fFrame *Frame)
{
	delete fGroupFrame;
	
	fGroupFrame = Frame;
}
*/
void fBaseGroup::drawObject( const BRegion &ClippingRegion, bool FullUpdate) const
{
	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::draw()\n");
	#endif

	if( getView() == NULL)
		return;

	#if FBASEGROUP_DEBUG >= 0
	ShowGroupLayout;
	#endif

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	#if FBASEGROUP_DEBUG > 3
	fprintf( stderr, "fBaseGroup::draw() Drawing to ");
	Frame.PrintToStream();
	#endif

	if( Frame.IsValid() == false)
		return;

    if( getView()->Window() == NULL)
        return;

    if( getView()->Window()->Lock() == false)
        return;

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	// save state
	getView()->PushState();

	BRegion FillRegion;
	FillRegion.Set( Frame);
	
	FillRegion.IntersectWith( &ClippingRegion);

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
//		getView()->FillRect( Frame, B_SOLID_LOW);
		getView()->FillRegion( &FillRegion, B_SOLID_LOW);

	// determine region for drawing
	BRect BeFrame = getObjectFrame();
	BeFrame.SetRightBottom( BeFrame.RightBottom() + BPoint( 1.0, 1.0));

	BRegion NewRegion;
	NewRegion.Set( BeFrame);
	NewRegion.IntersectWith( &ClippingRegion);

	// draw objects
	int32 Item = 0;
	fObject *TempObject;

	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		if( NewRegion.Intersects( TempObject->getObjectFrame()))
		{
//			getView()->PopState();
//			getView()->PushState();
			getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));
			if( FullUpdate)
				TempObject->setClippingRegion( ClippingRegion);
			TempObject->drawObject( ClippingRegion, FullUpdate);
		}
	}

	// restore state
	getView()->PopState();

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())    
		getView()->Window()->Unlock();

	#if FBASEGROUP_DEBUG > 1
	fprintf( stderr, "fBaseGroup::draw() end\n");
	#endif
}

