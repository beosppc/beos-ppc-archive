// fTabGroup.cpp

#include "fTabGroup.h"
#include "fFactory.h"

#include "fEvents.h"

#if DEBUG > 0
#define FTABGROUP_DEBUG DEBUG
#endif

//#undef FTABGROUP_DEBUG
//#define FTABGROUP_DEBUG 4

VirtualClassDefinition( fTabGroup, fBaseGroup);

fTabGroup::fTabGroup( void)
{
	#if FTABGROUP_DEBUG > 0
	fprintf( stderr, "fTabGroup::fTabGroup()\n");
	#endif

	fInset		= 2.0;

	fActiveItem	= NULL;

	fBaseGroup::setSpacing( 0.0);

	#if FTABGROUP_DEBUG > 0
	fprintf( stderr, "fTabGroup::fTabGroup() end\n");
	#endif
}

fTabGroup::~fTabGroup( void)
{
	#if FTABGROUP_DEBUG > 0
	fprintf( stderr, "fTabGroup::~fTabGroup()\n");
	#endif

	fTabItem *TempObject;

	while(( TempObject = static_cast<fTabItem *>( fObjects.RemoveItem(( int32) 0))) != NULL)
		delete TempObject;

	#if FTABGROUP_DEBUG > 0
	fprintf( stderr, "fTabGroup::~fTabGroup() end\n");
	#endif
}

void fTabGroup::addObject( fObject *NewObject)
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::addObject()\n");
	#endif

	if( NewObject->isOfType( "fTabItem") == false)
	{
		delete NewObject;
		return;
	}

	fTabItem *NewTabItem = dynamic_cast<fTabItem *>( NewObject);

	NewTabItem->setParent( this);
	NewTabItem->setView( getView());
	NewTabItem->setInset( fInset);
	if( getEnabled() == false)
		NewTabItem->setEnabled( false);

	fObjects.AddItem( NewTabItem);

	if( fActiveItem == NULL)
	{
		fActiveItem = NewTabItem;
		fActiveItem->setActive( true);
	}

	// if the object is attached to a window, tell the new child object
	if( fParentWindow)
		NewObject->attachedToWindow( fParentWindow);

	updateIfNeeded();

	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::addObject() end\n");
	#endif
}

void fTabGroup::removeObject( fObject *OldObject)
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::removeObject()\n");
	#endif

	if( OldObject == fActiveItem)
	{
		if( fObjects.CountItems())
			setActiveItem( static_cast<fTabItem *>( fObjects.ItemAt(( int32) 0)));
		else
			setActiveItem( NULL);
	}

	fObjects.RemoveItem( OldObject);

	OldObject->setParent( NULL);
	OldObject->setView( NULL);

	if( fParentWindow)
		OldObject->detachedFromWindow();

	updateIfNeeded();

	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::removeObject() end\n");
	#endif
}

void fTabGroup::setSpacing( float /*NewSpacing*/)
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::setSpacing()\n");
	#endif

	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::setSpacing() end\n");
	#endif
}

void fTabGroup::setBorders( float NewBorder)
{
	fObject::setBorders( NewBorder);

	int32 Item = 0;
	fTabItem *TempObject;

	while(( TempObject = static_cast<fTabItem *>( fObjects.ItemAt( Item++))) != NULL)
		if( TempObject->getObject())
			TempObject->getObject()->setBorders( NewBorder);

	updateIfNeeded();
}

void fTabGroup::setHorizontalBorder( float NewHorizontalBorder)
{
	fObject::setHorizontalBorder( NewHorizontalBorder);

	int32 Item = 0;
	fTabItem *TempObject;

	while(( TempObject = static_cast<fTabItem *>( fObjects.ItemAt( Item++))) != NULL)
		if( TempObject->getObject())
			TempObject->getObject()->setHorizontalBorder( NewHorizontalBorder);

	updateIfNeeded();
}

void fTabGroup::setVerticalBorder( float NewVerticalBorder)
{
	fObject::setVerticalBorder( NewVerticalBorder);

	int32 Item = 0;
	fTabItem *TempObject;

	while(( TempObject = static_cast<fTabItem *>( fObjects.ItemAt( Item++))) != NULL)
		if( TempObject->getObject())
			TempObject->getObject()->setVerticalBorder( NewVerticalBorder);

	updateIfNeeded();
}

void fTabGroup::setView( BView *NewView)
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::setView()\n");
	#endif

	fObject::setView( NewView);

	int32 Item = 0;
	fTabItem *TempObject;

	while(( TempObject = static_cast<fTabItem *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->setView( NewView);

	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::setView() end\n");
	#endif
}

void fTabGroup::setInset( float NewInset)
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::setInset()\n");
	#endif

	fInset = NewInset;

	int32 Item = 0;
	fTabItem *TempObject;

	// set new inset on all tabitems
	while(( TempObject = static_cast<fTabItem *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->setInset( fInset);

	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::setInset() end\n");
	#endif
}

void fTabGroup::setFont( const BFont *Font)
{
	int32 Item = 0;
	fObject *TempObject;

	// set new font for all tabitems
	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->setFont( Font);

	updateIfNeeded();
}

void fTabGroup::setActiveItem( fTabItem *NewActive)
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::setActive()\n");
	#endif

	if( fActiveItem == NewActive)
		return;

	fActiveItem = NewActive;

	int32 Item = 0;
	fTabItem *TempObject;
	
	while(( TempObject = static_cast<fTabItem *>( fObjects.ItemAt( Item++))) != NULL)
		TempObject->setActive( false);
	
	if( fActiveItem)
		fActiveItem->setActive( true);

	setSize( getSize());

	redraw( getObjectFrame());
//	if( getView())
//		getView()->Invalidate( getObjectFrame());

	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::setActive() end\n");
	#endif
}

void fTabGroup::messageReceived( int32 Event, BMessage *Message)
{
    #if FTABGROUP_DEBUG > 1
    fprintf( stderr, "fTabGroup::messageReceived()\n");
    #endif

	switch( Event)
	{
		case F_ACTIVATE_ITEM:
		{
			fObject *SourcePointer = NULL;
			
			if( Message->FindPointer( "fSourcePointer", reinterpret_cast<void **>( &SourcePointer)) < B_OK)
			{
				#if FTABGROUP_DEBUG > 3
				fprintf( stderr, "fTabGroup::messageReceived() Error getting fSourcePointer!\n");
				#endif
			
				const char *SourceName = Message->FindString( "fSourceName");

				if( SourceName == NULL)
				{
					#if FTABGROUP_DEBUG > 3
					fprintf( stderr, "fTabGroup::messageReceived() Error getting fSourceName!\n");
					#endif
			
					return;
				}
				
				SourcePointer = const_cast<fObject *>( findObject( SourceName));
			}

			if( SourcePointer)
			{
				if( SourcePointer->isOfType( "fTabItem"))
					setActiveItem( dynamic_cast<fTabItem *>(  SourcePointer));
			}
		}
		break;

		default:
		{
			fBaseGroup::messageReceived( Event, Message);
		}
		break;
	}

    #if FTABGROUP_DEBUG > 1
    fprintf( stderr, "fTabGroup::messageReceived() end\n");
    #endif
}

const fObject *fTabGroup::containsPoint( const fPoint &Point) const
{
	#if FTABGROUP_DEBUG > 4
	fprintf( stderr, "fTabGroup::containsPoint()\n");
	#endif

	if( fObject::containsPoint( Point) == NULL)
		return( NULL);

	int32 Item = 0;
	fTabItem *TempObject;

	while(( TempObject = static_cast<fTabItem *>( fObjects.ItemAt( Item++))) != NULL)
	{
		const fObject *TempObject2 = TempObject->containsPoint( Point);

		if( TempObject2)
			return( TempObject2);
	}
	
	return( this);

	#if FTABGROUP_DEBUG > 4
	fprintf( stderr, "fTabGroup::containsPoint() end\n");
	#endif
}

void fTabGroup::drawObject( const BRegion &ClippingRegion, bool FullUpdate) const
{
	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::draw()\n");
	#endif

	if( getView() == NULL)
		return;

	BRect Frame = getObjectFrame();

	Frame.InsetBy( getHorizontalBorder(), getVerticalBorder());

	if( Frame.IsValid() == false)
	{
		#if FTABGROUP_DEBUG > 3
		fprintf( stderr, "fTabGroup::draw() Drawing to ");
		Frame.PrintToStream();
		#endif

		return;
	}

	if( getView()->Window() == NULL)
		return;

	if( getView()->Window()->Lock() == false)
		return;

	// set drawing environment
	getView()->SetDrawingMode( B_OP_COPY);

	// set background color if not already set
	if( getBackgroundColor() != getView()->LowColor())
		getView()->SetLowColor( getBackgroundColor());

	// Clear background if there is no parent or if the backgroundcolors differ
//	if(( getParent() == NULL) || ( getParent()->getBackgroundColor() != getBackgroundColor()))
		getView()->FillRect( Frame, B_SOLID_LOW);

	getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));

	// save state
	getView()->PushState();

	#if FTABGROUP_DEBUG > 3
	fprintf( stderr, "fTabGroup::draw() %d items to draw.\n", fObjects.CountItems());
	#endif

    getView()->SetPenSize( 1.0);

	fTabItem *TempObject;

	// Draw all items except for the active one
	int32 Item = fObjects.CountItems() - 1;

	while(( TempObject = static_cast<fTabItem *>( fObjects.ItemAt( Item--))) != NULL)
	{
		if( TempObject != fActiveItem)
		{
			#if FTABGROUP_DEBUG > 3
			fprintf( stderr, "fTabGroup::draw() Drawing tab %d. Size: ", Item + 1);
			TempObject->getSize().PrintToStream();
			#endif
			
			if( ClippingRegion.Intersects( TempObject->getObjectFrame()))
			{
//				getView()->PopState();
//				getView()->PushState();
				getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));
				if( FullUpdate)
					TempObject->setClippingRegion( ClippingRegion);
				TempObject->drawObject( ClippingRegion, FullUpdate);
			}
		}

	}

	// Draw the active item and the object it manages
	if( fActiveItem)
	{
		#if FTABGROUP_DEBUG > 3
		fprintf( stderr, "fTabGroup::draw() Drawing active tab.\n");
		#endif

		if( ClippingRegion.Intersects( fActiveItem->getObjectFrame()))
		{
//			getView()->PopState();
//			getView()->PushState();
			getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));
			if( FullUpdate)
				fActiveItem->setClippingRegion( ClippingRegion);
			fActiveItem->drawObject( ClippingRegion, FullUpdate);
		}

		if( fActiveItem->getObject())
			if( ClippingRegion.Intersects( fActiveItem->getObject()->getObjectFrame()))
			{
//				getView()->PopState();
//				getView()->PushState();
				getView()->ConstrainClippingRegion( new BRegion( ClippingRegion));
				if( FullUpdate)
					fActiveItem->getObject()->setClippingRegion( ClippingRegion);
				fActiveItem->getObject()->drawObject( ClippingRegion, FullUpdate);
			}
	}

	// restore state
	getView()->PopState();

	getView()->ConstrainClippingRegion( NULL);

	if( getView()->Window())
		getView()->Window()->Unlock();

	#if FTABGROUP_DEBUG > 1
	fprintf( stderr, "fTabGroup::draw() end\n");
	#endif
}
