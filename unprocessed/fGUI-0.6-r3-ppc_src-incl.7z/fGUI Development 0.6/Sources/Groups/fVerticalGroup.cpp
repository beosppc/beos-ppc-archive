// fVerticalGroup.cpp

#include "fVerticalGroup.h"
#include "fFactory.h"

#if DEBUG > 0
#define FVGROUP_DEBUG DEBUG
#endif
 
//#undef FVGROUP_DEBUG
//#define FVGROUP_DEBUG 5

ClassDefinition( fVerticalGroup, fBaseGroup, "");

fVerticalGroup::fVerticalGroup( void)
{
	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::fVerticalGroup()\n");
	#endif

	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::fVerticalGroup() end\n");
	#endif
}

fVerticalGroup::~fVerticalGroup( void)
{
	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::~fVerticalGroup()\n");
	#endif

	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::~fVerticalGroup() end\n");
	#endif
}

void fVerticalGroup::calculateMinimumSize( void)
{
	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::calculateMinimumSize()\n");
	#endif

	fPoint Size;

	int32 Item = 0;
	const fObject *TempObject;
	
	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		fPoint minSize = TempObject->getMinimumSize();
		fPoint prefSize = TempObject->getPreferredSize();

		// add the height of the object
		if( TempObject->getVerticalWeight() == 0)
			Size.y += prefSize.y;
		else
			Size.y += minSize.y;

		float temp;

		// get width of the object
		if( TempObject->getHorizontalWeight() == 0)
			temp = prefSize.x;
		else
			temp = minSize.x;

		// if wider than previous width, take the new width
		if( temp > Size.x)
			Size.x = temp;
	}
	
	// Add spacing for objects	
	if( --Item)
		Size.y += fSpacing * ( Item - 1);

	setMinimumSize( Size);

	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::calculateMinimumSize() end\n");
	#endif
}

void fVerticalGroup::calculateMaximumSize( void)
{
	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::calculateMaximumSize()\n");
	#endif

	fPoint Size;

	int32 Item = 0;
	const fObject *TempObject;
	fPoint TempSize;
	
	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		fPoint prefSize = TempObject->getPreferredSize();
		fPoint maxSize = TempObject->getMaximumSize();

		// add the height of the object
		if( TempObject->getVerticalWeight() == 0)
			Size.y += prefSize.y;
		else
			Size.y += maxSize.y;

		float temp;

		// get width of the object
		if( TempObject->getHorizontalWeight() == 0)
			temp = prefSize.x;
		else
			temp = maxSize.x;

		// if wider than previous width, take the new width
		if( temp > Size.x)
			Size.x = temp;
	}

	// Add spacing for objects	
	if( --Item)
		Size.y += fSpacing * ( Item - 1);

	setMaximumSize( Size);

	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::calculateMaximumSize() end\n");
	#endif
}

void fVerticalGroup::calculatePreferredSize( void)
{
	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::calculatePreferredSize()\n");
	#endif

	fPoint Size;

	int32 Item = 0;
	const fObject *TempObject;
	fPoint TempSize;
	
	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		TempObject->getPreferredSize( TempSize);
		
		Size.y += TempSize.y;

		if( TempSize.x > Size.x)
			Size.x = TempSize.x;
	}

	// Add spacing for objects	
	if( --Item)
		Size.y += fSpacing * ( Item - 1);

	setPreferredSize( Size);

	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::calculatePreferredSize() end\n");
	#endif
}

void fVerticalGroup::setSize( const fPoint &SetSize)
{
	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::setSize()\n");
	#endif

	fObject::setSize( SetSize);

	fPoint Borders( getHorizontalBorder(), getVerticalBorder());

	fPoint NewSize = SetSize;

	NewSize -= Borders;
	NewSize -= Borders;

	float NewWidth	= NewSize.x;
	float NewHeight	= NewSize.y;

	int32 Item = 0;
	fObject *SomeObject;

	int32 ItemCount = fObjects.CountItems();

	if( ItemCount == 0)
		return;

	// Zwischen allen Objekten fSpacing Zwischenraum lassen...
	NewHeight -= ( ItemCount - 1) * fSpacing;
		
	#if FVGROUP_DEBUG > 3
	fprintf( stderr, "fVerticalGroup::setSize() %d Items to layout. Layoutsize: ", ItemCount);
	NewSize.PrintToStream();
	#endif

	fPoint *Sizes = new fPoint[ ItemCount];
	fPoint *Positions = new fPoint[ ItemCount];

	float TotalWeight = 0.0;
	
	// 1. Durchgang:	Objekte mit Weight == 0 mit Preferred Size bewerten
	//				Diese Objekte zentrieren in x-Richtung
	//				Gewichte addieren

	#if FVGROUP_DEBUG > 3
	fprintf( stderr, "fVerticalGroup::setSize() Pass 1\n");
	#endif

	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		if( SomeObject->getVerticalWeight() == 0)
		{
			// set vertical size, subtract object height from total height
			Sizes[ Item].y = SomeObject->getPreferredSize().y;
			NewHeight -= Sizes[ Item].y;

			#if FVGROUP_DEBUG > 3
			fprintf( stderr, "fVerticalGroup::setSize() Setting Object %d Size to:", Item);
			Sizes[Item].PrintToStream();
			#endif
		}
		else
			TotalWeight += SomeObject->getVerticalWeight();
	}

	// 2. Durchgang:	Objekte, die eine Groesse </> ihrer min/max-Size bekommen
	//				wuerden bekommen min/max-Size

	#if FVGROUP_DEBUG > 3
	fprintf( stderr, "fVerticalGroup::setSize() Pass 2\n");
	#endif

	bool minmaxfound = true;

	while( minmaxfound)
	{
		minmaxfound = false;
		
		for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
		{
			// Noch keine Groesse zugewiesen ?
			if( Sizes[ Item].y == 0.0)
			{
				float ObjectHeight = NewHeight * SomeObject->getVerticalWeight() / TotalWeight;
				
				fPoint minSize = SomeObject->getMinimumSize();
				fPoint maxSize = SomeObject->getMaximumSize();
								
				if( ObjectHeight < minSize.y)
				{
					#if FVGROUP_DEBUG > 3
					fprintf( stderr, "fVerticalGroup::setSize() Object %d: ObjectHeight < minSize.y\n", Item);
					#endif

					minmaxfound = true;

					NewHeight -= minSize.y;
					TotalWeight -= SomeObject->getVerticalWeight();
					
					Sizes[ Item].y = minSize.y;
				}
				else if( ObjectHeight > maxSize.y)
				{
					#if FVGROUP_DEBUG > 3
					fprintf( stderr, "fVerticalGroup::setSize() Object %d: ObjectHeight > maxSize.y\n", Item);
					#endif

					minmaxfound = true;

					NewHeight -= maxSize.y;
					TotalWeight -= SomeObject->getVerticalWeight();
					
					Sizes[ Item].y = maxSize.y;
				}
			}
		}
	}

	// 3.Durchgang:	Allen uebrigen Objekten beliebige Groesse zuweisen.

	#if FVGROUP_DEBUG > 3
	fprintf( stderr, "fVerticalGroup::setSize() Pass 3\n");
	#endif

	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		// Noch keine Groesse zugewiesen ?
		if( Sizes[ Item].y == 0.0)
		{
			#if FVGROUP_DEBUG > 3
			fprintf( stderr, "fVerticalGroup::setSize() Calculating size for Object: %d\n", Item);
			#endif

			Sizes[ Item].y = NewHeight * SomeObject->getVerticalWeight() / TotalWeight;
		}
	}

	#if FVGROUP_DEBUG > 3
	fprintf( stderr, "fVerticalGroup::setSize() Pass 4\n");
	#endif

	// Run 4:		Calculate horizontal sizes and positions.
	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		fPoint maxSize = SomeObject->getMaximumSize();

		// if horizontalweight == 0 set size to preferred size and center
		// else set to new width if not > max width
		if( SomeObject->getHorizontalWeight() == 0)
			Sizes[ Item].x = SomeObject->getPreferredSize().x;
		else
		{
			if( NewWidth > maxSize.x)
				Sizes[ Item].x = maxSize.x;				
			else
				Sizes[ Item].x = NewWidth;
		}

		// align object horizontally
		switch( SomeObject->getHorizontalAlignment())
		{
			case fObject::F_HALIGN_LEFT:
				break;
			
			case fObject::F_HALIGN_CENTER:
				Positions[ Item].x = ( NewWidth - Sizes[ Item].x) / 2;
				break;
			
			case fObject::F_HALIGN_RIGHT:
				Positions[ Item].x = NewWidth - Sizes[ Item].x;
				break;
		}

		#if FVGROUP_DEBUG > 3
		fprintf( stderr, "fVerticalGroup::setSize() Setting vertical size for object %d to %f\n", Item, Sizes[ Item].y);
		fprintf( stderr, "fVerticalGroup::setSize() Setting horizontal size for object %d to %f\n", Item, Sizes[ Item].x);
		#endif
	}

	// Run 5: Set size and position
	#if FVGROUP_DEBUG > 3
	fprintf( stderr, "fVerticalGroup::setSize() Pass 5\n");
	#endif

	float topPosition = 0.0;

	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		#if FVGROUP_DEBUG > 3
		fprintf( stderr, "fVerticalGroup::setSize() Setting Object %d Size to: ", Item);
		Sizes[Item].PrintToStream();
		fprintf( stderr, "fVerticalGroup::setSize() Setting Object %d Position to: ", Item);
		(getPosition() + fPoint( Positions[ Item].x, topPosition) + Borders).PrintToStream();
		#endif

//		Sizes[ Item].roundToInteger();
		SomeObject->setSize( Sizes[ Item]);
		SomeObject->setPosition( getPosition() + fPoint( Positions[ Item].x, topPosition) + Borders);
		
		topPosition += Sizes[ Item].y + fSpacing;
	}

	delete [] Sizes;
	delete [] Positions;

	#if FVGROUP_DEBUG > 1
	fprintf( stderr, "fVerticalGroup::setSize() end\n");
	#endif
}