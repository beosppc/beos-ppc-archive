// fGroup.cpp

#include "fGroup.h"

#if DEBUG > 0
#define FGROUP_DEBUG DEBUG
#endif
 
//#undef FGROUP_DEBUG

VirtualClassDefinition( fGroup, fObject);

fGroup::fGroup( void)
{
}

fGroup::~fGroup( void)
{
}

DoMethodBegin( fGroup)
	DoMethodDefinitionBegin( "Child", addObject, 1)
		DoMethodVariableCast( fObject *, fClassInfo *, NewObject)
		DoMethodVoidCall( addObject)( NewObject)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "InsertObject", insertObject, 2)
		DoMethodVariableCast( fObject *, fClassInfo *, NewObject)
		DoMethodVariable( int32, Position)
		DoMethodVoidCall( insertObject)( NewObject, Position)
	DoMethodDefinitionEnd
	
	DoMethodDefinitionBegin( "InsertObjectAfter", insertObjectAfter, 2)
		DoMethodVariableCast( fObject *, fClassInfo *, NewObject)
		DoMethodVariableCast( fObject *, fClassInfo *, OtherObject)
		DoMethodVoidCall( insertObjectAfter)( NewObject, OtherObject)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "InsertObjectBefore", insertObjectBefore, 2)
		DoMethodVariableCast( fObject *, fClassInfo *, NewObject)
		DoMethodVariableCast( fObject *, fClassInfo *, OtherObject)
		DoMethodVoidCall( insertObjectBefore)( NewObject, OtherObject)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "RemoveObject", removeObject, 1)
		DoMethodVariableCast( fObject *, fClassInfo *, OldObject)
		DoMethodVoidCall( removeObject)( OldObject)
	DoMethodDefinitionEnd

	DoMethodDefinitionBegin( "Spacing", setSpacing, 1)
		DoMethodVariable( float, NewSpacing)
		DoMethodVoidCall( setSpacing)( NewSpacing)
	DoMethodDefinitionEnd
DoMethodEnd( fObject)


