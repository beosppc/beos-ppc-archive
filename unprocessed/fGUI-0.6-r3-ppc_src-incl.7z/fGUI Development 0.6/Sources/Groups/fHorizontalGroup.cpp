// fHorizontalGroup.cpp

#include "fHorizontalGroup.h"
#include "fFactory.h"

#if DEBUG > 0
#define FHGROUP_DEBUG DEBUG
#endif
 
//#undef FHGROUP_DEBUG
//#define FHGROUP_DEBUG 4

ClassDefinition( fHorizontalGroup, fBaseGroup, "");

fHorizontalGroup::fHorizontalGroup( void)
{
	#if FHGROUP_DEBUG > 0
	fprintf( stderr, "fHorizontalGroup::fHorizontalGroup()\n");
	#endif

	#if FHGROUP_DEBUG > 0
	fprintf( stderr, "fHorizontalGroup::fHorizontalGroup() end\n");
	#endif
}

fHorizontalGroup::~fHorizontalGroup( void)
{
	#if FHGROUP_DEBUG > 0
	fprintf( stderr, "fHorizontalGroup::~fHorizontalGroup()\n");
	#endif

	#if FHGROUP_DEBUG > 0
	fprintf( stderr, "fHorizontalGroup::~fHorizontalGroup end()\n");
	#endif
}

void fHorizontalGroup::calculateMinimumSize( void)
{
	#if FHGROUP_DEBUG > 1
	fprintf( stderr, "fHorizontalGroup::calculateMinimumSize()\n");
	#endif
	
	fPoint Size;

	int32 Item = 0;
	const fObject *TempObject;
	
	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		fPoint minSize = TempObject->getMinimumSize();
		fPoint prefSize = TempObject->getPreferredSize();

		// add the width of the object
		if( TempObject->getHorizontalWeight() == 0)
			Size.x += prefSize.x;
		else
			Size.x += minSize.x;

		float temp;

		// get height of the object
		if( TempObject->getVerticalWeight() == 0)
			temp = prefSize.y;
		else
			temp = minSize.y;

		// if higher than previous height, take the new height
		if( temp > Size.y)
			Size.y = temp;
	}

	// Add spacing for objects	
	if( --Item)
		Size.x += fSpacing * ( Item - 1);

	setMinimumSize( Size);

	#if FHGROUP_DEBUG > 1
	fprintf( stderr, "fHorizontalGroup::calculateMinimumSize() end\n");
	#endif
}

void fHorizontalGroup::calculatePreferredSize( void)
{
	#if FHGROUP_DEBUG > 1
	fprintf( stderr, "fHorizontalGroup::calculatePreferredSize()\n");
	#endif

	fPoint Size;

	int32 Item = 0;
	const fObject *TempObject;
	fPoint TempSize;
	
	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		TempObject->getPreferredSize( TempSize);
		
		Size.x += TempSize.x;

		if( TempSize.y > Size.y)
			Size.y = TempSize.y;
	}

	// Add spacing for objects	
	if( --Item)
		Size.x += fSpacing * ( Item - 1);

	setPreferredSize( Size);

	#if FHGROUP_DEBUG > 1
	fprintf( stderr, "fHorizontalGroup::calculatePreferredSize() end\n");
	#endif
}

void fHorizontalGroup::calculateMaximumSize( void)
{
	#if FHGROUP_DEBUG > 1
	fprintf( stderr, "fHorizontalGroup::calculateMaximumSize()\n");
	#endif

	fPoint Size;

	int32 Item = 0;
	const fObject *TempObject;
	fPoint TempSize;
	
	while(( TempObject = static_cast<fObject *>( fObjects.ItemAt( Item++))) != NULL)
	{
		fPoint prefSize = TempObject->getPreferredSize();
		fPoint maxSize = TempObject->getMaximumSize();

		// add the width of the object
		if( TempObject->getHorizontalWeight() == 0)
			Size.x += prefSize.x;
		else
			Size.x += maxSize.x;

		float temp;

		// get height of the object
		if( TempObject->getVerticalWeight() == 0)
			temp = prefSize.y;
		else
			temp = maxSize.y;

		// if higher than previous height, take the new height
		if( temp > Size.y)
			Size.y = temp;
	}

	// Add spacing for objects	
	if( --Item)
		Size.x += fSpacing * ( Item - 1);

	setMaximumSize( Size);

	#if FHGROUP_DEBUG > 1
	fprintf( stderr, "fHorizontalGroup::calculateMaximumSize() end\n");
	#endif
}

void fHorizontalGroup::setSize( const fPoint &Size)
{
	#if FHGROUP_DEBUG > 1
	fprintf( stderr, "fHorizontalGroup::setSize()\n");
	#endif

	fObject::setSize( Size);

	fPoint Borders( getHorizontalBorder(), getVerticalBorder());

	fPoint NewSize = Size;

	NewSize -= Borders;
	NewSize -= Borders;

	float NewWidth	= NewSize.x;
	float NewHeight	= NewSize.y;

	int32 Item = 0;
	fObject *SomeObject;

	int32 ItemCount = fObjects.CountItems();

	if( ItemCount == 0)
		return;

	// Zwischen allen Objekten fSpacing Zwischenraum lassen...
	NewWidth -= ( ItemCount - 1) * fSpacing;

	#if FHGROUP_DEBUG > 3
	fprintf( stderr, "fHorizontalGroup::setSize() %d Items to layout. Layoutsize: ", ItemCount);
	NewSize.PrintToStream();
	#endif

	fPoint *Sizes		= new fPoint[ ItemCount];
	fPoint *Positions	= new fPoint[ ItemCount];

	float TotalWeight = 0.0;
	
	// Run 1:		Use preferred size for objekts with HorizontalWeight == 0
	//			center these objects (if vertical weight == 0)
	//			add weights

	#if FHGROUP_DEBUG > 3
	fprintf( stderr, "fHorizontalGroup::setSize() Pass 1\n");
	#endif

	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		if( SomeObject->getHorizontalWeight() == 0)
		{
			// set horizontal size, subtract object width from total width
			Sizes[ Item].x = SomeObject->getPreferredSize().x;
			NewWidth -= Sizes[ Item].x;

			#if FHGROUP_DEBUG > 3
			fprintf( stderr, "fHorizontalGroup::setSize() HorizontalWeight == 0 -> Setting Object %d Size to:", Item);
			Sizes[Item].PrintToStream();
			#endif
		}
		else
			TotalWeight += SomeObject->getHorizontalWeight();
	}

	// Run 2:		Objects which should get a size smaller or bigger than their min/max size
	//			will be set to min/max size, respectively.

	#if FHGROUP_DEBUG > 3
	fprintf( stderr, "fHorizontalGroup::setSize() Pass 2\n");
	#endif

	bool minmaxfound = true;

	while( minmaxfound)
	{
		minmaxfound = false;
		
		for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
		{
			// Noch keine Groesse zugewiesen ?
			if( Sizes[ Item].x == 0.0)
			{
				float ObjectWidth = NewWidth * SomeObject->getHorizontalWeight() / TotalWeight;
				
				fPoint minSize = SomeObject->getMinimumSize();
				fPoint maxSize = SomeObject->getMaximumSize();
								
				if( ObjectWidth < minSize.x)
				{
					#if FHGROUP_DEBUG > 3
					fprintf( stderr, "fHorizontalGroup::setSize() Object %d: ObjectWidth < minSize.x\n", Item);
					#endif

					minmaxfound = true;

					NewWidth -= minSize.x;
					TotalWeight -= SomeObject->getHorizontalWeight();
					
					Sizes[ Item].x = minSize.x;
				}
				else if( ObjectWidth > maxSize.x)
				{
					#if FHGROUP_DEBUG > 3
					fprintf( stderr, "fHorizontalGroup::setSize() Object %d: ObjectWidth > maxSize.x\n", Item);
					#endif

					minmaxfound = true;

					NewWidth -= maxSize.x;
					TotalWeight -= SomeObject->getHorizontalWeight();
					
					Sizes[ Item].x = maxSize.x;
				}
			}
		}
	}

	// 3.Durchgang:	Allen uebrigen Objekten beliebige Groesse zuweisen.

	#if FHGROUP_DEBUG > 3
	fprintf( stderr, "fHorizontalGroup::setSize() Pass 3\n");
	#endif

	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		// Noch keine Groesse zugewiesen ?
		if( Sizes[ Item].x == 0.0)
		{
			#if FHGROUP_DEBUG > 3
			fprintf( stderr, "fHorizontalGroup::setSize() Calculating size for Object: %d\n", Item);
			#endif

			Sizes[ Item].x = NewWidth * SomeObject->getHorizontalWeight() / TotalWeight;
		}
	}

	#if FHGROUP_DEBUG > 3
	fprintf( stderr, "fHorizontalGroup::setSize() Pass 4\n");
	#endif

	// Run 4:		Calculate vertical sizes and positions.
	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		fPoint maxSize = SomeObject->getMaximumSize();

		// if verticalweight == 0 set size to preferred size and center
		// else set to new height if not > max height
		if( SomeObject->getVerticalWeight() == 0)
			Sizes[ Item].y = SomeObject->getPreferredSize().y;
		else
		{
			if( NewHeight > maxSize.y)
				Sizes[ Item].y = maxSize.y;				
			else
				Sizes[ Item].y = NewHeight;
		}

		// align object vertically
		switch( SomeObject->getVerticalAlignment())
		{
			case fObject::F_VALIGN_TOP:
				break;
			
			case fObject::F_VALIGN_CENTER:
				Positions[ Item].y = ( NewHeight - Sizes[ Item].y) / 2;
				break;
			
			case fObject::F_VALIGN_BOTTOM:
				Positions[ Item].y = NewHeight - Sizes[ Item].y;
				break;
		}

		#if FHGROUP_DEBUG > 3
		fprintf( stderr, "fHorizontalGroup::setSize() Setting vertical size for object %d to %f\n", Item, Sizes[ Item].y);
		#endif
	}

	// Run 5: Set size and position
	#if FHGROUP_DEBUG > 3
	fprintf( stderr, "fHorizontalGroup::setSize() Pass 5\n");
	#endif

	float leftPosition = 0.0;

	for( Item = 0; ( SomeObject = static_cast<fObject *>( fObjects.ItemAt( Item))) != NULL; Item++)
	{
		#if FHGROUP_DEBUG > 3
		fprintf( stderr, "fHorizontalGroup::setSize() Setting Object %d Size to: ", Item);
		Sizes[Item].PrintToStream();
		fprintf( stderr, "fHorizontalGroup::setSize() Setting Object %d Position to: ", Item);
		(fPoint( getPosition() + fPoint( leftPosition, Positions[ Item].y) + Borders)).PrintToStream();
		#endif

//		Sizes[ Item].roundToInteger();
		SomeObject->setSize( Sizes[ Item]);
		SomeObject->setPosition( getPosition() + fPoint( leftPosition, Positions[ Item].y) + Borders);
		
		leftPosition += Sizes[ Item].x + fSpacing;

		#if FHGROUP_DEBUG > 3
		fprintf( stderr, "fHorizontalGroup::setSize() CHECK: Object %d rectangle: ", Item);
		SomeObject->getObjectFrame().PrintToStream();
		#endif
	}

	delete [] Sizes;
	delete [] Positions;

	#if FHGROUP_DEBUG > 1
	fprintf( stderr, "fHorizontalGroup::setSize() end\n");
	#endif
}