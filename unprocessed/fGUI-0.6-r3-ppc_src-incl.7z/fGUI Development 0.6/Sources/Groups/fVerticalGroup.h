// fVerticalGroup.h

#ifndef fVerticalGroup_h
#define fVerticalGroup_h

#include "fBaseGroup.h"

#pragma export on

class fVerticalGroup : public fBaseGroup
{
	private:

		fVerticalGroup( const fVerticalGroup &CopyObject);
		fVerticalGroup &operator=( const fVerticalGroup &CopyObject);

//		static const char * const fClassName;

		ClassDeclaration( fVerticalGroup);

	protected:

		virtual void calculateMinimumSize( void);
		virtual void calculatePreferredSize( void);
		virtual void calculateMaximumSize( void);

	public:

		fVerticalGroup( void);
		virtual ~fVerticalGroup( void);

		virtual void setSize( const fPoint &NewSize);
};

#pragma export off

#endif
