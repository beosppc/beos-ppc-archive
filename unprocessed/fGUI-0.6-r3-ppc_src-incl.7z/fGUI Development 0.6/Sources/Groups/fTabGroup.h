// fTabGroup.h

#ifndef fTabGroup_h
#define fTabGroup_h

#include "fBaseGroup.h"
#include "fTabItem.h"

#pragma export on

class fTabGroup : public fBaseGroup
{
	private:

		fTabGroup( const fTabGroup &CopyObject);
		fTabGroup &operator=( const fTabGroup &CopyObject);

		VirtualClassDeclaration( fTabGroup);

	protected:

		float		 fInset;

		fTabItem	*fActiveItem;

	public:

		fTabGroup( void);
		virtual ~fTabGroup( void);

		virtual void addObject( fObject *NewObject);
		virtual void removeObject( fObject *OldObject);
		
		virtual void setSpacing( float NewSpacing);

		virtual void setBorders( float NewBorder);
		virtual void setHorizontalBorder( float NewHorizontalBorder);
		virtual void setVerticalBorder( float NewVerticalBorder);

		virtual void setView( BView *NewView);

		virtual void setInset( float NewInset);
		virtual void setFont( const BFont *Font);

		virtual void setActiveItem( fTabItem *NewActive);

		virtual void messageReceived( int32 Event, BMessage *Message);
		virtual const fObject *containsPoint( const fPoint &Point) const;

		virtual void drawObject( const BRegion &ClippingRegion, bool FullUpdate) const;
};

#pragma export off

#endif
