/*
	
	HelloView.h
	
	Copyright 1995 Be Incorporated, All Rights Reserved.
	
	Modified by jeremy Moskovich 20-feb-96
	Jeremy@shape.co.il
*/

#ifndef HELLO_VIEW_H
#define HELLO_VIEW_H

#ifndef _VIEW_H
#include <View.h>
#endif

class HelloView : public BView {

public:
				HelloView(BRect frame, char *name); 
virtual	void	AttachedToWindow();
virtual	void	Draw(BRect updateRect);
void			SetMyString( char *Str );

private:
char *theString; //String to display
};

#endif
