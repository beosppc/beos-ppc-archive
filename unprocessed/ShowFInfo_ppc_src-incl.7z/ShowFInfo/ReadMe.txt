2-feb-96
Jeremy Moskovich,
Digital Reality Studios

E-Mail:Jeremy@shape.co.il

Hi,
   enclosed is a simple program for displaying the type and creator of a file
dragged onto it.
	The source code is a simple adaptation of the "Hello World" program 
included with dr6.