/*
	
	HelloWindow.cpp
	
	Copyright 1995 Be Incorporated, All Rights Reserved.
	
	Modified by jeremy Moskovich 20-feb-96
	Jeremy@shape.co.il
	
*/

#ifndef _APPLICATION_H
#include <Application.h>
#endif

#ifndef HELLO_WINDOW_H
#include "HelloWindow.h"
#endif

HelloWindow::HelloWindow(BRect frame)
				: BWindow(frame, "File Dropped", B_TITLED_WINDOW, B_NOT_RESIZABLE)
{
}

bool HelloWindow::QuitRequested()
{
	be_app->PostMessage(B_QUIT_REQUESTED);
	return(TRUE);
}
