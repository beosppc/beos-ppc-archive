	/*
	
	TypeChecker.h
	
	Copyright 1996 Jeremy Moskovich, Digital Reality Studios�
	20-feb-96
	
	Jeremy@shape.co.il
	
	A simple program that displays the type and creator of a file
	dragged onto it...

*/

#ifndef TYPE_CHANGER_H
#define TYPE_CHANGER_H

#ifndef _APPLICATION_H
#include <Application.h>
#endif



#include <File.h>


class ChangerApplication : public BApplication {

public:
					ChangerApplication();
	virtual void	RefsReceived( BMessage *message );
	virtual void	AboutRequested( void ) {beep();};
	
private:
	HelloWindow		*resultWindow;
	HelloView		*resultView;

};

#endif
