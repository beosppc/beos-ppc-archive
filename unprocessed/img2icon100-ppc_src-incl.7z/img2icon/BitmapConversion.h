// BitmapConversion.h
// © 1998 Matt Lewinski

// Convert a bitmap to type B_RGB_32_BIT.
BBitmap*	BitmapTo32(BBitmap* inBitmap);

// Convert a bitmap to type B_RGB_32_BIT.
BBitmap*	BitmapTo8(BBitmap* inBitmap);
