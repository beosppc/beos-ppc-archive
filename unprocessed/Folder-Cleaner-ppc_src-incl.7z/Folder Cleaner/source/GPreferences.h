#pragma once

#define G_PREFERENCES_NAME "Folder Cleanner Settings"

typedef struct
	{
	BRect rect;
	BPoint offset;
	} prefs_t;


class GPreferences
{
public:
	GPreferences();
	~GPreferences(void);
	void SetDefault(void);
private:
	BFile *config_file;
};
