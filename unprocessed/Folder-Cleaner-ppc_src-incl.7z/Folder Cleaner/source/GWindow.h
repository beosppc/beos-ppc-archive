#pragma once

enum
{
	G_DEFAULT_REQUESTED = 'defa',
	G_GO_REQUESTED = 'go  ',
};

class GWindow : public BWindow
{
public:
	GWindow(void);
	virtual bool QuitRequested(void);
	virtual void MessageReceived(BMessage *message);
	void Stop(void);
private:
	char buffer[2048];
	uint32 max;
	team_id id;
	BView *background ;
friend long Stack(void *a1);
};

void Recurse(BEntry *entry);
long Stack(void *a1);
//inline int Depth(char *path);
