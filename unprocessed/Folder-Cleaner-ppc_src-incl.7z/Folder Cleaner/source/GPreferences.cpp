#include "GPreferences.h"

prefs_t prefs;

GPreferences::GPreferences()
{
	BPath config_dir_path;
	config_file = new BFile();
	SetDefault();
	if(find_directory(B_USER_SETTINGS_DIRECTORY,&config_dir_path)==B_NO_ERROR)
	{
		BDirectory config_dir(config_dir_path.Path());
		if(config_dir.CreateFile(G_PREFERENCES_NAME,config_file,true) == B_FILE_EXISTS)
			{
			config_file = new BFile(&config_dir,G_PREFERENCES_NAME, B_READ_WRITE);
			config_file->ReadAttr(G_PREFERENCES_NAME,B_RAW_TYPE,0,&prefs,sizeof(prefs));
			}
	}
}

GPreferences :: ~GPreferences()
{
	config_file->WriteAttr(G_PREFERENCES_NAME,B_RAW_TYPE,0,&prefs,sizeof(prefs));
}

void GPreferences::SetDefault(void)
{
	prefs.rect = BRect(80,40,80+464,40+290);
	prefs.offset = BPoint(20,20);
}
