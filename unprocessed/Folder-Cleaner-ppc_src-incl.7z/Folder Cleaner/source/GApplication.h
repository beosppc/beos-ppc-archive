#pragma once

#include "GPreferences.h"

#define G_APPLICATION_SIGNATURE "application/x-guile.FolderCleaner"

class GApplication: public BApplication
{
public:
	GApplication();
	virtual void AboutRequested(void);
	virtual bool QuitRequested(void);
private:
};
