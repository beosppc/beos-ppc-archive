#include "GApplication.h"
#include "GPreferences.h"
#include "GWindow.h"

GPreferences *preferences;
GWindow *window;
void main(void)
{
	(new GApplication())->Run();
}

GApplication :: GApplication() : BApplication(G_APPLICATION_SIGNATURE)
{
	preferences = new GPreferences();
	window = new GWindow();
}

void GApplication::AboutRequested(void)
{
	(new BAlert(NULL,"Folder Cleanner 1.0\nGuillaume Lefevre","OK"))->Go();
}

bool GApplication :: QuitRequested(void)
{
	delete(preferences);
	return(true);
}
