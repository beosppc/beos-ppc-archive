=========================================================================
Magnetic Scrolls Interpreter V1.0 by Niclas Karlsson 1997
BeOS Version Release 1 by Tinic Uro <5uro@informatik.uni-hamburg.de>
BeOS Icon drawn by Tinic Uro (I hope it looks orginal)
=========================================================================

Introduction
-------------------------------------------------------------------------

	Finally you can play the great games of Magnetic Scrolls without
	the need of a real C64, Atari or Amiga emulator. This is a real 1.0 
	version, so dont expect too much from it. Many features are actually 
	missing, but I believe I will enhance the BeOS version so it will 
	be more useable.

	The following games are supported:
	
		- The Pawn
		- Guild of Thieves
		- Jinxter
		- Fish
		- Corruption
		- Myth

	Wonderland will probaly never work with this program since it
	uses a completly different system.


Requirements
-------------------------------------------------------------------------

	- BeOS Preview Release
	- Orginal Magnetic Scrolls games. Actually you can rip of the game 
	  data from C64 disk dumps and the graphics from Amiga disks.


How to use Magnetic
-------------------------------------------------------------------------

	To run Magnetic double click it. A filerequester will ask for a 
	gamefile. Magnetic will also look for a file in the same directory 
	with a .gfx extension (lowercase!), which should contain the graphics. 
	Ex.: 'game.mag' --> 'game.gfx' or 'ThePawn' --> 'ThePawn.gfx'
	The graphics files are not needed to play the games, but its a really
	nice plus for the athmosphere!
	
	If you want to drag files on the Magnetic icon to start them, you
	should first use the 'Identify' function after you unpacked the
	archive. Select the icon of Magnetic, go into the File menu of the 
	Tracker and select 'Identify'. I really dont know why this is 
	necessary, but it seems to work then...
	
	Magnetic can be also started from a terminal. Usage:
	
		Magnetic [options] gamefile [gfxfile]
			
	Options:
	
		-d[n]     activate registerdump (after n instructions)
		-r[name]  read script file
		-s[n]     safety mode, exits automatically (after n instructions)
		-t[name]  write transcript file
		-w[name]  write script file	
	
	A window should then be opened and you should be able to play
	the game. While playing there are actually two internal commands
	which can be used while playing:
	
		#undo     undo last move - don't use it near are_you_sure prompts
		#logoff   turn off script writing

		
How to create .mag anf .gfx files
-------------------------------------------------------------------------

	Actually you can only rip of the game data from the C64 versions.
	Just create two dumps of the disks (use the D64 format) and type:
	
		xtract64 disk1.d64 disk2.d64 story.mag
		
	To create a gfx file you need the files from a disk of an Amiga 
	version. Then just type
	
		gfxlink <path> story.gfx


Technical details
-------------------------------------------------------------------------

	Magnetic Scrolls games are in fact simple MC68000 programs. You 
	need an emulator to run the games. Yes, the C64 versions  
	emulated a MC68000 (This also explains the slow speed of the games ;-)!
	The programs itself have no idea in which environment they are.
	The connection to the outer world is done through LINE_A commands.

	The MS games (except Wonderland) only have limited funtionality 
	concerning the output. Unlike in Infocom/Z-Machine games you have 
	nearly no control over the cursor, fonts and styles which makes the 
	implementation quite easy. The text output is done through a 
	simple putchar(), the only special characters are backspace and
	linefeed.

	Personally I think Infocom had a much better and more advanced 
	system and this before Magnetic Scrolls existed! On the other
	hand their system allowed a fast and easy development, but I
	would personally prefer Inform/Z-Machine over C/68KASM 
	to create textadventures...
	
		
Sourcecode
-------------------------------------------------------------------------

	The sources can be even compiled with the limited linker. 
	The sources are actually completly free of charge and may be modifed 
	by anyone.

