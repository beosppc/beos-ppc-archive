Notes for these two files:

I actually have no idea about the situation of copyrights concerning 
Magnetic Scrolls games. AFAIK there is no one actually holding the
copyrights on them. When looking around on the net, I found rips of
the C64 disks on many places and I know some commercial CD collections
containing the disks. Since I dont get money with it I assume everything
should be okay when I distribute these two files.

To use these file, type 'Magnetic ThePawn.mag ThePawn.gfx &' in a terminal
or select the file 'ThePawn.mag' with the filerequester.

If you are looking for more C64 disks rips look at ftp://arnold.hiof.no/games/.
I found all Magnetic Scrolls games there. For the GFX files I actually
cant remember the right URL, but search for "Magnetic Scrolls" with
the AltaVista search engine (www.altavista.digital.com), thats the way 
I found them. I think it was on a page containg general informations about 
different text adventure creators. They are not needed to play the games. 
