// Copyright 1998, Patrick S. M. Gratton, All rights reserved.
// PierWindowBar.h --------------------------------------------------------
#pragma once

#include <View.h>

class PierWindowBar : public BView {
public:
	//Constructor
	PierWindowBar(BRect frame, const char* name);
	
	//Hook Functions
	virtual void	Draw(BRect updateRect);
	virtual void	WindowActivated(bool active);

private:
	bool	isActive;
	BMenu*	menu;
};
