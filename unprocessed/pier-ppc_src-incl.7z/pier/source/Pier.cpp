// Copyright 1998, Patrick S. M. Gratton, All rights reserved.
// Pier.cpp --------------------------------------------------------------
#include "PierApp.h"

main() {
	PierApp pierApp;
	pierApp.Run();
	return(0);
}
