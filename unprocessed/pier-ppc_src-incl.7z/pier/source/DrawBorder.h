// Copyright 1998, Patrick S. M. Gratton, All rights reserved.
// DrawBorder.h ------------------------------------------------------------
#pragma once

#include <View.h>

// Grey background colors
const rgb_color bg_color			= {216,216,216,255};
const rgb_color raise_color			= {255,255,255,255};
const rgb_color drop_color			= {194,194,194,255};

// Yellow title colors
const rgb_color title_color			= {255,203,  0,255};
const rgb_color title_raise_color	= {255,255,102,255};
const rgb_color title_drop_color	= {255,102,  0,255};

// Border
void DrawBorder(BView *view, bool raised = true, BRect frame = BRect(),
				rgb_color raise = raise_color, rgb_color drop = drop_color);
