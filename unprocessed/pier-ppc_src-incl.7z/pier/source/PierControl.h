// Copyright 1998, Patrick S. M. Gratton, All rights reserved.
// PierControl.h ============================================================
#pragma once
#include <Control.h>

// PierZoom =================================================================
class PierZoom : public BControl {
public:
private:
};

// PierClose ================================================================
class PierClose : public BControl {
public:
private:
};

// PierResize ===============================================================
class PierResize : public BControl {
public:
private:
};

// PierScrollUp =============================================================
class PierScrollUp : public BControl {
public:
private:
};

// PierScrollDown ===========================================================
class PierScrollDown : public BControl {
public:
private:
};

