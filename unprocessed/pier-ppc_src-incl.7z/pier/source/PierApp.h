// Copyright 1998, Patrick S. M. Gratton, All rights reserved.
// PierApp.h --------------------------------------------------------------
#pragma once

#include <Application.h>

class PierApp : public BApplication {
public:
	PierApp();
	
	virtual void Pulse(void);
};

