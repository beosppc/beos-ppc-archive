// Copyright 1998, Patrick S. M. Gratton, All rights reserved.
// Pier.h -----------------------------------------------------------------
#pragma once

#define PIER_SIGNATURE "application/x-vnd.PSMG-Pier"

