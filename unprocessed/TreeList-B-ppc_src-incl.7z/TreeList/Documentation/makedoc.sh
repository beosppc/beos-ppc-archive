#!/bin/sh
Doc++ -B footer.txt Intro.txt ../TreeList.h

 