#ifndef _PPCRACK_H_
#define _PPCRACK_H_


//void *loadfile(char *name);
void ppcrack(char *name, UBYTE *data, ULONG len);

#endif