/* ...............................................................

	WindowColors
	Copyright 1997-8 Steve Klingsporn <moofie@pobox.com>
	Based on WindowShade by Marco Nelissen <marcone@xs4all.nl>
	
		File:	AboutPanel.h
	
	Contains:	Class definition and includes for a last-minute
				about box.
	
	   Notes:	None.
	   
   ............................................................... */

#ifndef _ABOUT_PANEL_H
#define _ABOUT_PANEL_H

#ifndef _VIEW_H
#include <View.h>
#endif

#ifndef _WINDOW_COLORS_APPLICATION_H
#include "WindowColorsApplication.h"
#endif


/* ...............................................................	
	Constants
   ............................................................... */

const BRect		SUPPOSED_LINK_BOUNDS = BRect(75, 54, 356, 69);
const BRect		ICON_BOUNDS = BRect(30, 30, 61, 61);
const BPoint 	OK_BUTTON_RIGHT_EDGE = BPoint(408, 301);
const float 	LINE_SPACING = 16;


/* ...............................................................	
	AboutPanel class
   ............................................................... */

class AboutPanel : public BView
{
	public:
						AboutPanel(BRect frame);
	virtual				~AboutPanel();
	
			void		Show();
			void		AttachedToWindow();
			void		Draw(BRect updateRect);
			void		MouseDown(BPoint where);
			void		MessageReceived(BMessage *message);
			void		ComposeFeedbackMessage();
			void		VisitHomePage();
			
	private:
			BBitmap		*_icon;
};

#endif