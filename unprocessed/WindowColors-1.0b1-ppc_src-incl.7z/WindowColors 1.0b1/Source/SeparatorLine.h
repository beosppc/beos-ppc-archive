/* ...............................................................

	WindowColors
	Copyright 1997-8 Steve Klingsporn <moofie@pobox.com>
	Based on WindowShade by Marco Nelissen <marcone@xs4all.nl>
	
		File:	SeparatorLine.h
	
	Contains:	Class definition and includes for separator line
				BView subclass.
	
	   Notes:	None.
	   
   ............................................................... */
  
#ifndef _SEPARATOR_LINE_H
#define _SEPARATOR_LINE_H

#ifndef _WINDOW_COLORS_APPLICATION_H
#include "WindowColorsApplication.h"
#endif

#ifndef _VIEW_H
#include <View.h>
#endif

/* ...............................................................
	SeparatorLine class
   ............................................................... */

class SeparatorLine : public BView
{
	public:
					SeparatorLine(BRect frame, 
								  const char *name, 
								  orientation kind, 
								  uint32 resizeMask,
								  uint32 flags);
		void		Draw(BRect updateRect);
			
	private:
		
		orientation	_kind;
};

#endif