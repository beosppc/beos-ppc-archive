// LGenWindow.h
// Autor: Christian Lörchner
// Letzte Änderung: 29.07.05
// This code is distributed under the terms of the Team Maui Licence.

#ifndef _LGEN_WINDOW_H
#define _LGEN_WINDOW_H

#include <Window.h>

#ifndef _LGEN_VIEW_H
#include "LGenView.h"
#endif

#include <Application.h>

#include <stdlib.h> // sprintf and srand/ rand
#include <time.h>  // time(NULL)

class LGenWindow : public BWindow
{
  public:
  					LGenWindow(BPoint from, BPoint to);
	virtual	void 	MessageReceived(BMessage *msg);
  	virtual bool	QuitRequested();
  	
  	LGenView	*lGenView;
};

#endif
