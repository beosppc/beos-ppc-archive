// LottoGen.cpp
// Autor: Christian Lörchner
// Letzte Änderung: 21.07.05
// This code is distributed under the terms of the Team Maui Licence.

#include "LottoGen.h"

LottoGen::LottoGen()
	:BApplication(APP_SIGNATURE)
{
  ScreenInfo screen; // get the current screen resolution
  screen.UpdateInfo();
  
  LGenWindow	*lGenWindow;
  lGenWindow = new LGenWindow(BPoint(screen.GetX()/2-WINDOW_WIDTH/2, screen.GetY()/2-WINDOW_HEIGHT/2), 
                              BPoint(screen.GetX()/2+WINDOW_WIDTH/2, screen.GetY()/2+WINDOW_HEIGHT/2));
                              
  lGenWindow->Show();

}
