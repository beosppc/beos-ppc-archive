// LGenWindow.cpp
// Autor: Christian Lörchner
// Letzte Änderung: 29.07.05
// This code is distributed under the terms of the Team Maui Licence.

#include "LGenWindow.h"

LGenWindow::LGenWindow(BPoint from, BPoint to)
	:BWindow(BRect(from, to), "LottoGen", 
	B_TITLED_WINDOW_LOOK, B_NORMAL_WINDOW_FEEL, B_NOT_RESIZABLE | B_NOT_ZOOMABLE)
{
  BRect frame = BRect(from, to);
  frame.OffsetTo(B_ORIGIN);
  lGenView = new LGenView(frame);
  AddChild(lGenView);
  srand(time(0));
}

void LGenWindow::MessageReceived(BMessage *msg)
{
  switch(msg->what)
  {
	case GEN_BTN_MSG:
	{
	  
	  static char* buf = (char*) calloc(3, 1);
	  
	  int number[6] = {0, 0, 0, 0, 0, 0};
	  int i = 0;
	  int value;
	  bool isUnique;	  
	  	  
	  while (i != 6) // generate 6 numbers
	  {
	    do 
	    {
	      isUnique = true;
	      value = rand()%49+1;
	      for (int j=0; j<6; j++) // but be sure to have no number twice or more times
          {
            if (number[j] == value)
              isUnique = false;
          }	      
	    } while (!isUnique);
	    number[i] = value;
	    i++;
	  }
	  
	  // print out the generated numbers
	  sprintf(buf, "%i", number[0]);
	  lGenView->number1->SetText(buf);
	  
	  sprintf(buf, "%i", number[1]);
	  lGenView->number2->SetText(buf);
	  
	  sprintf(buf, "%i", number[2]);
	  lGenView->number3->SetText(buf);
	  
	  sprintf(buf, "%i", number[3]);
	  lGenView->number4->SetText(buf);
	  
	  sprintf(buf, "%i", number[4]);
	  lGenView->number5->SetText(buf);
	  
	  sprintf(buf, "%i", number[5]);
	  lGenView->number6->SetText(buf);

	}
	default:
	  BWindow::MessageReceived(msg);
  }
}

bool LGenWindow::QuitRequested()
{
	be_app_messenger.SendMessage(B_QUIT_REQUESTED);
	return(true);
}

