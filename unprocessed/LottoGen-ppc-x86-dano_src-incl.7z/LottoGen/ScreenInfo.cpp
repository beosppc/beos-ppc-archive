//ScreenInfo.cpp
// Autor: Christian Lörchner
// Letzte Änderung: 21.07.05
// This code is distributed under the terms of the Team Maui Licence.

#include "ScreenInfo.h"

ScreenInfo::ScreenInfo()
	:BScreen(B_MAIN_SCREEN_ID)
{
  UpdateInfo();
}

bool ScreenInfo::UpdateInfo()
{
  GetMode(&mode);
  x = mode.virtual_width;
  y = mode.virtual_height;
  return true;
}

int32 ScreenInfo::GetX()
{
  return x;
}

int32 ScreenInfo::GetY()
{
  return y;
}
