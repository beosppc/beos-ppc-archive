// LottoGen.h
// Autor: Christian Lörchner
// Letzte Änderung: 21.07.05
// This code is distributed under the terms of the Team Maui Licence.

#ifndef _LOTTO_GEN_H
#define _LOTTO_GEN_H

#include <Application.h>

#ifndef _LOTTO_GEN_CONST_H
#include "LottoGenConst.h"
#endif

#ifndef _LGEN_WINDOW_H
#include "LGenWindow.h"
#endif

#ifndef _SCREEN_INFO
#include "ScreenInfo.h"
#endif

class LottoGen : public BApplication
{
  public:
  		LottoGen();
};

#endif
