// LGenView.cpp
// Autor: Christian Lörchner
// Letzte Änderung: 29.07.05
// This code is distributed under the terms of the Team Maui Licence.

#include "LGenView.h"

LGenView::LGenView(BRect frame)
	:BView(frame, "LGenView", B_FOLLOW_ALL, B_WILL_DRAW)
{
  SetViewColor(ui_color(B_PANEL_BACKGROUND_COLOR));
  
  number1 = new BStringView(BRect(20, 40, 70, 90), "number1", "0");
  AddChild(number1);
  number1->SetFontSize(40);
  number1->SetAlignment(B_ALIGN_CENTER);
  
  number2 = new BStringView(BRect(80, 40, 130, 90), "number1", "0");
  AddChild(number2);
  number2->SetFontSize(40);
  number2->SetAlignment(B_ALIGN_CENTER);
  
  number3 = new BStringView(BRect(140, 40, 190, 90), "number1", "0");
  AddChild(number3);
  number3->SetFontSize(40);
  number3->SetAlignment(B_ALIGN_CENTER);
  
  number4 = new BStringView(BRect(200, 40, 250, 90), "number1", "0");
  AddChild(number4);
  number4->SetFontSize(40);
  number4->SetAlignment(B_ALIGN_CENTER);
  
  number5 = new BStringView(BRect(260, 40, 310, 90), "number1", "0");
  AddChild(number5);
  number5->SetFontSize(40);
  number5->SetAlignment(B_ALIGN_CENTER);
  
  number6 = new BStringView(BRect(320, 40, 370, 90), "number1", "0");
  AddChild(number6);
  number6->SetFontSize(40);
  number6->SetAlignment(B_ALIGN_CENTER);
    
  genButton = new BButton(BRect(125, 120, 265, 150), "genButton", "generieren", new BMessage(GEN_BTN_MSG));
  AddChild(genButton);
}

void LGenView::Draw(BRect frame)
{
  StrokeLine(BPoint(75, 30), BPoint(75, 100));
  StrokeLine(BPoint(135, 30), BPoint(135, 100));
  StrokeLine(BPoint(195, 30), BPoint(195, 100));
  StrokeLine(BPoint(255, 30), BPoint(255, 100));
  StrokeLine(BPoint(315, 30), BPoint(315, 100));
}
