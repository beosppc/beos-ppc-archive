//ScreenInfo.h
// Autor: Christian Lörchner
// Letzte Änderung: 21.07.05
// This code is distributed under the terms of the Team Maui Licence.

#ifndef _SCREEN_INFO_H
#define _SCREEN_INFO_H

#include <Screen.h>

class ScreenInfo : public BScreen
{
  public:
					ScreenInfo();
			bool 	UpdateInfo();
			int32 	GetX();
			int32 	GetY();
  private:
    display_mode	mode;
    int32			x, y;

};
#endif
