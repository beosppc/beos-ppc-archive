//main.cpp
// Autor: Christian Lörchner
// Letzte Änderung: 21.07.05
// This code is distributed under the terms of the Team Maui Licence.

#include "LottoGen.h"

int main()
{
  LottoGen LottoApp;
  
  LottoApp.Run();
  
  return 0;
}
