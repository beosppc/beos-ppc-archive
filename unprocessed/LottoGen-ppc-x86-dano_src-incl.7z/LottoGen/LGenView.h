// LGenView.h
// Autor: Christian Lörchner
// Letzte Änderung: 29.07.05
// This code is distributed under the terms of the Team Maui Licence.

#ifndef _LGEN_VIEW_H
#define _LGEN_VIEW_H

#include <View.h>
#include <InterfaceDefs.h> //for ui_color()

#include <interface/Button.h>
#include <interface/StringView.h>

class LGenView : public BView
{
  public:
  	#define GEN_BTN_MSG	'btng'
    
    BButton		*genButton;
  	BStringView	*number1;
  	BStringView	*number2;
  	BStringView	*number3;
  	BStringView	*number4;
  	BStringView	*number5;
  	BStringView	*number6;
  	
    				LGenView(BRect frame);
  					
  	virtual	void	Draw(BRect frame);
};

#endif
