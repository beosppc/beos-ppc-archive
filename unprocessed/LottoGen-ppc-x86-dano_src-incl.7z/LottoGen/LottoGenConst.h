// LottoGenConst.h
// Autor: Christian Lörchner
// Letzte Änderung: 21.07.05
// This code is distributed under the terms of the Team Maui Licence.

#ifndef _LOTTO_GEN_CONST_H
#define _LOTTO_GEN_CONST_H

  #define APP_SIGNATURE 	"application/x-vnd.CL-LottoGen"
  #define WINDOW_HEIGHT 	170
  #define WINDOW_WIDTH 	390

#endif
