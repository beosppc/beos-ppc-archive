/*****************************************************************************

	Projet	: Nerdkill End AddOn

	Fichier	:	nerdkill_end.cpp
	Partie	: End

	Auteur	: RM
	Date		: 040597
	Format	: tabs==2

	Nerdkill is an interactive app, and as a programmer, I add no time and no idea
	about the end game. This is why I decided that, YOU, programmer, will do the end
	as YOU want it to be !

	Please have fun, just code anything you want and then, if you want to share your
	add-on, publish it or just send it to me - I will integrate the better one in the
	next release.

	The add-on interface is very simple and straightforward : one function that is
	called upon the end of game, before the main window is closed. The function receive
	the number of killed nerds (currently, 200 I think) and the number of shoots or other
	actions the user takes to do so. Nerkdill is not a competition game, there is no
	time limit nor time count. If you want to compete, use the number of shoot as a rating !

	What you can do : add a hall of fame, sound, movies, great show, as you like !

	The returned value is currently unused. Nothing prevents the game from stopping.
	I think I will use positive (>0) values to say : game over, quit, restart, etc.

	Nerdkill loads the first add-on called "nerdkill_end" in the "nerdkill_addon"
	directory at the same level than the game.

*****************************************************************************/

#pragma export on
extern "C"
{
	long nerdkill_end_game(long number_of_killed_nerd, long number_of_shoot);
}
#pragma export reset


//**********************************************************************
long nerdkill_end_game(long number_of_killed_nerd, long number_of_shoot)
//**********************************************************************
/*
	AddOn func : all nerds have been exterminated.
*/
{
char s[512];
BAlert *box;

	sprintf(s,
					"All nerds have been exterminated !"
					"\n\nGreat !"
					"\nBeside that, it tooks you only %d shoots"
					"\nto kick these damned %d nerds."
					"\n\nHey, Joe, you're a true geek !",
					number_of_shoot,
					number_of_killed_nerd);

	box = new BAlert("Nerdkill End", s, "   OK   ");
	if (box) box->Go();
	return B_NO_ERROR;
} // end of nerdkill_end_game


// eoc
