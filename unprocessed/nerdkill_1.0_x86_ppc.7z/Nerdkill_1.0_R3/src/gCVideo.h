/***************
*	gCVideo.h	*
***************/

#ifdef AMIGA
#include "aCVideo.h"
#endif

#ifdef BEBOX
#include "bCVideo.h"
#endif

#ifdef WINNT4
#include "wCVideo.h"
#endif

/* eof */