/*****************************************************************************

	Projet	: Droids

	Fichier	:	bCApplication.h
	Partie	: Loader

	Auteur	: RM
	Format	: tabs==2

*****************************************************************************/

#ifndef _H_BCAPPLICATION_
#define _H_BCAPPLICATION_

#include "machine.h"


//---------------------------------------------------------------------------

#define K_GRAF_SPH		'gSpH'
#define K_GRAF_PULCO	'gPul'
#define K_CALL_END		'cEnd'

//**************************************
class CApplication : public BApplication
//**************************************
{
public:
	CApplication(void);
	virtual ~CApplication(void);

	virtual	void AboutRequested();
	virtual void ReadyToRun(void);
	virtual bool QuitRequested(void);
	virtual void MessageReceived(BMessage *msg);

	// methodes "cross-platform"
	BOOL init(void);
	void run(void);

	void callEndAddOn(long nerds, long shoots);

	BMenu	*mMainMenu;	// HOOK DR8->DR9

private:
	BMenuItem		*mGrafSph;
	BMenuItem		*mGrafPulco;

	BDirectory mDirAddOn;

}; // end of class defs for CApplication


//---------------------------------------------------------------------------

#endif // of _H_BCAPPLICATION_

// eoh
