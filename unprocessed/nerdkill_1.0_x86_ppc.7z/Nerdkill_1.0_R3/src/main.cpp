/****************
*	main.cpp	*
****************/

#include "machine.h"
#include "gCApplication.h"
#include "externs.h"

#define DEBUG 1
#include <Debug.h>

#include <stdio.h>
#include <stdlib.h>

CApplication *gApplication = NULL;

extern "C" void toto(void);
void toto(void)
{
	printf("toto start\n");
	SET_DEBUG_ENABLED(true);
	TRESPASS();
	int i;
	double a=0;
	double b=1.0;
	for(i=300; i>0; i--) a+=b;
	printf("toto end\n");
}

/*****************************/
int main(int /*agrc*/,char ** /*argv[]*/)
/*****************************/
{
CApplication gApp;

	//toto();
	gApplication = &gApp; // hairy but works...

	try
	{
		if(gApp.init()) gApp.run();
		else printf("Error during initialization...\n");
	}
	catch(...)
	{
		BAlert *box = new BAlert("Nerdkill Error",
														 "Unhandled Exception thrown,"
														 "\ncatched in main()",
														 "   OK   ");
		if(box) box->Go();
	}

	return 0;
}

/* eof */