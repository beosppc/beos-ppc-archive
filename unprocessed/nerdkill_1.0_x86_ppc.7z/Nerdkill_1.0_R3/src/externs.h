/****************
*	externs.h	*
****************/

#ifndef _H_EXTERNS_
#define _H_EXTERNS_

// HOOK RM 110297 : supprimer =NULL ici
// et ajouter le mot clef class (forward definition sur les
// classes non utilisees lors de l'inclusion de externs.h)

extern class CInterface		*gInterface;
extern class CVideo				*gVideo;
extern class CThread			*gThreadMoteur;		// RM 130297
extern class CMoteur			*gMoteur;					// RM 130297
extern class CApplication	*gApplication;

#endif

/* eof */