/*****************************************************************************

	Projet	: Droids

	Fichier	:	gCApplication.h
	Partie	: Loader

	Auteur	: RM
	Format	: tabs==2

*****************************************************************************/

#ifndef _H_GCAPPLICATION_
#define _H_GCAPPLICATION_

#include "machine.h"

//---------------------------------------------------------------------------

#ifdef AMIGA
#include "aCApplication.h"
#endif

#ifdef BEBOX
#include "bCApplication.h"
#endif

#ifdef WINNT4
#include "wCApplication.h"
#endif



//---------------------------------------------------------------------------

#endif // of _H_GCAPPLICATION_

// eoh
