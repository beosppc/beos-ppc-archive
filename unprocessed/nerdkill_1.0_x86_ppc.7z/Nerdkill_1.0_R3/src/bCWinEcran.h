/*****************************************************************************

	Projet	: Droids

	Fichier	:	bCWinEcran.h
	Partie	: Video

	Auteur	: RM
	Date		: 110297
	Format	: tabs==2

*****************************************************************************/

#ifndef _H_BCWINECRAN_
#define _H_BCWINECRAN_


#include "machine.h"
#include "bCViewEcran.h"

//---------------------------------------------------------------------------


//********************************
class CWinEcran : public BWindow
//********************************
{
public:
	CWinEcran(BRect frame, char *titre);
	virtual ~CWinEcran(void);

	BOOL init(void);
	virtual	bool QuitRequested();
	virtual	void DispatchMessage(BMessage *message, BHandler *handler);

	void setScroll(ULONG x, ULONG y);

	CViewEcran * ecran1(void) { return mEcran1; }
	CViewEcran * ecran2(void) { return mEcran2; }

//----
protected:
	CViewEcran	*mEcran1, *mEcran2;

	bool mAskToQuit;

}; // end of class defs for CWinEcran


//---------------------------------------------------------------------------

#endif // of _H_BCWINECRAN_

// eoh
