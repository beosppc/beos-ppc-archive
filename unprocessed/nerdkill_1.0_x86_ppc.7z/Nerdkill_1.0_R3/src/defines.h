/****************
*	defines.h	*
*****************
*	Cross-Dev	*
****************/

#ifndef _H_DEFINES_
#define _H_DEFINES_

#define MAX_INTERF_HEIGHT	400
#define MAX_LIST_ENTRY		500
#define MAX_LINE_LEN			40
#define MAX_NB_BUTTON			30
#define MAX_NB_LIST				4

#define RECTF_DISABLED		1

#define BUTF_DOWN					1
#define BUTF_NOTUP				2
#define BUTF_NOTDOWN			4
#define BUTF_CHECK				8

#define GID_PROGRAM				1
#define GID_PLAYER				2
#define GID_GAME					3
#define GID_NETWORK				4

#endif // of _H_DEFINES_

/* eof */

