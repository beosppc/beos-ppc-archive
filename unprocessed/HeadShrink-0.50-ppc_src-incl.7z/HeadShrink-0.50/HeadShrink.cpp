// Code hacked by Peter Hinely
// *Some* changes are indicated by a "// pH" comment
// I should rewrite the whole program from scratch
// starting with an example Tracker Add-On...

/*************************************************************************

	Project : ZipMe
	Author  : R'alf <mailto:raphael.moll@inforoute.cgs.fr>

	Version : 0.7.1
	Date    : 20 August 1997

	Format  : tabs == 2	

	Description :
	- The idea is to zip files, cope with it !
	- If only ONE folder or ONE file is selected, the file or the folder name
	  is used to make a "foo.zip" file.
	- If more than one item is selected, the whole stuff is packed under "archive.zip"
	  file name, with an incresing number if entry already exists.

	Version 0.7.1 :
	- did I really output a version numbered 0.7 before ? I can't remember :(
	- Integrate some useful stuff from Bernie Estavillo (bernie@metrowerks.com)
	1. Unique file names so the new archive will not overwrite an existing archive.
	2. Prepend the date to the file name when the Shift key is held down, so an
	   archive of a directory called test will end up with a name like
	   1997-08-13.test.zip. I'm not sure how useful this will be to others.
	- I also modified Bernie's nice code so that the date can be appended in the
	  form of zipname_ddmmyyyy.zip if you hold down the Control key (don't blame me, it's
	  more natural for me to see dates in the "other" way, i.e. the French one :))
	  If you hold both Control and Shift, you get the append date.

	Version 0.6 :
	- now gracefully handles files containing spaces, quotes, double
	  quotes and others characters interpreted by the shell. Thx to GL !

	For example, the file :
	"./#zi|;p ~m^ &$e_06 _P&R.t)xt.z ip.z_ @ip.z\}ip.zip&(-_.zip)=~#{[|`\^@]}^$¨$*%!;,?.§<stuff>dyn"
	can now be correctly zipped (I've tried ;))

	Version 0.0 :
	- Based on code from TermHire.cpp, v0.97, release date 24/05/97 by
	  Pierre BRUA (brua@dess-info.u-strasbg.fr
	
	---
	USE AT YOUR OWN RISK !

*************************************************************************/

#include <Directory.h>
#include <Window.h>
#include <StringView.h>
#include <File.h>
#include <Alert.h>
#include <Message.h>
#include <Errors.h>
#include <Path.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

// this tell the compiler that process_refs will be called from
// outside (by the Tracker)

#include <TrackerAddOn.h>

//------------------------------------------------------------------------
// some defines...

#pragma once

// use this define if you want little windows to explain you what's going on
#define VERBOSE

// use this define if you want printf() in the terminal (run a terminal,
// use Olivier's TManager to quit the Tracker, type /boot/system/Tracker & in
// the terminal and you get the stdout here. Too cool !
#undef DPRINTF
//#define DPRINTF

// the name of the add_on
#define ADDON_NAME "HeadShrink"
#define ADDON_VERS "0.50"

// change behavior as you want it to. It's a bad idea to remove -r for directory handling !
//#define K_ZIP_OPTIONS ""

#ifndef max
#define max(a,b) ((a)>(b) ? (a) : (b))
#endif

//------------------------------------------------------------------------
// internal state. I use a struct rather than global variables.

struct SState
{
	BWindow *win;
	BTextControl *leaf, *dir, *lasterr, *method, *number;
	BStatusBar *bar;
	int32 errorCount;
	int32 totalCount;
	int32 baseCount;
	bool appendDate;
	bool prependDate;
};


//------------------------------------------------------------------------
// local prototypes 
void error(const char *message);
void createWindow(SState &state);
void closeWindow(SState &state);
void setFileInfo(SState &state, const char *leaf, const char *dir);
void setError(SState &state, const char *error);
void setMethod(SState &state, const char *text);
void setNumber(SState &state, int32 count);
char* uniqueBaseName(SState &state, BPath path);
void GenerateArchiveNames(SState &state, BPath path); // pH
void EscapeMetacharacters(char* output, char* input);

void packFileOrDir(SState &state, entry_ref &ref, bool isdir);

BPath tempPath; // pH 

/* Code to help a little the fellow user double-clicking the
   add-on icon directly.
*/
int main(int, char **)
{
	new BApplication("application/x-vnd.ralf-vanilla");
	BAlert *box = new BAlert(ADDON_NAME,
													 "Thanks for using " ADDON_NAME " !\n\n"
													 "Please move the " ADDON_NAME " executable into\n"
													 "/boot/home/config/add-ons/Tracker/\n"
													 "and try again !",
													 "Great !");
	box->Go();
	delete be_app;
	return 0;
}


//*****************************
void error(const char *message)
//*****************************
/*
	Displays a message in a dialog box (yes, believe it!)
*/
{
	BAlert *alert = new BAlert(ADDON_NAME " Error :\n", message, "OK");
	alert->Go();
}

// A function to escape metacharacters in the bash shell
// From the bash documentation:
// metacharacter: A character that, when unquoted, separates words. 
// One of the following: 
//     | & ; ( ) < > space tab 
// \ ' " should be in the above list. -pH
void EscapeMetacharacters(char* output, char* input) {
  while(*input != '\0') {
  	switch(*input) {
		case '\\': 
    	case '"': 
 		case '\'': 
  		case '|': 
  		case '&': 
  		case ';': 
  		case '(': 
 		case ')': 
 		case '<': 
 		case '>': 
 		case ' ': 
 		case '\t': 
 			*output++ = '\\';
  	}
  	*output++ = *input++;
  }
  *output = '\0';
}

char                 zipArchiveEscapedPath[B_FILE_NAME_LENGTH * 2];
char                 bz2ArchiveEscapedPath[B_FILE_NAME_LENGTH * 2];
char                 bozArchiveEscapedPath[B_FILE_NAME_LENGTH * 2];
//********************************************************************************
void GenerateArchiveNames(SState &state, BPath path)
//********************************************************************************
{
    char baseName[B_FILE_NAME_LENGTH * 2];

    if (state.appendDate) { // append the current date to the end of the file name
        time_t          now;
        struct tm       *date;
        now = time(NULL);
        date = localtime(&now);
    	char dateString[16] = "";
        strftime(dateString, 16, "(%m-%d-%y)", date);
        sprintf(baseName, "%s%s", path.Leaf(), dateString);
    }
    else {
    	strcpy(baseName, path.Leaf());
    }

    int32 count = 0;

	char theUniqueBaseName[B_FILE_NAME_LENGTH * 2 + 128];
	
	BPath parentPath;
	path.GetParent(&parentPath);
	
	char zipArchivePath[B_FILE_NAME_LENGTH * 2];
	char bz2ArchivePath[B_FILE_NAME_LENGTH * 2];
	char bozArchivePath[B_FILE_NAME_LENGTH * 2];
	do {
		if(count == 0) {
    		strcpy(theUniqueBaseName, baseName);
    	}
		else {
    		sprintf(theUniqueBaseName, "%s{%d}", baseName, count);
		}
    	sprintf(zipArchivePath, "%s/%s.zip", tempPath.Path(), theUniqueBaseName);
    	sprintf(bz2ArchivePath, "%s/%s.zip.bz2", tempPath.Path(), theUniqueBaseName);
    	sprintf(bozArchivePath, "%s/%s.boz", parentPath.Path(), theUniqueBaseName);
		count++;
	} while(BEntry(zipArchivePath).Exists() || BEntry(bz2ArchivePath).Exists() || BEntry(bozArchivePath).Exists()); // pH

    EscapeMetacharacters(zipArchiveEscapedPath, zipArchivePath);
    EscapeMetacharacters(bz2ArchiveEscapedPath, bz2ArchivePath);
    EscapeMetacharacters(bozArchiveEscapedPath, bozArchivePath);

    return;
}


//********************************************************************************
void packFileOrDir(SState &state, entry_ref &ref, bool isdir)
//********************************************************************************
/*
	Version update:
	- there was previously two functions, packDirectory() and packFile() but the code
	  was so similar that I packed them into only one. From a Zip point-of-view, packing
	  a dir or a file changes nothing, only the setMethod() comment changes ;)
	  (at first, I thougth to add some tricky code inside packDir to display names of
	  packed files on the fly. Finally I lazily forgot the stuff.)
	- this now calls uniqueBaseName(), idea from Bernie, make zip names uniques and add a date
	  if needed.
*/
{
BEntry entry(&ref);
BEntry parent;
BPath path;
BPath parentPath;
char buf[B_FILE_NAME_LENGTH*2+128];

	entry.GetParent(&parent);
	entry.GetPath(&path);
	parent.GetPath(&parentPath);

	setFileInfo(state, path.Leaf(), parentPath.Path());

	chdir(parentPath.Path());

	if(isdir) 
		setMethod(state, "HeadShrinking directory (storage phase)...");
	else 
		setMethod(state, "HeadShrinking file (storage phase)...");
	
	GenerateArchiveNames(state, path); // pH

	char leafEscapedPath[B_FILE_NAME_LENGTH*2+128];
	EscapeMetacharacters(leafEscapedPath, (char*) path.Leaf());
	sprintf(buf, "zip -ryq0 %s %s", zipArchiveEscapedPath, leafEscapedPath);
	
	// issue the real action...

	if(system(buf) != 0) {
		fprintf(stderr, "%s\n", buf);
		BAlert *alert = new BAlert("BAlert", "Error during creation of archive with zip.", "OK", NULL, NULL, B_WIDTH_AS_USUAL, B_STOP_ALERT); 
		alert->Go();
		BAlert *alert1 = new BAlert("BAlert", buf, "Okay"); 
		alert1->Go();
		return;
   	}

	if(isdir) 
		setMethod(state, "HeadShrinking directory (compression phase)...");
	else 
		setMethod(state, "HeadShrinking file (compression phase)...");

	sprintf(buf, "bzip2 %s", zipArchiveEscapedPath);

	if(system(buf) != 0) {
		fprintf(stderr, "%s\n", buf);
		BAlert *alert = new BAlert("BAlert", "Error during compression with bzip2.", "OK", NULL, NULL, B_WIDTH_AS_USUAL, B_STOP_ALERT); 
		alert->Go();
		BAlert *alert1 = new BAlert("BAlert", buf, "Okay"); 
		alert1->Go();
		return;
   	}

	sprintf(buf, "mv %s %s", bz2ArchiveEscapedPath, bozArchiveEscapedPath);

	if(system(buf) != 0) {
		fprintf(stderr, "%s\n", buf);
		BAlert *alert = new BAlert("BAlert", "Error renaming file with mv.", "OK", NULL, NULL, B_WIDTH_AS_USUAL, B_STOP_ALERT); 
		alert->Go();
		BAlert *alert1 = new BAlert("BAlert", buf, "Okay"); 
		alert1->Go();
		return;
   	}   	
}


//********************************************************
void process_refs(entry_ref dir_ref, BMessage* msg, void*)
//********************************************************
/*
	this is the function the Tracker call when the add-on is selected
	dir_ref is the folder you have launched it from
	msg is a BMessage containing the references to BEntry's(Files/Folders)
	and for "void *", I don't know yet...
*/
{
int32 count;	// number of references stored in the BMessage
ulong type;		// type of the BMessage
SState state;
BPath path;

	state.win = NULL;
	state.errorCount = 0;
	state.totalCount = 0;
	state.baseCount = 0;
    //state.prependDate = ((modifiers() & B_SHIFT_KEY) != 0);
    state.prependDate = 0;
    state.appendDate = ((modifiers() & B_SHIFT_KEY) != 0);

	// this creates an informative window about the completion of the add-on
	#ifdef VERBOSE
		createWindow(state);
	#endif

	// first, we consider the case when the add-on has been selected
	// from the file menu of the browser window or by right-clicking
	// in the background of the window
	// i.e : in this case, there is no refs on the BMessage
	msg->GetInfo("refs", &type, &count);
	if (count == 0)
	{
		error("Please select a file or a directory to compress !");
	}
	else
	{
		BDirectory dir;
		BEntry entry;

		// if there are datas on the BMessage, but not from the
		// directory type, exit...
		if (dir.SetTo(&dir_ref) != B_NO_ERROR) 
		{
			error("You must launch " ADDON_NAME " from folders.");
			return;
		}
		if(dir.GetEntry(&entry) != B_NO_ERROR)
		{
			error("Sorry, I cannot access the folder while launching " ADDON_NAME);
			return;
		}

		state.totalCount = count;

		#ifdef VERBOSE
		if (state.win && state.bar)
		{
			state.win->Lock();
			state.bar->SetMaxValue(count);
			state.win->Unlock();
		}
		#endif

	if(find_directory(B_COMMON_TEMP_DIRECTORY, &tempPath) != B_OK) { // pH
		BAlert *alert = new BAlert("BAlert", "Error obtaining path to tmp directory.", "OK", NULL, NULL, B_WIDTH_AS_USUAL, B_STOP_ALERT); 
		alert->Go();
		return;
	}

		try
		{
			for(long i=0; i<count; i++)
			{
				// pack one file or one directory...
				entry_ref ref;
				BDirectory dir;
	
				setNumber(state, i);
				if (msg->FindRef("refs", i, &ref) >= B_NO_ERROR)
				{
					// if the ref is a folder, expand the directory content
					if(dir.SetTo(&ref) >= B_NO_ERROR) packFileOrDir(state, ref, true);
					else
					{
						BFile file;
						if(file.SetTo(&ref, B_READ_ONLY) >= B_NO_ERROR) packFileOrDir(state, ref, false);
					}
				}
			}
		}
		catch(...)
		{
			setError(state, "Bad luck !\nException throw !\nProbably IO or File Exception.");
		}
	}
	
	// exit...

	if (state.errorCount > 0)
	{
		char s[256];
		sprintf(s, ADDON_NAME " v." ADDON_VERS " :\n%d error%s detected.",
			state.errorCount, (state.errorCount > 1 ? "s" : ""));
		#ifdef VERBOSE
			if (state.win) state.win->Activate();
		#endif
		error(s);
	}

	#ifdef VERBOSE
		closeWindow(state);
	#endif
}


//******************************
void createWindow(SState &state)
//******************************
{
	BRect area(0, 0, 300, 80);

	BScreen screen;		// -- DR9 PR
	BRect r=screen.Frame();
	area.OffsetBy(r.Width()/2-125, r.Height()/2-80);

	state.win = new BWindow(area, ADDON_NAME " Status", B_TITLED_WINDOW,
							B_NOT_ZOOMABLE | B_NOT_V_RESIZABLE | B_NOT_CLOSABLE);
	if (!state.win) return;

	BRect bounds = state.win->Bounds();
	BView *base = new BView(bounds, B_EMPTY_STRING, B_FOLLOW_ALL, B_WILL_DRAW);
	base->SetViewColor(230, 230, 230);
	if (!base) goto error;	// I could have used an exception...
	state.win->AddChild(base);

	BRect rect;
	rect.left		= bounds.left  + 10.0;
	rect.top		= bounds.top   + 10.0;
	rect.right	= bounds.right - 10.0;
	rect.bottom	= rect.top+15;

	uint32 rmask = B_FOLLOW_LEFT_RIGHT | B_FOLLOW_TOP;
	BStringView *str= new BStringView(rect, B_EMPTY_STRING,
						ADDON_NAME " v." ADDON_VERS ", by Peter Hinely", rmask, B_WILL_DRAW);
	if (!str) goto error;	
	base->AddChild(str);

	rect = str->Frame();
	rect.OffsetBy(0.0, rect.Height()+ 20.0);
	state.leaf		= new BTextControl(rect, B_EMPTY_STRING, "File name", "", NULL, rmask);
	if (!state.leaf) goto error;
	base->AddChild(state.leaf);

	rect = state.leaf->Frame();
	rect.OffsetBy(0.0, rect.Height()+ 10.0);
	state.dir			= new BTextControl(rect, B_EMPTY_STRING, "Directory", "", NULL, rmask);
	if (!state.dir) goto error;
	base->AddChild(state.dir);

	rect.OffsetBy(0.0, rect.Height()+ 10.0);
	state.lasterr	= new BTextControl(rect, B_EMPTY_STRING, "Last Error", "", NULL, rmask);
	if (!state.lasterr) goto error;
	base->AddChild(state.lasterr);

	rect.OffsetBy(0.0, rect.Height()+ 10.0);
	state.method	= new BTextControl(rect, B_EMPTY_STRING, "Running", "", NULL, rmask);
	if (!state.method) goto error;
	base->AddChild(state.method);

	state.number = NULL;

	rect.OffsetBy(0.0, rect.Height()+10.0);
	state.bar = new BStatusBar(rect, B_EMPTY_STRING, "File count", NULL /*, B_WILL_DRAW, rmask*/);
	if (!state.bar) goto error;
	state.bar->SetFlags(B_WILL_DRAW | B_FULL_UPDATE_ON_RESIZE);
	state.bar->SetResizingMode(rmask);
	base->AddChild(state.bar);
	rect = state.bar->Frame();

	long n=20;
	n = max(state.leaf   ->StringWidth("File name" ), n);
	n = max(state.dir    ->StringWidth("Directory" ), n);
	n = max(state.lasterr->StringWidth("Last Error"), n);
	n = max(state.method ->StringWidth("Running"   ), n);
	state.leaf   ->SetDivider(n + 2.0);
	state.dir    ->SetDivider(n + 2.0);
	state.lasterr->SetDivider(n + 2.0);
	state.method ->SetDivider(n + 2.0);

	state.leaf   ->SetFlags(B_WILL_DRAW);
	state.dir    ->SetFlags(B_WILL_DRAW);
	state.lasterr->SetFlags(B_WILL_DRAW);
	state.method ->SetFlags(B_WILL_DRAW);

	state.win->ResizeTo(bounds.Width(), rect.bottom+10.0);
	state.win->SetSizeLimits(bounds.Width(), r.Width()-20.0, rect.bottom+10.0, rect.bottom+10.0);
	state.win->Show();
	return;

error:
	state.win = NULL;

} // end of createWindow


//******************************
void 	closeWindow(SState &state)
//******************************
{
#ifndef VERBOSE
	return;
#endif
	if (!state.win) return;

	state.win->Lock();
	state.win->Quit();
	int32 val;
	wait_for_thread(state.win->Thread(), &val);

} // end of closeWindow



//****************************************************************
void 	setFileInfo(SState &state, const char *leaf, const char *dir)
//****************************************************************
{
#ifndef VERBOSE
	return;
#endif
	if (!state.win) return;
	state.win->Lock();
	if (leaf && state.leaf) state.leaf->SetText(leaf);
	if (dir  && state.dir ) state.dir ->SetText(dir );
	state.win->Unlock();
} // end of setFileInfo


//****************************************************************
void 	setError(SState &state, const char *error)
//****************************************************************
{
#ifndef VERBOSE
	return;
#endif
	if (!state.win) return;
	state.win->Lock();
	if (error && state.lasterr) state.lasterr->SetText(error);
	state.win->Unlock();
} // end of setError


//****************************************************************
void 	setMethod(SState &state, const char *text)
//****************************************************************
{
#ifndef VERBOSE
	return;
#endif
	if (!state.win) return;
	state.win->Lock();
	if (text && state.method) state.method->SetText(text);
	state.win->Unlock();
} // end of setMethod


//****************************************************************
void 	setNumber(SState &state, int32 count)
//****************************************************************
{
char s[256];
#ifndef VERBOSE
	return;
#endif
	if (!state.win) return;
	sprintf(s, "%d of %d", state.baseCount+count, state.totalCount);
	state.win->Lock();
	if (state.bar) state.bar->Update(1.0, NULL, s);
	state.win->Unlock();
} // end of setNumber


// eoc

