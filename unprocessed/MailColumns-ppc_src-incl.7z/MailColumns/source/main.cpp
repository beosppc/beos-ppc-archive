// MailColumns
// © jonas.sundstrom@kirilla.com

#define DEBUG 0
#include <Debug.h>
#include <Application.h>
#include <Roster.h>
#include <stdio.h>

#include <Message.h>

#include "EmailColumnsApp.h" 

void ErrorMessage (const char * a_text, int32 a_status);

int main()
{
//	system("clear");

	new EmailColumnsApp();
	be_app	-> Run();
	delete	be_app;
	return (0);
}

void
ErrorMessage	(const char * a_text, int32 a_status)
{
	PRINT(("%s: %s\n", a_text, strerror(a_status)));
}

