// MailColumns
// © jonas.sundstrom@kirilla.com

#define DEBUG 0
#include <Debug.h>
#include <MessageRunner.h>

#define MAIL_COLUMNS_STRING_ATTRIBUTES
//#define MAIL_COLUMNS_INT32_ATTRIBUTES

#include <stdio.h>

#include <Application.h>
#include <Roster.h>
#include <String.h>
#include <Mime.h>
#include <Volume.h>
#include <VolumeRoster.h>
#include <Messenger.h>
#include <Node.h>
#include <NodeMonitor.h>
#include <fs_attr.h>
#include <SupportDefs.h>
#include <StorageDefs.h>
#include <Query.h>
#include <TypeConstants.h>

#include "EmailColumnsApp.h"
#include "QueryLooper.h"
#include "EmailFolder.h"

EmailColumnsApp::EmailColumnsApp	(void)
 : BApplication	("application/x-vnd.Kirilla-MailColumns")
{
	do_add_attributes_to_mimetype	=	true;

	m_folder_list	=	new	BList(7);
	m_inode_list	=	new	BList(7);
}

EmailColumnsApp::~EmailColumnsApp	(void)
{
	int32	zero	=	0;
	EmailFolder	*	folder;
	
	while((folder = (EmailFolder *) m_folder_list->ItemAt(zero)) != NULL)
	{
		// remove folder
		m_folder_list->RemoveItem(zero);
		delete	folder;
	}
	
	status_t	exit_value;

	if (! do_quit)
	{
		// delete loopers
		m_New_QLooper->		PostMessage(B_QUIT_REQUESTED);
		m_Read_QLooper->	PostMessage(B_QUIT_REQUESTED);
		m_Draft_QLooper->	PostMessage(B_QUIT_REQUESTED);
		m_Pending_QLooper->	PostMessage(B_QUIT_REQUESTED);
		m_Replied_QLooper->	PostMessage(B_QUIT_REQUESTED);
		m_Saved_QLooper->	PostMessage(B_QUIT_REQUESTED);
		m_Sent_QLooper->	PostMessage(B_QUIT_REQUESTED);
		
		wait_for_thread(m_New_QLooper->Thread(), & exit_value);
		wait_for_thread(m_Read_QLooper->Thread(), & exit_value);	
		wait_for_thread(m_Draft_QLooper->Thread(), & exit_value);
		wait_for_thread(m_Pending_QLooper->Thread(), & exit_value);
		wait_for_thread(m_Replied_QLooper->Thread(), & exit_value);
		wait_for_thread(m_Saved_QLooper->Thread(), & exit_value);
		wait_for_thread(m_Sent_QLooper->Thread(), & exit_value);
	}
				
	// delete lists
	delete	m_folder_list;
	delete	m_inode_list;
}

void 
EmailColumnsApp::ArgvReceived	(int32 argc, char **argv)
{
	if(argc <= 1)	// no arguments
		return;

	BString argument = argv[1];
	
	if (argument == "--no-reg")
		do_add_attributes_to_mimetype	=	false;
	
	if (argument == "--help")
	{
		do_quit	=	true;
		printf(	"\n"
				"MailColumns 1.0 (c) jonas.sundstrom@kirilla.com\n\n"
				"Options:\n"
				"--no-reg        Do not add column attributes to folder MIME-type.\n"
				"--help          Display this marvelous help text.\n\n");
	}
}

void
EmailColumnsApp::ReadyToRun	(void)
{
	//BMessage	msg	('prnt');
	//BMessageRunner * runner =	new BMessageRunner(this, & msg, 5000000);
	//runner->	InitCheck();
	if (do_quit)
	{
		be_app->	PostMessage(B_QUIT_REQUESTED);
		return;
	}
	
	if (do_add_attributes_to_mimetype)
		AddAttrToMIME();
		
	m_New_QLooper		=	new	QueryLooper("(MAIL:status==New)", "New");
	m_Read_QLooper		=	new	QueryLooper("(MAIL:status==Read)", "Read");
	m_Draft_QLooper		=	new	QueryLooper("(MAIL:status==Draft)", "Draft");
	m_Pending_QLooper	=	new	QueryLooper("(MAIL:status==Pending)", "Pending");
	m_Replied_QLooper	=	new	QueryLooper("(MAIL:status==Replied)", "Replied");
	m_Saved_QLooper		=	new	QueryLooper("(MAIL:status==Saved)", "Saved");
	m_Sent_QLooper		=	new	QueryLooper("(MAIL:status==Sent)", "Sent");
}

bool
EmailColumnsApp::QuitRequested	(void)
{
	PrintStatus	();

	return BApplication::QuitRequested();
}

void 
EmailColumnsApp::MessageReceived	(BMessage * a_message)
{
	switch(a_message->what)
	{
		case 'prnt':
				PrintStatus	();
			break;
			
		case 'init':
				HandleInit	(a_message);
			break;

		case B_QUERY_UPDATE:
				QueryUpdate	(a_message);
			break;
			
		case B_NODE_MONITOR:
				NodeMonitor	(a_message);
			break;			

		default:
				BApplication::MessageReceived(a_message);
			break;			
	}
}

void
EmailColumnsApp::HandleInit	(BMessage * a_message)
{
	// 
	// Original code
	// 
	/*
	BString QLName;
	a_message->FindString("QLName", & QLName);

	entry_ref	ref;
	int32		ref_count	=	0;

	while(a_message->FindRef("refs", ref_count, & ref) == B_OK)
	{
		CountEmail	(& ref, & QLName);
		ref_count++;
	}
	*/
		
	//
	// New code
	//
	
	BString QLName;
	a_message->FindString("QLName", & QLName);
	
	int32		num_of_refs	=	0;
	type_code	type		=	B_REF_TYPE;
	
	a_message->GetInfo("refs", & type, & num_of_refs);
	
	PRINT(("Got 'init' message: %s (%ld)\n", QLName.String(), num_of_refs));	//**//

	entry_ref	ref;

	while(a_message->FindRef("refs", & ref) == B_OK)
	{
		int32			count		=	0;
		EmailFolder	*	folder		=	NULL;
		bool			got_folder	=	false;
		
		while((folder = (EmailFolder *) m_folder_list->ItemAt(count)) != NULL)
		{
			if (folder-> GetInode() == ref.directory)
			{
				got_folder	=	true;
				folder-> 	HandleInit	(a_message);
				break;
			}
			count++;
		}
	
		if (got_folder == false)
		{
			folder	=	CreateFolder(& ref);
			folder->	HandleInit	(a_message);
		}	
	}

	// PRINT(("Got 'init' message: %ld %s messages.\n", ref_count, QLName.String()));
}

void 
EmailColumnsApp::NodeMonitor	(BMessage * a_message)
{
	PRINT(("B_NODE_MONITOR "));	

	int32 opcode = 0;
	a_message	->	FindInt32("opcode", & opcode);
	
	/* B_ENTRY_CREATED */
	// -- ignored -- 
	// New email are caught as Query updates, and
	// if the email resides in an unknown folder
	// it will be added as an EmailFolder
	
	
	if (opcode == B_ENTRY_REMOVED)	// cases:
									// 1. folder removed
									// (removed email are handled as B_QUERY_UPDATE::B_ENTRY_REMOVED)
	
	{
		PRINT(("B_ENTRY_REMOVED\n"));
		int32			folder_count	=	0;
		EmailFolder	*	folder;
		
		while((folder = (EmailFolder *) m_folder_list->ItemAt(folder_count)) != NULL)
		{
			if (folder-> DidIJustDie	(a_message) == true)
			{
				PRINT((">> a folder died <<\n"));	
				
				// remove folder
				m_folder_list->RemoveItem(folder_count);
				delete	folder;
				
				return;
			}
			folder_count++;
		}		
	}
	
	if (opcode == B_ENTRY_MOVED)	// cases:
									// 1. folder moved
									// 2. email moved - both folders known
									// 3. email moved - known source, unknown target
									// (New email are handled as B_QUERY_UPDATE::B_ENTRY_CREATED)
	{
		PRINT(("B_ENTRY_MOVED\n"));	
		
		/* FOLDER MOVED	*/
		
		int32			folder_count	=	0;
		EmailFolder	*	folder;
		
		while((folder = (EmailFolder *) m_folder_list->ItemAt(folder_count)) != NULL)
		{
			if (folder-> DidIJustMove	(a_message) == true)
			{
				PRINT((">> a folder moved <<\n"));	
				return;
			}
			folder_count++;
		}
		
		/*	EMAIL MOVED	*/

		// entry_ref to moved entity
		entry_ref	file_ref;
		const char *	name;
		a_message->	FindInt32("device", & file_ref.device);
		a_message->	FindInt64("to directory", & file_ref.directory);
		a_message->	FindString("name", & name);
		file_ref.set_name(name);
		
		// entry_ref to parent folder
		entry_ref	dir_ref;
		BEntry	entry (& file_ref);
		entry.	GetParent (& entry);
		entry.	GetRef(& dir_ref);

		// inode of moved entity
		ino_t	file_inode;
		a_message->	FindInt64("node", & file_inode);


		// MOVE WITHIN FOLDER  (RENAME)
		// FROM DIRECTORY == TO DIRECTORY
		// -> ignore
		
		ino_t	to_dir_inode;
		ino_t	from_dir_inode;
		
		a_message->	FindInt64("to directory", & to_dir_inode);
		a_message->	FindInt64("from directory", & from_dir_inode);
		
		if (to_dir_inode == from_dir_inode)
		{
			PRINT((">> rename within folder (ignored) <<\n"));	
			return;		// folder renames are already taken care of,
		}				// and we don't care about email files that are renamed
		

		// FIND CASE
		
		folder_count	=	0;
		bool	to_known	=	false;
		bool	from_known	=	false;
		
		EmailFolder * to_folder		=	NULL;
		EmailFolder * from_folder	=	NULL;

		while((folder = (EmailFolder *) m_folder_list->ItemAt(folder_count)) != NULL)
		{
			if (folder-> GetInode() == to_dir_inode)
			{
				to_known = true;
				to_folder	=	folder;
			}
			
			if (folder-> GetInode() == from_dir_inode)
			{
				from_known = true;
				from_folder	=	folder;
			}
			
			folder_count++;
		}

		// CASE 1
		// FROM: known
		// TO: known
		
		if (from_known && to_known)
		{
			//PRINT(("CASE 1, FROM:known, TO:known\n"));	
		
			if (NotDuplicate(file_inode))	// catch duplicate B_ENTRY_MOVED
			{
				// discount email from source folder
				from_folder->	DiscountEmail	(& file_ref);
			
				// count email for target folder
				to_folder->		CountEmail		(& file_ref);
			}
		}
		
		// CASE 2
		// FROM: known
		// TO: unknown
		
		if ((from_known == true) && (to_known == false))
		{
			//PRINT(("CASE 1, FROM:known, TO:unknown\n"));
			
			// discount email from source folder
			from_folder->	DiscountEmail	(& file_ref);			
		
			// create new folder
			folder = CreateFolder(& file_ref);
			
			// count email for target folder	
			folder->	CountEmail		(& file_ref);
		}
	}
}

void 
EmailColumnsApp::QueryUpdate	(BMessage * a_message)
{
	BString QLName;
	a_message	->	FindString("QLName", & QLName);

	PRINT(("B_QUERY_UPDATE (%s) ", QLName.String()));	

	int32 opcode = 0;
	a_message	->	FindInt32("opcode", & opcode);
	
	if (opcode == B_ENTRY_CREATED)
	{
		PRINT(("B_ENTRY_CREATED\n"));
		
		/* Create an entry_ref */
		entry_ref ref;
		const char * name;

		a_message->FindInt32("device", & ref.device);
		a_message->FindInt64("directory", & ref.directory);
		a_message->FindString("name", & name);
		ref.set_name(name);
		
		CountEmail		(& ref, & QLName);
	}
	
	if (opcode == B_ENTRY_REMOVED)
	{
		PRINT(("B_ENTRY_REMOVED\n"));	

		DiscountEmail	(a_message, & QLName);
		
		// Leave Folder Object intact
	}
}

void 
EmailColumnsApp::DiscountEmail		(BMessage * a_message, BString * QLName)
{
	int32			folder_count	=	0;
	EmailFolder	*	folder;
	
	while((folder = (EmailFolder *) m_folder_list->ItemAt(folder_count)) != NULL)
	{
		if (folder-> DiscountEmail(a_message, QLName) == true)
			break;
		
		folder_count++;
	}
}

void 
EmailColumnsApp::CountEmail		(entry_ref * a_ref, BString * QLName)
{
	int32			folder_count	=	0;
	EmailFolder	*	folder;
	bool			got_folder		=	false;
	
	while((folder = (EmailFolder *) m_folder_list->ItemAt(folder_count)) != NULL)
	{
		//PRINT(("Match ref () against folder (%ld)\n", ref.name, folder_count));
		
		if (folder-> CountEmail(a_ref, QLName) == true)
		{
			got_folder = true;
			break;
		}
		
		folder_count++;
	}

	if (got_folder == false)
	{
		folder	= 	CreateFolder	(a_ref);
		folder->	CountEmail		(a_ref, QLName);
	}
}

EmailFolder *  
EmailColumnsApp::CreateFolder	(const entry_ref * a_ref)
{
	BEntry	entry(a_ref);
	entry.GetParent(& entry);
	
	entry_ref dir_ref;
	entry.GetRef(& dir_ref);
	
	EmailFolder * folder = new EmailFolder(& dir_ref);	// create folder object
	m_folder_list->AddItem(folder);						// add object to list
	
	// create node_ref for 
	
	node_ref	dir_node;
	dir_node.device	=	a_ref->device;
	dir_node.node	=	a_ref->directory;
	
	// start node-monitoring folder NAME and DIRECTORY
	
	watch_node(& dir_node, B_WATCH_NAME | B_WATCH_DIRECTORY , be_app_messenger);
	
	return folder;
}

void 
EmailColumnsApp::PrintStatus	(void)
{
	int32			folder_count	=	0;
	EmailFolder	*	folder;
	
	while((folder = (EmailFolder *) m_folder_list->ItemAt(folder_count)) != NULL)
	{
		folder-> PrintStatus();
		folder_count++;
	}
}

bool
EmailColumnsApp::NotDuplicate	(ino_t	a_inode)
{
	int32		count		=	0;
	ino_t	*	inode;
	
	while((inode = (ino_t *) m_inode_list->ItemAt(count)) != NULL)
	{
		if (a_inode == *inode)	// duplicate
		{
			PRINT(("Caught duplicate inode.\n"));
		
			m_inode_list->RemoveItem(count);
			return false;
		}
		
		count++;
	}

	inode	=	new ino_t	(a_inode);

	m_inode_list->AddItem(inode);
	return true;
}


void 
EmailColumnsApp::AddAttrToMIME	(void)
{
	BMessage folder_attributes;
	
	// make type
	BMimeType	folder_type ("application/x-vnd.Be-directory");
	
	// check that type is installed
	if (! folder_type.IsInstalled())
		return;
	
	// get attribute info
	if (folder_type.GetAttrInfo(& folder_attributes) != B_OK)
		return;
	
	// if attribute X is not installed
	// -> install attribute X
	
#ifdef MAIL_COLUMNS_INT32_ATTRIBUTES
	
	if (! AttributeExists(& folder_attributes, "MCOLS:new", B_INT32_TYPE))
		InstallAttribute	(& folder_attributes, "New", "MCOLS:new", B_INT32_TYPE, false, true, false, 1, 40);
			
	if (! AttributeExists(& folder_attributes, "MCOLS:read", B_INT32_TYPE))
		InstallAttribute	(& folder_attributes, "Read", "MCOLS:read", B_INT32_TYPE, false, true, false, 1, 40);
		
	if (! AttributeExists(& folder_attributes, "MCOLS:draft", B_INT32_TYPE))
		InstallAttribute	(& folder_attributes, "Draft", "MCOLS:draft", B_INT32_TYPE, false, true, false, 1, 40);
		
	if (! AttributeExists(& folder_attributes, "MCOLS:pending", B_INT32_TYPE))
		InstallAttribute	(& folder_attributes, "Pending", "MCOLS:pending", B_INT32_TYPE, false, true, false, 1, 40);
	
	if (! AttributeExists(& folder_attributes, "MCOLS:replied", B_INT32_TYPE))
		InstallAttribute	(& folder_attributes, "Replied", "MCOLS:replied", B_INT32_TYPE, false, true, false, 1, 40);
		
	if (! AttributeExists(& folder_attributes, "MCOLS:saved", B_INT32_TYPE))
		InstallAttribute	(& folder_attributes, "Saved", "MCOLS:saved", B_INT32_TYPE, false, true, false, 1, 40);
		
	if (! AttributeExists(& folder_attributes, "MCOLS:sent", B_INT32_TYPE))
		InstallAttribute	(& folder_attributes, "Sent", "MCOLS:sent", B_INT32_TYPE, false, true, false, 1, 40);
		
#endif	// MAIL_COLUMNS_INT32_ATTRIBUTES

#ifdef MAIL_COLUMNS_STRING_ATTRIBUTES	
	if (! AttributeExists(& folder_attributes, "MCOLS:new", B_STRING_TYPE))
		InstallAttribute	(& folder_attributes, "New", "MCOLS:new", B_STRING_TYPE, false, true, false, 1, 40);
			
	if (! AttributeExists(& folder_attributes, "MCOLS:read", B_STRING_TYPE))
		InstallAttribute	(& folder_attributes, "Read", "MCOLS:read", B_STRING_TYPE, false, true, false, 1, 40);
		
	if (! AttributeExists(& folder_attributes, "MCOLS:draft", B_STRING_TYPE))
		InstallAttribute	(& folder_attributes, "Draft", "MCOLS:draft", B_STRING_TYPE, false, true, false, 1, 40);
		
	if (! AttributeExists(& folder_attributes, "MCOLS:pending", B_STRING_TYPE))
		InstallAttribute	(& folder_attributes, "Pending", "MCOLS:pending", B_STRING_TYPE, false, true, false, 1, 40);
	
	if (! AttributeExists(& folder_attributes, "MCOLS:replied", B_STRING_TYPE))
		InstallAttribute	(& folder_attributes, "Replied", "MCOLS:replied", B_STRING_TYPE, false, true, false, 1, 40);
		
	if (! AttributeExists(& folder_attributes, "MCOLS:saved", B_STRING_TYPE))
		InstallAttribute	(& folder_attributes, "Saved", "MCOLS:saved", B_STRING_TYPE, false, true, false, 1, 40);
		
	if (! AttributeExists(& folder_attributes, "MCOLS:sent", B_STRING_TYPE))
		InstallAttribute	(& folder_attributes, "Sent", "MCOLS:sent", B_STRING_TYPE, false, true, false, 1, 40);		
#endif	// MAIL_COLUMNS_STRING_ATTRIBUTES

	// Commit attributes
	folder_type.SetAttrInfo(& folder_attributes);
	
	// install type
	folder_type.Install();
}

bool
EmailColumnsApp::AttributeExists(BMessage * a_msg, const char * a_name, const int32 a_type)
{
	BString 	NameString;
	int32		type		=	0;
	int32		counter		=	0;
	
	while((a_msg->FindString("attr:name", counter, & NameString)) == B_OK)
	{
		if(NameString == a_name)
		{
			if (a_msg->FindInt32("attr:type", counter, &type) == B_OK)
			{
				if (a_type == type)		return true;
				else					return false;
			}
			else return false;
		}
		counter++;
	}
	return false;
}

void
EmailColumnsApp::InstallAttribute (
		BMessage * a_message, 
		const char * a_public_name,
		const char * a_name, 
		int32 a_type, 
		bool a_editable,
		bool a_viewable,
		bool a_extra,
		int32 a_alignment,
		int32 a_width )
{
	a_message->AddString("attr:public_name", a_public_name);
	a_message->AddString("attr:name", a_name);
	a_message->AddInt32("attr:type", a_type);
	a_message->AddBool("attr:editable", a_editable);
	a_message->AddBool("attr:viewable", a_viewable);
	a_message->AddBool("attr:extra", a_extra);
	a_message->AddInt32("attr:alignment", a_alignment);
	a_message->AddInt32("attr:width", a_width);
}

/*
void 
EmailColumnsApp::WriteAttributes	()
{
	int32			count	=	0;
	EmailFolder	*	folder;
	
	while((folder = (EmailFolder *) m_folder_list->ItemAt(count)) != NULL)
	{
		folder-> WriteAttributes();
		count++;
	}
}
*/

