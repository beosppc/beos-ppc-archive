#include <Looper.h>
#include <Message.h>
#include <Messenger.h>

#ifndef _QUERY_LOOPER_

class QueryLooper : public BLooper
{
public:
	QueryLooper (
					const char * a_query_string,
					const char * name = NULL,
					int32 priority = B_NORMAL_PRIORITY,
					int32 portCapacity = B_LOOPER_PORT_DEFAULT_CAPACITY
				);
	~QueryLooper (void);

	virtual void	MessageReceived	(BMessage	*	a_message);
			void	StartQuery		(void);
			void	StopQuery		(void);
			void 	QueryUpdate		(BMessage * a_message);

private:

	BQuery		*	m_query;
	BVolume		*	m_query_volume;
	BMessenger	*	m_query_messenger;

};

#define _QUERY_LOOPER_
#endif
