// MailColumns
// © jonas.sundstrom@kirilla.com

#define DEBUG 0
#include <Debug.h>

#define MAIL_COLUMNS_STRING_ATTRIBUTES
//#define MAIL_COLUMNS_INT32_ATTRIBUTES


#include <Node.h>
#include <String.h>
#include <Path.h>
#include <Application.h>
#include <fs_attr.h>

#include "EmailFolder.h"

void ErrorMessage (const char * a_text, int32 a_status);

EmailFolder::EmailFolder	(const entry_ref * a_ref)
 : BNode	(a_ref)
{
	m_ref	=	*a_ref;
	
	NewMail		=	0;
	ReadMail	=	0;
	DraftMail	=	0;
	PendingMail	=	0;
	RepliedMail	=	0;
	SavedMail	=	0;
	SentMail	=	0;
	
	//PRINT(("Folder (%s) created.\n", m_ref.name));
}

EmailFolder::~EmailFolder	(void)	
{
	PRINT(("Destroying folder %s.\n", m_ref.name));

	NewMail		=	0;
	ReadMail	=	0;
	DraftMail	=	0;
	PendingMail	=	0;
	RepliedMail	=	0;
	SavedMail	=	0;
	SentMail	=	0;

	WriteAttributes	();	// until Tracker picks up attribute removal
	
	snooze(10000);

	RemoveAttributes();
}


ino_t		
EmailFolder::GetInode		(void)
{
	node_ref nref;
	GetNodeRef(& nref);
	
	return nref.node;
}

char * 
EmailFolder::Name		(void)
{
	return m_ref.name;
}

void
EmailFolder::HandleInit		(BMessage * a_message)
{
	BString QLName;
	a_message->FindString("QLName", & QLName);

	PRINT(("%s::HandleInit: %s\n", Name(), QLName.String()));

	entry_ref	ref;
	int32		ref_count	=	0;
	
	while(a_message->FindRef("refs", ref_count, & ref) == B_OK)
	{
		if (GetInode() == ref.directory)
		{
			CountEmail	(QLName);
			a_message->	RemoveData("refs", ref_count);	//**//
			ref_count--;
		}
		ref_count++;
	}
	
	WriteAttributes	();
}

bool
EmailFolder::CountEmail	(entry_ref * a_ref, BString * QLName)
{
	//PRINT(("CountEmail	(entry_ref * a_ref, BString * QLName)\n"));
	
	if (GetInode() != a_ref->directory)
		return false;
		
	//PRINT(("Folder (%s) -- Email (%s) \n", Name(), a_ref->name));
		
	CountEmail(*QLName);
	
	WriteAttributes	();
		
	return true;
}

bool
EmailFolder::DiscountEmail	(BMessage * a_message, BString * QLName)
{
	entry_ref	ref;
	a_message->	FindInt64("directory", & ref.directory);

	if (GetInode() != ref.directory)
		return false;

	//PRINT(("Folder (%s) -- Email (%s) \n", Name(), a_ref->name));
		
	DiscountEmail(*QLName);
		
	WriteAttributes	();

	return true;
}

void
EmailFolder::CountEmail	(BString QLName)
{
//	PRINT(("CountEmail (%s)\n", QLName.String()));

	// from QueryLoopers   
	// or
	// from reading MAIL:status attribute   (Node Monitor)
	if (QLName == "New")			NewMail++;
	if (QLName == "Read")			ReadMail++;
	if (QLName == "Draft")			DraftMail++;
	if (QLName == "Pending")		PendingMail++;
	if (QLName == "Replied")		RepliedMail++;
	if (QLName == "Saved")			SavedMail++;
	if (QLName == "Sent")			SentMail++;
}

void
EmailFolder::DiscountEmail	(BString QLName)
{
//	PRINT(("DiscountEmail (%s)\n", QLName.String()));

	// from QueryLoopers   
	// or
	// from reading MAIL:status attribute   (Node Monitor)
	if (QLName == "New")			NewMail--;
	if (QLName == "Read")			ReadMail--;
	if (QLName == "Draft")			DraftMail--;
	if (QLName == "Pending")		PendingMail--;
	if (QLName == "Replied")		RepliedMail--;
	if (QLName == "Saved")			SavedMail--;
	if (QLName == "Sent")			SentMail--;
}


void
EmailFolder::CountEmail	(entry_ref * a_ref)
{
	//PRINT(("CountEmail: (%s), (%s)\n", Name(), a_ref->name));

	// read attribute	+	CountEmail (status)		

	BNode	file_node;
	status_t	status	=	B_OK;
	
	if ((status = file_node.SetTo(a_ref)) != B_OK)
	{
		ErrorMessage ("file_node.SetTo(a_ref) ", status);
		return;
	}

	attr_info	a_info;
	
	if ((status = file_node.GetAttrInfo("MAIL:status", & a_info)) != B_OK)
	{
		ErrorMessage ("file_node.GetAttrInfo(MAIL:status) ", status);
		return;
	}
	
	// PRINT(("attr_info.size: (%Ld)\n", a_info.size));
	
	char * buf = new char [a_info.size+1];
	
	if ((status = file_node.ReadAttr("MAIL:status", B_STRING_TYPE, 0, buf, a_info.size+1)) < 0)
	{
		ErrorMessage ("file_node.ReadAttr(MAIL:status) ", status);
		return;
	}
	
	BString mail_status = buf;
	CountEmail(mail_status);
	
	WriteAttributes	();

	delete buf;
}

void
EmailFolder::DiscountEmail	(entry_ref * a_ref)
{
	//PRINT(("DiscountEmail: (%s), (%s)\n", Name(), a_ref->name));

	// read attribute	+	DiscountEmail (status)		

	BNode	file_node;
	status_t	status	=	B_OK;
	
	if ((status = file_node.SetTo(a_ref)) != B_OK)
	{
		ErrorMessage ("file_node.SetTo(a_ref) ", status);
		return;
	}

	attr_info	a_info;
	
	if ((status = file_node.GetAttrInfo("MAIL:status", & a_info)) != B_OK)
	{
		ErrorMessage ("file_node.GetAttrInfo(MAIL:status) ", status);
		return;
	}
	
	// PRINT(("attr_info.size: (%Ld)\n", a_info.size));
	
	char * buf = new char [a_info.size+1];
	
	if ((status = file_node.ReadAttr("MAIL:status", B_STRING_TYPE, 0, buf, a_info.size+1)) < 0)
	{
		ErrorMessage ("file_node.ReadAttr(MAIL:status) ", status);
		return;
	}
	
	BString mail_status = buf;
	DiscountEmail(mail_status);
	
	WriteAttributes	();

	delete buf;
}

void
EmailFolder::PrintStatus	()
{
	BPath path (& m_ref);

	PRINT(("%s --- New: %ld, Read: %ld, Draft: %ld, Pending: %ld, Replied: %ld, Saved: %ld, Sent: %ld\n", 
			path.Path(), NewMail, ReadMail, DraftMail, PendingMail, RepliedMail, SavedMail, SentMail));
}


bool
EmailFolder::DidIJustMove	(BMessage * a_message)
{
	entry_ref	ref;
	a_message->	FindInt64("node", & ref.directory);

	if (GetInode() != ref.directory)	// ?: inode of EmailFolder == inode of update msg
		return false;
	
	// update EmailFolder's entry_ref
	const char *name;
	a_message->	FindInt32("device", & m_ref.device);
	a_message->	FindInt64("to directory", & m_ref.directory);
	a_message->	FindString("name", & name);
	m_ref.set_name(name);
	
	return true;
}

void	
EmailFolder::NewEntryRef	(entry_ref * a_ref)
{
	m_ref = *a_ref;
}


bool
EmailFolder::DidThisMoveTo	(BMessage * a_message)
{
	entry_ref	ref;
	a_message->	FindInt64("to directory", & ref.directory);

	if (GetInode() != ref.directory)	// ?: inode of EmailFolder == inode of update msg
		return false;
	
	// get entry_ref of file
	const char *name;
	a_message->	FindInt32("device", & ref.device);
	a_message->	FindInt64("to directory", & ref.directory);
	a_message->	FindString("name", & name);
	ref.set_name(name);
	
	CountEmail	(& ref);	// count email
	
	WriteAttributes	();
	
	return true;
}

bool
EmailFolder::DidThisMoveFrom	(BMessage * a_message)
{
	entry_ref	ref;
	a_message->	FindInt64("from directory", & ref.directory);

	if (GetInode() != ref.directory)	// ?: inode of EmailFolder == inode of update msg
		return false;
	
	// get entry_ref of file
	const char *name;
	a_message->	FindInt32("device", & ref.device);
	a_message->	FindInt64("to directory", & ref.directory);
	a_message->	FindString("name", & name);
	ref.set_name(name);
	
	DiscountEmail	(& ref);	// discount email
	
	WriteAttributes	();
	
	return true;
}

bool
EmailFolder::DidIJustDie	(BMessage * a_message)
{
	ino_t	inode;
	a_message->	FindInt64("node", & inode);

	if (GetInode() == inode)	
		return true;
	
	return false;
}

void
EmailFolder::WriteAttributes	(void)
{
	#ifdef MAIL_COLUMNS_STRING_ATTRIBUTES
	
	char * NewMail_string = new char [22];
	char * ReadMail_string = new char [22];
	char * DraftMail_string = new char [22];
	char * PendingMail_string = new char [22];
	char * RepliedMail_string = new char [22];
	char * SavedMail_string = new char [22];
	char * SentMail_string = new char [22];
	
	sprintf(NewMail_string, "%ld", NewMail);
	sprintf(ReadMail_string, "%ld", ReadMail);
	sprintf(DraftMail_string, "%ld", DraftMail);
	sprintf(PendingMail_string, "%ld", PendingMail);
	sprintf(RepliedMail_string, "%ld", RepliedMail);
	sprintf(SavedMail_string, "%ld", SavedMail);
	sprintf(SentMail_string, "%ld", SentMail);
	
	if (NewMail == 0)		sprintf(NewMail_string, " ");
	if (ReadMail == 0)		sprintf(ReadMail_string, " ");
	if (DraftMail == 0)		sprintf(DraftMail_string, " ");
	if (PendingMail == 0)	sprintf(PendingMail_string, " ");	
	if (RepliedMail == 0)	sprintf(RepliedMail_string, " ");	
	if (SavedMail == 0)		sprintf(SavedMail_string, " ");
	if (SentMail == 0)		sprintf(SentMail_string, " ");

	WriteAttr("MCOLS:new", B_STRING_TYPE, 0, NewMail_string, 22);
	WriteAttr("MCOLS:read", B_STRING_TYPE, 0, ReadMail_string, 22);
	WriteAttr("MCOLS:draft", B_STRING_TYPE, 0, DraftMail_string, 22);
	WriteAttr("MCOLS:pending", B_STRING_TYPE, 0, PendingMail_string, 22);
	WriteAttr("MCOLS:replied", B_STRING_TYPE, 0, RepliedMail_string, 22);
	WriteAttr("MCOLS:saved", B_STRING_TYPE, 0, SavedMail_string, 22);
	WriteAttr("MCOLS:sent", B_STRING_TYPE, 0, SentMail_string, 22);

	#endif	// MAIL_COLUMNS_STRING_ATTRIBUTES
	
	
	#ifdef MAIL_COLUMNS_INT32_ATTRIBUTES

	WriteAttr("MCOLS:new", B_INT32_TYPE, 0, & NewMail, 4);
	WriteAttr("MCOLS:read", B_INT32_TYPE, 0, & ReadMail, 4);
	WriteAttr("MCOLS:draft", B_INT32_TYPE, 0, & DraftMail, 4);
	WriteAttr("MCOLS:pending", B_INT32_TYPE, 0, & PendingMail, 4);
	WriteAttr("MCOLS:replied", B_INT32_TYPE, 0, & RepliedMail, 4);
	WriteAttr("MCOLS:saved", B_INT32_TYPE, 0, & SavedMail, 4);
	WriteAttr("MCOLS:sent", B_INT32_TYPE, 0, & SentMail, 4);

	#endif	// MAIL_COLUMNS_INT32_ATTRIBUTES
}

void
EmailFolder::RemoveAttributes	(void)
{
	RemoveAttr("MCOLS:new");
	RemoveAttr("MCOLS:read");
	RemoveAttr("MCOLS:draft");
	RemoveAttr("MCOLS:pending");
	RemoveAttr("MCOLS:replied");
	RemoveAttr("MCOLS:saved");
	RemoveAttr("MCOLS:sent");
}


