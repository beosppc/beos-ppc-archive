#include <Application.h>
#include <Message.h>
#include <List.h>
#include <Looper.h>

#include "EmailFolder.h"

#ifndef _EMAIL_COLUMNS_APP_

class EmailColumnsApp : public BApplication
{
public:
	EmailColumnsApp (void);
	~EmailColumnsApp (void);

	virtual void	ReadyToRun		(void);
	virtual bool	QuitRequested	(void);
	virtual void	MessageReceived	(BMessage * a_message);
	virtual void	ArgvReceived	(int32 argc, char **argv);

private:

	void			AddAttrToMIME		(void);
	bool			AttributeExists		(
											BMessage * a_msg,
											const char * a_name,
											const int32 a_type
										);
	void			InstallAttribute 	(
											BMessage * a_message, 
											const char * a_public_name,
											const char * a_name, 
											int32 a_type, 
											bool a_editable,
											bool a_viewable,
											bool a_extra,
											int32 a_alignment,
											int32 a_width 
										);

	void			HandleInit			(BMessage * a_message);
	void 			QueryUpdate			(BMessage * a_message);
	void 			NodeMonitor			(BMessage * a_message);
	
	bool 			NotDuplicate		(ino_t	a_inode);
	
	void			CountEmail			(entry_ref * a_ref, BString * QLName);
	void 			DiscountEmail		(BMessage * a_message, BString * QLName);
	EmailFolder *  	CreateFolder		(const entry_ref * a_ref);
	
	void 			PrintStatus			(void);
	
//	void 			WriteAttributes		();
	
	BList				*	m_folder_list;
	BList				*	m_inode_list;	// for NotDuplicate()
	
	BLooper				*	m_New_QLooper;
	BLooper				*	m_Read_QLooper;
	BLooper				*	m_Draft_QLooper;
	BLooper				*	m_Pending_QLooper;
	BLooper				*	m_Replied_QLooper;
	BLooper				*	m_Saved_QLooper;
	BLooper				*	m_Sent_QLooper;
	
	bool	do_add_attributes_to_mimetype;
	bool	do_quit;						// for --help
};

#define _EMAIL_COLUMNS_APP_
#endif
