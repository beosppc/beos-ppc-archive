// MailColumns
// © jonas.sundstrom@kirilla.com

#define DEBUG 0
#include <Debug.h>

#include <Looper.h>
#include <String.h>
#include <Query.h>
#include <VolumeRoster.h>

#include "QueryLooper.h"

QueryLooper::QueryLooper	(
							const char * a_query_string,
							const char * name,
							int32 priority,
							int32 portCapacity
							)
 : BLooper	(name, priority, portCapacity)
{
	m_query_messenger	=	new BMessenger(NULL, this);
	
	m_query_volume	=	new BVolume();
	BVolumeRoster	vol_roster;
	vol_roster	.	GetBootVolume(m_query_volume);
	
	m_query		=	new	BQuery();

	m_query	->	SetVolume(m_query_volume);
	m_query	->	SetPredicate(a_query_string);
	m_query	->	SetTarget(* m_query_messenger);

	Run();
	PostMessage('strt');	
}

QueryLooper::~QueryLooper	(void)	
{
	delete		m_query;
	delete		m_query_volume;
	delete		m_query_messenger;
}

void 
QueryLooper::MessageReceived	(BMessage * a_message)
{
	switch(a_message->what)
	{
		case 'strt':
				StartQuery();
			break;

		case 'stop':
				StopQuery();
			break;

		case B_QUERY_UPDATE:
				QueryUpdate(a_message);
			break;
					
		default:
				BLooper::MessageReceived(a_message);
			break;			
	}
}

void 
QueryLooper::StartQuery	()
{
	status_t status;
	status	=	m_query	->	Fetch();
		
	// PRINT(("%s: %s\n", "query->Fetch()", strerror(status)));
	
	entry_ref	ref;
	
	BMessage	msg('init');
	
	while(m_query->GetNextRef(& ref) == B_OK)
	{
	//	PRINT(("%s\n", ref.name));

		msg.AddRef("refs", & ref);
	}

	BString QLName;
	QLName = Name();
	msg.AddString("QLName", QLName);

	be_app	->	PostMessage(& msg);
}

void 
QueryLooper::StopQuery	()
{
	m_query	->	Clear();
}


void 
QueryLooper::QueryUpdate	(BMessage * a_message)
{
	// PRINT(("QueryLooper::QueryUpdate()\n"));

	BString QLName;
	QLName = Name();
	a_message	->	AddString("QLName", QLName);

	be_app	->	PostMessage(a_message);
}

