#include <Node.h>
#include <Message.h>
#include <Entry.h>
#include <String.h>

#ifndef _EMAIL_FOLDER_

class EmailFolder : public BNode
{
public:
	EmailFolder		(const entry_ref * a_ref);
	~EmailFolder	(void);

			ino_t	GetInode		(void);
			char *	Name			(void);
			
			void	HandleInit		(BMessage * a_message);
			
			bool	CountEmail		(entry_ref * a_ref, BString * QLName);
			void	CountEmail		(entry_ref * a_ref);

			bool	DiscountEmail	(BMessage * a_message, BString * QLName);
			void	DiscountEmail	(entry_ref * a_ref);
			
			bool	DidIJustMove	(BMessage * a_message);
			bool	DidIJustDie		(BMessage * a_message);
			
			bool	DidThisMoveTo	(BMessage * a_message);
			bool	DidThisMoveFrom	(BMessage * a_message);
			
			void	PrintStatus		(void);

private:
			void	NewEntryRef		(entry_ref * a_ref);

			void	CountEmail		(BString QLName);
			void	DiscountEmail	(BString QLName);

			void	WriteAttributes		();
			void	RemoveAttributes	();


	entry_ref	m_ref;
	
	int32	NewMail;
	int32	ReadMail;
	int32	DraftMail;
	int32	PendingMail;
	int32	RepliedMail;
	int32	SavedMail;
	int32	SentMail;
};

#define _EMAIL_FOLDER_
#endif
