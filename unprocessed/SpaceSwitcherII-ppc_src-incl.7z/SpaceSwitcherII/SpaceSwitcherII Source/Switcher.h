#define ssChangeMode 771003

class SwitcherApp : public BApplication
{
	public:
		SwitcherApp(ulong);
		
		void 	MessageReceived(BMessage*);

};

class SwitcherWindow : public BWindow
{
	public:	
		SwitcherWindow(BRect);
	
		bool	QuitRequested();
};


class SwitcherView : public BView
{
	public:
		SwitcherView(BRect);
		~SwitcherView();
		
		void	Pulse();
		void	Draw(BRect);
		void	MouseDown(BPoint);
	
	private:	
		int currentWorkspace;
		BPopUpMenu *menu;
		float * labelOffsets;
};