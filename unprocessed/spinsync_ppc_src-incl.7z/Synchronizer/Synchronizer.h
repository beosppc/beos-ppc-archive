//
// Synchronizer
// Copyright 1998 by Spindigo Softworks
//

#ifndef H_Synchronizer
#define H_Synchronizer

#include <Application.h>
#include <Window.h>
#include <View.h>
#include <Locker.h>
#include <string>
#include <map>


class fileData
{
public:
	node_ref nref;
	string remotepath;
	fileData() {remotepath = ""; dirty = false;}
	bool dirty;
};


class FSNetLooper;

class SynchronizerApplication : public BApplication 
{
public:
	SynchronizerApplication();
	void MessageReceived(BMessage *);
	void Pulse();
	bool QuitRequested();
	void RefsReceived(BMessage *mess);
	
	enum {
		setSyncInterval = 23000,
		syncNow,
		setServer,
		setLogin,
		setPassword,
		removeFiles,
		setFileInfo,
		setViewMessenger,
		setTargetDir, 
		setPassive,
		setAscii		
	};
	
protected:
	typedef map<string, fileData, less<string>, allocator<fileData> > fdMap;
	fdMap m_files;
	
	BMessenger m_viewMessenger;
	FSNetLooper  *m_netLooper;
	BMessenger m_netMessenger;
	
	string m_server;
	string m_login;
	string m_passwd;
	string m_target;
	bool m_passive;
	bool m_ascii;
	
	int m_interval;
	time_t m_lastSync;
	
	bool p_watchRef(entry_ref &ref, const char *remote=0);
	void p_removeFiles(BMessage *mess);
	void p_setMessengers(BMessage *mess);
	void p_nodeMonitor(BMessage *mess);
	void p_save(BMessage *mess);
};



#endif
