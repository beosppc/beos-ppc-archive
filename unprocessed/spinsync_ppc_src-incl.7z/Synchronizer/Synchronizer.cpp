//
// Synchronizer
// Copyright 1998 by Spindigo Softworks
//

#include "Synchronizer.h"
#include <Autolock.h>
#include <MenuItem.h>
#include <MenuBar.h>
#include "FSWindow.h"
#include "FSView.h"
#include <Node.h>
#include <NodeInfo.h>
#include <NodeMonitor.h>
#include <Path.h>
#include <Entry.h>
#include <Directory.h>
#include "FSNetLooper.h"

int main(int, char **)
{	
	SynchronizerApplication *Synchronizer = 0;
	int rc = 0;
	
	try {
		Synchronizer = new SynchronizerApplication();
		Synchronizer->Run();
	}
	
	catch(...)
	{
		rc = -1;
	}
	
	delete Synchronizer;
	return rc;
}

SynchronizerApplication::SynchronizerApplication()
		  		  : BApplication("application/x-vnd.spindigo-Synchronizer")
{
	FSWindow *fsw;
	string name = "Synchronizer";
	BRect frame; 
	
	frame.Set(100, 100, 500, 500);
	m_interval = -1;
	m_lastSync = 0;
	m_server = "your.ftp.server.com";
	m_login = "you";
	m_passwd = "";
	m_target = "";
	m_passive = false;
	m_ascii = false;
	
	fsw = new FSWindow(frame, name);
	fsw->Show();
	SetPulseRate(1000000);
	
}


void SynchronizerApplication::Pulse()
{
	time_t tim;
	time_t diff;
	char buf[32];
	static time_t lastPrint = 0;
	BMessage moose(FSView::syncTimer);	
	
		
	tim = time(0);
	
	if(m_lastSync == 0)
		m_lastSync = tim;
	
	diff = tim - m_lastSync;
	
	if(m_interval < 0)
		return;
		
	if(diff >= m_interval * 60)
	{
		fdMap::iterator it;
		BMessage mess(FSNetLooper::syncFiles);
		
		int x = 0;
		for(it=m_files.begin(); it != m_files.end(); it++)
		{
			if(((*it).second).dirty == true)
			{
				//
				// Our node_ref is likely stale now, since editors 
				// typically copy over the old files.  The net_thread will
				// send us an updated ref in a REFS_RECEIVED message.
				//
				// The net thread algorithm is:
				// 1.  Make an entry to the file, see if it exists
				// 2.  Get a node_ref to the file
				// 3.  upload the file
				// 4.  mark it as clean for the view thread
				// 5.  send the app a refs_received message
				//
				mess.AddString("localpath", ((*it).first).c_str());
				mess.AddString("remotepath", (*it).second.remotepath.c_str());			
				x++;
			}
		}
		mess.AddString("server", m_server.c_str());
		mess.AddString("login", m_login.c_str());
		mess.AddString("passwd", m_passwd.c_str());
		mess.AddString("targetDir", m_target.c_str());
		mess.AddBool("passive", m_passive);
		mess.AddBool("ascii", m_ascii);
		mess.AddInt32("num", x);

		if(x > 0)
		{
			m_netMessenger.SendMessage(&mess);
		}
		
		m_lastSync = tim;
	}

	if(m_interval > 0 && diff > 0 && ((m_interval * 60) - diff) >= 0 && tim - lastPrint >= 1)
	{
		sprintf(buf, "%d:%02d", ((m_interval * 60) - diff) / 60, ((m_interval * 60) - diff) % 60);
		moose.AddString("string", buf);
		m_viewMessenger.SendMessage(&moose);
		lastPrint = tim;
	}
}


void SynchronizerApplication::MessageReceived(BMessage *mess)
{
	char *name;
	int tmp;
	int8 inter;
	BMessage strmsg(FSView::syncTimer);
	bool boo;
	
	switch(mess->what)
	{
		case setSyncInterval:
			mess->FindInt8("Interval", &inter);
			m_interval = inter;
			if(m_interval == -1)
			{
				strmsg.AddString("string", "on demand");
				m_viewMessenger.SendMessage(&strmsg);
			}
		break;
		
		case syncNow:
			tmp = m_interval;
			m_interval = 0;
			Pulse();
			m_interval = tmp;
		break;
		
		case setServer:
			mess->FindString("Server", &name);
			m_server = name;
		break;
		
		case setLogin:
			mess->FindString("Login", &name);
			m_login = name;
		break;
		
		case setPassword:
			mess->FindString("Password", &name);
			m_passwd = name;
		break;
		
		case setTargetDir:
			mess->FindString("target", &name);
			m_target = name;
		break;
		
		case setPassive:
			mess->FindBool("passive", &boo);
			m_passive = boo;
		break;
		
		case setAscii:
			mess->FindBool("ascii", &boo);
			m_ascii = boo;
		break;
		
		case removeFiles:
			p_removeFiles(mess);
		break;
		
		case setFileInfo:
		break;
		
		case setViewMessenger:
			p_setMessengers(mess);
		break;
		
		case B_SIMPLE_DATA:
			RefsReceived(mess);
		break;
		
		case B_NODE_MONITOR:
			p_nodeMonitor(mess);
		break;
		
		case B_SAVE_REQUESTED:
			p_save(mess);
		break;
		
		default:
			BApplication::MessageReceived(mess);
		break;
	}
	
}



void SynchronizerApplication::p_setMessengers(BMessage *mess)
{
			mess->FindMessenger("Messenger", &m_viewMessenger);
			m_netLooper = new FSNetLooper(m_viewMessenger);
			BMessenger foo(0, m_netLooper);
			m_netMessenger = foo;
}


bool SynchronizerApplication::QuitRequested()
{
	return true;
}

void SynchronizerApplication::p_save(BMessage *mess)
{
	entry_ref directory;
	char *name;
	string message = "Could not save ";
	BMessage smess(FSView::showString);
	BFile file;
	
	if(mess->FindString("name", &name) == B_OK)
	{
		if (mess->FindRef("directory", &directory) == B_OK)
		{
			BDirectory dir(&directory);
			if(dir.InitCheck() == B_NO_ERROR)
			{
				if(dir.CreateFile(name, &file,  false) == B_OK)
				{
					BNodeInfo ni(&file);
					ni.SetType("text/x-spindigo-fsgroup");
					ni.SetPreferredApp("application/x-vnd.spindigo-Synchronizer");
					string outstr;
					fdMap::iterator it;
					char num[32];
					
					outstr = "# Spindigo Synchronizer group file\n";
					outstr += m_server; outstr += "\n";
					outstr += m_login; outstr += "\n";
					outstr += m_target; outstr += "\n";
					if(m_passive) 
						outstr += "on\n";
					else
						outstr += "off\n";
					
					if(m_ascii) 
						outstr += "on\n";
					else
						outstr += "off\n";
					
					sprintf(num, "%d\n", m_files.size());
					
					outstr += num;
					
					for(it=m_files.begin(); it != m_files.end(); it++)
					{
						outstr += (*it).first; outstr += "\n";
						outstr += (*it).second.remotepath; outstr += "\n";
					}
					
					if(file.Write(outstr.c_str(), outstr.length()) == outstr.length())
					{
						//
						// success!
						// 

						message = "Saved ";
					}
				}
			}
		}
	}
	
	if(name != 0)
		message += name;
		
	smess.AddString("string", message.c_str());
	m_viewMessenger.SendMessage(&smess);
}


void SynchronizerApplication::p_removeFiles(BMessage *mess)
{
	unsigned long type;
	long count;
	int i;
	char *path;
	string spath;
	fileData data;
	fdMap::iterator it;
	BEntry entry;
	node_ref nref;
	
	mess->GetInfo("path", &type, &count); 

	for(i=0; i < count; i++) 
	{ 
		if (mess->FindString("path", i, &path) == B_OK) 
		{
			if(path != 0)
			{
				spath = path;
				if((it = m_files.find(spath)) != m_files.end())
				{
					data = (*it).second;
					m_files.erase(it);					
					watch_node(&data.nref, B_STOP_WATCHING, be_app_messenger);
				} 
			}
		}
	}
}


void SynchronizerApplication::RefsReceived(BMessage *message) 
{ 
	unsigned long type; 
	long count; 
	entry_ref ref; 
	long i;
	char mimetype[255];
	BMessage vmess(FSView::addToFileList);
	
	if(m_viewMessenger.IsValid() != true)
	{
		//
		// view messenger not here yet... repost and go on
		//
		PostMessage(message);
		return;
	}
		
	message->GetInfo("refs", &type, &count); 
	
	if (type != B_REF_TYPE) 
		return; 
	for(i=0; i < count; i++) 
	{ 
       if (message->FindRef("refs", i, &ref) == B_OK) 
       { 
			//
			// What we do depends on the file type.
			// If it's a Synchronizer group, we load it and pass the info to the view.
			// If it's a normal file we pass the entry_ref on to the view.
			// If it's a pe group, we deconstruct it and pass its files on to the view.
			//
			BNode lnode(&ref);
			BNodeInfo ni(&lnode);
			string typestr;
			
			ni.GetType(mimetype);
			typestr = mimetype;
			
			if(typestr == "text/x-pe-group")
			{
				//
				// pe group
				//
				// Syntax:
				//
				// ### pe Group File
				// /boot/home/howard/projects/Synchronizer/Synchronizer.cpp
				// /boot/home/howard/projects/Synchronizer/Synchronizer.h
				// [...]
				//
				// If someone drops a pe group on us, they will likely 
				// want the grp file transferred as well...
				//
				
				if(p_watchRef(ref) == true)
					vmess.AddRef("refs", &ref);
								
				BFile grpfile(&ref, B_READ_ONLY);
				
				if(grpfile.InitCheck() == B_NO_ERROR)
				{
					char *buffer = 0;
					off_t siz;
					string pef, pel;
					int n, nn;
					
					grpfile.GetSize(&siz);
					buffer = new char[siz];
					buffer[0] = 0;
					grpfile.Read(buffer, siz);
					pef = buffer;
					delete buffer;
					
					n = 0;
					while(n >= 0)
					{
						nn = pef.find('\n', n);
						if(nn > 0)
						{
							pel = pef.substr(n, nn - n);
							if(pel[0] != '#')
							{
								BEntry ent(pel.c_str());
								if(ent.InitCheck() == B_NO_ERROR)
								{		
									ent.GetRef(&ref);
									if(p_watchRef(ref) == true)
										vmess.AddRef("refs", &ref);
								}
							}	
						}
						n = nn;
						if(n >= 0)
							n++;	
					}
								
				}
				continue;
			} 
			
			if(typestr == "text/x-spindigo-fsgroup")
			{
				//
				// Synchronizer group
				//
				// comment
				// server 
				// login 
				// target 
				// passive 
				// ascii 
				// num 
				// local 
				// remote
				//...			
				BFile spinfile(&ref, B_READ_ONLY);
				
				if(spinfile.InitCheck() == B_NO_ERROR)
				{
					char *bu = 0;
					off_t siz1;
					long off, off2;
					string sg, pr1, pr2;
					long num;
					
					spinfile.GetSize(&siz1);
					bu = new char[siz1];
					bu[0] = 0;
					spinfile.Read(bu, siz1);
					sg = bu;
					delete bu;
					
					//
					// skip first line
					//
					off = sg.find('\n') + 1;
					off2 = sg.find('\n', off);
					m_server = sg.substr(off, off2 - off);
					vmess.AddString("server", m_server.c_str());
					
					off = off2 + 1;
					off2 = sg.find('\n', off);
					m_login = sg.substr(off, off2 - off);
					vmess.AddString("login", m_login.c_str());
										
					off = off2 + 1;
					off2 = sg.find('\n', off);
					m_target = sg.substr(off, off2 - off);
					vmess.AddString("target", m_target.c_str());
					
					off = off2 + 1;
					off2 = sg.find('\n', off);
					pr1 = sg.substr(off, off2 - off);
					if(pr1 == "on")
						m_passive = true;
					vmess.AddBool("passive", m_passive);
										
					off = off2 + 1;
					off2 = sg.find('\n', off);
					pr1 = sg.substr(off, off2 - off);
					if(pr1 == "on")
						m_ascii = true;
					vmess.AddBool("ascii", m_ascii);
											
					off = off2 + 1;
					off2 = sg.find('\n', off);
					pr1 = sg.substr(off, off2 - off);
					num = atol(pr1.c_str());

					for(i=0;i<num;i++)
					{
						off = off2 + 1;
						off2 = sg.find('\n', off);
						pr1 = sg.substr(off, off2 - off);
						
						off = off2 + 1;
						off2 = sg.find('\n', off);
						pr2 = sg.substr(off, off2 - off);
						
						{
							BEntry ent(pr1.c_str());
							if(ent.InitCheck() == B_NO_ERROR)
							{		
								ent.GetRef(&ref);
								if(p_watchRef(ref, pr2.c_str()) == true)
									vmess.AddRef("refs", &ref);
							}
						}	
					}
				}
				continue;
			}
			
			//
			// it's just a plain-old file
			//
			if(p_watchRef(ref) == true)
				vmess.AddRef("refs", &ref);

       } 
	}
	
	m_viewMessenger.SendMessage(&vmess);
}


bool SynchronizerApplication::p_watchRef(entry_ref &ref, const char *remote)
{
	fileData fd;
	string fname;
	BPath path;
	BEntry entry;
	node_ref nref;
	bool rc = false;
	fdMap::iterator it;
	
	entry.SetTo(&ref);
	if(entry.InitCheck() == B_NO_ERROR)
	{
		entry.GetPath(&path);	
		if(path.InitCheck() == B_NO_ERROR)
		{
			fname = path.Path();
			
			if(remote == 0)
				fd.remotepath = path.Leaf();
			else 
				fd.remotepath = remote;
				
			if((it = m_files.find(fname)) == m_files.end())
			{
				rc = true;
			} else
			{
				rc = false;
				fd.remotepath = (*it).second.remotepath;
			}
			
			entry.GetNodeRef(&nref);
			fd.nref = nref;	
			m_files[fname] = fd;
			watch_node(&nref, B_WATCH_ALL, be_app_messenger);
		}		
	}
	return rc;
}


void SynchronizerApplication::p_nodeMonitor(BMessage *msg)
{
	fdMap :: iterator it;
	int32 opcode;
	node_ref nref;
	BMessage dirtmess(FSView::filesDirty);	
	int32 x;

	
	if(msg->FindInt32("opcode", &opcode) == B_OK) 
	{ 	
		switch(opcode) 
		{
			case B_STAT_CHANGED:
			case B_ENTRY_REMOVED:
			case B_ENTRY_MOVED:
			case B_ENTRY_CREATED:
				//
				// NOTE: Many editors are nuking files on saves
				//
				msg->FindInt32("device", &nref.device); 
				msg->FindInt64("node", &nref.node);
				x = 0;
				for(it = m_files.begin(); it != m_files.end(); it++)
				{
					if((*it).second.nref == nref)
					{
						//
						// Here we go.  We need to get a new node_ref for this file now...
						//
						(*it).second.dirty = true;
						dirtmess.AddString("file", (*it).first.c_str());	
						x++;
					}
				}
				dirtmess.AddInt32("num", x);
				if(x > 0)
				{
					m_viewMessenger.SendMessage(&dirtmess);
				}

			break;
			

		}         
	}          	
}


