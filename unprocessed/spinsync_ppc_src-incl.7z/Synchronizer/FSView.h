//
// Synchronizer
// Copyright 1998 by Spindigo Softworks
//

#ifndef H_SynchronizerView
#define H_SynchronizerView

#include <View.h>
#include <ListView.h>
#include <TextControl.h>
#include <StringView.h>
#include <FilePanel.h>
#include <CheckBox.h>
#include <string>
#include <list>


class roView : public BView
{
public:
	roView(BRect frame, char *name);
	void MessageReceived(BMessage* mess); 

protected:
	void p_roCheck(BMessage *mess);
	rgb_color m_backColor;

};

class FSView : public roView 
{
public:
	FSView(BRect frame, char *name); 
	virtual	void AttachedToWindow();
	virtual	void Draw(BRect updateRect);
	void MessageReceived(BMessage* mess); 
	void Pulse();
	
	enum msgs {
		listItemInvoked=2300,
		addFileButton,
		removeFileButton,
		editInfoButton,
		saveGroupButton,
		setServerText,
		setLoginText, 
		setPasswdText,
		periodOnDemand, 
		period1, 
		period5, 
		period10, 
		period30,
		syncNow,	
		addToFileList,
		showString,
		filesDirty,
		filesClean,
		syncTimer,
		setDefDirText,
		setPassive,
		setAscii
	};	
	
protected:
	BListView *m_fileList;
	BTextControl *m_passwdText;
	BTextControl *m_serverText;
	BTextControl *m_loginText;
	BTextControl *m_defDir;
	BCheckBox *m_passive;
	BCheckBox *m_ascii;
	BStringView *m_sv;
	BStringView *m_synctimer;
	BFilePanel *m_panel;
	BFilePanel *m_save_panel;
		
	string m_server;
	string m_login;
	string m_passwd;
	string m_status;
	
	bool m_statusDirty;
	
	void p_addListEntries(BMessage *mess);
	void p_removeListEntries();
	void p_fileState(BMessage *mess, bool dirty);
};

#endif
