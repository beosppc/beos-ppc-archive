//
// Synchronizer
// Copyright 1998 by Spindigo Softworks
//


#include "FSView.h"
#include <Box.h>
#include <ScrollView.h>
#include <MenuItem.h>
#include <MenuBar.h>
#include <Button.h>
#include <MenuField.h>
#include "Synchronizer.h"
#include <Path.h>
#include <Entry.h>
#include <Node.h>
#include <NodeInfo.h>


//
// move this to be a static member of roView
//
typedef list<BView *, allocator<BView *> > viewList;
static viewList pgRoViews;

static void launchnode(const char *path);

class FSMenu : public BMenu
{
public:
	FSMenu(FSView *v, const char *name);
};



FSMenu::FSMenu(FSView *v, const char *name)
	: BMenu(name)
{
	SetTargetForItems(v);
	SetLabelFromMarked(true);
}


class fileListItem : public BStringItem
{
public:
	fileListItem(const char *text);
	void DrawItem(BView *owner, BRect frame, bool complete = false);
	bool m_dirty;
};


fileListItem::fileListItem(const char *text)
	: BStringItem(text)
{
	m_dirty = false;
}


void fileListItem::DrawItem(BView *owner, BRect frame, bool complete)
{
	rgb_color rcol = {0, 0, 0, 255};
	
	if(m_dirty == true)
		rcol.red = 255;
	
	owner->SetHighColor(rcol);
	BStringItem::DrawItem(owner, frame, complete);
}


roView::roView(BRect rect, char *name)
	   	   : BView(rect, name, B_FOLLOW_ALL, B_WILL_DRAW | B_PULSE_NEEDED)
{
	m_backColor.red = 0x68;
	m_backColor.green = 0x6C;
	m_backColor.blue = 0xAC;
	m_backColor.alpha = 255;
	
	SetViewColor(m_backColor);
}



void  roView::MessageReceived( BMessage* mess ) 
{ 
    switch ( mess->what ) 
    { 
	    case B_PASTE: 
	    	p_roCheck(mess);
	    break; 
	    
	    default: 
	        BView::MessageReceived(mess); 
	    break; 
    } 
}

//
// Check for a roColor drop
//
void roView::p_roCheck(BMessage *mess)
{
	rgb_color *cc;
    long  numBytes = sizeof(rgb_color); 
	viewList::iterator it;
	
	if (mess->FindData("RGBColor", B_RGB_COLOR_TYPE, (const void**)&cc, &numBytes) == B_OK ) 
        { 
			if(cc != 0)
			{
           		m_backColor = *cc;           
				if ( mess->WasDropped() ) 
				{ 	
					for(it = pgRoViews.begin(); it != pgRoViews.end(); it++)
					{
						if(*it != 0)
						{
							(*it)->SetViewColor(m_backColor);
							(*it)->Invalidate();
						}
					}
				} 
			}
		} 
}



FSView::FSView(BRect rect, char *name)
			: roView(rect, name)
{
	m_server = "your.ftp.server.com";
	m_login = "you";
	m_fileList = 0;
	m_passwdText = 0;
	m_serverText = 0;
	m_loginText = 0;
	m_synctimer = 0;
	m_sv = 0;
	m_panel = 0;
	m_statusDirty = false;
}


void FSView::Pulse()
{

	if(m_statusDirty == true)
	{
		m_sv->SetText(m_status.c_str());
		m_statusDirty = false;
	}
}


void FSView::AttachedToWindow()
{
	BRect rect, topHalf, topQtr, botQtr, listRect, butRect, tmpRect, pasvRect;
	roView *topView, *midView, *botView;
	BBox *top, *middle, *bottom;
	BButton *but;
	BMenuField *menufield;
	FSMenu *menu;
	BMenuItem *item;
	BFont lfont(be_bold_font); 
	BMessage am(SynchronizerApplication::setViewMessenger);

	//
	// This code sucks.  I'll really have to get Marco's layout lib one of these
	// days.
	//
	// Please don't hate me for this function.  It started out simple but grew, 
	// sort of like pond scum.
	//
	
	rect = Bounds();
	topHalf = rect;
	topHalf.InsetBy(0.0, 10.0);
	topHalf.OffsetTo(B_ORIGIN);
	
	tmpRect.Set(topHalf.left, topHalf.bottom, topHalf.right, rect.bottom);
	m_sv = new BStringView(tmpRect, "status", "Welcome to Synchronizer, from Spindigo Softworks");
	m_sv->SetFont(&lfont);
	
	this->AddChild(m_sv);
	pgRoViews.push_back(m_sv);	
		
	topHalf.InsetBy(0.0, floor(topHalf.bottom / 4.0));
	topHalf.OffsetTo(B_ORIGIN);
	topQtr = topHalf;
	
	topQtr.InsetBy(0.0, floor(topQtr.bottom / 4.0));
	botQtr = topQtr;
	topQtr.OffsetTo(topHalf.left, topHalf.bottom);
	botQtr.OffsetTo(topQtr.left, topQtr.bottom);

	topHalf.InsetBy(5.0, 5.0);
	topQtr.InsetBy(5.0, 5.0);
	botQtr.InsetBy(5.0, 5.0);
	
	topView = new roView(topHalf, "");
	midView = new roView(topQtr, "");
	botView = new roView(botQtr, "");

	AddChild(topView);
	AddChild(midView);
	AddChild(botView);

	topHalf.OffsetTo(B_ORIGIN);
	topQtr.OffsetTo(B_ORIGIN);
	botQtr.OffsetTo(B_ORIGIN);


	lfont.SetSize(16.0); 
	lfont.SetShear(120.0);
	
	top = new BBox(topHalf, "Files to Sync", B_FOLLOW_ALL);
	top->SetFont(&lfont);	
	top->SetLabel("Files to Sync");
	middle = new BBox(topQtr, "Remote login info", B_FOLLOW_ALL);
	middle->SetFont(&lfont);	
	middle->SetLabel("Remote login info");
	bottom = new BBox(botQtr, "Periodicity", B_FOLLOW_ALL);
	bottom->SetFont(&lfont);	
	bottom->SetLabel("Periodicity");

	topView->AddChild(top);
	midView->AddChild(middle);
	botView->AddChild(bottom);

	listRect = topHalf;
	listRect.InsetBy(floor(topHalf.right / 8.0) + 20.0, 20.0);
	listRect.OffsetTo(topHalf.left + 10.0, topHalf.top + 20.0);

	m_fileList = new BListView(listRect, "File List", B_MULTIPLE_SELECTION_LIST);
	BScrollView *bsl = new BScrollView("listscroll", m_fileList, B_FOLLOW_ALL, 0, true, true);
	m_fileList->SetInvocationMessage(new BMessage(listItemInvoked));
	m_fileList->SetTarget(this);
	butRect.Set(0.0, 0.0, 80.0, 24.0);

	butRect.OffsetTo(listRect.right + 30.0, listRect.top);

	
	but = new BButton(butRect, "addfile", "Add Files", new BMessage(FSView::addFileButton));
	but->SetTarget(this);
	but->SetDrawingMode(B_OP_OVER);
	top->AddChild(but);
	
	butRect.OffsetTo(listRect.right + 30.0, butRect.bottom + 8.0);

	but = new BButton(butRect, "remfile", "Remove Files", new BMessage(FSView::removeFileButton));
	but->SetTarget(this);
	but->SetDrawingMode(B_OP_OVER);
	top->AddChild(but);

	butRect.OffsetTo(listRect.right + 30.0, butRect.bottom + 8.0);

	but = new BButton(butRect, "sfile", "Save Group", new BMessage(FSView::saveGroupButton));
	but->SetTarget(this);
	but->SetDrawingMode(B_OP_OVER);
	top->AddChild(but);
		
	top->AddChild(bsl);
		
	tmpRect.Set(0.0, 0.0, 200.0, 20.0);
	pasvRect.Set(0.0, 0.0, 140.0, 20.0);
		
	tmpRect.OffsetTo(topQtr.left + 10.0, topQtr.top + 20.0);	
	m_serverText = new BTextControl(tmpRect, "server", "Server:", m_server.c_str(), new BMessage(FSView::setServerText));
	m_serverText->SetDivider(60.0);
	m_serverText->SetTarget(this);
	middle->AddChild(m_serverText);
	pgRoViews.push_back(m_serverText);	

	pasvRect.OffsetTo(tmpRect.right + 20.0, tmpRect.top);
	m_ascii = new BCheckBox(pasvRect, "ascii", "Use ASCII mode for text", new BMessage(FSView::setAscii));
	m_ascii->SetTarget(this);
	middle->AddChild(m_ascii);
	pgRoViews.push_back(m_ascii);
		
	tmpRect.OffsetTo(topQtr.left + 10.0, tmpRect.bottom +2.0);
	m_loginText = new BTextControl(tmpRect, "login", "Login:", m_login.c_str(), new BMessage(FSView::setLoginText));
	m_loginText->SetDivider(60.0);
	m_loginText->SetTarget(this);
	middle->AddChild(m_loginText);
	pgRoViews.push_back(m_loginText);
	
	pasvRect.OffsetTo(tmpRect.right + 20.0, tmpRect.top);
	m_passive = new BCheckBox(pasvRect, "pasv", "Use Passive ftp", new BMessage(FSView::setPassive));
	m_passive->SetTarget(this);
	middle->AddChild(m_passive);
	pgRoViews.push_back(m_passive);
		
	tmpRect.OffsetTo(topQtr.left + 10.0, tmpRect.bottom +2.0);
	pasvRect.Set(0.0, 0.0, 120.0, 20.0);
	pasvRect.OffsetTo(topQtr.left + 10.0, tmpRect.top);
	tmpRect = pasvRect;	
	m_passwdText = new BTextControl(tmpRect, "passwd", "Password:", "", new BMessage(FSView::setPasswdText));
	m_passwdText->SetTarget(this);
	m_passwdText->SetDivider(60.0);
	middle->AddChild(m_passwdText);
	pgRoViews.push_back(m_passwdText);

	pasvRect.Set(0.0, 0.0, 200.0, 20.0);
	pasvRect.OffsetTo(tmpRect.right + 40.0, tmpRect.top);

	m_defDir = new BTextControl(pasvRect, "default dir", "Target dir:", "", new BMessage(FSView::setDefDirText));
	m_defDir->SetDivider(60.0);
	m_defDir->SetTarget(this);
	middle->AddChild(m_defDir);
	pgRoViews.push_back(m_defDir);	
	
	menu = new FSMenu(this, "On Demand");
	item = new BMenuItem("On Demand", new BMessage(periodOnDemand));
	item->SetTarget(this);
	menu->AddItem(item);

	item = new BMenuItem("Every Minute", new BMessage(period1));
	item->SetTarget(this);
	menu->AddItem(item);

	item = new BMenuItem("Every 5 Minutes", new BMessage(period5));
	item->SetTarget(this);
	menu->AddItem(item);

	item = new BMenuItem("Every 10 Minutes", new BMessage(period10));
	item->SetTarget(this);
	menu->AddItem(item);

	item = new BMenuItem("Every 30 Minutes", new BMessage(period30));
	item->SetTarget(this);
	menu->AddItem(item);
	
	tmpRect.Set(0.0, 0.0, 200.0, 20.0);
	tmpRect.OffsetTo(botQtr.left + 10.0, botQtr.top + 20.0);
	
	menufield = new BMenuField(tmpRect, "syncwhen", "Sync files:", menu);
	menufield->SetDivider(60.0);
	bottom->AddChild(menufield);
	
	butRect.Set(0.0, 0.0, 96.0, 24.0);
	butRect.OffsetTo(tmpRect.left, tmpRect.bottom + 12.0);

	but = new BButton(butRect, "syncnow", "Sync Now", new BMessage(FSView::syncNow));
	but->SetTarget(this);
	but->SetDrawingMode(B_OP_OVER);
	bottom->AddChild(but);
	
	tmpRect.Set(0.0, 0.0, 85.0, 50.0);
	tmpRect.OffsetTo(butRect.right + 80.0, butRect.top - 40.0);
	m_synctimer = new BStringView(tmpRect, "synctimestatic", "Next sync:");
	m_synctimer->SetFont(&lfont);
	bottom->AddChild(m_synctimer);
	pgRoViews.push_back(m_synctimer);
	
	tmpRect.Set(tmpRect.right, tmpRect.top, tmpRect.right + 100.0, tmpRect.bottom);
	m_synctimer = new BStringView(tmpRect, "synctime", "on demand");
	m_synctimer->SetFont(&lfont);
	bottom->AddChild(m_synctimer);

	
	pgRoViews.push_back(m_synctimer);	
	pgRoViews.push_back(menufield);	
	pgRoViews.push_back(top);
	pgRoViews.push_back(middle);
	pgRoViews.push_back(bottom);
	pgRoViews.push_back(this);


	am.AddMessenger("Messenger", BMessenger(this));
	be_app->PostMessage(&am);
	
	roView::AttachedToWindow();
}

void FSView::Draw(BRect r)
{
	roView::Draw(r);
}


void launchnode(const char *path)
{
	entry_ref ref;
	BEntry entry;
	
	if(path == 0)
		return;
	
	if(entry.SetTo(path) == B_NO_ERROR)
	{
		if(entry.GetRef(&ref) == B_NO_ERROR)
		{			
			be_roster->Launch(&ref);
		}
	}
}


void  FSView::MessageReceived( BMessage* mess ) 
{
	BMessage outmess;	
	char *str;
	int32 i, j;
	long count;
	unsigned long type;
	
    switch ( mess->what ) 
    {
		case addFileButton:
			if(m_panel == 0)
				m_panel = new BFilePanel();
		
			m_panel->Refresh();
			m_panel->Show();
		break;
		
		case removeFileButton:
			p_removeListEntries();
		break;
		
		case listItemInvoked:

			mess->GetInfo("index", &type, &count);
			
			for(i=0;i<count; i++)
			{
				mess->FindInt32("index", i, &j);
				launchnode(((fileListItem *) m_fileList->ItemAt(j))->Text());
			}
		break;
		
		case editInfoButton:
		break;
		
		case saveGroupButton:
			if(m_save_panel == 0)
				m_save_panel = new BFilePanel(B_SAVE_PANEL);
		
			m_save_panel->Refresh();
			m_save_panel->Show();

		break;
		
		case setDefDirText:
			outmess.what = SynchronizerApplication::setTargetDir;
			outmess.AddString("target", m_defDir->Text());
			be_app->PostMessage(&outmess);
		break;
		
		case setPassive:
			outmess.what = SynchronizerApplication::setPassive;
			outmess.AddBool("passive", (bool) (m_passive->Value() == B_CONTROL_ON));
			be_app->PostMessage(&outmess);			
		break;
		
		case setAscii:
			outmess.what = SynchronizerApplication::setAscii;
			outmess.AddBool("ascii", (bool) (m_ascii->Value() == B_CONTROL_ON));
			be_app->PostMessage(&outmess);			
		break;
		
		case periodOnDemand: 
			outmess.what = SynchronizerApplication::setSyncInterval;
			outmess.AddInt8("Interval", -1);
			be_app->PostMessage(&outmess);
		break;
		
		case syncNow:	
			outmess.what = SynchronizerApplication::syncNow;
			be_app->PostMessage(&outmess);
		break;
		
		case period1: 
			outmess.what = SynchronizerApplication::setSyncInterval;
			outmess.AddInt8("Interval", 1);
			be_app->PostMessage(&outmess);
		break;
		
		case period5: 
			outmess.what = SynchronizerApplication::setSyncInterval;
			outmess.AddInt8("Interval", 5);
			be_app->PostMessage(&outmess);
		break;
		
		case period10: 
			outmess.what = SynchronizerApplication::setSyncInterval;
			outmess.AddInt8("Interval", 10);
			be_app->PostMessage(&outmess);
		break;
		
		case period30:
			outmess.what = SynchronizerApplication::setSyncInterval;
			outmess.AddInt8("Interval", 30);
			be_app->PostMessage(&outmess);
		break;
		
		case setServerText:
			m_server = m_serverText->Text();
			outmess.what = SynchronizerApplication::setServer;
			outmess.AddString("Server", m_server.c_str());
			be_app->PostMessage(&outmess);
		break;
		
		case setLoginText:
			m_login = m_loginText->Text();
			outmess.what = SynchronizerApplication::setLogin;
			outmess.AddString("Login", m_login.c_str());
			be_app->PostMessage(&outmess);
		break;
		
		case setPasswdText:	
			if(strcmp(m_passwdText->Text(), "<hidden>") != 0)
			{
				m_passwd = m_passwdText->Text();
				m_passwdText->SetText("<hidden>");
				m_passwdText->Invalidate();
				outmess.what = SynchronizerApplication::setPassword;
				outmess.AddString("Password", m_passwd.c_str());
				be_app->PostMessage(&outmess);
			}
		break;
		
		case addToFileList:
			p_addListEntries(mess);
		break;
		
		case showString:
			str = 0;
			mess->FindString("string", &str);
			if(str != 0)
			{
				m_status = str;
				m_statusDirty = true;
			}
		break;
		
		case filesDirty:
			p_fileState(mess, true);
		break;
		
		case filesClean:
			p_fileState(mess, false);
		break;
		
		case syncTimer:
			str = 0;
			mess->FindString("string", &str);
			if(str != 0)
			{
				m_synctimer->SetText(str);
				m_synctimer->Invalidate();
			}
		break;
		
		case B_SIMPLE_DATA:
		case B_REFS_RECEIVED:
			be_app->PostMessage(mess);
		break;
		
	    default: 
	        roView::MessageReceived(mess); 
	    break; 
    } 
}


void FSView::p_fileState(BMessage *mess, bool state)
{
	int32 num = 0;
	long i, j;
	char *file;
	string sfile;
	fileListItem *fli;
	
	if(m_fileList == 0)
		return;

	mess->FindInt32("num", &num);
	
	if(num == 0)
		return;
	
	for(i = 0; i < num; i++)
	{
		mess->FindString("file", i, &file);
		if(file != 0)
		{
			sfile = file;
			for(j = 0; j < m_fileList->CountItems(); j++)
			{
				fli = (fileListItem *) m_fileList->ItemAt(j);
				if(fli != 0 && (fli->Text() != 0))
				{
					 if(sfile == fli->Text())
					 {
					 	fli->m_dirty = state;
					 	break;
					 }
				}
			}
		}
	}
	
	m_fileList->Invalidate();	
}


//
// Take a message full of entry refs, add them to our list view
//
void FSView::p_addListEntries(BMessage *mess)
{
	BMessage fileInfo(SynchronizerApplication::setFileInfo);
	unsigned long type; 
	long count; 
	long i;
	string fname;
	BPath path;
	BEntry entry;
	fileListItem *si;
	entry_ref ref;
	char *val;
	bool boo;
	
	if(m_fileList == 0)
		return;
		
	mess->GetInfo("refs", &type, &count); 
	
	for (i=0; i < count; i++ ) 
	{ 
       if(mess->FindRef("refs", i, &ref) == B_OK) 
       { 
		 	entry.SetTo(&ref);
			if(entry.InitCheck() == B_NO_ERROR)
			{
				entry.GetPath(&path);	
				if(path.InitCheck() == B_NO_ERROR)
				{
					fname = path.Path();
					si = new fileListItem(fname.c_str());
					m_fileList->AddItem(si);
      			}
      		}
       }
	}
	
	if(mess->FindString("server", &val) == B_OK)
	{
		m_server = val;
		m_serverText->SetText(val);
		m_serverText->Invalidate();
	}
	
	if(mess->FindString("login", &val) == B_OK)
	{
		m_login = val;
		m_loginText->SetText(val);
		m_loginText->Invalidate();
	}

	if(mess->FindString("target", &val) == B_OK)
	{
		m_defDir->SetText(val);
		m_defDir->Invalidate();
	}

	if(mess->FindBool("passive", &boo) == B_OK)
	{
		if(boo)
			m_passive->SetValue(B_CONTROL_ON);
		else
			m_passive->SetValue(B_CONTROL_OFF);
	}	
	
	if(mess->FindBool("ascii", &boo) == B_OK)
	{
		if(boo)
			m_ascii->SetValue(B_CONTROL_ON);
		else
			m_ascii->SetValue(B_CONTROL_OFF);
	}	

	m_fileList->Invalidate();
}


void FSView::p_removeListEntries()
{
	BMessage am(SynchronizerApplication::removeFiles);
    fileListItem *item; 
    long selected = 0; 
    int i = 0;
    const char *path;
    
    while ((selected = m_fileList->CurrentSelection(0)) >= 0) 
    { 
    	i++;
        item = (fileListItem *) m_fileList->RemoveItem(selected); 
        if(item != 0)
        {
        	path = item->Text();
        	am.AddString("path", path);
        	delete item;
        }   
    }	
    
    if(i > 0)
    	be_app->PostMessage(&am);
	
}
