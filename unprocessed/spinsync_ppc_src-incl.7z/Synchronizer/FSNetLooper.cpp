//
// Synchronizer
// Copyright 1998 by Spindigo Softworks
//

#include "FSNetLooper.h"
#include "Synchronizer.h"
#include "FSView.h"
#include "NLAddress.h"
#include "NLEndpoint.h"
#include "NLException.h"
#include <Entry.h>
#include <Node.h>
#include <NodeInfo.h>
#include <Path.h>
#include <stdio.h>

FSNetLooper::FSNetLooper(BMessenger &viewMsg)
	: BLooper("net looper")
{
	m_viewMessenger = viewMsg;
	Run();
}


void FSNetLooper::p_logMsg(const char *msg)
{
	BMessage mess(FSView::showString);
	mess.AddString("string", msg);
	m_viewMessenger.SendMessage(&mess);
	fprintf(stdout, "Synchronizer: %s\n", msg);
}


void FSNetLooper::MessageReceived(BMessage *mess)
{
	switch(mess->what)
	{
		case FSNetLooper::syncFiles:
			p_sendDirtyFiles(mess);
		break;
	}
}


void FSNetLooper::p_sendDirtyFiles(BMessage *mess)
{
	char *val;
	string server, login, passwd, local, remote, targetDir;
	int32 num;
	long i;
	entry_ref er;
	bool failed = false, passive;
	
	if(mess->FindString("server", &val) != B_OK)
		return;
	server = val;
	
	if(mess->FindString("login", &val) != B_OK)
		return;
	login = val;

	if(mess->FindString("passwd", &val) != B_OK)
		return;
	passwd = val;

	if(mess->FindString("targetDir", &val) != B_OK)
		return;
	targetDir = val;
	
	if(targetDir.length() > 0)
	{
		if(targetDir[targetDir.length() - 1] != '/')
			targetDir += '/';
	}

	if(mess->FindBool("passive", &passive) != B_OK)
		return;
		
	if(mess->FindBool("ascii", &m_ascii) != B_OK)
		return;
	
	if(mess->FindInt32("num", &num) != B_OK)
		return;

	if(num == 0)
		return;
	
	try 
	{
		FtpClient ftp;
		string msg;
		
		ftp.setPassive(passive);
		
		msg = "Connecting to ";
		msg += server; msg += "...";
		p_logMsg(msg.c_str());
		if(ftp.connect(server, login, passwd) != true)
		{
			//
			// send failure message
			//
			p_logMsg("Connection failed!");
			return;
		}
				
		for(i = 0; i < num; i++)
		{
			if(mess->FindString("localpath", i, &val) != B_OK)
				return;
			local = val;
			if(mess->FindString("remotepath", i, &val) != B_OK)
				return;
			remote = val;
			if(remote.find('/') == -1)
			{
				//
				// If the remote path does not include a directory,
				// append the default dirname to it
				//
				if(targetDir.length() > 0)
				{
					remote = targetDir + remote;
				}
			}
			
			msg = "Syncing ";
			msg += local; msg += "...";
			p_logMsg(msg.c_str());
			if(p_sendFile(local, remote, er, ftp) == true)
			{
				//
				// Mark as clean in the view, send a refs_received
				// to the app
				//
				BMessage viewMess(FSView::filesClean);
				BMessage appMess(B_REFS_RECEIVED);
				
				viewMess.AddInt32("num", 1);
				viewMess.AddString("file", local.c_str());
				appMess.AddRef("refs", &er);
				m_viewMessenger.SendMessage(&viewMess);
				be_app_messenger.SendMessage(&appMess);
				
			} else {
				msg = "Sync failed for ";
				msg += local; msg += "!";
			    p_logMsg(msg.c_str());			
			    failed = true;
			}
		}
	}
		
	catch(NLException &ftpx)
	{
	
	}
	string fmsg = "Sync complete.";
	if(failed)
		fmsg += "  Some files failed to sync...";
	p_logMsg(fmsg.c_str());

}





bool FSNetLooper::p_sendFile(const string &local, const string &remote, entry_ref &er, FtpClient &ftp)
{
	BEntry entry(local.c_str());
	string tmprname = "Synchronizer__Upload";
	bool rc = false;
	FtpClient::ftp_mode mode = FtpClient::binary_mode;
	long i;
	
	if(entry.Exists() == false)
	{
		return false;
	}
	
	if((i = remote.rfind('/')) != -1)
	{
		tmprname = remote.substr(0, i + 1) + tmprname;
	}
	
	entry.GetRef(&er);
	
	if(m_ascii == true)
	{
		//
		// check the mime type to see if this is a text file
		//
		char mimetype[255];
		BNode lnode(&er);
		BNodeInfo ni(&lnode);
		string typestr;
			
		ni.GetType(mimetype);
		typestr = mimetype;
		if(typestr.find("text") >= 0)
			mode = FtpClient::ascii_mode;
	}
	
	rc = ftp.putFile(local, tmprname, mode);
	if(rc == true)
	{
		rc = ftp.moveFile(tmprname, remote);
	}
	
	return rc;
}


