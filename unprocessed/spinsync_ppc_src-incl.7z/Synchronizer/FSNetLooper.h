//
// Synchronizer
// Copyright 1998 by Spindigo Softworks
//

#ifndef H_SynchronizerNetLooper
#define H_SynchronizerNetLooper

#include <Looper.h>
#include <Application.h>
#include "FtpClient.h"


class FSNetLooper : public BLooper
{
public:

	FSNetLooper(BMessenger &viewMsg);
	void MessageReceived(BMessage *mess);
	
	enum {
		syncFiles=23999
	};
	
protected:
	bool p_sendFile(const string &local, const string &remote, entry_ref &er, FtpClient &ftp);
	void p_logMsg(const char *msg);
	BMessenger m_viewMessenger;
	void p_sendDirtyFiles(BMessage *mess);
	bool m_ascii;
	
};


#endif
