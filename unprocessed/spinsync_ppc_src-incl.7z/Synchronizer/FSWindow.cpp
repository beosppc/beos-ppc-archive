//
// Synchronizer
// Copyright 1998 by Spindigo Softworks
//


#include <Application.h>

#include "FSWindow.h"
#include "FSView.h"
#include "Synchronizer.h"
#include <ScrollView.h>
#include <MenuItem.h>
#include <MenuBar.h>
#include <ScrollView.h>



FSWindow::FSWindow(BRect frame, string &name)
				: BWindow(frame, name.c_str(), B_TITLED_WINDOW, B_NOT_RESIZABLE)
{
	BRect ucRect = frame;
	FSView *ucView;
	
	ucRect.OffsetTo(B_ORIGIN);
	ucView = new FSView(ucRect, (char *) name.c_str());

	this->AddChild(ucView);

}




void FSWindow::MessageReceived(BMessage *mess)
{
	
	switch(mess->what)
	{								
		default:
			BWindow::MessageReceived(mess);
		break;
	}

}

bool FSWindow::QuitRequested()
{	
	be_app->PostMessage(B_QUIT_REQUESTED);
	return true;
}


