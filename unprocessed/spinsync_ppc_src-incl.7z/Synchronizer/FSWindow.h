//
// Synchronizer
// Copyright 1998 by Spindigo Softworks
//

#ifndef H_SynchronizerWIN
#define H_SynchronizerWIN

#include <Window.h>
#include <string>


class FSWindow : public BWindow 
{
public:
	FSWindow(BRect frame, string &name); 
	virtual	bool QuitRequested();
			
 	void MessageReceived(BMessage *message);
 	 	
protected:


};

#endif
