#include <Application.h>

class RPNApp
	:public BApplication
{
	public:
	RPNApp();
	virtual void ReadyToRun();
};