#include <ctype.h>

int isint( double testdbl );
int isnumber( const char * instring );
void makeupper( char * string );