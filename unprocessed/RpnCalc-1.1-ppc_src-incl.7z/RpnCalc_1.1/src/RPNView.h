#include <View.h>

class RPNView
	:public BView
{
	public:
	RPNView( BRect Frame, const char * name );	
};