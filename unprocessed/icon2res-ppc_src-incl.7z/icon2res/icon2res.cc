/* icon2res - Converts attributes to a mwbres resource file */
/* Daniel Lundin <daniel@swelinux.org>  */

#include <stdio.h>
#include <memory.h>
#include <string.h>
#include <Be.h>

//#define CONVERT_ALL_ATTRIBS

void Dump(char *fileName, char* attrName);
void Convert(FILE* rfile,
			BNode *node , 
			char *attrName, 
			attr_info *ainfo,
			uint32 resid);

int main(int argc, char *argv[])
{
	char aname[B_ATTR_NAME_LENGTH];
	char filename[B_FILE_NAME_LENGTH];
	char resfile[B_FILE_NAME_LENGTH];
	uint i=1;
	attr_info ainfo;
	status_t err;
	FILE *file;
	BNode 	*node;
	
	switch( argc) {
	
		case 4:
			strcpy(aname,argv[3]);

		case 3:
			strcpy(filename,argv[1]);
			strcpy(resfile,argv[2]);
			if ( strncmp( &resfile[strlen(resfile)-2], ".r", 2 ) )	// Make sure resfile ends with .r
				strcat(resfile,".r");
			break;	
	
		case 5:				
		default:
			printf("\nIcon2res 1.0 ");
			#ifdef CONVERT_ALL_ATTRIBS
				printf("[Allattribs hack version]");
			#endif
			printf("\nBy: Daniel Lundin <daniel@swelinux.org>\n\n");
			printf("Usage: icon2res inputfile resfile [attrname]\n");
			exit(0);
	}
	
	node=new BNode(filename);	// Open node
	
	if( node->InitCheck() != B_NO_ERROR ) {
		printf("Open icon file failed.\n");
	} else {
	
		file=fopen(resfile,"w+");	// Open output file
	
		if( file == NULL ) 
			printf("Error opening resourcefile\n");
		else {
	
			printf("  Type   Name                     Size     Length   Res.ID\n");
			printf("  ------ ------------------------ -------- -------- ------\n");
			
		
			if( argc>3 ) {		// Attribute name was given as argument so we just need to convert one attr
	
				if( node->GetAttrInfo(aname,&ainfo) == B_NO_ERROR )
					Convert(file,node, aname,&ainfo,101);
	
			} else			// Step through all icon attributes
				while (node->GetNextAttrName(aname) == B_NO_ERROR) {	
					node->GetAttrInfo(aname,&ainfo);
					Convert(file,node, aname,&ainfo,100+i);
					i++;
				}
			fclose(file);	// Close output file
		}
		delete node;		
	}
}


void Convert(	FILE* rfile,BNode *node,
			char *attrName, 
			attr_info *ainfo, 
			uint32 resid)
{
	ssize_t size;
	uint32 *buffer;
	uint32 width, height;

#ifndef CONVERT_ALL_ATTRIBS
	if( ainfo->type == 'ICON' || ainfo->type == 'MICN' )	{	// Is attribute an icon?
#endif
		buffer=(uint32 *)malloc(ainfo->size);
			
		if( NULL!=buffer ) {

			// Set default icon dimensions
			if( ainfo->type=='ICON' )
				width=height=32;
			else if ( ainfo->type=='MICN' )
				width=height=16;				
		
			size=(node->ReadAttr(attrName,NULL,NULL,buffer,ainfo->size) ) / 4;	// 4 bytes/

			// Print attribute/resource to stdout
			printf("  %-4.4s   %-24.24s %-3ux %-3u %-8lu %-6u\n",
					&(ainfo->type),
					attrName,
					width,
					height,
					size,
					resid
				);	
						
			// Print resource header
			fprintf(rfile,"resource( \'%.4s', %u, \"%s\" )\n{",
					&(ainfo->type),resid,attrName);

			for( 	uint32 i=0;i<size;i++) {

				if( i%8==0 )				// 8  unit32's per line
					fprintf(rfile,"\n   ");	
					
				fprintf(rfile,"%-10lu", buffer[i]);
				
				if( i+1<size )				// Place a comma if this isn't the last uint32
					fprintf(rfile," ,");
			}
			fprintf(rfile,"\n}\n");
			
			free(buffer);	// Free memory
		}
	
#ifndef CONVERT_ALL_ATTRIBS
	}
#endif

}

