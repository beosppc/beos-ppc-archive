// EPSTranslator v1.0.0
//
// Author: Tom Hays, trh@lns598.lns.cornell.edu
//

extern "C" {
	
status_t Identify(BPositionIO &stream, 
	const translation_format *inFormat,	 
	BMessage *ioExtension, 
	translator_info &info, 
	uint32 type);

status_t Translate(BPositionIO &input, 
	const translator_info &info, 
	BMessage *extension, 
	uint32 type, 
	BPositionIO &output);
	
}
