#include <stdio.h>
#include <string.h>
#include <stdlib.h>
 
#include <TranslatorAddOn.h>
#include <TranslationDefs.h>
#include <TranslatorFormats.h>

#define	EPS_TYPE_CODE	'EPSF'
 
// EPSTranslator v1.0.0
//
// Author: Tom Hays, trh@lns598.lns.cornell.edu
//
// Thanks to:
//
//  E. Tomlinson for the source of XPMTranslator used as an example
//  for the TranslationKit.
//
//  Thomas Merz for the source of jpeg2ps used as an example for Base85 encoding.

//
// Translates RGB B_TRANSLATOR_BITMAP into EPS (without compression)
// 1 bit B_TRANSLATOR_BITMAPS are planned for the future.

// This version uses Base85 encoding in the EPS for the bitmap  

// After 24, 8, and 1 bit images are possible, compression will 
// be added.  Level 2 PostScript compression options will include:
// RLE, CCITTFaxEncode, DCTEncode

status_t ToEPS(BPositionIO *input, BPositionIO *output);
void ToHex(char *theHex,uint8 value);
int ToBase85Buffered(unsigned char *inputBuf, long int *inLength, 
                     unsigned char *outBuf, long int *outLength, bool last);
int ToBase85(unsigned char *the85, unsigned char *theBinary, int numBytes);
uint32 get_stream_type(BPositionIO *stream);

#pragma export on

char translatorInfo[] = "EPS translator for bitmap images"; 

char translatorName[] = "EPS bitmap"; 

int32 translatorVersion = 100;

translation_format inputFormats[] =
{
// Why do I have to have this first entry?
// This translator only will output the EPS
// and not input EPS.  Hmmm...
	{
		EPS_TYPE_CODE,
		B_TRANSLATOR_BITMAP,
		0.1,
		0.1,
		"application/postscript",
		"EPS image"
	},
	{
		B_TRANSLATOR_BITMAP,
		B_TRANSLATOR_BITMAP,
		0.1,
		0.1,
		"image/x-be-bitmap",
		"Be Bitmap Format"
	},
	{ 0, 0, 0, 0, 0, 0 } 
};

translation_format outputFormats[] =
{
//	{
//		B_TRANSLATOR_BITMAP,
//		B_TRANSLATOR_BITMAP,
//		0.1,
//		0.1,
//		"image/x-be-bitmap",
//		"Be Bitmap Format"
//	},
	{
		EPS_TYPE_CODE,
		B_TRANSLATOR_BITMAP,
		0.1,
		0.1,
		"application/postscript",
		"EPS image"
	},
	{ 0, 0, 0, 0, 0, 0 } 
};

//	Identify()
//	check the identity of the input stream, and see if a match with the
//	output capabilities of the translator exists.  The legitimate possibilities
//	are:
//	input = DATA_BITMAP, output = EPS_TYPE_CODE or nothing -> output EPS data

status_t Identify(
	BPositionIO *stream, 
	const translation_format *inFormat,
	BMessage *ioExtension, 
	translator_info *info,
	uint32 type)
{
	uint32 ourType;
	
	ourType = get_stream_type(stream);  

    if (ourType == B_TRANSLATOR_BITMAP && (!type || type == EPS_TYPE_CODE))
	{
		info->type = inputFormats[1].type;
		info->group = inputFormats[1].group;
		info->quality = inputFormats[1].quality;
		info->capability = inputFormats[1].capability;
		strcpy(info->name,inputFormats[1].name);
		strcpy(info->MIME,inputFormats[1].MIME);
		return B_OK;
	}
	else
		return B_NO_TRANSLATOR;
}

//	Translate()
status_t Translate(
	BPositionIO *input, 
	const translator_info *info, 
	BMessage *extension, 
	uint32 type, 
	BPositionIO *output
	)
{
	uint32 ourType;
	
	ourType = get_stream_type(input);

	if (ourType == B_TRANSLATOR_BITMAP && (!type || type == EPS_TYPE_CODE))
		return ToEPS(input,output);
	else
		return B_NO_TRANSLATOR;
}

#pragma export reset

status_t ToEPS(BPositionIO *input, BPositionIO *output)
{
    char outBuffer[1024];
    TranslatorBitmap theBitmap;
    int llx, lly, urx, ury;        /* Bounding box coordinates */
    time_t theTime;
    int pageHeight,pageWidth, margin;
    int imageWidth, imageHeight;
    int row, column;
    uint8 alpha, red, green, blue;
    char the85[7];
    
    int lineLengthCounter;
    unsigned char *inDataBuf,*inputBuffer;
    unsigned char *outDataBuf;
    long imageSourceBytes;    
    long imageTargetBytes;
    long imagePixels, pixel;
    long iQuart, numQuartuplets;
    long i, outPosn, numLines;
    long int inBufLength, outBufLength;
    long bytesPerRow;
    int inputOffset;
    
    int outLineLength = 75;
    long totalOutputBytes;
        
	input->Seek(0,SEEK_SET); // Read from beginning.
    input->Read(&theBitmap,sizeof(theBitmap)); // BigEndian ok for PPC

	switch(theBitmap.colors){
       case B_GRAY1:
           return B_NO_TRANSLATOR;  
   	       break;
       case B_GRAY8:
       case B_RGB32:
           break;
       case B_CMAP8:
       case B_RGB15:
       case B_RGB15_BIG:
       case B_RGBA15_BIG:
       case B_RGB16:
       case B_RGB16_BIG:
           return B_NO_TRANSLATOR;  
           break;
       case B_RGB32_BIG:
           return B_NO_TRANSLATOR;  
   	       break;
       default:
           return B_NO_TRANSLATOR; 
           break;
      	}
	

    margin     = 20;            
    
    imageWidth = theBitmap.bounds.IntegerWidth()+1;
    imageHeight = theBitmap.bounds.IntegerHeight()+1;
    llx = margin;
    lly = margin;
    urx = margin + imageWidth;
    ury = margin + imageHeight;

    imagePixels = imageWidth*imageHeight;
    
    switch (theBitmap.colors){
           case B_RGB32:
              imageSourceBytes = imageWidth*4; // one row at a time
              imageSourceBytes += 3;  // Used for converting to base85.
              imageTargetBytes = imageWidth*3*5/4+10; // enough for base85
              break;
           case B_GRAY8:
              imageSourceBytes = imageWidth; // one row at a time
              imageSourceBytes += 3;  // Used for converting to base85.
              imageTargetBytes = imageWidth*5/4+10; // enough for base85
              break;
           default:
           break;
    }       
    
    inDataBuf = (unsigned char *)malloc(imageSourceBytes);
	outDataBuf = (unsigned char *)malloc(imageTargetBytes); // 5/4 + 2
	if (inDataBuf == NULL || outDataBuf == NULL) {
		free(inDataBuf);
		free(outDataBuf);
		return B_NO_MEMORY;
	}


  sprintf(outBuffer, "%%!PS-Adobe-3.0 EPSF-3.0\n");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "%%%%Creator: EPSTranslator %s by Thomas Hays v0.8\n");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "%%%%Title: unknown\n");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "%%%%CreationDate: %s", ctime(&theTime));
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "%%%%BoundingBox: %d %d %d %d\n", 
                   llx, lly, urx, ury);
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "%%%%DocumentData: Clean7Bit\n");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "%%%%LanguageLevel: 2\n");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "%%%%EndComments\n");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "%%%%BeginProlog\n");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "%%%%EndProlog\n");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "%%%%Page: 1 1\n");

    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "/languagelevel where {pop languagelevel 2 lt}");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "{true} ifelse {\n");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "  (file 'unknown' needs PostScript Level 2!");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "\\n) dup print flush\n");
    output->Write(outBuffer,strlen(outBuffer));  
  sprintf(outBuffer, "  /Helvetica findfont 20 scalefont setfont ");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "100 100 moveto show showpage stop\n");
    output->Write(outBuffer,strlen(outBuffer));
  sprintf(outBuffer, "} if\n");
    output->Write(outBuffer,strlen(outBuffer));

  sprintf(outBuffer, "save\n");
    output->Write(outBuffer,strlen(outBuffer));    


  sprintf(outBuffer, "/RawData currentfile /ASCII85Decode filter def\n");
      output->Write(outBuffer,strlen(outBuffer));    

  sprintf(outBuffer,"%i %i translate\n",margin,margin);
    output->Write(outBuffer,strlen(outBuffer));    

  sprintf(outBuffer,"%i %i scale\n",
       imageWidth, imageHeight);
    output->Write(outBuffer,strlen(outBuffer));    

  switch(theBitmap.colors){
     case B_RGB32:
        sprintf(outBuffer,"/DeviceRGB setcolorspace\n");
        break;
     case B_GRAY8:
        sprintf(outBuffer,"/DeviceGray setcolorspace\n");
        break;
     default:
        break;
  }
    output->Write(outBuffer,strlen(outBuffer));    

  sprintf(outBuffer, "{ << /ImageType 1\n");
    output->Write(outBuffer,strlen(outBuffer));    
  sprintf(outBuffer, "     /Width %d\n", imageWidth);
    output->Write(outBuffer,strlen(outBuffer));    
  sprintf(outBuffer, "     /Height %d\n", imageHeight);
    output->Write(outBuffer,strlen(outBuffer));    
  sprintf(outBuffer, "     /ImageMatrix [ %d 0 0 %d 0 %d ]\n",
                    imageWidth, -imageHeight, imageHeight);
    output->Write(outBuffer,strlen(outBuffer));    
  sprintf(outBuffer, "     /DataSource RawData\n");
    output->Write(outBuffer,strlen(outBuffer));    
  sprintf(outBuffer, "     /BitsPerComponent 8\n");
    output->Write(outBuffer,strlen(outBuffer));    

  switch(theBitmap.colors){
     case B_RGB32:
        sprintf(outBuffer, "     /Decode [0 1 0 1 0 1]\n");
        break;
     case B_GRAY8:
        sprintf(outBuffer, "     /Decode [0 1\n");
        break;
     default:
        break;
  }
    output->Write(outBuffer,strlen(outBuffer));    

  sprintf(outBuffer, "  >> image\n");
    output->Write(outBuffer,strlen(outBuffer));    

  sprintf(outBuffer, "%  RawData flushfile\n");
    output->Write(outBuffer,strlen(outBuffer));    
  sprintf(outBuffer, "  showpage\n");
    output->Write(outBuffer,strlen(outBuffer));    
  sprintf(outBuffer, "  restore\n");
     output->Write(outBuffer,strlen(outBuffer));    
  sprintf(outBuffer, "} exec\n");
    output->Write(outBuffer,strlen(outBuffer));    

  lineLengthCounter = 0;

  inputOffset = 0;  // There may be 1-3 bytes left over from the previous time.
  switch(theBitmap.colors){
     case B_RGB32:
        bytesPerRow = imageWidth*4;
        break;
     case B_GRAY8:
        bytesPerRow = imageWidth*1;
        break;
     default:
        break;
  }
  
  for (row = 0; row < imageHeight; row++){
     inputBuffer = inDataBuf + inputOffset;
     input->Read(inputBuffer, bytesPerRow);

     // Do an in-place conversion of the source bytes from the BBitmap format to
     // the EPS image format 
     switch (theBitmap.colors){
        case B_RGB32:
           for (pixel = 0; pixel < imageWidth; pixel++){
      	      // Translates from BGRA to RGB order
              inputBuffer[pixel*3]   = (unsigned char) inputBuffer[pixel*4+2]; //Red
              inputBuffer[pixel*3+1] = (unsigned char) inputBuffer[pixel*4+1]; //Green
              inputBuffer[pixel*3+2] = (unsigned char) inputBuffer[pixel*4  ]; //Blue
              // Alpha ignored            
            }
           inBufLength = imageWidth*3 + inputOffset;
           break;
        case B_GRAY8:
           // do nothing since the formats are identical;
           inBufLength = imageWidth + inputOffset;
        break;

        default:
        break;
     }       
       
     if (row == imageHeight -1){
        inputOffset = ToBase85Buffered(inDataBuf, &inBufLength,outDataBuf,&outBufLength,true);
     } else {
        inputOffset = ToBase85Buffered(inDataBuf, &inBufLength,outDataBuf,&outBufLength,false);
     }

     output->Write(outDataBuf,outBufLength);
 
  } // end loop over rows. 

  sprintf(outBuffer, "\n\%\%EOF\n");
    output->Write(outBuffer,strlen(outBuffer));    

    return B_OK;
}

/* Converts the buffer inputBuf to base85 (as the Postscript Level 2 filter. */
/* This routine allows the caller to send it blocks of data of any length.   */
/* If there are more blocks coming, (!last), this will eat the data up to a  */
/* multiple of 4 bytes and leave the leftover in the buffer.                */
/* If it is the last block, all of the data will be consumed.  */
/* Make sure that the output buffer is long enough. */
/* A conservative guess for the output buffer is: */
/* out = in *5/4 + 7; */
int ToBase85Buffered(unsigned char *inputBuf, long int *inLength, 
                     unsigned char *outBuf, long int *outLength, bool last){
   long int numPackets;
   long int leftOver;
   
   long int bufPosn;
   long int i;

   unsigned char the85[7];
   
   *outLength = 0;
   numPackets = *inLength/4;
   leftOver = *inLength - numPackets*4;

   bufPosn = 0;
   for (i=0;i<numPackets;i++){
      *outLength += ToBase85(outBuf+(*outLength), inputBuf+bufPosn,4);
      bufPosn += 4;
   }	

   if (last){
   	  *outLength += ToBase85(outBuf+(*outLength), inputBuf+bufPosn, leftOver);
      *inLength = 0; /* Ate it all */
   } else {
      /* Leave remainder at the beginning of the input buffer */
      for (i=0;i<leftOver;i++){
         inputBuf[i] = inputBuf[bufPosn + i];	
         *inLength = leftOver;
      }
   }   	  

  return leftOver;                     	
} 


/* 
 theBinary is numBytes long;
 numBytes is between 1 and 4;
 the85 needs to be at least 7 bytes long.  The longest case is for 
 the case when numBytes = 3. (4 in base85, 2 for EOD, 1 for null)
*/
int ToBase85(unsigned char *the85, unsigned char *theBinary, int numBytes){
/* Based upon code (C) by Thomas Merz 1994-1996 */

unsigned long power85[5] = { 1L, 85L, 85L*85, 85L*85*85, 85L*85*85*85};

  unsigned long value, outValue;
  int i,outPosn;
    
     outPosn = 0;
     value = ((unsigned long)(((unsigned int)theBinary[0] << 8) + theBinary[1]) << 16) +
                   (((unsigned int)theBinary[2] << 8) + theBinary[3]);

if (numBytes == 4){

      if (value == 0){
         the85[0]='z';  /* shortcut for 0 */
         the85[1]='\0';
      } else {  /* non-zero number from 4 bytes of input */ 
      /* calculate 5 ASCII85 bytes and output them */
         for (i = 4; i >= 0; i--) {
	        outValue = value / power85[i];
	        the85[outPosn] = (unsigned char)outValue + '!';
            outPosn++;
	        value     -= outValue * power85[i];
         }
         the85[outPosn] = '\0'; /* To make a well formed string */
         outPosn++;
      }
  } else { /* Handle less than 4 and append EOD (occurs only at the end of the stream) */
      for (i = numBytes-1; i >= 0; i--){   /* accumulate bytes */
         value += (unsigned long)theBinary[i] << 8 * (3-i);
      }
    /* encoding as above, but output only count+1 bytes */
      for (i = 4; i >= 4-numBytes; i--) {
         outValue = value / power85[i];
         the85[outPosn]= (unsigned char)outValue + '!';
         outPosn++;
         value -= outValue * power85[i];
      }
      /* terminate with the EOD marker for the base85 encoding */
      the85[outPosn] = '~';
         outPosn++;
      the85[outPosn] = '>';
         outPosn++;      
  }

return strlen((const char *)the85);
} 


//	get_stream_type()
//	accomplish the job of stream identification.  A B_TRANSLATOR_BITMAP is
//	indicated by the first byte, which must equal the "magic" value of
//	'bits'. 
//	Otherwise return zero, to indicate unknown type.
uint32 get_stream_type(BPositionIO *stream)
{
	status_t err;
	char buffer[16];
	uint32 bitsType = B_TRANSLATOR_BITMAP;
	
	err = stream->Read(buffer,sizeof(buffer));
	if (err <= 0)
		return 0;
	stream->Seek(-err,SEEK_CUR);
	if (!memcmp(buffer,&bitsType,sizeof(bitsType)))
		return B_TRANSLATOR_BITMAP;
	else
		return 0;
}

