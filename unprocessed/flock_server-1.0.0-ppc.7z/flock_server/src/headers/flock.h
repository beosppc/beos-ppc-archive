// flock.h

#ifndef FLOCK_H
#define FLOCK_H

#include <sys/stat.h>

#include <BeBuild.h>
#include <SupportDefs.h>

#ifdef _BUILDING_LIBFLOCK
#	define _IMPEXP_LIBFLOCK	_EXPORT
#else
#	define _IMPEXP_LIBFLOCK	_IMPORT
#endif
 
#ifdef __cplusplus
extern "C" {
#endif

// flock() operation flags
#define LOCK_SH	(0x00)	// shared lock
#define LOCK_EX	(0x01)	// exclusive lock
#define LOCK_UN	(0x02)	// unlock
#define LOCK_NB	(0x04)	// non-blocking

/*!	\brief Acquires or releases a file lock.

	This implementation is NOT compliant with the BSD flock() specification.
	The major difference is that with this implementation a lock is bound
	to the file descriptor and the team for which the lock was acquired. This
	means in particular that dup() and dup2() will not clone/copy or otherwise
	transfer the lock status from the source FD to the target FD, i.e.
	a lock on the source FD cannot be released using the target FD.
	The same holds true when fork()ing. The child process will not benefit from
	a file lock the parent process had acquired, and cannot release it.

	The main reason for this non-compliance is, that it would be a significantly
	greater overhead to track file table entries, which, I don't think is
	worth it, since most applications don't rely on more than the basic
	behavior provided by this function (i.e. lock a file, read/modify it,
	unlock it).

	\param fd The file descriptor for the file in question.
	\param operation One of \c LOCK_SH, \c LOCK_EX, \c LOCK_UN, optionally
		   bit-wise ORed with \c LOCK_NB.
	\return \c 0 on success, \c -1 on error. In the latter case \c errno is
			set accordingly.
*/
extern int flock(int fd, int operation);


/* flock_xyz() functions that should be used instead of the original xyz()
 * functions, since they potentially close file descriptors for which a
 * lock may exist. When the latter ones are used, the flock server cannot
 * realize that and will not free the lock for the file (at least not until
 * the application is terminated).
 *
 * Using these functions can be done explicitely or e.g. by adding
 * `-Dclose=flock_close -Ddup2=flock_dup2' to the compiler flags. The latter
 * method is a bit ugly but often the more comfortable way when porting
 * applications.
 *
 * Note, that there might be other functions closing FDs that are missing
 * here. It is possible to invoke \code flock(fd, LOCK_UN) \endcode on an
 * already closed file descriptor.
 */

extern int flock_close(int fd);
extern int flock_dup2(int fd1, int fd2);

#ifdef __cplusplus
}	// extern "C"
#endif

#endif	// FLOCK_H
