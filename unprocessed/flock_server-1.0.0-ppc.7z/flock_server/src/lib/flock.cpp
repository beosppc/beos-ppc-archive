// flock.cpp

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#include <new>

#include <Autolock.h>
#include <Locker.h>
#include <OS.h>

#include "flock.h"
#include "flock_server.h"
#include "SLList.h"

// We cache in a table, for what FDs we have locks. This allows us to unlock
// without contacting the server at all.

struct FlockTableEntry : SLListLinkImpl<FlockTableEntry> {
	sem_id	semaphore;
	bool	shared;
	bool	locked;
	bool	busy;
};

static const int kFlockTableSizeIncrement = 256;
static FlockTableEntry *sFlockTable = NULL;
static int sFlockTableSize = 0;
static BLocker sFlockTableLock;

// init_at_fork
static
void
init_at_fork()
{
	// reinit the flock table lock
	new (&sFlockTableLock) BLocker;

	// set all flock table entries to unlocked
	BAutolock _(sFlockTableLock);
	for (int i = 0; i < sFlockTableSize; i++)
		sFlockTable[i].locked = false;
}

// FlockServerInit
static struct FlockServerInit {
	FlockServerInit()
	{
		atfork(init_at_fork);
	}
} sFlockServerInit;

// ensure_flock_table_size
static
status_t
ensure_flock_table_size(int fd)
{
	if (fd < 0)
		return B_BAD_VALUE;

	BAutolock _(sFlockTableLock);

	if (fd < sFlockTableSize)
		return B_OK;

	// resize the table
	int newTableSize = (fd + kFlockTableSizeIncrement - 1)
		/ kFlockTableSizeIncrement * kFlockTableSizeIncrement;
	FlockTableEntry *newTable = (FlockTableEntry*)realloc(sFlockTable,
		newTableSize * sizeof(FlockTableEntry));
	if (!newTable)
		return B_NO_MEMORY;

	// clear the new entries
	for (int i = sFlockTableSize; i < newTableSize; i++) {
		newTable[i].locked = false;
		newTable[i].busy = false;
	}

	sFlockTable = newTable;
	sFlockTableSize = newTableSize;

	return B_OK;
}

// flock_internal
static
status_t
flock_internal(int fd, int operation) {
	static bool serverPortInitialized = false;
	static port_id serverPort = -1;

	if (fd < 0)
		return B_BAD_VALUE;

	bool blocking = !(operation & LOCK_NB);
	operation &= LOCK_SH | LOCK_EX | LOCK_UN;

	// ensure the table is big enough
	status_t error = ensure_flock_table_size(fd);
	if (error != B_OK)
		return error;

	sFlockTableLock.Lock();

	// Deal with unlocks immediately. Since we always unlock -- even if we
	// just want to up- or downgrade the lock -- we can safely bail out here,
	// if the entry is busy, since it won't be locked then.
	if (operation == LOCK_UN) {
		if (!sFlockTable[fd].busy && sFlockTable[fd].locked) {
			delete_sem(sFlockTable[fd].semaphore);
			sFlockTable[fd].locked = false;
		}
		sFlockTableLock.Unlock();
		return B_OK;
	}

	// we want to lock: wait for the entry to become unbusy
	while (sFlockTable[fd].busy) {
		sFlockTableLock.Unlock();
		if (!blocking)
			return B_WOULD_BLOCK;
		snooze(3000);
		sFlockTableLock.Lock();
	}

	// unlock, if locked, and mark the entry busy
	if (sFlockTable[fd].locked) {
		delete_sem(sFlockTable[fd].semaphore);
		sFlockTable[fd].locked = false;
	}
	sFlockTable[fd].busy = true;
	sFlockTableLock.Unlock();

	// if not yet initialized, get the server port
	if (!serverPortInitialized) {
		serverPort = find_port(FLOCK_SERVER_PORT_NAME);
		// If the port wasn't present at this point, we could start
		// the server. In fact, I tried this and in works, but unfortunately
		// it also seems to confuse our pipes (with both load_image() and
		// system()). So, we can't help it, the server has to be started
		// manually before using the function.
		serverPortInitialized = true;
	}
	if (serverPort < 0)
		return B_ERROR;

	// stat() the file to get the node_ref
	struct stat st;
	if (fstat(fd, &st) < 0)
		return errno;

	// create a reply port
	port_id replyPort = create_port(1, "flock reply port");
	if (replyPort < 0)
		return replyPort;

	// create a semaphore others will wait on while we own the lock
	sem_id lockSem = -1;
	if (operation != LOCK_UN) {
		char semName[64];
		sprintf(semName, "flock %ld:%lld\n", st.st_dev, st.st_ino);
		lockSem = create_sem(0, semName);
		if (lockSem < 0) {
			delete_port(replyPort);
			return lockSem;
		}
	}

	// prepare the request
	flock_server_request request;
	request.replyPort = replyPort;
	request.lockSem = lockSem;
	request.device = st.st_dev;
	request.node = st.st_ino;
	request.fd = fd;
	request.operation = operation;
	request.blocking = blocking;

	// We ask the server to get us the requested lock for the file.
	// The server returns semaphores for all existing locks (or will exist
	// before it's our turn) that prevent us from getting the lock just now.
	// We block on them one after the other and after that officially own the
	// lock. If we told the server that we don't want to block, it will send
	// an error code, if that is not possible.

	// send the request
	error = write_port(serverPort, 0, &request, sizeof(request));

	flock_server_reply *reply = NULL;
	if (error == B_OK) {
		// get the reply size
		int replySize = port_buffer_size(replyPort);
		if (replySize < 0)
			error = replySize;

		// allocate reply buffer
		if (error == B_OK) {
			reply = (flock_server_reply*)malloc(replySize);
			if (!reply)
				error = B_NO_MEMORY;
		}

		// read the reply
		if (error == B_OK) {
			int32 code;
			ssize_t bytesRead = read_port(replyPort, &code, reply, replySize);
			if (bytesRead < 0) {
				error = bytesRead;
			} else if (bytesRead != replySize) {
				error = B_ERROR;
			}
		}
	}

	// get the error returned by the server
	if (error == B_OK)
		error = reply->error;

	// wait for all lockers before us
	if (error == B_OK) {
		int i;
		for (i = 0; i < reply->semaphoreCount; i++)
			while (acquire_sem(reply->semaphores[i]) == B_INTERRUPTED);
	}

	// free the reply buffer
	free(reply);

	// delete the reply port
	delete_port(replyPort);

	// on failure delete the semaphore
	if (error != B_OK)
		delete_sem(lockSem);

	// update the flock table entry
	{
		BAutolock _(sFlockTableLock);
		if (error == B_OK) {
			sFlockTable[fd].semaphore = lockSem;
			sFlockTable[fd].locked = true;
			sFlockTable[fd].shared = (operation == LOCK_SH);
		}
		sFlockTable[fd].busy = false;
	}

	return error;
}

// flock
int
flock(int fd, int operation) {
	status_t error = flock_internal(fd, operation);
	return (error == B_OK ? 0 : (errno = error, -1));
}

// flock_close
int
flock_close(int fd) {
	flock_internal(fd, LOCK_UN);

	return close(fd);
}

// flock_dup2
int
flock_dup2(int fd1, int fd2)
{
	int result = dup2(fd1, fd2);

	// if successful, we need to unlock the old second FD
	if (result >= 0)
		flock_internal(fd2, LOCK_UN);

	return result;
}

