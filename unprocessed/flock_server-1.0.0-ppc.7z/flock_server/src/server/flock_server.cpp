// flock_server.cpp

#include <stdio.h>
#include <string.h>
#include <unistd.h>

#ifdef __MWERKS__
#	include <hashmap.h>
#else
#	include <hash_map>
#endif
#include <functional>

#include <Application.h>
#include <Node.h>

#include "flock.h"
#include "flock_server.h"

// debugging...
//#define PRINT(x) { printf x; }
#define PRINT(x) ;

// our team -- set in main()
static team_id sTeam = -1;

// The maximal number of threads allowed to wait for a file lock, and the
// resulting maximal reply size.
enum {
	MAX_WAITERS = 1024,
	MAX_REPLY_SIZE = sizeof(flock_server_reply) + MAX_WAITERS * sizeof(sem_id)
};

// A node_ref extension with a nicer constructor.
struct NodeRef : node_ref {
	NodeRef(dev_t device, ino_t node)
	{
		this->device = device;
		this->node = node;
	}
};

// Class representing a (potential) lock.
struct FlockEntry {

	FlockEntry(team_id team, sem_id lockSem, int fd, bool shared)
		: team(team),
		  lockSem(lockSem),
		  fd(fd),
		  shared(shared),
		  next(NULL)
	{
		PRINT(("FlockEntry::FlockEntry(team: %ld, sem: %ld, fd: %d, "
			"shared: %d)\n", team, lockSem, fd, shared));
	}

	~FlockEntry()
	{
		PRINT(("FlockEntry::~FlockEntry(team: %ld, sem: %ld, fd: %d, "
			"shared: %d)\n", team, lockSem, fd, shared));
		if (lockSem >= 0) {
			set_sem_owner(lockSem, sTeam);
			delete_sem(lockSem);
		}
	}

	team_id team;
	sem_id lockSem;
	int fd;
	bool shared;

	FlockEntry *next;	// next in the list
};

// hash function class for NodeRef (for hash_map)
struct NodeRefHash
{
	size_t operator()(const NodeRef &nodeRef) const
	{
		uint32 hash = nodeRef.device;
		hash = hash * 17 + (uint32)nodeRef.node;
		hash = hash * 17 + (uint32)(nodeRef.node >> 32);
		return hash;
	}
};

// maps NodeRefs to FlockEntries (a list of them)
typedef hash_map<NodeRef, FlockEntry*, NodeRefHash, equal_to<NodeRef> >
	FlockEntryMap;
static FlockEntryMap sFlockEntries;

// put_flock_entry
//
// put a FlockEntry for a NodeRef
static
void
put_flock_entry(const NodeRef &nodeRef, FlockEntry *entry)
{
	sFlockEntries[nodeRef] = entry;
}

// remove_flock_entry
//
// remove the FlockEntries for a NodeRef key
static
void
remove_flock_entry(const NodeRef &nodeRef)
{
	sFlockEntries.erase(nodeRef);
}

// get_flock_entry
//
// returns the FlockEntry for a given NodeRef key
static
FlockEntry *
get_flock_entry(const NodeRef &nodeRef)
{
	FlockEntryMap::iterator it = sFlockEntries.find(nodeRef);
	if (it == sFlockEntries.end())
		return NULL;
	FlockEntry *entry = it->second;

	// remove all entries that are obsolete
	FlockEntry *firstEntry = entry;
	FlockEntry *previousEntry = NULL;
	sem_info semInfo;
	while (entry) {
		if (get_sem_info(entry->lockSem, &semInfo) != B_OK) {
			FlockEntry *oldEntry = entry;
			entry = entry->next;
			if (previousEntry)
				previousEntry->next = oldEntry->next;
			else
				firstEntry = entry;
			delete oldEntry;
		} else {
			previousEntry = entry;
			entry = entry->next;
		}
	}
	if (firstEntry)
		put_flock_entry(nodeRef, firstEntry);
	else
		remove_flock_entry(nodeRef);

	return firstEntry;
}

// find_flock_entry
//
// Finds a FlockEntry with the given FD and team.
static
FlockEntry *
find_flock_entry(FlockEntry *entry, team_id team, int fd,
	FlockEntry **_previousEntry = NULL)
{
	FlockEntry *previousEntry = NULL;
	while (entry) {
		if (entry->team == team && entry->fd == fd) {
			// found it
			if (_previousEntry)
				*_previousEntry = previousEntry;
			return entry;
		}

		previousEntry = entry;
		entry = entry->next;
	}
	return entry;
}

// remove_lock
//
// Processes a given unlock request.
static
status_t
remove_lock(team_id team, flock_server_request &request)
{
	// get the flock entry list
	NodeRef nodeRef(request.device, request.node);

	PRINT(("remove_lock(): file: (%ld, %lld), team: %ld, fd: %d\n",
		request.device, request.node, team, request.fd));

	// find the entry to be removed
	FlockEntry *previousEntry = NULL;
	FlockEntry *entry = find_flock_entry(get_flock_entry(nodeRef), team,
		request.fd, &previousEntry);
	
	if (!entry)
		return B_BAD_VALUE;

	// remove the entry
	if (previousEntry) {
		previousEntry->next = entry->next;
	} else {
		if (entry->next) {
			put_flock_entry(nodeRef, entry->next);
		} else {
			remove_flock_entry(nodeRef);
		}
	}
	delete entry;
	return B_OK;

}

// add_lock
//
// Processes a given lock request.
static
status_t
add_lock(team_id team, flock_server_request &request,
	flock_server_reply &reply)
{
	bool shared = (request.operation == LOCK_SH);

	PRINT(("add_lock(): shared: %d, blocking: %d, file: (%ld, %lld), "
		"team: %ld, fd: %d\n", shared, request.blocking, request.device,
		request.node, team, request.fd));

	// get the flock entry list
	NodeRef nodeRef(request.device, request.node);

	FlockEntry *entry = get_flock_entry(nodeRef);

	reply.semaphoreCount = 0;

	// special case: the caller already has the lock
	if (entry && entry->team == team && entry->fd == request.fd) {
		if (shared == entry->shared)
			return B_OK;

		FlockEntry *nextEntry = entry->next;
		if (!nextEntry) {
			// noone is waiting: just relabel the entry
			entry->shared = shared;
			delete_sem(request.lockSem); // re-use the old semaphore
			return B_OK;
		} else if (shared) {
			// downgrade to shared lock: this is simple, if only share or
			// exclusive lockers were waiting, but in mixed case we can
			// neither just replace the semaphore nor just relabel the entry,
			// but if mixed we have to surrender the exclusive lock and apply
			// for a new one

			// check, if there are only exclusive lockers waiting
			FlockEntry *waiting = nextEntry;
			bool onlyExclusiveWaiters = true;
			while (waiting && onlyExclusiveWaiters) {
				onlyExclusiveWaiters &= !waiting->shared;
				waiting = waiting->next;
			}

			if (onlyExclusiveWaiters) {
				// just relabel the entry
				entry->shared = shared;
				delete_sem(request.lockSem); // re-use the old semaphore
				return B_OK;
			}

			// check, if there are only shared lockers waiting
			waiting = nextEntry;
			bool onlySharedWaiters = true;
			while (waiting && onlySharedWaiters) {
				onlySharedWaiters &= waiting->shared;
				waiting = waiting->next;
			}

			if (onlySharedWaiters) {
				// replace the semaphore
				delete_sem(entry->lockSem);
				entry->lockSem = request.lockSem;
				entry->shared = shared;
				return B_OK;
			}

			// mixed waiters: fall through...
		} else {
			// upgrade to exclusive lock: fall through...
		}

		// surrender the lock and re-lock
		if (!request.blocking)
			return B_WOULD_BLOCK;
		remove_lock(team, request);
		entry = nextEntry;

		// fall through...
	}

	// add the semaphores of the preceding exclusive locks to the reply
	FlockEntry* lastEntry = entry;
	while (entry) {
		if (!shared || !entry->shared) {
			if (!request.blocking)
				return B_WOULD_BLOCK;

			reply.semaphores[reply.semaphoreCount++] = entry->lockSem;
		}

		lastEntry = entry;
		entry = entry->next;
	}

	// create a flock entry and add it
	FlockEntry *newEntry = new FlockEntry(team, request.lockSem, request.fd,
		shared);
	if (lastEntry)
		lastEntry->next = newEntry;
	else
		put_flock_entry(nodeRef, newEntry);
		
	return B_OK;
}

// request_loop
static
int32
request_loop(void *data)
{
	port_id requestPort = *(port_id*)data;

	while (true) {
		// read the request
		flock_server_request request;
		int32 code;
		ssize_t bytesRead = read_port(requestPort, &code, &request,
			sizeof(request));
		if (bytesRead == B_BAD_PORT_ID)
			return 0;
		if (bytesRead != (int32)sizeof(request))
			continue;

		// get the team
		port_info portInfo;
		if (get_port_info(request.replyPort, &portInfo) != B_OK)
			continue;
		team_id team = portInfo.team;

		char replyBuffer[MAX_REPLY_SIZE];
		flock_server_reply &reply = *(flock_server_reply*)replyBuffer;

		// handle the request
		status_t error = B_ERROR;
		switch (request.operation) {
			case LOCK_SH:
			case LOCK_EX:
				error = add_lock(team, request, reply);
				break;
			case LOCK_UN:
				error = remove_lock(team, request);
				break;
		}

		if (error == B_OK) {
			PRINT(("  -> successful\n"));
		} else {
			PRINT(("  -> failed: %s\n", strerror(error)));
		}

		// prepare the reply
		reply.error = error;
		int32 replySize = sizeof(flock_server_reply);
		if (error == B_OK)
			replySize += reply.semaphoreCount * sizeof(sem_id) ;

		// send the reply
		write_port(request.replyPort, 0, &reply, replySize);
	}
}

// main
int
main()
{
	// get independent of our creator
	setpgid(0, 0);

	// get team
	thread_info threadInfo;
	status_t error = get_thread_info(find_thread(NULL), &threadInfo);
	if (error != B_OK) {
		fprintf(stderr, "Failed to get info for the current thread: %s\n",
			strerror(error));
		exit(1);
	}
	sTeam = threadInfo.team;

	// create the request port
	port_id requestPort = create_port(10, FLOCK_SERVER_PORT_NAME);
	if (requestPort < 0) {
		fprintf(stderr, "Failed to create request port: %s\n",
			strerror(requestPort));
		exit(1);
	}

	// spawn the request handling loop
	thread_id requestThread = spawn_thread(request_loop, "request loop",
		B_NORMAL_PRIORITY, &requestPort);
	if (requestThread < 0) {
		fprintf(stderr, "Failed to spawn request thread: %s\n",
			strerror(requestThread));
		exit(1);
	}
	resume_thread(requestThread);

	BApplication app("application/x-vnd.yellowbites.flock-server");
	app.Run();

	// terminate the request thread
	delete_port(requestPort);
	status_t result;
	wait_for_thread(requestThread, &result);

	return 0;
}
