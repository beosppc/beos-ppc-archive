// flock_server.h

#ifndef FLOCK_SERVER_H
#define FLOCK_SERVER_H

#include <OS.h>

#define FLOCK_SERVER_PORT_NAME "perl flock server"

// client request
typedef struct flock_server_request {
    port_id	replyPort;
    sem_id	lockSem;
    dev_t	device;
    ino_t	node;
    int 	fd;
    int		operation;
    bool	blocking;
} flock_server_request;

// server reply
typedef struct flock_server_reply {
    status_t	error;
    int			semaphoreCount;
    sem_id		semaphores[1];
} flock_server_reply;

#endif	// FLOCK_SERVER_H
