#!/bin/sh
cp Mark\ As\ Read ~/config/add-ons/Tracker/