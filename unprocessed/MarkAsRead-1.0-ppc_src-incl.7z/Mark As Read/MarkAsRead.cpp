#pragma export on
void process_refs(entry_ref dir_ref, BMessage* msg, void*);
#pragma export reset

void process_refs(entry_ref dir_ref, BMessage* msg, void*)
{
	BAlert* alert;
	ulong type;
	entry_ref ref;
	int32 result;
	int i=0;
	long num;
	msg->GetInfo("refs", &type, &num);

	if (num == 0) {
		alert = new BAlert("", "You must select a mail message for this to work.", "Cancel");
		alert->Go();
		return;
	}
	
	while (msg->FindRef("refs", i, &ref) == B_NO_ERROR) {
		attr_info info;
		BNode	*emailNode=new BNode(&ref);
		emailNode->GetAttrInfo("MAIL:status",&info);
		emailNode->WriteAttr("MAIL:status",B_STRING_TYPE,0,"Read",5);
		i++;
	}			
}
